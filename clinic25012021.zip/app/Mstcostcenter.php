<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstcostcenter extends Model
{
    protected $table = 'MEDSYS_MSTCOSTCENTERS';


    public $timestamps = false;
}
