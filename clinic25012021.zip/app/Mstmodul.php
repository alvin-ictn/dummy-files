<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstmodul extends Model
{
    protected $table = 'MEDSYS_MSTMODULES';


    public $timestamps = false;
}
