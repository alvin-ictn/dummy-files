<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pwdhists extends Model
{
    //
    protected $table = 'MEDSYS_PWDHISTS';
    
    protected $guarded = [];
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'VUSRID', 'VUSRPASS', 'VMODI'
    ];
	
    public $timestamps = false;
}
