<?php

function getURl(){

    return "w2016a:8089";
    
}