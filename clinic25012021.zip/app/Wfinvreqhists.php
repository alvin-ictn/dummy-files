<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wfinvreqhists extends Model
{
	protected $table = 'MEDSYS_WFINVREQHISTS';
	
	public $timestamps = false;
}
