<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstdrugslogs extends Model
{
    protected $table = 'MEDSYS_MSTDRUGLOGS';


    public $timestamps = false;
}
