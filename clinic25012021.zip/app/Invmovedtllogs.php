<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invmovedtllogs extends Model
{
	protected $table = 'MEDSYS_INVMOVEDTLLOGS';
	
	public $timestamps = false;
}
