<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IcdModel extends Model
{
    protected $table = 'MEDSYS_ICDDIAGNOSIS';
    
	protected $primaryKey = 'IID';

    protected $fillable = ['VDXCODE','VDXNAME','VREMARKS','VCREA','VMODI'];
    public $timestamps = false;
}
