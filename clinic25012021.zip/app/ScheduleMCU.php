<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ScheduleMCU extends Model
{
    //
    protected $table = 'MEDSYS_SCHDMCU';

    protected $primaryKey = 'TSESSIONTIME';

    protected $fillable = [
        'TSESSIONTIME', 'IDAYQUOTA', 'ISATURDAYQUOTA', 'BACTIVE','VCREA','DCREA','VMODI','DMODI'
    ];
    public $timestamps = false;
}
