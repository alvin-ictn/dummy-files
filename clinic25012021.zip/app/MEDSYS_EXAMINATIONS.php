<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MEDSYS_EXAMINATIONS extends Model
{
    //
    protected $table = 'MEDSYS_EXAMINATIONS';

	protected $primaryKey = 'VBOOKINGNO';


    public $timestamps = false;
}
