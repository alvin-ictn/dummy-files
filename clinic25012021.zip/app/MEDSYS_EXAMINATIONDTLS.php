<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MEDSYS_EXAMINATIONDTLS extends Model
{
    //
    protected $table = 'MEDSYS_EXAMINATIONDTLS';


    public $timestamps = false;
}
