<?php

namespace App\Imports;

use App\IcdModel;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\Importable;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Carbon\Carbon;
use Session;

class ICDImport implements ToModel,WithValidation, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    use Importable;
    
    public function model(array $row)
    {
        return new IcdModel([

                'VDXCODE' => $row['vdxcode'],
                'VDXNAME' => $row['vdxname'], 
                'VREMARKS' => $row['vremarks'], 
                'VCREA' => Session::get('id'),
                'DCREA' => Carbon::now(),
                'VMODI' => '',
                'DMODI' => '',


        ]);
    }
    public function rules(): array
    {
        return [
             
             // Can also use callback validation rules
             '*.vdxcode' => function($attribute, $value, $onFailure) {
                 $first = IcdModel::where('VDXCODE',$value)->select('VDXCODE')->first()->VDXCODE ?? 'NULL';
                //  dd($first);
                  if ($value === $first) {
                    // var_dump($value);
                       $onFailure('Data with current inputted VDXCODE = '.$value.' is already exists!');
                  }
              }
        ];
    }
   
   
}
