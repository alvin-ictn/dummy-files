<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use app\Mstdistrict;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use App\Exports\DistrictExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use DB;

class DistrictController extends Controller
{
    public function getajaxdistrictcode($id){

        $i = base64_decode($id);
         $select = DB::select("SELECT COUNT(*) AS hitung FROM vw_mstdistrict WHERE DISTRICTCODE = '".$i."' ")[0];
         if($select->hitung <= 0){
            $null['data'] = "";
         }else{
            $null['data'] = "already";
         }
         return response()->json($null, 200);
    }

    public function ajax(Request $request){

        $dist = \App\Mstdistrict::all();
        $view = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY MONTH(MODIFY_DATE) DESC,YEAR(MODIFY_DATE) DESC,MODIFY_DATE ASC) AS No, DISTRICTCODE, DISTRICTNAME, PROV_NAME, STATUS, MODIFY_DATE, MODIFY_NAME FROM vw_mstdistrict");

        return Datatables::of($view)
        ->addIndexColumn()

        ->filter(function ($instance) use ($request) {

            if (!empty($request->get('date'))) {
            
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
                    return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                
                });
            
            }
            if (!empty($request->get('search'))) {
                // search entire table
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                   $tmp_search = $request->get('search');  // inputed string in Search field
                   $column_names = ['No', 'DISTRICTCODE', 'DISTRICTNAME', 'PROV_NAME', 'STATUS', 'MODIFY_NAME', 'MODIFY_DATE'];
                   for($i = 0; $i < count($column_names); $i++)
                   {
                      // Check if cell of $column_names[$i] contains $tmp_search
                      if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                   }
                   return false;
                });
            }
        })
        
        ->addColumn('no', function($row){
            return $row->No;
        })
        ->addColumn('action', function($row){
            if(RoleAccessController::FunctionAccessCheck('U', 'F11')) return $row->DISTRICTCODE;
            else return null;
        })
        ->addColumn('modify_date', function($row){
            return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
        })
        
        ->rawColumns(['action','no'])
        ->make(true);
    }

    public function insert(){
        $prop = \App\Mstprov::where('BACTIVE','=','1')->get();
        return view('home/district/add')->with('prop',$prop);
    }

    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'kodedist' => 'required|max:5',
            'namedist' =>'required|max:50',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        $select = DB::select("SELECT COUNT(*) AS hitung FROM vw_mstdistrict WHERE DISTRICTCODE = '".$request->kodedist."'")[0];
        if($select->hitung <= 0){
            $data =  new \App\Mstdistrict();
            $data->VDISTRICTCODE = $request->kodedist;
            $data->VDISTRICTNAME = $request->namedist;
            $data->VPROVCODE = $request->kodeprov;
            $data->BACTIVE = '1';
            $data->DMODI = Carbon::now();
            $data->VCREA =  Session::get('id');
            $data->VMODI =  Session::get('id');
            $data->save();
            return response()-> json(['succsess'], 200);
        
        }else{
            
            return response()->json(['success'], 400);
        }
    }
    
    public function update(Request $request)
    {
        $districtsel = \App\Mstdistrict::where('VDISTRICTCODE','=',$request->distcode);
        
        $validator = Validator::make($request->all(), [
            'distname' => 'required|max:50',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        $districtsel->update([
            'VDISTRICTNAME' => $request->distname,
            'BACTIVE'  => $request->BACTIVEs,
            'DMODI'  => carbon::now(),
            'VCREA'  => Session::get('id'),
            'VMODI'  => Session::get('id'),
            
        ]);
        return response()->json(['succsess'], 200);
    }
    public function getdistrict($id){

        $districtsel = \App\Mstdistrict::where('VPROVCODE','=',$id)->get();
            $district ="";
            $district .="----";
            foreach($districtsel as $a){

                $district .="<option value=".$a->VDISTRICTCODE.">".$a->VDISTRICTNAME."</option>";
            }
        return response()->json($district, 200);
    }
    public function edit($id){

        $ids = base64_decode($id);
        $district = \App\Mstdistrict::where('VDISTRICTCODE',$ids)->first();
        $prov =  DB::table('MEDSYS_MSTPROVS')->where('VPROVCODE', $district->VPROVCODE)->first();
        return view('home/district/update',compact('district'))->with('prov',$prov);
    }
    
	public function export_excel(Request $request)
	{
        if(!$request){

            $id ="";
            return Excel::download(new DistrictExport($id),'District.xls');


        }else{
            $no = $request->no;
            $code = $request->code;
            $name = $request->name;
            $provname = $request->provname;
            if(!$request->lastmo){
                $lastmo = '';
            }else{
                
                $lastmo = Carbon::parse($request->lastmo)->format('d-M-Y');

            }
            $status = $request->status;
            $modifiedn = $request->modifiedn;
            $search = $request->search;

            return Excel::download(new DistrictExport($no,$code,$name,$provname,$lastmo,$status,$modifiedn,$search),'District.xls');

        }
    }
}
