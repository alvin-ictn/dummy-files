<?php

namespace App\Http\Controllers;

use App\Candidates;
use DateTime;
use App\Exports\McuExport;
use App\Mstcostcenter;
use App\Mstemployees;
use App\Mstpersonelareas;
use App\Mstsettings;
use App\Mstusers;
use App\Registmcudtls;
use App\Registmcus;
use App\Registmcushists;
use App\ScheduleMCU;
use Carbon\Carbon;
use DataTables;
use PDF;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use App\Exports\ScheduleMcuExport;
use Maatwebsite\Excel\Facades\Excel;
use Session;

class McuController extends Controller
{
    public function index()
    {
		return view('home/mcu/list/index', ['dates' => $this->getdatelookup()->getData()->data]);
    }
	public function ajaxmcuschedule(Request $request){

		// $insertins = \App\Mstmedical::all();
        $view = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY MONTH(A.DMODI) DESC,YEAR(A.DMODI) DESC,A.DMODI ASC) AS No,A.TSESSIONTIME,A.IDAYQUOTA,A.ISATURDAYQUOTA, A.BACTIVE, A.VMODI, A.DMODI,(SELECT B.VNAME FROM MEDSYS_MSTEMPLOYEES B WHERE B.VUSRID=A.VMODI
        UNION
        SELECT B.VNAME FROM MEDSYS_MSTCLINICSTAFFS B
        WHERE B.VUSRID=A.VMODI) AS MODIFY_NAMES FROM MEDSYS_SCHDMCU A");

        return Datatables::of($view)
            ->addIndexColumn()

            // ->filter(function ($instance) use ($request) {
            //     if (!empty($request->get('date'))) {
                
            //         $instance->collection = $instance->collection->filter(function ($row) use ($request) {
            //             $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
            //             return Str::contains($row['DMODI'], $dot) ? true : false;
                    
            //         });
                
            //     }
            //     if (!empty($request->get('search'))) {
            //         // search entire table
            //         $instance->collection = $instance->collection->filter(function ($row) use ($request) {
            //             $tmp_search = $request->get('search');  // inputed string in Search field
            //             $column_names = ['No', 'TSESSIONTIME', 'IDAYQUOTA', 'ISATURDAYQUOTA', 'BACTIVE', 'VMODI', 'DMODI'];
            //             // for($i = 0; $i < count($column_names); $i++)
            //             // {
            //             //     // Check if cell of $column_names[$i] contains $tmp_search
            //             //     if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
            //             // }
            //             return false;
            //         });
            //     }
			// })
			->addColumn('TSESSIONTIME', function($row){
				$html ='<a href="/account/mcu/schedule/form/'.base64_encode(date('h:i', strtotime($row->TSESSIONTIME))).'">'.date('h:i', strtotime($row->TSESSIONTIME)).'</a>';
                return  $html;
            })
            ->addColumn('no', function($row){
                return $row->No;
			})
			->addColumn('BACTIVE', function($row){
                if($row->BACTIVE === '1'){

					$return = 'Active';
				}else{

					$return = 'InActive';
				}
				return $return;

			})
			->addColumn('modif_date', function($row){
				return Carbon::parse($row->DMODI)->format('d-M-Y H:i:s A');
			})
            ->addColumn('modify_date', function($row){
                return Carbon::parse($row->DMODI)->format('YmdHis');
            })
            ->rawColumns(['TSESSIONTIME','no'])
            ->make(true);
	}
	public function scheduleForm($id = NULL){
		if($id != NULL){
			$base64 = base64_decode($id);
			$str = date('h:i:s', strtotime($base64));
			$find = ScheduleMCU::find($str);

			//$format = Carbon::parse($find->DMODI)->format('YmdHis');
			return view('home/schmcu/form',['find'=>$find,'str'=>$str]);

		}else{
			
			// $find = '';
			$find = ScheduleMCU::find('');

			return view('home/schmcu/form',['find'=>$find ?? NULL,'str'=>$str ?? NULL]);
		}

	}
	public function schedulemcuPost(Request $request){

		$str = date('h:i:s', strtotime($request->TSCHSTART));
		$old = date('h:i:s', strtotime($request->old_data));

		$find = ScheduleMCU::find($str);
		if($find != NULL){
			$schedule = $find;
			$schedule->VMODI = Session::get('id'); 
			$schedule->DMODI = carbon::now();
		}else{
			$schedule = new ScheduleMCU();
			$schedule->VCREA = Session::get('id'); 
			$schedule->DCREA = carbon::now();
			$schedule->VMODI = Session::get('id'); 
			$schedule->DMODI = carbon::now();
		}
			$schedule->TSESSIONTIME = $str; 
			$schedule->IDAYQUOTA = $request->code; 
			$schedule->ISATURDAYQUOTA = $request->saturday; 
			$schedule->BACTIVE = $request->BACTIVEs; 
			$schedule->save();

			return response()->json(['success'], 200);

	}
	public function ajax(Request $request)
	{
		$SDATE = $request->get('DFROM');
		$EDATE = $request->get('DTO');
		if (parent::check_role("HRADM") || parent::check_role("ADM"))
		{
			$VIDNO = 'ALL';
			$VCREA = 'ALL';
		}
		else if (RoleAccessController::FunctionAccessCheck('C', 'F33'))
		{
			$VIDNO = 'ALL';
			$VCREA = Session::get('id');
		}
		else
		{
			$VIDNO = Mstemployees::where('VUSRID', Session::get('id'))->first()->VEMPSAPID;
			$VCREA = 'ALL';
		}
		$mcusel = DB::select("EXEC sp_RegisterMCU ?, ?, ?, ?", [$VIDNO, $VCREA, $SDATE, $EDATE]);
		return DataTables::of($mcusel)
                ->addIndexColumn()
				->filter(function ($instance) use ($request) {
					if (!empty($request->get('reserved_date')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							$dot = Carbon::parse($request->get('reserved_date'))->format('d-M-Y');
							return Str::contains($row['DRESERVED'], $dot) ? true : false;
						});
					}
					if (!empty($request->get('verified_date')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							$dot = Carbon::parse($request->get('verified_date'))->format('d-M-Y');
							return Str::contains($row['DVERIFIED'], $dot) ? true : false;
						});
					}
					if (!empty($request->get('completed_date')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							$dot = Carbon::parse($request->get('completed_date'))->format('d-M-Y');
							return Str::contains($row['DCOMPLETED'], $dot) ? true : false;
						});
					}
					if (!empty($request->get('created_date')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							$dot = Carbon::parse($request->get('created_date'))->format('d-M-Y');
							return Str::contains($row['DCREA'], $dot) ? true : false;
						});
					}
					if (!empty($request->get('modified_date')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							$dot = Carbon::parse($request->get('modified_date'))->format('d-M-Y');
							return Str::contains($row['DMODI'], $dot) ? true : false;
						});
					}
					if (!empty($request->get('search')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							if (Str::contains(Str::lower($row['VREGNO']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VIDNO']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['EMPNAME']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['PERSONALAREA']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['SUBPERSONALAREA']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['COSTCENTER']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['PACKAGE']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['GENDER']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DRESERVED']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['TSESSIONTIME']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VDOCSTATUS']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DVERIFIED']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DCOMPLETED']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VCREA']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DCREA']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VMODI']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DMODI']), Str::lower($request->get('search'))))
							{
								return true;
							}
							return false;
						});
					}
				})
				->addColumn('action', function($row){ return $row->VREGNO; })
                ->rawColumns(['action'])
                ->make(true);
    }
	
	public function form($mcu = NULL, $page = NULL)
	{
		if ($mcu != NULL)
		{
			if ($page == 'first')
			{
				$mcu = Registmcus::where('VREGNO', base64_decode($mcu))->leftjoin('MEDSYS_CANDIDATES', 'MEDSYS_REGISTMCUS.VIDNO', '=', 'MEDSYS_CANDIDATES.VCANDIDATENO')->select('MEDSYS_REGISTMCUS.*','MEDSYS_CANDIDATES.VNAME', DB::raw("SUBSTRING(CONVERT(VARCHAR, TSESSIONTIME), 1, 5) TSESSIONTIME"))->first();
				$histories = Registmcushists::where('VREGNO', $mcu->VREGNO)->select('MEDSYS_REGISTMCUSHISTS.*', DB::raw("SUBSTRING(CONVERT(VARCHAR, TSESSIONTIME), 1, 5) TSESSIONTIME"))->get();
				return view('home/mcu/list/form', ['mcu' => $mcu, 'histories' => $histories]);
			}
			if ($page == 'second')
			{
				$type = Registmcus::find(base64_decode($mcu))->VIDTYPE;
				if ($type != 3)
				{
					$mcu = Registmcus::where('VREGNO', base64_decode($mcu))
							->leftjoin('MEDSYS_MSTEMPLOYEES', function ($join) { $join->on('MEDSYS_REGISTMCUS.VIDNO', '=', 'MEDSYS_MSTEMPLOYEES.VEMPSAPID')->where('MEDSYS_MSTEMPLOYEES.BACTIVE', '1'); })
							->leftjoin('MEDSYS_MSTSETTINGS', function ($join)
								{
									$join->on('MEDSYS_MSTEMPLOYEES.VGNDRCODE', '=', 'MEDSYS_MSTSETTINGS.VSETCODE')->where('MEDSYS_MSTSETTINGS.VSETID', 'GENDER')->where('MEDSYS_MSTSETTINGS.BACTIVE', '1');
								})
							->leftjoin('MEDSYS_MSTSUBPERSONELAREAS', function ($join)
								{
									$join->on('MEDSYS_MSTEMPLOYEES.VSUBPRSNLAREACODE', '=', 'MEDSYS_MSTSUBPERSONELAREAS.VSUBPRSNLAREACODE')
									->whereColumn('MEDSYS_MSTEMPLOYEES.VPRSNLAREACODE', 'MEDSYS_MSTSUBPERSONELAREAS.VPRSNLAREACODE')->where('MEDSYS_MSTSUBPERSONELAREAS.BACTIVE', '1');
								})
							->leftjoin('MEDSYS_MSTPERSONELAREAS', 'MEDSYS_MSTEMPLOYEES.VPRSNLAREACODE', '=', 'MEDSYS_MSTPERSONELAREAS.VPRSNLAREACODE')
							->leftjoin('MEDSYS_MSTCOSTCENTERS', 'MEDSYS_MSTEMPLOYEES.VCOSTCNTRCODE', '=', 'MEDSYS_MSTCOSTCENTERS.VCOSTCNTRCODE')
							->select('MEDSYS_REGISTMCUS.*', 'MEDSYS_MSTSETTINGS.VSETDESC', 'MEDSYS_MSTEMPLOYEES.VNAME', 'MEDSYS_MSTEMPLOYEES.VADDRESS',
								DB::raw("CONCAT(MEDSYS_MSTSUBPERSONELAREAS.VSUBPRSNLAREACODE, ' - ', VSUBPRSNLNAME) AS VSUBPRSNL"),
								DB::raw("CONCAT(MEDSYS_MSTPERSONELAREAS.VPRSNLAREACODE, ' - ', VPRSNLNAME) AS VPRSNL"), 'MEDSYS_MSTEMPLOYEES.VPHONENO',
								DB::raw("CONCAT(MEDSYS_MSTCOSTCENTERS.VCOSTCNTRCODE, ' - ', VCOSTCNTRNAME) AS VCOSTCNTR"))->first();
					\App::setLocale($mcu->BBAHASA == '1' ? 'id' : 'en');
				}
				else
				{
					$mcu = Registmcus::where('VREGNO', base64_decode($mcu))
							->leftjoin('MEDSYS_CANDIDATES', 'MEDSYS_REGISTMCUS.VIDNO', '=', 'MEDSYS_CANDIDATES.VCANDIDATENO')
							->leftjoin('MEDSYS_MSTSETTINGS', function ($join)
								{
									$join->on('MEDSYS_CANDIDATES.VGNDRCODE', '=', 'MEDSYS_MSTSETTINGS.VSETCODE')->where('MEDSYS_MSTSETTINGS.VSETID', 'GENDER')->where('MEDSYS_MSTSETTINGS.BACTIVE', '1');
								})
							->leftjoin('MEDSYS_MSTPERSONELAREAS', 'MEDSYS_CANDIDATES.VPRSNLAREACODE', '=', 'MEDSYS_MSTPERSONELAREAS.VPRSNLAREACODE')
							->leftjoin('MEDSYS_MSTCOSTCENTERS', 'MEDSYS_CANDIDATES.VCOSTCNTRCODE', '=', 'MEDSYS_MSTCOSTCENTERS.VCOSTCNTRCODE')
							->select('MEDSYS_REGISTMCUS.*', 'MEDSYS_MSTSETTINGS.VSETDESC', 'MEDSYS_CANDIDATES.VNAME',
								DB::raw("' - ' AS VSUBPRSNL"),
								DB::raw("CONCAT(MEDSYS_MSTPERSONELAREAS.VPRSNLAREACODE, ' - ', VPRSNLNAME) AS VPRSNL"), DB::raw("'' AS VPHONENO"),
								DB::raw("CONCAT(MEDSYS_MSTCOSTCENTERS.VCOSTCNTRCODE, ' - ', VCOSTCNTRNAME) AS VCOSTCNTR"))->first();
					\App::setLocale($mcu->BBAHASA == '1' ? 'id' : 'en');
				}
				$dtls = Registmcudtls::where('VREGNO', $mcu->VREGNO)->get();
				return view('home/mcu/list/form', ['mcu' => $mcu, 'dtls' => $dtls]);
			}
		}
		else
		{
			$user = Mstusers::find(Session::get('id'));
			return view('home/mcu/list/form', ['user' => $user, 'histories' => []]);
		}
    }

    public function getdepartmentlookup()
	{
		return response()->json(['data' => Mstcostcenter::where('BACTIVE', '1')->select('VCOSTCNTRCODE', 'VCOSTCNTRNAME')->get()]);
    }

    public function getbusinessunitlookup()
	{
		return response()->json(['data' => Mstpersonelareas::where('BACTIVE', '1')->select('VPRSNLAREACODE', 'VPRSNLNAME')->get()]);
    }

    public function getemployeelookup()
	{
		return response()->json(['data' => Mstemployees::where('BACTIVE', '1')
														->where('VUSRID', '<>', Session::get('id'))
														->where('VCOSTCNTRCODE', Mstemployees::where('VUSRID', Session::get('id'))->where('BACTIVE', '1')->first()->VCOSTCNTRCODE)
														->get()]);
    }

    public function getdatelookup()
	{
		return response()->json(['data' => DB::select("SELECT FORMAT(DATEADD(DAY, number + 1, GETDATE()), 'MM/dd/yyyy') DATES, FORMAT(DATEADD(DAY, number + 1, GETDATE()), 'dddd') DAYS,
														CASE WHEN
															DATEPART(DW, DATEADD(DAY, number + 1, GETDATE())) = 1 THEN '0'
															ELSE CASE WHEN
																DATEPART(DW, DATEADD(DAY, number + 1, GETDATE())) = 7 THEN (SELECT SUM(ISATURDAYQUOTA) FROM MEDSYS_SCHDMCU)
																ELSE (SELECT SUM(IDAYQUOTA) FROM MEDSYS_SCHDMCU)
															END
														END QUOTA,
														(SELECT COUNT(1) FROM MEDSYS_REGISTMCUS WHERE DRESERVED = FORMAT(DATEADD(DAY, number + 1, GETDATE()), 'MM/dd/yyyy') AND BDEDUCTQUOTA = 1) RESERVED,
														CASE WHEN
															DATEPART(DW, DATEADD(DAY, number + 1, GETDATE())) = 1 THEN '0'
															ELSE CASE WHEN
																DATEPART(DW, DATEADD(DAY, number + 1, GETDATE())) = 7 THEN
																(
																	(SELECT SUM(ISATURDAYQUOTA) FROM MEDSYS_SCHDMCU)
																	-
																	(SELECT COUNT(1) FROM MEDSYS_REGISTMCUS WHERE DRESERVED = FORMAT(DATEADD(DAY, number + 1, GETDATE()), 'MM/dd/yyyy') AND BDEDUCTQUOTA = 1)
																)
																ELSE
																(
																	(SELECT SUM(IDAYQUOTA) FROM MEDSYS_SCHDMCU)
																	-
																	(SELECT COUNT(1) FROM MEDSYS_REGISTMCUS WHERE DRESERVED = FORMAT(DATEADD(DAY, number + 1, GETDATE()), 'MM/dd/yyyy') AND BDEDUCTQUOTA = 1)
																)
															END
														END REMAINING
														FROM master..spt_values
														WHERE type = 'P'
														AND DATEADD(DAY, number + 1, GETDATE()) <= GETDATE() + 12")]);
    }

    public function getschdlist($date, $day)
	{
		if ($day == 'Saturday')
		{
			return DB::select("SELECT SUBSTRING(CONVERT(VARCHAR, TSESSIONTIME), 1, 5) AS TSESSIONTIME
								FROM MEDSYS_SCHDMCU
								WHERE ISATURDAYQUOTA > (SELECT COUNT(1) FROM MEDSYS_REGISTMCUS WHERE DRESERVED = '" . $date . "' AND BDEDUCTQUOTA = 1) AND BACTIVE = 1");
		}
		else
		{
			return DB::select("SELECT SUBSTRING(CONVERT(VARCHAR, TSESSIONTIME), 1, 5) AS TSESSIONTIME
								FROM MEDSYS_SCHDMCU
								WHERE IDAYQUOTA > (SELECT COUNT(1) FROM MEDSYS_REGISTMCUS WHERE DRESERVED = '" . $date . "' AND BDEDUCTQUOTA = 1) AND BACTIVE = 1");
		}
	}
	
	public function save(Request $request)
    {
		$now = carbon::now();
		if ($request->VREGNO != NULL)
		{
			$mcu = Registmcus::find($request->VREGNO);
			$mcu->VDOCSTATUS = 'O';
			$mcu->VMODI = Session::get('id');
			$mcu->DMODI = $now;
			foreach ($request->all() as $key => $value)
			{
				if (is_array($value))
				{
					continue;
				}
				$mcu->$key = $value;
			}
		}
		else
		{
			if ($now >= new DateTime(Mstsettings::where('VSETID', 'PRMMCU')->where('BACTIVE', '1')->first()->VSETDESC))
			{
				return response()->json(['error' => 'ga bisa mcu'], 500);
			}
			$mcu = new Registmcus();
			$yy = substr($now->format('Y'), 2, 2);
			$mcu->VIDTYPE = $request->VIDTYPE;
			if ($mcu->VIDTYPE == '1')
			{
				$mcu->VIDNO = Mstemployees::where('BACTIVE', '1')->where('VUSRID', Session::get('id'))->first()->VEMPSAPID;
			}
			elseif ($mcu->VIDTYPE == '2')
			{
				$mcu->VIDNO = $request->VIDNOA;
			}
			else
			{
				if (Registmcus::where('VIDTYPE', '3')->where('DCREA', $now->toDateString())->count() >= Mstsettings::where('VSETID', 'CANDIDATEMCU')->where('BACTIVE', '1')->first()->VSETDESC)
				{
					return response()->json(['error' => 'Register Candidate has reached the limit per day'], 500);
				}
				$candidate = new Candidates();
				$candidate->VNAME = $request->VNAME;
				$candidate->VCITYBIRTH = $request->VCITYBIRTH;
				$candidate->DBIRTH = $request->DBIRTH;
				$candidate->VIDTYPE = $request->VIDTYPEC;
				$candidate->VIDCARDNO = $request->VIDCARDNO;
				$candidate->VGNDRCODE = $request->VGNDRCODE;
				$candidate->VAPPLPOS = $request->VAPPLPOS;
				$candidate->VUSRID = $request->VUSRID;
				$candidate->VCOSTCNTRCODE = $request->VCOSTCNTRCODE;
				$candidate->VPRSNLAREACODE = $request->VPRSNLAREACODE;
				$candidate->VCREA = Session::get('id');
				$candidate->DCREA = $now;
				$candidate->VMODI = Session::get('id');
				$candidate->DMODI = $now;
			}
			if ($mcu->VIDNO != NULL)
			{
				if (Registmcus::where('VIDNO', $mcu->VIDNO)->whereYear('DCREA', $now->format('Y'))->exists())
				{
					return response()->json(['error' => 'Booking can only 1 time in a year for each person'], 500);
				}
				$d1 = new DateTime(Mstemployees::where('VEMPSAPID', $mcu->VIDNO)->first()->DHIRE);
				$d2 = new DateTime(Mstsettings::where('VSETID', 'PRMMCU')->where('BACTIVE', '1')->first()->VSETCODE);
				$diff = $d2->diff($d1);
				if ($d1 >= $d2 || $diff->y < 1)
				{
					return response()->json(['error' => 'blom setahun'], 500);
				}
			}
			if ($mcu->VIDTYPE != '3')
			{
				$package = Mstemployees::where('VEMPSAPID', $mcu->VIDNO)->join('MEDSYS_MSTPACKAGES', 'MEDSYS_MSTEMPLOYEES.VPACKAGECODE', '=', 'MEDSYS_MSTPACKAGES.VPCKGCODE')->first();
				if ($package == NULL)
				{
					$package =	Mstemployees::where('VEMPSAPID', $mcu->VIDNO)
								->leftjoin('MEDSYS_MSTCOSTCENTERPACKAGES', 'MEDSYS_MSTEMPLOYEES.VCOSTCNTRCODE', '=', 'MEDSYS_MSTCOSTCENTERPACKAGES.VCOSTCNTRCODE')
								->leftjoin('MEDSYS_MSTPACKAGES', 'MEDSYS_MSTCOSTCENTERPACKAGES.VPACKAGECODE', '=', 'MEDSYS_MSTPACKAGES.VPCKGCODE')
								->first();
				}
				$dateOfBirth = Mstemployees::where('VEMPSAPID', $mcu->VIDNO)->first()->DBIRTH;
			}
			else
			{
				$package =	Mstcostcenter::where('MEDSYS_MSTCOSTCENTERS.VCOSTCNTRCODE', $candidate->VCOSTCNTRCODE)
							->leftjoin('MEDSYS_MSTCOSTCENTERPACKAGES', 'MEDSYS_MSTCOSTCENTERS.VCOSTCNTRCODE', '=', 'MEDSYS_MSTCOSTCENTERPACKAGES.VCOSTCNTRCODE')
							->leftjoin('MEDSYS_MSTPACKAGES', 'MEDSYS_MSTCOSTCENTERPACKAGES.VPACKAGECODE', '=', 'MEDSYS_MSTPACKAGES.VPCKGCODE')
							->first();
				$dateOfBirth = $candidate->DBIRTH;
			}
			$mcu->BBAHASA = $request->BBAHASA;
			$mcu->DRESERVED = $request->DRESERVED;
			$mcu->TSESSIONTIME = $request->TSESSIONTIME;
			$mcu->BDEDUCTQUOTA = $request->BDEDUCTQUOTA ?? 0;
			$mcu->VPACKAGECODE = $package->VPCKGCODE;
			$mcu->BVITALSIGN = $package->BVITALSIGN;
			$mcu->BURINE = $package->BURINE;
			$mcu->BRONTGEN = $package->BRONTGEN;
			$mcu->BDARAHNONCHOL = $package->BDARAHNONCHOL;
			$mcu->BFISIK = $package->BFISIK;
			$mcu->BSPIRO = $package->BSPIRO;
			$mcu->BAUDIO = $package->BAUDIO;
			if (Carbon::parse($dateOfBirth)->age < 30)
			{
				$mcu->BDARAHCHOL = 0;
				$mcu->BEKG = 0;
			}
			else
			{
				$mcu->BDARAHCHOL = $package->BDARAHCHOL;
				$mcu->BEKG = $package->BEKG;
			}
			$mcu->VDOCSTATUS = 'V';
			$mcu->DSUBMIT = $now;
			$mcu->VCREA = Session::get('id');
			$mcu->DCREA = $now;
			$mcu->VMODI = Session::get('id');
			$mcu->DMODI = $now;
			$hist = new Registmcushists();
			$hist->ILINENO = 1;
			$hist->DRESERVED = $mcu->DRESERVED;
			$hist->TSESSIONTIME = $mcu->TSESSIONTIME;
			$hist->BDEDUCTQUOTA = $mcu->BDEDUCTQUOTA;
			$hist->VUSER = $mcu->VCREA;
			$hist->DDATE = $mcu->DCREA;
		}
		DB::beginTransaction();
		try
		{
			if ($mcu->VREGNO == NULL)
			{
				$rgno = DB::select("SELECT SUM(NLASTNO) NLASTNO FROM MEDSYS_MSTNOS WHERE VTRXCODE = 'MC' AND NYEAR = '" . $yy . "'")[0]->NLASTNO;
				$mcu->VREGNO = 'MC' . $yy . str_pad($rgno + 1, 6, '0', STR_PAD_LEFT);
				if ($rgno == NULL)
				{
					DB::table('MEDSYS_MSTNOS')->insert([ 'NLASTNO' => '1', 'NYEAR' => $yy, 'NMONTH' => '0', 'NDATE' => '0', 'VTRXCODE' => 'MC', 'DCREA' => $now, 'VCREA' => Session::get('id') ]);
				}
				else
				{
					DB::table('MEDSYS_MSTNOS')->where('VTRXCODE', 'MC')->where('NYEAR', $yy)->update([ 'NLASTNO' => $rgno + 1, 'DMODI' => $now, 'VMODI' => Session::get('id') ]);
				}
				$hist->VREGNO = $mcu->VREGNO;
			}
			else
			{
				if (isset($request->ILINE))
				{
					for ($x = 0; $x < count($request->ILINE); $x++)
					{
						$line = new Registmcudtls();
						$line->VREGNO = $mcu->VREGNO;
						$line->ILINENO = $x + 1;
						$line->IRWP_FROM = $request->IRWP_FROM[$x];
						$line->IRWP_TO = $request->IRWP_TO[$x];
						$line->VRWP_CO = $request->VRWP_CO[$x];
						$line->VRWP_JOBTYPE = $request->VRWP_JOBTYPE[$x];
						$line->BRWP_DEBU = $request->BRWP_DEBU[$x];
						$line->BRWP_ASAP = $request->BRWP_ASAP[$x];
						$line->BRWP_GAS = $request->BRWP_GAS[$x];
						$line->BRWP_BISING = $request->BRWP_BISING[$x];
						$line->IRWP_TIME = $request->IRWP_TIME[$x];
						$line->VRWP_REMARK = $request->VRWP_REMARK[$x];
						$line->VCREA = Session::get('id');
						$line->DCREA = $now;
						$line->VMODI = Session::get('id');
						$line->DMODI = $now;
						$line->save();
					}
				}
			}
			if (isset($candidate))
			{
				$cano = DB::select("SELECT SUM(NLASTNO) NLASTNO FROM MEDSYS_MSTNOS WHERE VTRXCODE = 'CA' AND NYEAR = '" . $yy . "'")[0]->NLASTNO;
				$candidate->VCANDIDATENO = 'CA' . $yy . str_pad($cano + 1, 6, '0', STR_PAD_LEFT);
				if ($cano == NULL)
				{
					DB::table('MEDSYS_MSTNOS')->insert([ 'NLASTNO' => '1', 'NYEAR' => $yy, 'NMONTH' => '0', 'NDATE' => '0', 'VTRXCODE' => 'CA', 'DCREA' => $now, 'VCREA' => Session::get('id') ]);
				}
				else
				{
					DB::table('MEDSYS_MSTNOS')->where('VTRXCODE', 'CA')->where('NYEAR', $yy)->update([ 'NLASTNO' => $cano + 1, 'DMODI' => $now, 'VMODI' => Session::get('id') ]);
				}
				$mcu->VIDNO = $candidate->VCANDIDATENO;
				$candidate->save();
			}
			$mcu->save();
			if (isset($hist))
			{
				$hist->save();
			}
			DB::commit();
		}
		catch (\Exception $e)
		{
			DB::rollBack();
			if (!isset($e->errorInfo))
			{
				$response['error'] = $e;
				return response()->json($response, 500);
			}
			else
			{
				$response['error'] = $e->errorInfo[2];
				return response()->json($response, 500);
			}
		}
		if ($request->VREGNO != NULL)
		{
			return response()->json(['success'], 200);
		}
		else
		{
			return response()->json(['url' => base64_encode($mcu->VREGNO)], 200);
		}
    }

    public function proceed($id, $type)
	{
		$now = carbon::now();
		$mcu = Registmcus::find($id);
		$mcu->VDOCSTATUS = $type;
		if ($type == 'D')
		{
			$mcu->DCOMPLETED = $now;
		}
		if ($type == 'E')
		{
			$mcu->DVERIFIED = $now;
		}
		$mcu->VMODI = Session::get('id');
		$mcu->DMODI = $now;
		$hist = new Registmcushists();
		$hist->VREGNO = $mcu->VREGNO;
		$hist->ILINENO = DB::select("SELECT COUNT(ILINENO) ILINENO FROM MEDSYS_REGISTMCUSHISTS WHERE VREGNO = '" . $hist->VREGNO . "'")[0]->ILINENO + 1;
		$hist->DRESERVED = $mcu->DRESERVED;
		$hist->TSESSIONTIME = $mcu->TSESSIONTIME;
		$hist->BDEDUCTQUOTA = $mcu->BDEDUCTQUOTA;
		$hist->VUSER = $mcu->VMODI;
		$hist->DDATE = $mcu->DMODI;
		DB::beginTransaction();
		try
		{
			$mcu->save();
			$hist->save();
			DB::commit();
			if ($mcu->VDOCSTATUS == 'C' && $mcu->VIDTYPE != '3')
			{
				$emp = Mstemployees::where('VEMPSAPID', $mcu->VIDNO)->first();
				if ($emp->VDEPTHEADMAIL != NULL)
				{
					try
					{
						EmailController::CancelMCUSendEmail($emp, $mcu);
					}
					catch (\Exception $e)
					{
						
					}
				}
			}
		}
		catch (\Exception $e)
		{
			DB::rollBack();
			if (!isset($e->errorInfo))
			{
				$response['error'] = $e;
				return response()->json($response, 500);
			}
			else
			{
				$response['error'] = $e->errorInfo[2];
				return response()->json($response, 500);
			}
		}
		return response()->json(['success'], 200);
	}

    public function reschedule($id, $date, $time)
	{
		$mcu = Registmcus::find($id);
		$mcu->DRESERVED = $date;
		$mcu->TSESSIONTIME = $time;
		if ($mcu->VDOCSTATUS == 'C')
		{
			$mcu->VDOCSTATUS = 'V';
		}
		$mcu->VMODI = Session::get('id');
		$mcu->DMODI = carbon::now();
		$hist = new Registmcushists();
		$hist->VREGNO = $mcu->VREGNO;
		$hist->ILINENO = DB::select("SELECT COUNT(ILINENO) ILINENO FROM MEDSYS_REGISTMCUSHISTS WHERE VREGNO = '" . $hist->VREGNO . "'")[0]->ILINENO + 1;
		$hist->DRESERVED = $mcu->DRESERVED;
		$hist->TSESSIONTIME = $mcu->TSESSIONTIME;
		$hist->BDEDUCTQUOTA = $mcu->BDEDUCTQUOTA;
		$hist->VUSER = $mcu->VMODI;
		$hist->DDATE = $mcu->DMODI;
		DB::beginTransaction();
		try
		{
			$mcu->save();
			$hist->save();
			DB::commit();
		}
		catch (\Exception $e)
		{
			DB::rollBack();
			if (!isset($e->errorInfo))
			{
				$response['error'] = $e;
				return response()->json($response, 500);
			}
			else
			{
				$response['error'] = $e->errorInfo[2];
				return response()->json($response, 500);
			}
		}
		return response()->json(['success'], 200);
	}

    public function print($mcu)
	{
		$type = Registmcus::find(base64_decode($mcu))->VIDTYPE;
		if ($type != 3)
		{
			$mcu = Registmcus::where('VREGNO', base64_decode($mcu))
					->leftjoin('MEDSYS_MSTEMPLOYEES', function ($join) { $join->on('MEDSYS_REGISTMCUS.VIDNO', '=', 'MEDSYS_MSTEMPLOYEES.VEMPSAPID')->where('MEDSYS_MSTEMPLOYEES.BACTIVE', '1'); })
					->leftjoin('MEDSYS_MSTSETTINGS', function ($join)
						{
							$join->on('MEDSYS_MSTEMPLOYEES.VGNDRCODE', '=', 'MEDSYS_MSTSETTINGS.VSETCODE')->where('MEDSYS_MSTSETTINGS.VSETID', 'GENDER')->where('MEDSYS_MSTSETTINGS.BACTIVE', '1');
						})
					->leftjoin('MEDSYS_MSTSUBPERSONELAREAS', function ($join)
						{
							$join->on('MEDSYS_MSTEMPLOYEES.VSUBPRSNLAREACODE', '=', 'MEDSYS_MSTSUBPERSONELAREAS.VSUBPRSNLAREACODE')
							->where('MEDSYS_MSTEMPLOYEES.VPRSNLAREACODE', 'MEDSYS_MSTSUBPERSONELAREAS.VPRSNLAREACODE')->where('MEDSYS_MSTSUBPERSONELAREAS.BACTIVE', '1');
						})
					->leftjoin('MEDSYS_MSTPERSONELAREAS', 'MEDSYS_MSTEMPLOYEES.VPRSNLAREACODE', '=', 'MEDSYS_MSTPERSONELAREAS.VPRSNLAREACODE')
					->leftjoin('MEDSYS_MSTCOSTCENTERS', 'MEDSYS_MSTEMPLOYEES.VCOSTCNTRCODE', '=', 'MEDSYS_MSTCOSTCENTERS.VCOSTCNTRCODE')
					->leftjoin('MEDSYS_MSTPACKAGES', 'MEDSYS_REGISTMCUS.VPACKAGECODE', '=', 'MEDSYS_MSTPACKAGES.VPCKGCODE');
			$mcu =	$mcu->select('MEDSYS_REGISTMCUS.*', 'MEDSYS_MSTSETTINGS.VSETDESC', 'MEDSYS_MSTEMPLOYEES.VNAME', 'MEDSYS_MSTPACKAGES.VPCKGNAME',
						DB::raw("CONCAT(MEDSYS_MSTSUBPERSONELAREAS.VSUBPRSNLAREACODE, ' - ', VSUBPRSNLNAME) AS VSUBPRSNL"),
						DB::raw("CONCAT(MEDSYS_MSTPERSONELAREAS.VPRSNLAREACODE, ' - ', VPRSNLNAME) AS VPRSNL"), 'MEDSYS_MSTEMPLOYEES.VPHONENO',
						DB::raw("CONCAT(MEDSYS_MSTCOSTCENTERS.VCOSTCNTRCODE, ' - ', VCOSTCNTRNAME) AS VCOSTCNTR"),
						DB::raw("CASE WHEN VDOCSTATUS = 'V' THEN 'Confirm' WHEN VDOCSTATUS = 'O' THEN 'SUBMITTED' WHEN VDOCSTATUS = 'C' THEN 'Cancel' END AS VDOCSTATUS"),
						DB::raw("SUBSTRING(CONVERT(VARCHAR, TSESSIONTIME), 1, 5) AS TSESSIONTIME"),
						DB::raw("DATEDIFF(hour, DBIRTH, MEDSYS_REGISTMCUS.DCREA)/8766 AS AGE"))->first();
			\App::setLocale($mcu->BBAHASA == '1' ? 'id' : 'en');
		}
		else
		{
			$mcu = Registmcus::where('VREGNO', base64_decode($mcu))
					->leftjoin('MEDSYS_CANDIDATES', 'MEDSYS_REGISTMCUS.VIDNO', '=', 'MEDSYS_CANDIDATES.VCANDIDATENO')
					->leftjoin('MEDSYS_MSTSETTINGS', function ($join)
						{
							$join->on('MEDSYS_CANDIDATES.VGNDRCODE', '=', 'MEDSYS_MSTSETTINGS.VSETCODE')->where('MEDSYS_MSTSETTINGS.VSETID', 'GENDER')->where('MEDSYS_MSTSETTINGS.BACTIVE', '1');
						})
					->leftjoin('MEDSYS_MSTPERSONELAREAS', 'MEDSYS_CANDIDATES.VPRSNLAREACODE', '=', 'MEDSYS_MSTPERSONELAREAS.VPRSNLAREACODE')
					->leftjoin('MEDSYS_MSTCOSTCENTERS', 'MEDSYS_CANDIDATES.VCOSTCNTRCODE', '=', 'MEDSYS_MSTCOSTCENTERS.VCOSTCNTRCODE')
					->leftjoin('MEDSYS_MSTPACKAGES', 'MEDSYS_REGISTMCUS.VPACKAGECODE', '=', 'MEDSYS_MSTPACKAGES.VPCKGCODE')
					->select('MEDSYS_REGISTMCUS.*', 'MEDSYS_MSTSETTINGS.VSETDESC', 'MEDSYS_CANDIDATES.VNAME', 'MEDSYS_MSTPACKAGES.VPCKGNAME',
						DB::raw("' - ' AS VSUBPRSNL"),
						DB::raw("CONCAT(MEDSYS_MSTPERSONELAREAS.VPRSNLAREACODE, ' - ', VPRSNLNAME) AS VPRSNL"), DB::raw("'' AS VPHONENO"),
						DB::raw("CONCAT(MEDSYS_MSTCOSTCENTERS.VCOSTCNTRCODE, ' - ', VCOSTCNTRNAME) AS VCOSTCNTR"),
						DB::raw("CASE WHEN VDOCSTATUS = 'V' THEN 'Confirm' WHEN VDOCSTATUS = 'O' THEN 'SUBMITTED' WHEN VDOCSTATUS = 'C' THEN 'Cancel' END AS VDOCSTATUS"),
						DB::raw("SUBSTRING(CONVERT(VARCHAR, TSESSIONTIME), 1, 5) AS TSESSIONTIME"),
						DB::raw("DATEDIFF(hour, DBIRTH, MEDSYS_REGISTMCUS.DCREA)/8766 AS AGE"))->first();
			\App::setLocale($mcu->BBAHASA == '1' ? 'id' : 'en');
		}
		$dtls = Registmcudtls::where('VREGNO', $mcu->VREGNO)->get();
		$pdf = PDF::loadview('Pdf/mcu', ['mcu' => $mcu, 'dtls' => $dtls]);
    	return $pdf->stream('mcu_' . $mcu->VREGNO . '_'.carbon::parse(Carbon::now())->format('Y/m/d').'.pdf');
	}
	public function export_schedulemcu(Request $request){

		if(!$request){

            $id ="";
            return Excel::download(new ScheduleMcuExport($id),'MCU_schedule.xls');

        }else{
            $no = $request->no;
            $dayqouta = $request->dayqouta;
            $stqouta = $request->stqouta;
			$stime = $request->stime;
			$status = $request->status;

            // $addesc = $request->addesc;
            $lmname = $request->lmname;
            
            if (!$request->date) $date = '';
            else $date = Carbon::parse($request->date)->format('d-M-Y');
            
            $search = $request->search;

            return Excel::download(new ScheduleMcuExport($no,$dayqouta,$stqouta,$stime,$status,$lmname,$date,$search),'MCU_schedule.xls');

        }

	}
	
	public function export_excel(Request $request)
	{
        if (!$request)
		{
			return Excel::download(new McuExport(""), 'MCU.xls');
        }
		else
		{
            $from_date = $request->from_date;
            $to_date = $request->to_date;
            $registration_no = $request->registration_no;
            $sap_id = $request->sap_id;
            $employee_name = $request->employee_name;
			$personnel_area = $request->personnel_area;
            $sub_personnel_area = $request->sub_personnel_area;
            $cost_center = $request->cost_center;
            $package = $request->package;
            $gender = $request->gender;
            $reserved_date = $request->reserved_date;
            $time = $request->time;
            $document_status = $request->document_status;
            $verified_date = $request->verified_date;
            $completed_date = $request->completed_date;
            $created_name = $request->created_name;
            $created_date = $request->created_date;
            $last_modified_name = $request->last_modified_name;
            $modified_date = $request->modified_date;
            $search = $request->search;
			return Excel::download(new McuExport($from_date, $to_date, $registration_no, $sap_id, $employee_name, $personnel_area, $sub_personnel_area, $cost_center, $package, $gender, $reserved_date, $time, $document_status, $verified_date, $completed_date, $created_name, $created_date, $last_modified_name, $modified_date, $search), 'MCU.xls');
        }
	}
}
