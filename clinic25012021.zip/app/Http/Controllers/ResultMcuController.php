<?php

namespace App\Http\Controllers;

use App\Exports\McuResultExport;
use App\Mstclinicstaffs;
use App\Mstemployees;
use App\Mstgnrl;
use App\Mstsettings;
use App\Mstusers;
use App\Registmcus;
use App\Resultmcuanalysis;
use App\Resultmcuattch;
use App\Resultmcuaudios;
use App\Resultmcuchecks;
use App\Resultmcuphysics;
use App\Resultmcuspiros;
use Carbon\Carbon;
use DataTables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;
use Session;

class ResultMcuController extends Controller
{
    public function index()
    {
		return view('home/mcu/result/index');
    }
	
	public function ajax(Request $request)
	{
		if (parent::check_role("ADM") || parent::check_role("ANALYST") || parent::check_role("PRMDC") || parent::check_role("DCTR") || parent::check_role("HRADM"))
		{
			$resultmcusel = DB::select("EXEC sp_ResultMCU 'ALL', 'ALL', '2000-01-01', '2100-01-01'");
		}
		else if (parent::check_role("HRRCT"))
		{
			$resultmcusel = DB::select("EXEC sp_ResultMCU 'ALL', '" . Session::get('id') . "', '2000-01-01', '2100-01-01'");
		}
		else
		{
			$vidno = Mstusers::where('MEDSYS_MSTUSERS.VUSRID', Session::get('id'))
						->leftjoin('MEDSYS_MSTEMPLOYEES', function ($join) { $join->on('MEDSYS_MSTEMPLOYEES.VUSRID', '=', 'MEDSYS_MSTUSERS.VUSRID')->where('MEDSYS_MSTEMPLOYEES.BACTIVE', '1'); })
						->leftjoin('MEDSYS_MSTCLINICSTAFFS', 'MEDSYS_MSTCLINICSTAFFS.VUSRID', '=', 'MEDSYS_MSTUSERS.VUSRID')
						->select(DB::raw('COALESCE(MEDSYS_MSTEMPLOYEES.VEMPSAPID, MEDSYS_MSTCLINICSTAFFS.VUSRID) AS VIDNO'))
						->first()->VIDNO;
			$resultmcusel = DB::select("EXEC sp_ResultMCU '" . $vidno . "', 'ALL', '2000-01-01', '2100-01-01'");
		}
		return DataTables::of($resultmcusel)
                ->addIndexColumn()
				->filter(function ($instance) use ($request) {
					if (!empty($request->get('verifiedDate')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							$dot = Carbon::parse($request->get('verifiedDate'))->format('d-M-Y');
							return Str::contains($row['DVERIFIED'], $dot) ? true : false;
						});
					}
					if (!empty($request->get('completedDate')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							$dot = Carbon::parse($request->get('completedDate'))->format('d-M-Y');
							return Str::contains($row['DCOMPLETED'], $dot) ? true : false;
						});
					}
					if (!empty($request->get('resultDate')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							$dot = Carbon::parse($request->get('resultDate'))->format('d-M-Y');
							return Str::contains($row['DRESULT'], $dot) ? true : false;
						});
					}
					if (!empty($request->get('search')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							if (Str::contains(Str::lower($row['VREGNO']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VIDNO']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['EMPNAME']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DEPARTMENT']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DVERIFIED']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DCOMPLETED']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DRESULT']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['No']), Str::lower($request->get('search'))))
							{
								return true;
							}
							return false;
						});
					}
				})
				->addColumn('no', function($row){ return $row->No; })
                ->addColumn('action', function($row){ return $row->VREGNO; })
                ->rawColumns(['action','no'])
                ->make(true);
    }
	
	public function form($resultmcu)
	{
		$type = Registmcus::find(base64_decode($resultmcu))->VIDTYPE;
		if ($type != 3)
		{
			$resultmcu = Registmcus::where('VREGNO', base64_decode($resultmcu))
					->leftjoin('MEDSYS_MSTEMPLOYEES', function ($join) { $join->on('MEDSYS_REGISTMCUS.VIDNO', '=', 'MEDSYS_MSTEMPLOYEES.VEMPSAPID')->where('MEDSYS_MSTEMPLOYEES.BACTIVE', '1'); })
					->leftjoin('MEDSYS_MSTSETTINGS', function ($join)
						{
							$join->on('MEDSYS_MSTEMPLOYEES.VGNDRCODE', '=', 'MEDSYS_MSTSETTINGS.VSETCODE')->where('MEDSYS_MSTSETTINGS.VSETID', 'GENDER')->where('MEDSYS_MSTSETTINGS.BACTIVE', '1');
						})
					->select('MEDSYS_REGISTMCUS.*', 'MEDSYS_MSTEMPLOYEES.VNAME', 'MEDSYS_MSTSETTINGS.VSETDESC', 'MEDSYS_MSTEMPLOYEES.VGNDRCODE', DB::raw("format(MEDSYS_MSTEMPLOYEES.DBIRTH, 'dd MMMM yyyy') AS DBIRTH"), DB::raw("DATEDIFF(hour, MEDSYS_MSTEMPLOYEES.DBIRTH, GETDATE())/8766 AS AGE"))->first();
		}
		else
		{
			$resultmcu = Registmcus::where('VREGNO', base64_decode($resultmcu))
					->leftjoin('MEDSYS_CANDIDATES', 'MEDSYS_REGISTMCUS.VIDNO', '=', 'MEDSYS_CANDIDATES.VCANDIDATENO')
					->leftjoin('MEDSYS_MSTSETTINGS', function ($join)
						{
							$join->on('MEDSYS_CANDIDATES.VGNDRCODE', '=', 'MEDSYS_MSTSETTINGS.VSETCODE')->where('MEDSYS_MSTSETTINGS.VSETID', 'GENDER')->where('MEDSYS_MSTSETTINGS.BACTIVE', '1');
						})
					->leftjoin('MEDSYS_MSTCOSTCENTERS', 'MEDSYS_CANDIDATES.VCOSTCNTRCODE', '=', 'MEDSYS_MSTCOSTCENTERS.VCOSTCNTRCODE')
					->leftjoin('MEDSYS_MSTPERSONELAREAS', 'MEDSYS_CANDIDATES.VPRSNLAREACODE', '=', 'MEDSYS_MSTPERSONELAREAS.VPRSNLAREACODE')
					->select('MEDSYS_REGISTMCUS.*', 'MEDSYS_CANDIDATES.VNAME', 'MEDSYS_MSTSETTINGS.VSETDESC', 'MEDSYS_CANDIDATES.VGNDRCODE', DB::raw("format(MEDSYS_CANDIDATES.DBIRTH, 'dd MMMM yyyy') AS DBIRTH"), DB::raw("DATEDIFF(hour, MEDSYS_CANDIDATES.DBIRTH, GETDATE())/8766 AS AGE"), 'MEDSYS_CANDIDATES.VAPPLPOS', 'MEDSYS_MSTCOSTCENTERS.VCOSTCNTRNAME', 'MEDSYS_MSTPERSONELAREAS.VPRSNLNAME')->first();
		}
		$section = 5;
		if (Resultmcuphysics::where('VREGNO', $resultmcu->VREGNO)->doesntExist())
		{
			$section = 1;
			$VDOCTYPES = Mstgnrl::where('VGNRLTYPE', 'MCUDOCTYPE')->where('BACTIVE', '1')->get();
			$COLORVISIONS = Mstsettings::where('VSETID', 'COLORVISION')->where('BACTIVE', '1')->get();
		}
		else if (Resultmcuchecks::where('VREGNO', $resultmcu->VREGNO)->doesntExist())
		{
			$section = 2;
		}
		else if (Resultmcuspiros::where('VREGNO', $resultmcu->VREGNO)->doesntExist())
		{
			$section = 3;
		}
		else if (Resultmcuanalysis::where('VREGNO', $resultmcu->VREGNO)->doesntExist())
		{
			$section = 4;
			$COLORVISIONS = Mstsettings::where('VSETID', 'COLORVISION')->where('BACTIVE', '1')->get();
			$DOCTORS = Mstsettings::where('VSETID', 'MCUDCTR')->where('BACTIVE', '1')->orderBy('VSETCODE', 'asc')->get()->toArray();
			$ADVICES = Mstgnrl::where('VGNRLTYPE', 'MCUADVICE')->where('BACTIVE', '1')->get()->toArray();
		}
		\App::setLocale($resultmcu->BBAHASA == '1' ? 'id' : 'en');
		if ($section > 1)
		{
			$physics = Resultmcuphysics::find($resultmcu->VREGNO);
			$docs = Resultmcuattch::where('VREGNO', $resultmcu->VREGNO)->get();
		}
		if ($section > 2)
		{
			$checks = Resultmcuchecks::find($resultmcu->VREGNO);
		}
		if ($section > 3)
		{
			$spiros = Resultmcuspiros::find($resultmcu->VREGNO);
			$audios = Resultmcuaudios::find($resultmcu->VREGNO);
		}
		if ($section > 4)
		{
			$analysis = Resultmcuanalysis::find($resultmcu->VREGNO);
			$dr = Mstclinicstaffs::find($analysis->VCREA)->VNAME;
			$COLORVISIONS = Mstsettings::where('VSETID', 'COLORVISION')->where('BACTIVE', '1')->get();
			$DOCTORS = Mstsettings::where('VSETID', 'MCUDCTR')->where('BACTIVE', '1')->orderBy('VSETCODE', 'asc')->get()->toArray();
			$ADVICES = Mstgnrl::where('VGNRLTYPE', 'MCUADVICE')->where('BACTIVE', '1')->get()->toArray();
		}
		return view('home/mcu/result/form', ['resultmcu' => $resultmcu, 'section' => $section, 'VDOCTYPES' => $VDOCTYPES ?? null, 'COLORVISIONS' => $COLORVISIONS ?? null, 'DOCTORS' => $DOCTORS ?? null, 'ADVICES' => $ADVICES ?? null, 'physics' => $physics ?? null, 'checks' => $checks ?? null, 'spiros' => $spiros ?? null, 'audios' => $audios ?? null, 'analysis' => $analysis ?? null, 'dr' => $dr ?? null, 'docs' => $docs ?? null]);
    }
	
	public function save(Request $request)
    {
		$now = carbon::now();
		if ($request->section == 1)
		{
			$new = new Resultmcuphysics();
		}
		if ($request->section == 2)
		{
			$new = new Resultmcuchecks();
		}
		if ($request->section == 3)
		{
			$spiro = new Resultmcuspiros();
			$audio = new Resultmcuaudios();
			$spiro->VREGNO = $request->VREGNO;
			$audio->VREGNO = $request->VREGNO;
			foreach ($request->all() as $key => $value)
			{
				if (substr($key, 0, 1) == 'N')
				{
					$spiro->$key = $value;
				}
				elseif (substr($key, 0, 1) == 'I')
				{
					$audio->$key = $value;
				}
			}
			$spiro->VREMARKS = $request->S_VREMARKS;
			$spiro->VCREA = Session::get('id');
			$spiro->DCREA = $now;
			$spiro->VMODI = Session::get('id');
			$spiro->DMODI = $now;
			$audio->VREMARKS = $request->A_VREMARKS;
			$audio->VCREA = Session::get('id');
			$audio->DCREA = $now;
			$audio->VMODI = Session::get('id');
			$audio->DMODI = $now;
		}
		if ($request->section == 4 || $request->section == 5)
		{
			if ($request->section == 4)
			{
				$new = new Resultmcuanalysis();
				$new->VCREA = Session::get('id');
				$new->DCREA = $now;
			}
			else
			{
				$new = Resultmcuanalysis::find($request->VREGNO);
			}
			$new->VREGNO = $request->VREGNO;
			$new->VDRCOORD = $request->VDRCOORD;
			$new->VDRPATHOLOGY = $request->VDRPATHOLOGY;
			$new->VDRHEART = $request->VDRHEART;
			$new->VDRCHEST = $request->VDRCHEST;
			$new->VDRTHT = $request->VDRTHT;
			$new->VDRRADIOLOGY = $request->VDRRADIOLOGY;
			$new->VDECISIONNO = $request->VDECISIONNO;
			$new->VBLOODPRESSURE = $request->VBLOODPRESSURE;
			$new->VTOTCHOLESTEROL = $request->VTOTCHOLESTEROL;
			$new->VEKG = $request->VEKG;
			$new->VCHESTXRAY = $request->VCHESTXRAY;
			$new->VOTHERS = $request->VOTHERS;
			$new->VOKUPASI = $request->VOKUPASI;
			$new->VRISKS = $request->VRISKS;
			if (isset($request->VADVICE))
			{
				$new->VADVICE = implode("\n", $request->VADVICE);
			}
			$new->VMODI = Session::get('id');
			$new->DMODI = $now;
			$physic = Resultmcuphysics::find($request->VREGNO);
			foreach (Schema::getColumnListing('MEDSYS_RESULTMCUPHYSICS') as $key => $value)
			{
				if ($value == 'VCREA' || $value == 'DCREA')
				{
					continue;
				}
				$physic->$value = $request->$value;
			}
			$physic->VMODI = Session::get('id');
			$physic->DMODI = $now;
			$check = Resultmcuchecks::find($request->VREGNO);
			foreach (Schema::getColumnListing('MEDSYS_RESULTMCUCHECKS') as $key => $value)
			{
				if ($value == 'VCREA' || $value == 'DCREA')
				{
					continue;
				}
				$check->$value = $request->$value;
			}
			$check->VMODI = Session::get('id');
			$check->DMODI = $now;
			$spiro = Resultmcuspiros::find($request->VREGNO);
			foreach (Schema::getColumnListing('MEDSYS_RESULTMCUSPIROS') as $key => $value)
			{
				if ($value == 'VREMARKS' || $value == 'VCREA' || $value == 'DCREA')
				{
					continue;
				}
				$spiro->$value = $request->$value;
			}
			$spiro->VREMARKS = $request->S_VREMARKS;
			$spiro->VMODI = Session::get('id');
			$spiro->DMODI = $now;
			$audio = Resultmcuaudios::find($request->VREGNO);
			foreach (Schema::getColumnListing('MEDSYS_RESULTMCUAUDIOS') as $key => $value)
			{
				if ($value == 'VREMARKS' || $value == 'VCREA' || $value == 'DCREA')
				{
					continue;
				}
				$audio->$value = $request->$value;
			}
			$audio->VREMARKS = $request->A_VREMARKS;
			$audio->VMODI = Session::get('id');
			$audio->DMODI = $now;
			$mcu = Registmcus::find($request->VREGNO);
			$mcu->DRESULT = $now;
		}
		if ($request->section != 3 && $request->section != 4 && $request->section != 5)
		{
			foreach ($request->all() as $key => $value)
			{
				if (is_array($value))
				{
					continue;
				}
				$new->$key = $value;
			}
			unset($new->section);
			$new->VCREA = Session::get('id');
			$new->DCREA = $now;
			$new->VMODI = Session::get('id');
			$new->DMODI = $now;
		}
		DB::beginTransaction();
		try
		{
			if ($request->section != 3)
			{
				$new->save();
			}
			else
			{
				$spiro->save();
				$audio->save();
			}
			if ($request->section == 4 || $request->section == 5)
			{
				$physic->save();
				$check->save();
				$spiro->save();
				$audio->save();
				$mcu->save();
			}
			if ($request->section == 1)
			{
				if (isset($request->VDOCFILE))
				{
					for ($x = 0; $x < count($request->VDOCFILE); $x++)
					{
						$doc = new Resultmcuattch();
						$doc->VREGNO = $request->VREGNO;
						$doc->ILINENO = $request->ILINENO[$x];
						$doc->VDOCDESC = $request->VDOCTYPE[$x];
						if ($request->VDOCFILE[$x] != '')
						{
							$doc->VDOCFILE = $request->VDOCFILE[$x];
						}
						$doc->VREMARKS = $request->VREMARKS[$x];
						$doc->VCREA = Session::get('id');
						$doc->DCREA = $now;
						$doc->VMODI = Session::get('id');
						$doc->DMODI = $now;
						$doc->save();
						if ($request->VDOCFILE[$x] != '')
						{
							$request->file('files')[$x]->storeAs(Mstsettings::where('VSETID', 'MCUDOC')->where('VSETCODE', 'MCUDOC')->where('BACTIVE', '1')->first()->VSETDESC, $doc->VDOCFILE );
						}
					}
				}
			}
			DB::commit();
		}
		catch (\Exception $e)
		{
			DB::rollBack();
			if (!isset($e->errorInfo))
			{
				$response['error'] = $e;
				return response()->json($response, 500);
			}
			else
			{
				$response['error'] = $e->errorInfo[2];
				return response()->json($response, 500);
			}
		}
		return response()->json(['success'], 200);
    }
	
	public function download($id)
	{
		return response()->download(Storage::disk('c-drive')->path(Mstsettings::where('VSETID', 'MCUDOC')->where('VSETCODE', 'MCUDOC')->where('BACTIVE', '1')->first()->VSETDESC . '/' . $id), $id);
	}

	
	public function export_excel(Request $request)
	{
        if (!$request)
		{
			return Excel::download(new McuResultExport(""), 'MCU Result.xls');
        }
		else
		{
			$no = $request->no;
            $registration_no = $request->registration_no;
            $sap_id = $request->sap_id;
            $employee_name = $request->employee_name;
			$department = $request->department;
            $verified_date = $request->verified_date;
            $completed_date = $request->completed_date;
            $result_date = $request->result_date;
			$search = $request->search;
			
			return Excel::download(new McuResultExport($no, $registration_no, $sap_id, $employee_name, $department, $verified_date, $completed_date, $result_date, $search), 'MCU Result.xls');
        }
    }
}
