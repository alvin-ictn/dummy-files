<?php

namespace App\Http\Controllers;

use App\Exports\MovementInquiryExport;
use Illuminate\Http\Request;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use Illuminate\Support\Facades\Crypt;
use Maatwebsite\Excel\Facades\Excel;

class MovementInquiryController extends Controller
{
    //==== Ajax
    public function ajax(Request $request){
        $VCLINICCODE = $_GET['VCLINICCODE'];
        $VDRUGSCODE = $_GET['VITEMCODE'];
        $SDATE = Carbon::parse($_GET['DFROM'])->format('Y-m-d');
        $EDATE = Carbon::parse($_GET['DTO'])->format('Y-m-d');  
        // return response()->json([$VCLINICCODE, $VDRUGSCODE, $SDATE, $EDATE], 400);   // DEBUG
        $sp = \DB::select("EXEC sp_ItemMovementHistory ?,?,?,?", array($VCLINICCODE, $VDRUGSCODE, $SDATE, $EDATE));

        return Datatables::of($sp)
                ->addIndexColumn()

                ->filter(function ($instance) use ($request)
                {
                    if (!empty($request->get('date'))) {
                        // search Last Modified Date
                        $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                            $inputfield_date = Carbon::parse($request->get('date'))->format('d-M-Y');
                            $data_date = Carbon::parse($row['DCREA'])->format('d-M-Y');
                            return Str::contains($data_date, $inputfield_date) ? true : false;
                        });
                    }
                    if (!empty($request->get('search'))) {
                        // search entire table
                        $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                           $tmp_search = $request->get('search');  // inputed string in Search field
                           $column_names = ['No', 'DCREA', 'DEXPIRED', 'IQTY', 'VCLINICCODE', 'VTYPE', 'VTRXNO', 'VUOM'];
                           for($i = 0; $i < count($column_names); $i++)
                           {
                              // Check if cell of $column_names[$i] contains $tmp_search
                              if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                           }
                           return false;
                        });
                    }
                })

                ->addColumn('no', function($row){
                    return $row->No;
                })
                ->rawColumns(['no'])
                ->make(true);
    }

    //==== Get data for Item lookup table
    public function getitemlookup(){
        $views = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS No, DRUGS_CODE, DRUGS_CONTAIN, DRUGS_BRAND FROM vw_mstdrugs");

        return response()->json(['data' => $views]);
    }
    
    //==== Export
	public function export_excel(Request $request)
	{
        if (!$request)
		{
			return Excel::download(new MovementInquiryExport(""), 'Movement Inquiry.xls');
        }
		else
		{
            $clinic_code = $request->cliniccode;
            $drugs_code = $request->drugscode;
            $from_date = $request->from_date;
			$to_date = $request->to_date;
			$no = $request->no;
            $date = $request->date;
            $transno = $request->transno;
            $type = $request->type;
            $uom = $request->uom;
            $qty = $request->qty;
            $search = $request->search;
			// return response()->json([$clinic_code, $drugs_code, $from_date, $to_date, $no, $date, $transno, $type, $uom, $qty, $search], 400);
			return Excel::download(new MovementInquiryExport($clinic_code, $drugs_code, $from_date, $to_date, $no, $date, $transno, $type, $uom, $qty, $search), 'Movement Inquiry.xls');
        }
    }
}
