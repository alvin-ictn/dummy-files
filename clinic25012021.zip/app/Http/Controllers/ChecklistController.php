<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use app\Mstchecklist;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use Illuminate\Support\Facades\Crypt;
use DB;

class ChecklistController extends Controller
{
    public function ajax(Request $request)
    {
        $checklisits = \App\Mstchecklist::all();
        $checklist = \App\Mstchecklist::all()->first();

        return Datatables::of($checklisits)
                ->addIndexColumn()

                ->addColumn('no', function($row){
                    return '';
                })
                ->addColumn('action', function($row){

                    return '<a class="btn btn-link btn-sm" href="checklist/edit/'.Crypt::encryptString($row->VCHCKCODE).'">'.$row->VCHCKCODE.'</a>';

                })
                ->addColumn('BACTIVE', function($row){

                    if($row->BACTIVE === '1'){

                        $return = '<span class="badge badge-pill badge-success">Active</span>';
                    }else{

                        $return = '<span class="badge badge-pill badge-danger">Non active</span>';
                    }
                    return $return;

                })
                ->rawColumns(['action','BACTIVE','no'])
                ->make(true);
    }
    
    public function insert(){
        return view('home/checklist/add');
    }

    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'chckcode' => 'required|max:20',
            'chckname' =>'required|max:50',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        /// get dari Model  
        $data =  new \App\Mstchecklist();
        $data->VCHCKCODE = $request->chckcode;
        $data->VCHCKNAME = $request->chckname;
        $data->BACTIVE = $request->BACTIVEs;
        $data->VCREA =  Session::get('nameuser');
        $data->VMODI =  Session::get('nameuser');
        $data->save();
        return response()-> json(['succsess'], 200);
    }

    public function update(Request $request)
    {
        $checklistsel = \App\Mstchecklist::where('VCHCKCODE','=',$request->chckcode);
        
        $validator = Validator::make($request->all(), [
            'chckname' => 'required|max:50',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        $checklistsel->update([
            'VCHCKNAME' => $request->ccentername,
            'BACTIVE'  => $request->BACTIVEs,
            
        ]);
        return response()->json(['succsess'], 200);
    }
    
    public function edit($id){
        $ids = Crypt::decryptString($id);
        $checklisits = \App\Mstchecklist::where('VCHCKCODE',$ids)->first();

        return view('home/checklist/update',compact('checklisits'));
    }
}
