<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ICDModel;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use App\Exports\IcdExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use DB;
use App\Imports\ICDImport;


class IcdController extends Controller
{
    //
    public function index(){
        return view('home/icd/index');
    }
    public function ajax(Request $request){
        $views = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY  MONTH(DMODI) DESC,YEAR(DMODI) DESC,DMODI ASC) AS No,DMODI, VDXCODE, VDXNAME, VREMARKS,(SELECT B.VNAME FROM MEDSYS_MSTCLINICSTAFFS B WHERE B.VUSRID=A.VMODI
        UNION SELECT B.VNAME FROM MEDSYS_MSTEMPLOYEES B WHERE B.VUSRID=A.VMODI) AS MODIFY_NAME FROM  MEDSYS_ICDDIAGNOSIS A ");
        return Datatables::of($views)
        ->addIndexColumn()
        
        ->filter(function ($instance) use ($request) {
            if (!empty($request->get('search'))) {
                // search entire table
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                   $tmp_search = $request->get('search');  // inputed string in Search field
                   $column_names = ['No', 'VDXCODE', 'VDXNAME', 'VREMARKS'];
                   for($i = 0; $i < count($column_names); $i++)
                   {
                      // Check if cell of $column_names[$i] contains $tmp_search
                      if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                   }
                   return false;
                });
            }
        })

        ->addColumn('no', function($row){
            return $row->No;
        })
        ->addColumn('modify_date', function($row){
            return Carbon::parse($row->DMODI)->format('YmdHis');
            
        })
        ->addColumn('modif_date', function($row){
            return Carbon::parse($row->DMODI)->format('d-M-Y H:i:s A');
        })
        ->rawColumns(['action','no'])
        ->make(true);

    }
    public function import_excel(Request $request) 
	{
		// validasi
		$this->validate($request, [
			'file' => 'required|mimes:csv,xls,xlsx'
        ]);
        // $icd = ICDModel::all()->first();

 
		// menangkap file excel
        $file = $request->file('file');
        
		// membuat nama file unik
		$nama_file = rand().$file->getClientOriginalName();
 
		// upload ke folder file_diagnosis di dalam folder public
		$file->move('file_diagnosis',$nama_file);
 
        // import data
        
        // $import = Excel::import(new ICDImport, public_path('/file_diagnosis/'.$nama_file));
        

        try {
            Excel::import(new ICDImport, public_path('/file_diagnosis/'.$nama_file));

            return response()->json(200);

        } catch (\Maatwebsite\Excel\Validators\ValidationException $e) {
             $failures = $e->failures();
             foreach ($failures as $failure) {
                 $failure->row(); // row that went wrong
                 $failure->attribute(); // either heading key (if using heading row concern) or column index
                 $failure->errors(); // Actual error messages from Laravel validator
                 $failure->values(); // The values of the row that has failed.
             }
            //  $pesan["pesan"] = $failure->errors();
             return response()->json($pesan["pesan"]=$failure->errors(), 400);

        } 
    }
    
    public function export_excel(request $request){

        if (!$request){
            $id = "";
            return Excel::download(new IcdExport($id),'Icd.xls');


            
        }else{
            $no = $request->no;
            $diagcode = $request->diagcode;
            $diagname = $request->diagname;
            $remaks = $request->remaks;
            if(!$request->date){
                $lastmo = '';
            }else{
                
                $lastmo = Carbon::parse($request->date)->format('d-M-Y');

            }
            $search = $request->search;
            return Excel::download(new IcdExport($no,$diagcode,$diagname,$remaks,$lastmo,$search),'Icd.xls');

        }



    }
}
