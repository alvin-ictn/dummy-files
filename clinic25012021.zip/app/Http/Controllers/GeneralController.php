<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mstgnrl;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use App\Exports\GeneralExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use DB;

class GeneralController extends Controller
{
    public function  ajax(Request $request){

        $general = \App\Mstgnrl::all();
        $views = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY GNRLTYPE ASC, GNRLCODE ASC) AS No, GNRLTYPE, GNRLCODE, GNRLDESC, GNRLREMARKS, STATUS, MODIFY_DATE, MODIFY_NAME FROM vw_mstgeneral");
        return Datatables::of($views)
        ->addIndexColumn()
        
        ->filter(function ($instance) use ($request) {
        
            if (!empty($request->get('date'))) {
            
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
                    return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                
                });
            
            }
            if (!empty($request->get('search'))) {
                // search entire table
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $tmp_search = $request->get('search');  // inputed string in Search field
                    $column_names = ['No', 'GNRLTYPE', 'GNRLCODE', 'GNRLDESC', 'GNRLREMARKS', 'STATUS', 'MODIFY_NAME', 'MODIFY_DATE'];
                    for($i = 0; $i < count($column_names); $i++)
                    {
                        // Check if cell of $column_names[$i] contains $tmp_search
                        if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                    }
                    return false;
                });
            }
        })
        ->addColumn('no', function($row){
            return $row->No;
        })
        ->addColumn('action', function($row){
            if(RoleAccessController::FunctionAccessCheck('U', 'F14')) 
            {
                $null["link"] = base64_encode($row->GNRLTYPE.','.$row->GNRLCODE);
                $null["data"] = $row->GNRLTYPE;
                return $null;
            }
            else return null;
        })
        ->addColumn('modify_date', function($row){
            return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
        })
        ->rawColumns(['action','no'])
        ->make(true);

    }


    public function insert(){

        return view('home/general/add');
    }
    
    public function add(Request $request){
        $validatedData = Validator::make($request->all(), [
            'TYPE' => 'required',
            'code' => 'required|max:10',
            'desc' => 'required|max:50',
        ]);
        $error['eror'] = $validatedData->messages();
        if ($validatedData->fails()) {    
            return response()->json($error, 400);
        }
        $select = DB::select("SELECT COUNT(*) AS hitung FROM vw_mstgeneral WHERE GNRLTYPE = '".$request->TYPE."' AND GNRLCODE = '".$request->code."' ")[0];
        if($select->hitung <= 0){

            $data =  new \App\Mstgnrl();
            $data->VGNRLTYPE = $request->TYPE;
            $data->VGNRLCODE = $request->code;
            $data->VGNRLDESC = $request->desc;
            $data->VGNRLREMARKS = $request->rmrks;
            $data->BACTIVE = '1';
            $data->DMODI = Carbon::now();
            $data->VCREA = Session::get('id');
            $data->VMODI = Session::get('id');
            $data->save();
            return response()->json(['success'], 200);
        }else{
            
            return response()->json(['failed'], 400);
        }
    }
    
    public function update(Request $request)
    {
        $generals = \App\Mstgnrl::where('VGNRLTYPE','=',$request->type)->where('VGNRLCODE','=',$request->code);
        
        $validator = Validator::make($request->all(), [
            'type' => 'required|max:20',
            'code' => 'required|max:10',
            'desc' => 'required|max:50',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        $generals->update([
            'VGNRLTYPE' => $request->type,
            'VGNRLCODE'  => $request->code,
            'VGNRLDESC' => $request->desc,
            'VGNRLREMARKS' => $request->rmrks,
            'BACTIVE'  => $request->BACTIVEs,
            'DMODI'  => carbon::now(),
            'VMODI'  => Session::get('id'),
            
        ]);
        return response()->json(['success'], 200);
    }

    public function edit($id){

        $base = base64_decode($id);
        list($x,$y) = explode(",",$base);

        $general = \DB::select(DB::raw("SELECT GNRLTYPE, GNRLCODE, GNRLDESC, GNRLREMARKS, STATUS, MODIFY_DATE, MODIFY_NAME FROM vw_mstgeneral where GNRLTYPE = '".$x."' AND GNRLCODE = '".$y."'"))[0];

        return view('home/general/update',compact('general'));
    }

    public function getgenerallookup()
	{
		return response()->json(['data' => Mstgnrl::select('VGNRLTYPE')->distinct()->get()]);
    }

	public function export_excel(Request $request)
	{
        if (!$request){
            $id = "";
            return Excel::download(new GeneralExport($id),'General.xls');

            
        }else{
            $no = $request->no;
            $generaltype = $request->generaltype;
            $generalcode = $request->generalcode;
            if(!$request->lastmo){
                $lastmo = '';
            }else{
                
                $lastmo = Carbon::parse($request->lastmo)->format('d-M-Y');

            }
            $generaldesc = $request->generaldesc;
            $generalrem = $request->generalrem;
            $status = $request->status;
            $modifiedn = $request->modifiedn;
            $search = $request->search;
      
            return Excel::download(new GeneralExport($no,$generaltype,$generalcode,$generaldesc,$generalrem,$status,$lastmo,$modifiedn,$search),'General.xls');
            
        }
     
	}
}
