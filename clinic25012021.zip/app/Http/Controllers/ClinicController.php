<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ClinicModel;
use App\Mstsettings;
use App\Mstgnrl;
use App\Doclists;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Illuminate\Support\Str; 
use App\Exports\ClinicExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Storage;
use Validator;
use DB;

class ClinicController extends Controller
{
    public function getajaxcliniccode($id){

        $i = base64_decode($id);
         $select = DB::select("SELECT COUNT(*) AS hitung FROM vw_mstclinic WHERE CLINICCODE = '".$i."' ")[0];
         if($select->hitung <= 0){
            $null['data'] = "";
         }else{
            $null['data'] = "already";
         }
         return response()->json($null, 200);
    }


    public function ajax(Request $request){
        $clinic = ClinicModel::all();
        $view = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY CLINICCODE ASC) AS No, CLINICCODE, CLINICINIT, CLINICNAME, CLINIC_STATUS, SUBDISTRICTNAME, VSUBDISTRICTCODE, DISTRICTNAME, STATUS, MODIFY_NAME, MODIFY_DATE,REGION,BUSUNIT FROM vw_mstclinic");
       
        return Datatables::of($view)
        ->addIndexColumn()

        ->filter(function ($instance) use ($request) {

            if (!empty($request->get('date'))) {

                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
                    return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;

                });

            }
            if (!empty($request->get('search'))) {
                // search entire table
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $tmp_search = $request->get('search');  // inputed string in Search field
                    $column_names = ['No', 'CLINICCODE', 'CLINICINIT', 'CLINICNAME', 'CLINIC_STATUS', 'SUBDISTRICTNAME', 'DISTRICTNAME', 'STATUS', 'MODIFY_NAME', 'MODIFY_DATE','REGION','BUSUNIT'];
                    for($i = 0; $i < count($column_names); $i++)
                    {
                        // Check if cell of $column_names[$i] contains $tmp_search
                        if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                    }
                    return false;
                });
            }
        })
        
        ->addColumn('no', function($row){
            return $row->No;
        })
        ->addColumn('action', function($row){
            if(RoleAccessController::FunctionAccessCheck('U', 'F08')) return $row->CLINICCODE;
            else return null;
        })
        ->addColumn('modify_date', function($row){
            return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
        })
        
        ->rawColumns(['action','no'])
        ->make(true);
                
    }
    public function insert(){
        $clinic = \App\Mstsettings::select('VSETDESC','VSETCODE')
                                    ->where('VSETID','=','CLINICSTAT')->get();
        $clinicdoc = \App\Mstgnrl::where('VGNRLTYPE','=','CLINICDOCTYPE')->where('BACTIVE','=','1')->get();
        $regiontype = \App\Mstgnrl::where('VGNRLTYPE','=','REGIONTYPE')->where('BACTIVE','=','1')->get();
        return view('home/clinic/add',['clinic'=>$clinic,'clinicdoc'=>$clinicdoc,'regiontype'=>$regiontype]);
    }

    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'cliniccode' => 'required|max:20',
            'clinicname' =>'required|max:50',
            'SUBDISTRICTCODE' =>'required|max:5',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        
        // Give warning if current selected Cost Center has an active package
        $caught_data = $this->CheckClinicInitialExists($request->cliniccode, $request->clinicinit);
        if($caught_data != null) return response()->json(['error'=>"This Clinic Initial (" . $request->clinicinit . ") is already exists!"], 400);

        /// get dari model  
        $data =  new \App\ClinicModel();

        $data->VCLINICCODE = $request->cliniccode;
        $data->VSUBDISTRICTCODE = $request->SUBDISTRICTCODE;
        $data->VCLINICINIT = $request->clinicinit;
        $data->VCLINICNAME = $request->clinicname;
        $data->VCLINICSTATUS = $request->clinicstatus;
        $data->VDOCID = 'MEDSYS_MSTCLINICS/' . $request->cliniccode;
        $data->BACTIVE = '1';
        $data->VBU = $request->business;
        $data->VREGION = $request->region; 
        $data->DMODI = Carbon::now();
        $data->VCREA = Session::get('id');
        $data->VMODI = Session::get('id');
    
        $data->save();
        if (isset($request->VDOCFILENAME))
        {
            for ($x = 0; $x < count($request->VDOCFILENAME); $x++)
            {
                $doc = new Doclists();

                $doc->VDOCID = 'MEDSYS_MSTCLINICS/' . $request->cliniccode;
                $doc->VDOCTYPE = $request->VDOCTYPE[$x];
                $doc->VDOCNO = $request->VDOCNO[$x];
                $doc->VDOCFILENAME = $request->VDOCFILENAME[$x];
                $doc->DPERIODFR = $request->DPERIODFR[$x];
                $doc->DPERIODTO = $request->DPERIODTO[$x];
                $doc->VMODI = Session::get('id');
                $doc->save();
                $request->file('files')[$x]->storeAs(Mstsettings::where('VSETID', 'CLINICDOC')->where('VSETCODE', 'CLNCDOC')->where('BACTIVE', '1')->first()->VSETDESC, $doc->VID . '.' . $request->file('files')[$x]->extension() );
            }
        }
        
        return response()->json(['success'], 200);

    }

    public function view($id){
        $base = base64_decode($id);
        $clinic['clinic'] = ClinicModel::where('VCLINICCODE',$base)->first();
        return response()->json($clinic);

    }

    public function update(Request $request){
        $clinic = \App\ClinicModel::where('VCLINICCODE','=',$request->cliniccode);
        $validator = Validator::make($request->all(), [
            'clinicname' =>'required|max:50',
            'SUBDISTRICTCODE' =>'required|max:5',
            'clinicstatus' =>'required|max:10',
            'clinicinit' =>'required|max:2',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        
        // Give warning if current selected Cost Center has an active package
        $caught_data = $this->CheckClinicInitialExists($request->cliniccode, $request->clinicinit);
        if($caught_data != null) return response()->json(['error'=>"This Clinic Initial (" + $request->clinicinit + ") is already exists!"], 400);

        $clinic->update([
            'VCLINICCODE' => $request->cliniccode,
            'VSUBDISTRICTCODE' => $request->SUBDISTRICTCODE,
            'VCLINICINIT' => $request->clinicinit,
            'VCLINICNAME'  => $request->clinicname,
            'VCLINICSTATUS' => $request->clinicstatus,
            'VREGION' => $request->region, 
            'VBU' => $request->business,
            'BACTIVE'  => $request->BACTIVEs,
            'DMODI'  => carbon::now(),
            'VMODI'  => Session::get('id'),
            
        ]);
        if (isset($request->VDOCFILENAME))
		    {

		    	for ($x = 0; $x < count($request->VDOCFILENAME); $x++)
		    	{
                    $is_update = false;
                    if (strlen($request->VID[$x]) != 13)
                    {
                        $doc = Doclists::find($request->VID[$x]);
                        $is_update = true;
                        $old_file = $doc->VDOCFILENAME;
                    }
                    else
                    {
                        $doc = new Doclists();
                        $doc->VDOCID = 'MEDSYS_MSTCLINICS/' . $request->cliniccode;
                        $doc->VCREA = Session::get('id');
                    }
                    $doc->VDOCTYPE = $request->VDOCTYPE[$x];
                    $doc->VDOCNO = $request->VDOCNO[$x];
                    if ($request->VDOCFILENAME[$x] != '')
                    {
                        $doc->VDOCFILENAME = $request->VDOCFILENAME[$x];
                    }
		    		$doc->DPERIODFR = $request->DPERIODFR[$x];
		    		$doc->DPERIODTO = $request->DPERIODTO[$x];
		    		$doc->VMODI = Session::get('id');
                    $doc->save();
                 
		    		if ($request->VDOCFILENAME[$x] != '')
		    		{
                        
		    			if ($is_update)
		    			{
		    				Storage::delete('public'.Mstsettings::where('VSETID', 'CLINICDOC')->where('VSETCODE', 'CLNCDOC')->where('BACTIVE', '1')->first()->VSETDESC . '/' . strtolower($doc->VID . substr($old_file, strrpos($old_file, '.'))));
                        }
                        $request->file('files')[$x]->storeAs(Mstsettings::where('VSETID', 'CLINICDOC')->where('VSETCODE', 'CLNCDOC')->where('BACTIVE', '1')->first()->VSETDESC, $doc->VID . '.' . $request->file('files')[$x]->extension() );
		    		}
                }
		    }
        return response()->json(['success'], 200);
    }

    public function edit($id,$user = NULL){

        $ids = base64_decode($id);
        $clinic = ClinicModel::where('VCLINICCODE',$ids)->first();

        $Mstsubdistrict = \App\Mstsubdistrict::select('VSUBDISTRICTNAME', 'VDISTRICTCODE')->where('VSUBDISTRICTCODE',$clinic->VSUBDISTRICTCODE)->first();
        if(!empty($Mstsubdistrict))$Mstdistrict = \App\Mstdistrict::select('VDISTRICTNAME')->where('VDISTRICTCODE',$Mstsubdistrict->VDISTRICTCODE)->first();
        else $Mstdistrict = null;

        $setting1 = \App\Mstsettings::where('VSETID','CLINICSTAT')->get();
        $setting = \App\Mstsettings::where('VSETID','CLINICSTAT')->where('VSETCODE',$clinic->VCLINICSTATUS)->where('BACTIVE','=','1')->first();
        $clinicdoc = \App\Mstgnrl::where('VGNRLTYPE','=','CLINICDOCTYPE')->where('BACTIVE','=','1')->get();
        $user = ClinicModel::where('VCLINICCODE',$ids)->first();
        $docs = Doclists::where('VDOCID', 'MEDSYS_MSTCLINICS/'.$user->VCLINICCODE)->join('MEDSYS_MSTGENERALS', function ($join) { $join->on('MEDSYS_DOCLISTS.VDOCTYPE', '=', 'MEDSYS_MSTGENERALS.VGNRLCODE')->where('MEDSYS_MSTGENERALS.VGNRLTYPE', 'CLINICDOCTYPE'); })->get();
        $regiontype = \App\Mstgnrl::where('VGNRLTYPE','=','REGIONTYPE')->where('BACTIVE','=','1')->get();

        return view('home/clinic/update',['setting1'=>$setting1, 'docs' => $docs ?? NULL,'regiontype' => $regiontype],compact('clinic','setting','clinicdoc','Mstsubdistrict','Mstdistrict'));
    }
	
	public function export_excel(Request $request)
	{  
        if (!$request){
            $id = "";
            // $ids = DB::select("SELECT CLINICCODE, CLINICNAME, CLINICINIT, CLINIC_STATUS, CLINIC_AREA, STATUS, MODIFY_DATE, MODIFY_NAME FROM vw_mstclinic WHERE CLINICCODE LIKE '" . $base . "%' ");
            return   Excel::download(new ClinicExport($id),'Clinic.xls');
            
        }else{
            $no = $request->no;
            $clinic_code = $request->clinic_code; 
            $clinic_init = $request->clinic_init;
            $clinic_name = $request->clinic_name;
            $clinic_status = $request->clinic_status;
            $subdistname = $request->subdistname;
            $distname = $request->distname;
            $status = $request->status; 
            $lmname = $request->lmname;
            if(!$request->lmdate) $lmdate = '';
            else $lmdate = Carbon::parse($request->lmdate)->format('d-M-Y');
            $search = $request->search;

            // $ids = DB::select("SELECT CLINICCODE, CLINICNAME, CLINICINIT, CLINIC_STATUS, CLINIC_AREA, STATUS, MODIFY_DATE, MODIFY_NAME FROM vw_mstclinic WHERE CLINICCODE LIKE '" . $base . "%' ");
      
            return Excel::download(new ClinicExport($no,$clinic_code,$clinic_init,$clinic_name,$clinic_status,$subdistname,$distname,$status,$lmname,$lmdate,$search),'Clinic.xls');
            
        }

    }

    //==== Data for for Sub District lookup table
    public function getsubdistlookup(){
        $views = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS No, SUBDISTRICTCODE, SUBDISTRICTNAME, DISTRICT_NAME FROM vw_mstsubdistrict WHERE STATUS='Active'");

        return response()->json(['data' => $views]);
    }

    //==== ajax for Clinic Initial checking
    public function getajaxclinicinitialexists($id){
        $base = base64_decode($id);
        list($clinic_code, $clinic_initial) = explode(",", $base);

        if(!$this->CheckClinicInitialExists($clinic_code, $clinic_initial)) $null['data'] = "";
        else $null['data'] = "exists";
            
        return response()->json($null, 200);
    }

    //==== Check if current inputted Clinic Initial is already exists 
    public function CheckClinicInitialExists($_clinic_code, $_clinic_initial)
    {
        $select = ClinicModel::where("VCLINICCODE","!=",$_clinic_code)->where("VCLINICINIT", $_clinic_initial)->get();
        if(count($select) == 0) return false;
        else return true;
    }
}
