<?php

namespace App\Http\Controllers;

use App\ClinicModel;
use App\Exports\InventoryMovementExport;
use App\Invmovedtllogs;
use App\Invmovedtls;
use App\Invmovehdrlogs;
use App\Invmovehdrs;
use App\Invrequestdtls;
use App\Invrequests;
use App\Mstdrugs;
use App\Mstsettings;
use Carbon\Carbon;
use DataTables;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;
use Session;

class MovementController extends Controller
{
    public function index()
    {
		if (parent::check_role("PMCY") || parent::check_role("HRADM"))
		{
			return view('home/inventory/movement/index');
		}
		else
		{
			return redirect('/account/home');
		}
    }
	
	public function ajax(Request $request)
	{
		$movementsel = DB::select("SELECT ROW_NUMBER() OVER(ORDER BY DCREA DESC) AS No, FORMAT(DTRX,'dd-MMM-yyyy') AS DTRX, VTRXNO, VREQNO FROM MEDSYS_INVMOVEHDRS");
		return DataTables::of($movementsel)
                ->addIndexColumn()
				->filter(function ($instance) use ($request) {
					if (!empty($request->get('date')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							$dot = Carbon::parse($request->get('date'))->format('d-M-Y');
							return Str::contains($row['DTRX'], $dot) ? true : false;
						});
					}
					if (!empty($request->get('search')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							if (Str::contains(Str::lower($row['VREQNO']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DTRX']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VTRXNO']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['No']), Str::lower($request->get('search'))))
							{
								return true;
							}
							return false;
						});
					}
				})
				->addColumn('no', function($row){ return $row->No; })
                ->addColumn('action', function($row){ return $row->VTRXNO; })
                ->rawColumns(['action','no'])
                ->make(true);
    }
	
	public function form($movement = NULL)
	{
		$types = Mstsettings::select('VSETCODE', 'VSETDESC')->where('VSETID','TYPEMOVE')->where('BACTIVE','1')->get()->toArray();
		if ($movement != NULL)
		{
			$movement = Invmovehdrs::find(base64_decode($movement));
			$drugs = Invmovedtls::where('VTRXNO', $movement->VTRXNO)->leftjoin('MEDSYS_MSTDRUGS', 'MEDSYS_INVMOVEDTLS.VDRUGSCODE', '=', 'MEDSYS_MSTDRUGS.VDRUGSCODE')->leftjoin('MEDSYS_MSTSETTINGS', function ($join) { $join->on('MEDSYS_MSTDRUGS.PBF', '=', 'MEDSYS_MSTSETTINGS.VSETCODE')->where('MEDSYS_MSTSETTINGS.VSETID', 'PRMPBF'); })->select('MEDSYS_INVMOVEDTLS.*', 'MEDSYS_MSTDRUGS.VCONTAIN', 'MEDSYS_MSTDRUGS.VBRAND', 'MEDSYS_MSTDRUGS.VUOM', 'MEDSYS_MSTSETTINGS.VSETDESC AS PBF')->get();
			return view('home/inventory/movement/form', ['movement' => $movement, 'drugs' => $drugs, 'types' => $types]);
		}
		else
		{
			return view('home/inventory/movement/form', ['types' => $types]);
		}
    }

    public function getreqnolookup($flag)
	{
		$sql = DB::select("EXEC sp_RequestDashboard ?", [Session::get('namaclinic') ?? 'HO']);
		$data = array();
		foreach ($sql as $key => $val)
		{
			if ($val->COLOUR == Mstsettings::select('VSETDESC')->where('VSETID','COLOR')->where('VSETCODE','INVREQ')->where('BACTIVE','1')->first()->VSETDESC && $val->FLAG == $flag)
			{
				$data[] = $val;
			}
		}
		return response()->json(['data' => $data]);
    }

    public function getreqdetail($id, $type)
	{
		$sql = DB::select("EXEC sp_RequestDetail ?, ?", [Session::get('namaclinic') ?? 'HO', $id]);
		$data = array();
		foreach ($sql as $key => $val)
		{
			if ($val->COLOUR == Mstsettings::select('VSETDESC')->where('VSETID','COLOR')->where('VSETCODE','INVREQ')->where('BACTIVE','1')->first()->VSETDESC)
			{
				if ($type == 'ISS')
				{
					$sqlDetail = DB::select("EXEC sp_IssueStock ?, ?, ?", [Session::get('namaclinic') ?? 'HO', $val->VDRUGSCODE, $val->IQTYVERIFY]);
					$tempTotal = $val->IQTYVERIFY;
					foreach ($sqlDetail as $k => $v)
					{
						if ($v->ISSUE == 0)
						{
							continue;
						}
						$rd = new ReqDetail();
						$rd->VDRUGSCODE = $val->VDRUGSCODE;
						$rd->VCONTAIN = $val->VCONTAIN;
						$rd->VBRAND = $val->VBRAND;
						$rd->VUOM = $val->VUOM;
						$rd->PBF = $val->PBF;
						$rd->DEXPIRED = $v->DEXPIRED;
						if ($v->ISSUE <= $tempTotal)
						{
							$rd->IQTYVERIFY = $v->ISSUE;
							$tempTotal -= $v->ISSUE;
						}
						else
						{
							$rd->IQTYVERIFY = $tempTotal;
						}
						$data[] = $rd;
					}
				}
				if ($type == 'RCV')
				{
					if ($val->IQTY != NULL)
					{
						$val->IQTYVERIFY = $val->IQTY * -1;
						$val->DEXPIRED = $val->DEXPIRED;
					}
					$data[] = $val;
				}
			}
		}
		return response()->json(['data' => $data]);
    }

    public function getdruglookup(Request $request)
	{
		$query = "SELECT * FROM vw_mstdrugs WHERE STATUS = 'Active'";
		if ($request->except != NULL)
		{
			$query .= " AND DRUGS_CODE NOT IN (" . $request->except . ")";
		}
		return response()->json(['data' => DB::select($query)]);
    }
	
	public function save(Request $request)
    {
		$now = carbon::now();
		$inventory = new Invmovehdrs();
		$yy = substr($now->format('Y'), 2, 2);
		$inventory->VCLINICCODE = Session::get('namaclinic') ?? 'HO';
		$inventory->VTYPE = $request->VTYPE;
		$inventory->VREQNO = $request->VREQNO;
		$inventory->DTRX = $now;
		$inventory->VCREA = Session::get('id');
		$inventory->DCREA = $now;
		$inventory->VMODI = Session::get('id');
		$movelog = new Invmovehdrlogs();
		$movelog->VCLINICCODE = $inventory->VCLINICCODE;
		$movelog->VTYPE = $inventory->VTYPE;
		$movelog->VREQNO = $inventory->VREQNO;
		$movelog->DTRX = $inventory->DTRX;
		$movelog->VUSER = Session::get('id');
		DB::beginTransaction();
		try
		{
			$rqno = DB::select("SELECT SUM(NLASTNO) NLASTNO FROM MEDSYS_MSTNOS WHERE VTRXCODE = 'TR' AND NYEAR = '" . $yy . "'")[0]->NLASTNO;
			if ($inventory->VTYPE == 'ADJ')
			{
				$inventory->VTRXNO = ClinicModel::find(Session::get('namaclinic') ?? 'HO')->VCLINICINIT . 'AJ' . $yy . str_pad($rqno + 1, 4, '0', STR_PAD_LEFT);
			}
			if ($inventory->VTYPE == 'ISS')
			{
				$inventory->VTRXNO = ClinicModel::find(Session::get('namaclinic') ?? 'HO')->VCLINICINIT . 'IS' . $yy . str_pad($rqno + 1, 4, '0', STR_PAD_LEFT);
			}
			if ($inventory->VTYPE == 'RCV')
			{
				$inventory->VTRXNO = ClinicModel::find(Session::get('namaclinic') ?? 'HO')->VCLINICINIT . 'RC' . $yy . str_pad($rqno + 1, 4, '0', STR_PAD_LEFT);
			}
			if ($rqno == NULL)
			{
				DB::table('MEDSYS_MSTNOS')->insert([ 'NLASTNO' => '1', 'NYEAR' => $yy, 'NMONTH' => '0', 'NDATE' => '0', 'VTRXCODE' => 'TR', 'DCREA' => $now, 'VCREA' => Session::get('id'), 'VMODI' => Session::get('id') ]);
			}
			else
			{
				DB::table('MEDSYS_MSTNOS')->where('VTRXCODE', 'TR')->where('NYEAR', $yy)->update([ 'NLASTNO' => $rqno + 1, 'DMODI' => $now, 'VMODI' => Session::get('id') ]);
			}
			$inventory->save();
			$lineno = 1;
			for ($x = 0; $x < count($request->VDRUGSCODE); $x++)
			{
				$line = new Invmovedtls();
				$line->VTRXNO = $inventory->VTRXNO;
				$line->ILINENO = $lineno;
				$line->VCREA = Session::get('id');
				$line->DCREA = $now;
				$line->VMODI = Session::get('id');
				$line->VDRUGSCODE = $request->VDRUGSCODE[$x];
				$line->DEXPIRED = $request->DEXPIRED[$x];
				$line->IQTY = $request->IQTY[$x];
				if ($inventory->VTYPE == 'ADJ' && substr($line->IQTY, 0, 1) == '-')
				{
					$sql = DB::select("EXEC sp_IssueStock ?, ?, ?", [Session::get('namaclinic') ?? 'HO', $line->VDRUGSCODE, substr($line->IQTY, 1)]);
					if (count($sql) == 0)
					{
						return response()->json(['error' => 'No Stock for ' . $line->VDRUGSCODE], 500);
					}
					$dexp = NULL;
					$iqty = 0;
					$arrnew = array();
					foreach ($sql as $key => $val)
					{
						if ($val->ISSUE == 0)
						{
							continue;
						}
						if ($line->DEXPIRED == NULL)
						{
							if (substr($line->IQTY, 1) - $iqty > $val->BALANCE)
							{
								$iqty += $val->BALANCE;
								$arrnew[] = ['qty' => $val->BALANCE, 'expired' => $val->DEXPIRED];
							}
							else
							{
								$line->DEXPIRED = $val->DEXPIRED;
								$dexp = $val->DEXPIRED;
								$iqty = substr($line->IQTY, 1);
								break;
							}
						}
						else
						{
							if (substr($line->DEXPIRED, 0, 10) == $val->DEXPIRED)
							{
								if (substr($line->IQTY, 1) > $val->BALANCE)
								{
									DB::rollBack();
									return response()->json(['error' => 'Max Qty ' . $val->VDRUGSCODE . ' at Expired Date ' . date_format(DateTime::createFromFormat('Y-m-d', $val->DEXPIRED), "d-M-Y") . ' is ' . $val->BALANCE], 500);
								}
								else
								{
									$dexp = $val->DEXPIRED;
									$iqty = substr($line->IQTY, 1);
									break;
								}
							}
						}
					}
					if ($iqty < substr($line->IQTY, 1))
					{
						DB::rollBack();
						return response()->json(['error' => 'Max Qty ' . $line->VDRUGSCODE . ' is ' . $iqty], 500);
					}
					if (substr($line->DEXPIRED, 0, 10) != $dexp)
					{
						DB::rollBack();
						return response()->json(['error' => 'No Expired Date at ' . date_format($line->DEXPIRED, "d-M-Y") . ' for ' . $line->VDRUGSCODE], 500);
					}
					if (count($arrnew) > 0)
					{
						foreach ($arrnew as $k => $v)
						{
							$lineno++;
							$addline = new Invmovedtls();
							$addline->VTRXNO = $inventory->VTRXNO;
							$addline->ILINENO = $lineno;
							$addline->VCREA = Session::get('id');
							$addline->DCREA = $now;
							$addline->VMODI = Session::get('id');
							$addline->VDRUGSCODE = $request->VDRUGSCODE[$x];
							$addline->DEXPIRED = $v['expired'];
							$addline->IQTY = $v['qty'] * -1;
							$addline->save();
							$addmovedtllog = new Invmovedtllogs();
							$addmovedtllog->VTRXNO = $addline->VTRXNO;
							$addmovedtllog->ILINENO = $addline->ILINENO;
							$addmovedtllog->VDRUGSCODE = $addline->VDRUGSCODE;
							$addmovedtllog->DEXPIRED = $addline->DEXPIRED;
							$addmovedtllog->IQTY = $addline->IQTY;
							$addmovedtllog->VUSER = Session::get('id');
							$addmovedtllog->save();
							$iqty -= $v['qty'];
						}
						$line->IQTY = $iqty * -1;
					}
				}
				$line->save();
				$movedtllog = new Invmovedtllogs();
				$movedtllog->VTRXNO = $line->VTRXNO;
				$movedtllog->ILINENO = $line->ILINENO;
				$movedtllog->VDRUGSCODE = $line->VDRUGSCODE;
				$movedtllog->DEXPIRED = $line->DEXPIRED;
				$movedtllog->IQTY = $line->IQTY;
				$movedtllog->VUSER = Session::get('id');
				$movedtllog->save();
				$lineno++;
			}
			if ($inventory->VTYPE == 'RCV' && Invmovehdrs::where('VTYPE', 'RCV')->where('VREQNO', $inventory->VREQNO)->join('MEDSYS_INVMOVEDTLS', 'MEDSYS_INVMOVEHDRS.VTRXNO', '=', 'MEDSYS_INVMOVEDTLS.VTRXNO')->sum('IQTY') == Invrequestdtls::where('VREQNO', $inventory->VREQNO)->sum('IQTYVERIFY'))
			{
				$invReq = Invrequests::find($inventory->VREQNO);
				$invReq->BSTATUS = 'C';
				$invReq->save();
			}
			$movelog->VTRXNO = $inventory->VTRXNO;
			$movelog->save();
			DB::commit();
		}
		catch (\Exception $e)
		{
			DB::rollBack();
			if (!isset($e->errorInfo))
			{
				return response()->json($e, 500);
			}
			else
			{
				return response()->json($e->errorInfo[2], 500);
			}
		}
		return response()->json(['success'], 200);
    }
	
	public function export_excel(Request $request)
	{
        if (!$request)
		{
			return Excel::download(new InventoryMovementExport(""), 'Inventory Movement.xls');
        }
		else
		{
            $no = $request->no;
            $date = $request->date;
            $transaction_no = $request->transaction_no;
            $request_no = $request->request_no;
            $search = $request->search;
			return Excel::download(new InventoryMovementExport($no, $date, $transaction_no, $request_no, $search), 'Inventory Movement.xls');
        }
    }
}

class ReqDetail
{
	public $VDRUGSCODE;
	public $VCONTAIN;
	public $VBRAND;
	public $VUOM;
	public $PBF;
	public $IQTYVERIFY;
	public $DEXPIRED;
}
