<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Mstcostcenterpackges;
use App\Mstcostcenter;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use App\Exports\CostCenterPackagesExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use DB;

class CostCenterpackgesController extends Controller
{
    public function getajaxcostcenterpackages($id){

        $i = base64_decode($id);
         $select = DB::select("SELECT COUNT(*) AS hitung FROM vw_mstccpackage WHERE CC_CODE = '".$i."' ")[0];
         if($select->hitung <= 0){
            $null['data'] = "";
         }else{
            $null['data'] = "already";
         }
         return response()->json($null, 200);
    }
    public function getajaxcostcenterpackages2($id){

        $i = base64_decode($id);
         $select = DB::select("SELECT COUNT(*) AS hitung FROM vw_mstccpackage WHERE PCKG_CODE = '".$i."' ")[0];
         if($select->hitung <= 0){
            $null['data'] = "";
         }else{
            $null['data'] = "already2";
         }
         return response()->json($null, 200);
    }

    public function ajax(Request $request)
    {
        $costcenterpackages = \App\Mstcostcenterpackges::all();
        $view = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY  MONTH(MODIFY_DATE) DESC,YEAR(MODIFY_DATE) DESC,MODIFY_DATE ASC) AS No, CC_CODE, CC_NAME, PCKG_CODE, PCKG_NAME, STATUS, MODIFY_DATE, MODIFY_NAME 
                             FROM vw_mstccpackage");

        return Datatables::of($view)
        ->addIndexColumn()
        
        ->filter(function ($instance) use ($request) {

            if (!empty($request->get('date'))) {
            
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
                    return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                
                });
            
            }
            if (!empty($request->get('search'))) {
                // search entire table
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                   $tmp_search = $request->get('search');  // inputed string in Search field
                   $column_names = ['No', 'CC_CODE', 'CC_NAME', 'PCKG_CODE', 'PCKG_NAME', 'STATUS', 'MODIFY_NAME', 'MODIFY_DATE'];
                   for($i = 0; $i < count($column_names); $i++)
                   {
                      // Check if cell of $column_names[$i] contains $tmp_search
                      if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                   }
                   return false;
                });
            }
        })
        ->addColumn('no', function($row){
            return $row->No;
        })
        ->addColumn('action', function($row){
            if(RoleAccessController::FunctionAccessCheck('U', 'F10')) 
            {
                $null["link"] = base64_encode($row->CC_CODE.','.$row->PCKG_CODE);
                $null["data"] = $row->CC_CODE;
                return $null;
            }
            else return null;
        })
        ->addColumn('modify_date', function($row){
            return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
        })
        ->rawColumns(['action','no'])
        ->make(true);
    }

    public function insert(){
        return view('home/costcenterpackages/add');
    }

    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            // 'ccenter' => 'required|max:50',
            'ccentercode' => 'required|max:20',
            'packcode' =>'required|max:50',
        ]);

        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        // Give warning if current selected Cost Center has an active package
        $caught_data = $this->CheckCostCenterPackageExists($request->ccentercode);
        if($caught_data != null) 
        {
            $Mstpackages = \App\Mstpackages::where('VPCKGCODE',$caught_data ->VPACKAGECODE)->select('VPCKGCODE', 'VPCKGNAME')->first();
            return response()->json(['error'=>"This Cost Center has an active package<br/>(" . $Mstpackages->VPCKGCODE . " - " . $Mstpackages->VPCKGNAME . ")."], 400);
        } 

        /// get dari Model  
        $data =  new \App\Mstcostcenterpackges();
        $data->VCOSTCNTRCODE = $request->ccentercode;
        $data->VPACKAGECODE = $request->packcode;
        $data->BACTIVE = '1';
        $data->VCREA = Session::get('id');
        $data->VMODI = Session::get('id');
        $data->DMODI = Carbon::now();
        $data->save();
        /// cost
        // $data1 =  new \App\Mstcostcenter();
        // $data1->VCOSTCNTRCODE = $request->ccentercode;
        // $data1->VCOSTCNTRNAME = $request->ccenter;
        // $data1->BACTIVE = '1';
        // $data1->DMODI = Carbon::now();
        // $data1->VCREA = Session::get('id');
        // $data1->VMODI = Session::get('id');
        // $data1->save();
        
        return response()-> json(['succsess'], 200);
    }

    public function update(Request $request)
    {
        $costcentersel = \App\Mstcostcenterpackges::where('VCOSTCNTRCODE','=',$request->ccentercode)->where('VPACKAGECODE','=',$request->packcode);
        
        $validator = Validator::make($request->all(), [
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        // Give warning if current selected Cost Center has an active package
        if($request->BACTIVEs == "1")
        {
            $caught_data = $this->CheckCostCenterPackageExists($request->ccentercode);
            if($caught_data != null) 
            {
                $Mstpackages = \App\Mstpackages::where('VPCKGCODE',$caught_data ->VPACKAGECODE)->select('VPCKGCODE', 'VPCKGNAME')->first();
                return response()->json(['error'=>"This Cost Center has an active package<br/>(" . $Mstpackages->VPCKGCODE . " - " . $Mstpackages->VPCKGNAME . ")."], 400);
            } 
        }

        $costcentersel->update([
            'VCOSTCNTRCODE'  => $request->ccentercode,
            'VPACKAGECODE'  => $request->packcode,
            'BACTIVE'  => $request->BACTIVEs,
            'DMODI'  => carbon::now(),
            'VCREA'  => Session::get('id'),
            'VMODI'  => Session::get('id'),
            
        ]);
        return response()->json(['succsess'], 200);
    }
    
    public function edit($id){
        $base = base64_decode($id);
        list($costcode, $packagecode) = explode(",",$base);

        $costcenterpackges = \App\Mstcostcenterpackges::where('VCOSTCNTRCODE','=',$costcode)->where('VPACKAGECODE','=',$packagecode)->first();
        $Mstcostcenter = \App\Mstcostcenter::where('VCOSTCNTRCODE', $costcenterpackges->VCOSTCNTRCODE)->select('VCOSTCNTRCODE', 'VCOSTCNTRNAME')->first();
        $Mstpackages = \App\Mstpackages::where('VPCKGCODE', $costcenterpackges->VPACKAGECODE)->select('VPCKGCODE', 'VPCKGNAME')->first();

        return view('home/costcenterpackages/update',compact('costcenterpackges'), ['Mstcostcenter' => $Mstcostcenter, 'Mstpackages' => $Mstpackages]);
    }

    public function getcostcenterlookup()
	{
		return response()->json(['data' => \App\Mstcostcenter::select('VCOSTCNTRCODE', 'VCOSTCNTRNAME')->get()]);
    }

    public function getpackageslookup()
	{
		return response()->json(['data' => \App\Mstpackages::select('VPCKGCODE', 'VPCKGNAME')->get()]);
    }
    
	public function export_excel(Request $request)
	{
        if(!$request){

            $id ="";
            return Excel::download(new DistrictExport($id),'District.xls');


        }else{
            $costccode = $request->costccode;
            $costcname = $request->costcname;
            $pc = $request->pc;
            if(!$request->modifiedt){
                $lastmo = '';
            }else{
                $lastmo = Carbon::parse($request->modifiedt)->format('d-M-Y');

            }
            $pname = $request->pname;
            $no = $request->no;
            $status = $request->status;
            $slastmona = $request->lastmona;
            $search = $request->search;
            return Excel::download(new CostCenterPackagesExport($no,$costccode,$costcname,$pname,$pc,$lastmo,$status,$slastmona,$search),'CostCenterPackages.xls');

        }
    }

    //==== ajax for Cost Center package checking
    public function getajaxcostcenterpackageexists($id){

        $costcode = base64_decode($id);

        $caught_data = $this->CheckCostCenterPackageExists($costcode);

        if($caught_data == null) $null['data'] = "";
        else 
        {
            $Mstpackages = \App\Mstpackages::where('VPCKGCODE',$caught_data ->VPACKAGECODE)->select('VPCKGCODE', 'VPCKGNAME')->first();
            $null['data'] = "This Cost Center has an active package (" . $Mstpackages->VPCKGCODE . " - " . $Mstpackages->VPCKGNAME . ").";
        }
            
        return response()->json($null, 200);
    }

    //==== Check if current inputted Cost Center has an active package. Return: Cost Center Package data with an active status
    public function CheckCostCenterPackageExists($_costcode)
    {
        $select = Mstcostcenterpackges::where("VCOSTCNTRCODE", $_costcode)->where("BACTIVE", "1")->get();
        if(count($select) != 0) return $select->first();
        else return null;
    }
}
