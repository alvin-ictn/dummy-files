<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use app\Mstsubpersonal;
use app\Mstpersonelareas;
use App\Mstsubpersonelareas;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use Illuminate\Support\Facades\Storage;
use App\Exports\SubPersonnelExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use DB;

class SubPersonnelController extends Controller
{
    public function  ajax(Request $request){

        $view = \App\Mstsubpersonal::all();
        $views = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY MONTH(MODIFY_DATE) DESC,YEAR(MODIFY_DATE) DESC,MODIFY_DATE ASC) AS No, SUBPERSONELCODE, SUBPERSONELNAME, PERSONELNAME, STATUS, MODIFY_DATE, MODIFY_NAME 
                             FROM vw_mstsubpersonelarea");

        return Datatables::of($views)
            ->addIndexColumn()

            ->filter(function ($instance) use ($request) {
                if (!empty($request->get('date'))) {
                    $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                        $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
                        return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
    
                    });
                }
                if (!empty($request->get('search'))) {
                    // search entire table
                    $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                        $tmp_search = $request->get('search');  // inputed string in Search field
                        $column_names = ['No', 'SUBPERSONELCODE', 'SUBPERSONELNAME', 'PERSONELNAME', 'STATUS', 'MODIFY_NAME', 'MODIFY_DATE'];
                        for($i = 0; $i < count($column_names); $i++)
                        {
                            // Check if cell of $column_names[$i] contains $tmp_search
                            if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                        }
                        return false;
                    });
                }
            })
            ->addColumn('no', function($row){
                return $row->No;
            })
            ->addColumn('action', function($row){
                if(RoleAccessController::FunctionAccessCheck('U', 'F22')) 
                {
                    $null["link"] = base64_encode($row->SUBPERSONELCODE.','.$row->PERSONELNAME);
                    $null["data"] = $row->SUBPERSONELCODE;
                    return $null;
                }
                else return null;
            })
            ->addColumn('modify_date', function($row){
                return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
            })
            ->rawColumns(['action','no'])
            ->make(true);

    }
    
    public function insert(){

        return view('home/subpersonal/add');
    }

    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'subcode' => 'required|max:20',
            'subname' =>'required|max:50',
            'VPRSNLAREACODE' =>'required|max:20',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        // Give warning if current selected Cost Center has an active package
        $caught_data = $this->CheckSubPrsnlCodeExists($request->subcode, $request->VPRSNLAREACODE);
        if($caught_data != null) return response()->json(['error'=>"Sub Personnel Area Code already in use for this Personnel Area!"], 400);

        /// get dari model  
        $data =  new \App\Mstsubpersonal();
        $data->VSUBPRSNLAREACODE = $request->subcode;
        $data->VPRSNLAREACODE = $request->VPRSNLAREACODE;
        $data->VSUBPRSNLNAME = $request->subname;
        $data->BACTIVE = '1';
        $data->DMODI = Carbon::now();
        $data->VCREA = Session::get('id');
        $data->VMODI = Session::get('id');

        $data->save();
        return response()-> json(['succsess'], 200);
    }
    
    public function update(Request $request)
    {
        $modulsel = \App\Mstsubpersonal::where('VSUBPRSNLAREACODE','=',$request->subcode)->where('VPRSNLAREACODE','=',$request->VPRSNLAREACODE);
        
        $validator = Validator::make($request->all(), [
            'subcode' => 'required|max:20',
            'subname' =>'required|max:50',
            'VPRSNLAREACODE' =>'required|max:20',
        ]);

        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        $modulsel->update([
            'VSUBPRSNLAREACODE' => $request->subcode,
            'VPRSNLAREACODE' => $request->VPRSNLAREACODE,
            'VSUBPRSNLNAME' => $request->subname,
            'BACTIVE'  => $request->BACTIVEs,
            'DMODI'  => carbon::now(),
            'VCREA'  => Session::get('id'),
            'VMODI'  => Session::get('id'),
            
        ]);
        return response()->json(['succsess'], 200);
    }

    public function edit($id){

        $base = base64_decode($id);
        list($x,$y) = explode(",",$base);
        $subperson = \App\Mstsubpersonal::where('VSUBPRSNLAREACODE',$x)
        ->leftjoin('MEDSYS_MSTPERSONELAREAS', function ($join) {$join->on('MEDSYS_MSTSUBPERSONELAREAS.VPRSNLAREACODE', '=', 'MEDSYS_MSTPERSONELAREAS.VPRSNLAREACODE')->select('MEDSYS_MSTPERSONELAREAS.VPRSNLNAME');})
        ->where('VPRSNLNAME',$y)->first();

        return view('home/subpersonal/update',compact('subperson'));
    }

    public function getcodelookup()
	{
        $db = \App\Mstpersonelareas::select('VPRSNLAREACODE','VPRSNLNAME')->where('BACTIVE','=','1')->get();
		return response()->json(['data' => $db]);
    }

    public function export_excel(Request $request)
	{
        if(!$request){

            $request = "";
            return Excel::download(new SubPersonnelExport($request),'SubPersonnel.xls');

        }else{
            $no = $request->no;
            $subcode = $request->subcode;
            $subname = $request->subname;
            $persname = $request->persname;
            if(!$request->lastmo){
                $lastmo = '';
            }else{
                
                $lastmo = Carbon::parse($request->lastmo)->format('d-M-Y');

            }
            $status = $request->status;
            $modifiedn = $request->modifiedn;
            $search = $request->search;


            return Excel::download(new SubPersonnelExport($no,$subcode,$subname,$persname,$status,$modifiedn,$lastmo,$search),'SubPersonnel.xls');

        }
    }

    //==== ajax for Sub Personnel Area code checking
    public function getajaxsubpersonnel($id){

        $base = base64_decode($id);
        list($sub_prsnl_code, $prsnl_code) = explode(",", $base);

        if(!$this->CheckSubPrsnlCodeExists($sub_prsnl_code, $prsnl_code)) $null['data'] = "";
        else $null['data'] = "exists";
         
        return response()->json($null, 200);
    }

    //==== Check if current inputted Sub Personnel Area Code is already exists for current inputted Personnel Area
    public function CheckSubPrsnlCodeExists($_sub_prsnl_code, $_prsnl_code)
    {
        $select = Mstsubpersonelareas::where("VSUBPRSNLAREACODE", $_sub_prsnl_code)->where("VPRSNLAREACODE", $_prsnl_code)->get();
        if(count($select) == 0) return false;
        else return true;
    }
}
