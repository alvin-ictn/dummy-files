<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use app\Mstuserrole;
use App\Mstusers;
use App\Mstclinicstaffs;
use App\Mstemployees;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use App\Exports\UserRoleExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;

class UserRoleController extends Controller
{
    //==== Ajax
    public function ajax(Request $request){
        $docts = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY USERNAME ASC, ROLENAME ASC) AS No, * FROM vw_mstuserrole");
        return Datatables::of($docts)
                ->addIndexColumn()

                ->filter(function ($instance) use ($request)
                {
                    if (!empty($request->get('lmdate'))) {
                        // search Last Modified Date
                        $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                            $dot = Carbon::parse($request->get('lmdate'))->format('d-M-Y');
                            return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                        });
                    }

                    if (!empty($request->get('search'))) {
                        // search entire table
                        $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                            $tmp_search = $request->get('search');  // inputed string in Search field
                            $column_names = ['No', 'USERNAME', 'ROLENAME', 'STATUS', 'MODIFY_NAME', 'MODIFY_DATE'];
                            for($i = 0; $i < count($column_names); $i++)
                            {
                                // Check if cell of $column_names[$i] contains $tmp_search
                                if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                            }
                            return false;
                        });
                    }
                })

                ->addColumn('no', function($row){
                    return $row->No;
                })
                ->addColumn('action', function($row){
                    if(RoleAccessController::FunctionAccessCheck('U', 'F25')) return $row->USERNAME;
                    else return null;
                })
                ->addColumn('modify_date', function($row){
                    return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
                })
                ->rawColumns(['action','no'])
                ->make(true);
    }

    //==== Open add form
    public function insert(){
        return view('home/userrole/add');
    }

    //==== Open page to edit user role
    public function edit($id){
        $base = base64_decode($id);
        list($x,$y) = explode(',', $base);

        $userrole = \App\Mstuserrole::where('VUSRID', $x)->where('VROLEID', $y)->first();
        $mstclinicstaffs =  Mstclinicstaffs::select('VNAME')->where('VUSRID', $x)->first();
        $mstemployees = Mstemployees::select('VNAME')->where('VUSRID', $x)->first();
        $vw_getrole = \DB::select("SELECT ROLEDESC FROM vw_getrole WHERE ROLEID = '$y'")[0];

        return view('home/userrole/update', compact('userrole'), ['mstclinicstaffs' => $mstclinicstaffs, 'mstemployees' => $mstemployees, 'vw_getrole' => $vw_getrole]);
    }
    
    //==== Add a new role to a user
    public function add(Request $request){
        // check if the user has an active role
        $caught_data = $this->CheckHasRole($request->VUSRID);
        if($caught_data != NULL && $caught_data->ROLEID != $request->VROLEID) 
        {
            $response['error'] = "This user has an active role (" . $caught_data->ROLENAME . ").";  //---- (" . $request->VUSRID . " - " . $caught_data->USERNAME . ")
            return response()->json($response, 400);
        }
        
        // Validation
        $validator = Validator::make($request->all(), [
            'VUSRID' => 'required|max:50',
            'VROLEID' => 'required|max:10',
        ]);
        if ($validator->fails()) {   
            $response['error'] = "Please fill all required field(s)";
            return response()->json($response, 400);
        }
        
        // get from model  
        $data =  new \App\Mstuserrole();
        $data->VUSRID = $request->VUSRID;
        $data->VROLEID = $request->VROLEID;
        $data->DMODI = Carbon::now();
        $data->VCREA = Session::get('id');
        $data->VMODI = Session::get('id');
        $data->save();

        // Save to Master Users table
        $user = \App\Mstusers::find($request->VUSRID);
        $user->VGROUPUSR = $request->VROLEID;
        $user->save();

        return response()->json(['success'], 200);
    }

    //==== Edit(Active/Inactive) a user role
    public function update(Request $request){
        // check if the user has an active role
        $caught_role_data = $this->CheckHasRole($request->VUSRID);
        if($request->BACTIVEs == "1")
        {
            if($caught_role_data != NULL && $caught_role_data->ROLEID != $request->VROLEID) 
            {
                $response['error'] = "This user has an active role (" . $caught_role_data->ROLENAME . ").";  //---- (" . $request->VUSRID . " - " . $caught_role_data->USERNAME . ")
                return response()->json($response, 400);
            }
        }

        $userrolesel = \App\Mstuserrole::where('VUSRID','=',$request->VUSRID)->where('VROLEID','=',$request->VROLEID);

        $validator = Validator::make($request->all(), []);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        $userrolesel->update([
            'VUSRID' => $request->VUSRID,
            'VROLEID'  => $request->VROLEID,
            'BACTIVE'  => $request->BACTIVEs,
            'DMODI'  => carbon::now(),
            'VMODI'  => Session::get('id'),
        ]);

        // Save to Master Users table
        $user = \App\Mstusers::find($request->VUSRID);
        if ($request->BACTIVEs == "1") $user->VGROUPUSR = $request->VROLEID;                                     // save with current active role
        else if ($user->VGROUPUSR == $request->VROLEID && $request->BACTIVEs == "0") $user->VGROUPUSR = NULL;    // no active role(NULL), ($user->VGROUPUSR == $request->VROLEID) means current user role has been inactivated
        $user->save();

        return response()->json(['success'], 200);
                   
    }
    
    //==== Export index table to excel file
	public function export_excel(Request $request){
        if(!$request){
            $tmp = "";
            return Excel::download(new UserRoleExport($tmp),'UserRole.xls');
        }
        else{
            $no = $request->no;
            $username = $request->username;
            $rolename = $request->rolename;
            $status = $request->status;
            $lmname = $request->lmname;
            if(!$request->lmdate){
                $lmdate = '';
            }
            else{
                $lmdate = Carbon::parse($request->lmdate)->format('d-M-Y');
            }
            $search = $request->search;

            return Excel::download(new UserRoleExport($no,$username,$rolename,$status,$lmname,$lmdate,$search),'UserRole.xls');
        }
    }

    //==== Get data for User Name lookup table
    public function getusernamelookup(){
        $data = Mstusers::select('MEDSYS_MSTUSERS.*', \DB::raw('COALESCE(MEDSYS_MSTEMPLOYEES.VNAME, MEDSYS_MSTCLINICSTAFFS.VNAME) AS VNAME'))
        ->leftjoin('MEDSYS_MSTEMPLOYEES', function ($join) { $join->on('MEDSYS_MSTEMPLOYEES.VUSRID', '=', 'MEDSYS_MSTUSERS.VUSRID')->where('MEDSYS_MSTEMPLOYEES.BACTIVE', '1'); })
        ->leftjoin('MEDSYS_MSTCLINICSTAFFS', 'MEDSYS_MSTCLINICSTAFFS.VUSRID', '=', 'MEDSYS_MSTUSERS.VUSRID')->get();

		return response()->json(['data' => $data]);
    }

    //==== Get data for Role Name lookup table
    public function getrolenamelookup(){
        $views = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS No, ROLEID, ROLEDESC FROM vw_getrole");

        return response()->json(['data' => $views]);
    }

    //==== Check if there is an active Role for the User
    private function CheckHasRole($user_id_)
    {
        $all = \DB::select("SELECT A.BACTIVE AS STATUS, A.VROLEID AS ROLEID, B.VNAME AS USERNAME, C.VNAME AS USERNAME, D.VSETDESC AS ROLENAME FROM MEDSYS_MSTUSERROLES A 
                            LEFT JOIN MEDSYS_MSTEMPLOYEES B ON B.VUSRID = A.VUSRID 
                            LEFT JOIN MEDSYS_MSTCLINICSTAFFS C ON C.VUSRID = A.VUSRID
                            LEFT JOIN MEDSYS_MSTSETTINGS D ON A.VROLEID = D.VSETCODE AND D.VSETID = 'ROLEUSER'
                            WHERE A.VUSRID = '$user_id_'
                            ");
        foreach($all as $data)
        {
            if($data->STATUS == "1") return $data;
        }

        return NULL;
    }
}
