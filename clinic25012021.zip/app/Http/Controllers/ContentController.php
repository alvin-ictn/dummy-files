<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use app\Mstcontent;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Str; 
use App\Exports\ContentExport;
use Maatwebsite\Excel\Facades\Excel;

class ContentController extends Controller
{

    public function ajax(Request $request)
    {
        $contents = \App\Mstcontent::all();
        $content = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY MONTH(A.DMODI) DESC,YEAR(A.DMODI) DESC,A.DMODI ASC) AS No,A.DMODI, A.VCONTENTCODE, A.VCONTENTNAME, A.VCONTENT, A.DPUBLISH, A.BACTIVE,(SELECT B.VNAME FROM MEDSYS_MSTEMPLOYEES B WHERE B.VUSRID=A.VMODI
        UNION
        SELECT B.VNAME FROM MEDSYS_MSTCLINICSTAFFS B
        WHERE B.VUSRID=A.VMODI) AS MODIFY_NAMES 
        FROM MEDSYS_MSTCONTENTS A WHERE format(getdate(),'yyyy-MM-dd') >= format(A.DPUBLISH,'yyyy-MM-dd')") ;

        return Datatables::of($content)
                ->addIndexColumn()
                ->filter(function ($instance) use ($request) {

                    if (!empty($request->get('date'))) {
                    
                        $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                            $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
                            return Str::contains($row['DMODI'], $dot) ? true : false;
                        
                        });
                    
                    }
                    if (!empty($request->get('publish'))) {
                    
                        $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                            $dot = Carbon::parse($request->get('DPUBLISH'))->format('d-M-Y');
                            return Str::contains($row['DPUBLISH'], $dot) ? true : false;
                        
                        });
                    
                    }
                    
                    // if (!empty($request->get('search'))) {
                    //     // search entire table
                    //     $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    //        $tmp_search = $request->get('search');  // inputed string in Search field
                    //        $column_names = ['No', 'VCONTENTCODE', 'VCONTENTNAME', 'VCONTENT','BACTIVE','MODIFY_NAMES', 'DMODI'];
                    //        for($i = 0; $i < count($column_names); $i++)
                    //        {
                    //           // Check if cell of $column_names[$i] contains $tmp_search
                    //           if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                    //        }
                    //        return false;
                    //     });
                    // }
                })
                ->addColumn('no', function($row){
                    return '';
                })
                ->addColumn('action', function($row){

                    return '<a class="btn btn-link btn-sm" href="content/edit/'.Crypt::encryptString($row->VCONTENTCODE).'" data-id="'.$row->VCONTENTCODE.'">'.$row->VCONTENTCODE.'</a>';

                })
                ->addColumn('VCONTENT',function($row){

                    return substr($row->VCONTENT, -0, 100);

                })
                ->addColumn('BACTIVE', function($row){

                    if($row->BACTIVE === '1'){

                        $return = 'Active';
                    }else{

                        $return = 'InActive';
                    }
                    return $return;

                })
                ->addColumn('modify_date', function($row){
                    return Carbon::parse($row->DMODI)->format('YmdHis');
                })
                ->addColumn('modif_date', function($row){
                    return Carbon::parse($row->DMODI)->format('d-M-Y H:i:s A');
                })
                ->addColumn('DPUBLISH', function($row){
                    return Carbon::parse($row->DPUBLISH)->format('d-M-Y H:i:s A');
                })
                ->addColumn('DPUBLISHS', function($row){
                    return Carbon::parse($row->DPUBLISH)->format('YmdHis');
                })
                ->rawColumns(['action','BACTIVE','no','VCONTENT'])
                ->make(true);
    }

    public function view(Request $request){
        $base = base64_decode($request->id);
        $content['content'] = MstContent::where('VCONTENTCODE','=',$base)->first();
        return response()->json($content);
    }

    public function update(Request $request)
    {
        //
        $Mstcont = \App\Mstcontent::where('VCONTENTCODE','=',$request->code);
        $Mstcont->update([
            'VCONTENTNAME' => $request->judul,
            'VCONTENT' => $request->deskripsi,
            'BACTIVE'  => $request->BACTIVEs,
            'DMODI'  => carbon::now(),
            'VCREA'  => Session::get('id'),
            'VMODI'  => Session::get('id'),
        ]);
        return response()->json(['success'], 200);
    }

    public function insert()
    {
        return view('home/content/add');
    }
    
    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'judul' => 'required|max:100',
            'deskripsi' => 'required',

        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        $code = rand() + 1;
        /// get dari model  
        $data =  new \App\MstContent();
        $data->VCONTENTCODE = $code;
        $data->VCONTENTNAME = $request->judul;
        $data->VCONTENT = $request->deskripsi;
        $data->DPUBLISH = carbon::parse(str_replace('/', '-', $request->publish_date))->format('Y-m-d');
        // $data->VGROUPUSR = Session::get('groupuser')[0];
        $data->BACTIVE = '1';
        $data->DMODI = Carbon::now();
        $data->VCREA = Session::get('id');
        $data->VMODI = Session::get('id');
        $data->save();
        return response()-> json(['success'], 200);
    }
    public function export(Request $request){
        if (!$request){
            $id = "";
            // $ids = DB::select("SELECT CLINICCODE, CLINICNAME, CLINICINIT, CLINIC_STATUS, CLINIC_AREA, STATUS, MODIFY_DATE, MODIFY_NAME FROM vw_mstclinic WHERE CLINICCODE LIKE '" . $base . "%' ");
            return   Excel::download(new ContentExport($id),'Content.xls');
            
        }else{
            $no = $request->nos;
            $cc = $request->cc; 
            $co = $request->co;
            $cname = $request->cname;
            $lmname = $request->lmname;
            $status = $request->status;
            if(!$request->modifiedt) $modifiedt = '';
            else $modifiedt = Carbon::parse($request->modifiedt)->format('d-M-Y');

            if(!$request->publish) $publish = '';
            else $publish = Carbon::parse($request->publish)->format('d-M-Y');
            $search = $request->search;

            // $ids = DB::select("SELECT CLINICCODE, CLINICNAME, CLINICINIT, CLINIC_STATUS, CLINIC_AREA, STATUS, MODIFY_DATE, MODIFY_NAME FROM vw_mstclinic WHERE CLINICCODE LIKE '" . $base . "%' ");
      
            return Excel::download(new ContentExport($no,$cc,$co,$cname,$lmname,$status,$modifiedt,$publish,$search),'Content.xls');
        }

    }
    public function edit($id)
    {
        $idc = Crypt::decryptString($id);
        $content = \App\Mstcontent::where('VCONTENTCODE',$idc)->first();

        return view('home/content/update', compact('content'));
    }
}
