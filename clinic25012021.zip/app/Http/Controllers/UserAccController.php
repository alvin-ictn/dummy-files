<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use app\Mstuseracc;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use Illuminate\Support\Facades\Crypt;

class UserAccController extends Controller
{
    public function  ajax(){

        $useraccs = \App\Mstuseracc::all();

        return Datatables::of($useraccs)
                ->addIndexColumn()
                
                ->addColumn('no', function($row){
                    return '';
                })
                ->addColumn('action', function($row){

                    return '<a class="btn btn btn-link btn-sm" href="useracc/edit/'.Crypt::encryptString($row->VUSRID).'" >'.$row->VUSRID.'</a>';

                })
                ->rawColumns(['action','no'])
                ->make(true);

    }
    
    public function insert(){

        return view('home/useraccess/add');
    }

    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'id' => 'required|max:50',
            'code' =>'required|max:5',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        /// get dari model  
        $data =  new \App\Mstuseracc();
        $data->VUSRID = $request->id;
        $data->VMENUCODE = $request->code;
        $data->DMODI = Carbon::now();
        $data->VCREA = Session::get('id');
        $data->VMODI = Session::get('id');
        $data->save();
        return response()-> json(['succsess'], 200);
    }
    
    public function edit($id){

        $ids = base64_decode($id);
        $acc = \App\Mstuseracc::where('VUSRID',$ids)->first();

        return view('home/useraccess/update',compact('acc'));
    }

    
    public function update(Request $request)
    {
        $useracc = \App\Mstuseracc::where('VUSRID','=',$request->id);
        
        $validator = Validator::make($request->all(), [
            'id' => 'required|max:50',
            'code' => 'required|max:5',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        $useracc->update([
            'VUSRID' => $request->id,
            'VMENUCODE' => $request->code,
                        
        ]);
        return response()->json(['succsess'], 200);
    }
}
