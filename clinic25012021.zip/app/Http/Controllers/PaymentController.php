<?php

namespace App\Http\Controllers;

use App\Exports\PaymentExport;
use Illuminate\Http\Request;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str;
use App\BillModel;
use App\BookingModel;
use App\PatientModel;
use App\Mstclinicstaffs;
use App\ClinicModel;
use Maatwebsite\Excel\Facades\Excel;

class PaymentController extends Controller
{
    public function ajax(Request $request){
		$VCLINICCODE = Session::get('cliniccode');
        if ($request->input('DFROM')=='')$StartDate=Carbon::now()->startofMonth()->format('Y-m-d');
        else $StartDate = Carbon::parse($request->DFROM)->format('Y-m-d');
        if ($request->input('DTO')=='')$EndDate=Carbon::now()->endofMonth()->format('Y-m-d');
        else $EndDate= Carbon::parse($request->DTO)->format('Y-m-d');
        $Type = $request->pattype;
        $sp = \DB::select("EXEC sp_PaymentList ?,?,?,?", array($VCLINICCODE,$StartDate,$EndDate,$Type));

        return Datatables::of($sp)
				->addIndexColumn()

                ->filter(function ($instance) use ($request)
                {
                    if (!empty($request->get('date_of_birth'))) {
                         // search Date of Birth
                        $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                           $inputfielddate = Carbon::parse($request->get('date_of_birth'))->format('d-M-Y');
                           $data_date = Carbon::parse($row['DBIRTH'])->format('d-M-Y');
                           return Str::contains($data_date, $inputfielddate) ? true : false;
                        });
                    }

                    if (!empty($request->get('last_visit_date'))) {
                        // search Last Visit Date
                        $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                            $inputfielddate = Carbon::parse($request->get('last_visit_date'))->format('d-M-Y');
                            $data_date = Carbon::parse($row['LASTVISITDATE'])->format('d-M-Y');
                            return Str::contains($data_date, $inputfielddate) ? true : false;
                        });
                    }

                    if (!empty($request->get('last_modified_date'))) {
                        // search Last Visit Date
                        $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                            $inputfielddate = Carbon::parse($request->get('last_modified_date'))->format('d-M-Y');
                            $data_date = Carbon::parse($row['DMODI'])->format('d-M-Y');
                            return Str::contains($data_date, $inputfielddate) ? true : false;
                        });
                    }

                    if (!empty($request->get('search')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							if (Str::contains(Str::lower($row['No']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VMRNO']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VBOOKINGNO']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DOCTOR']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VNAME']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VTYPEPATIENT']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DBIRTH']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['GENDER']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['LASTVISITDATE']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VPHONENO']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['STATUS']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['TOTAL']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VMODI']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DMODI']), Str::lower($request->get('search'))))
							{
								return true;
							}
							return false;
						});
					}
                })

				->addColumn('no', function($row){
					return $row->No;
				})
                ->addColumn('action', function($row){
                    return $row->VMRNO;
                })
                ->addColumn('dbirth', function($row){
                    return Carbon::parse($row->DBIRTH);
                })
                ->addColumn('lastvisitdate', function($row){
                    return Carbon::parse($row->LASTVISITDATE);
                })
                ->addColumn('dmodi', function($row){
                    return Carbon::parse($row->DMODI);
                })
                ->rawColumns(['no','action','dbirth','lastvisitdate','dmodi'])
				->make(true);
    }

	public function form($id = NULL)
	{
		$decoded_id = base64_decode($id);
        list($booking_no, $line_no) = explode(",", $decoded_id);

		$bills = BillModel::where('VBOOKINGNO',$booking_no)->get();
        $booking = BookingModel::where('VBOOKINGNO',$booking_no)->select('VMRNO', 'VNAME', 'BSTATUS')->first();
		$type = PatientModel::where('VMRNO', $booking->VMRNO)->select('VTYPEPATIENT')->first()->VTYPEPATIENT;
		return view('home/payment/form', compact('booking_no', 'booking'), ['bills' => $bills, 'type' => $type]);
    }
    
    public function print($id = NULL)
	{
		$decoded_id = base64_decode($id);
        list($booking_no, $line_no) = explode(",", $decoded_id);
        
		$bills = BillModel::where('VBOOKINGNO',$booking_no)->get();
        $booking = BookingModel::where('VBOOKINGNO',$booking_no)->select('VMRNO', 'VNAME', 'VDRID', 'VCLINICCODE', 'DVISIT')->first();
        $booking->DVISIT = Carbon::parse($booking->DVISIT)->format('d-M-Y');
        $doctor = Mstclinicstaffs::where('VUSRID',$booking->VDRID)->select('VNAME')->first()->VNAME;
        $clinic = ClinicModel::where('VCLINICCODE',$booking->VCLINICCODE)->select('VCLINICNAME')->first()->VCLINICNAME;
        return view('home/payment/printpay', compact('booking'), ['booking_no' => $booking_no, 'bills' => $bills, 'doctor' => $doctor, 'clinic' => $clinic]);
	}

	public function remove($id){

		$ida = base64_decode($id);
		list($booking_no, $line_no) = explode(",", $ida);

        // Delete selected data
        \DB::table('MEDSYS_BILLS')->where('ILINENO', $line_no)->where('VBOOKINGNO',$booking_no)->delete();
        
		return response()->json(['success'],200);
	}

	public function save(Request $request)
    {
        
        $last_ilineno = BillModel::where('VBOOKINGNO',$request->VBOOKINGNO)->max('ILINENO') + 1;    // for newly added row (if there is one)
        $booking = BookingModel::where('VBOOKINGNO',$request->VBOOKINGNO)->where('VMRNO',$request->VMRNO)->first();
        $booking->update(['BSTATUS' => 'D', 'VMODI' => Session::get('id'), 'DMODI' => Carbon::now()]);

        // Delete row when item is not redeemed
        if(isset($request->BREEDEEM))
        {
            foreach ($request->BREEDEEM as $key => $value) {
                if($request->BREEDEEM[$key] === '0'){
                    $r = str_replace('B', 'T', $request->VBOOKINGNO);
                    \DB::table('MEDSYS_INVMOVEDTLS')->where('VTRXNO', $r)->where('ILINENO', $key)->delete();
                    if(count(\DB::table('MEDSYS_INVMOVEDTLS')->where('VTRXNO', $r)->get()) == 0) \DB::table('MEDSYS_INVMOVEHDRS')->where('VTRXNO', $r)->where('VCLINICCODE', $booking->VCLINICCODE)->delete();
                }
                $data = BillModel::where('VBOOKINGNO',$request->VBOOKINGNO)->where('ILINENO',$key)->first();
                $data->BREEDEEM = $request->BREEDEEM[$key] ?? '0';
                $data->VMODI = Session::get('id');
                $data->DMODI = Carbon::now();	
                $data->save();
            }
        }
        
        // When added a new row(with [NEW]) or edit a row(with [EDIT])
        if(isset($request->VITEMNAME))
        {
            for($x = 0; $x < count($request->VITEMNAME); $x++){
                if($request->ILINENO[$x] == "[NEW]") $data = new BillModel();	// Add a new row
                else {  // Edit existing row
                    $data = BillModel::where('VBOOKINGNO',$request->VBOOKINGNO)->where('ILINENO',$request->ILINENO[$x])->first();
                    $data->DMODI = Carbon::now();			
                }
    
                // add new row to table
                if($data->VREMARKS == ""){
                    $data->ILINENO = $last_ilineno;             
                    $data->VBOOKINGNO = $request->VBOOKINGNO;
                    $data->VTYPE = $request->VTYPE;
                    $data->VREMARKS = "[EDIT]";
                    $data->VCREA = Session::get('id');
                    
                    $last_ilineno++; // increament for next newly added row (if there's still more)
                }
    
                $data->VITEMNAME = $request->VITEMNAME[$x];
                $data->IQTY = $request->qty[$x];
                $data->NPRICE = $request->price[$x];
                $data->VMODI = Session::get('id');
    
                $data->save();
            }
        }

		return response()->json(['success'], 200);
    }
    
	public function export_excel(Request $request)
	{
        if (!$request)
		{
			return Excel::download(new PaymentExport(""), 'Payment List.xls');
        }
		else
		{
            // $clinic_code = Session::get('cliniccode');
            // if ($request->input('DFROM')=='')$start_date=Carbon::now()->startofMonth()->format('Y-m-d');
            // else $start_date = Carbon::parse($request->DFROM)->format('Y-m-d');
            // if ($request->input('DTO')=='')$end_date=Carbon::now()->endofMonth()->format('Y-m-d');
            // else $end_date= Carbon::parse($request->DTO)->format('Y-m-d');
            // $type = $request->pattype;

			$clinic_code = Session::get('cliniccode');
			$start_date = $request->start_date;
			$end_date = $request->end_date;
			$type = $request->type;
			$no = $request->no;
            $mr_no = $request->mr_no;
            $booking_no = $request->booking_no;
			$doctor = $request->doctor;
            $patient_name = $request->patient_name;
            $patient_type = $request->patient_type;
			$date_of_birth = $request->date_of_birth;
            $gender = $request->gender;
            $last_visit_date = $request->last_visit_date;
            $phone_no = $request->phone_no;
			$status = $request->status;
			$total = $request->total;
			$last_modified_name = $request->last_modified_name;
			$last_modified_date = $request->last_modified_date;
            $search = $request->search;
			
			return Excel::download(new PaymentExport($clinic_code, $start_date, $end_date, $type, $no, $mr_no, $booking_no, $doctor, $patient_name, $patient_type, $date_of_birth, $gender, $last_visit_date, $phone_no, $status, $total, $last_modified_name, $last_modified_date, $search), 'Payment List.xls');
        }
    }
}
