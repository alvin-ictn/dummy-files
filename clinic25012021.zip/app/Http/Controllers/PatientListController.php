<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use App\Exports\PatientListExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use PDF;

class PatientListController extends Controller
{
    //==== Ajax
    public function ajax(Request $request){
        $VCLINICCODE = Session::get('cliniccode');
        if($VCLINICCODE == '') $VCLINICCODE = 'HO';
        if($VCLINICCODE == ''){
            $VSURID = 'ALL';
        }else{
            $VSURID = Session::get('id');

        } 

        if($_GET['DFROM'] != null) $DFROM = Carbon::parse($_GET['DFROM'])->format('Y-m-d');
        else $DFROM = Carbon::now()->startofMonth()->format('Y-m-d'); 
        if($_GET['DTO'] != null)  $DTO =  Carbon::parse($_GET['DTO'])->format('Y-m-d');
        else $DTO = Carbon::now()->endOfMonth()->format('Y-m-d'); 
        // return response()->json([$DTO], 400);   // DEBUG
        $sp = \DB::select("EXEC sp_PatientList ?,?,?,?", array($VCLINICCODE, $DFROM, $DTO, $VSURID));
        
                return Datatables::of($sp)
                ->addIndexColumn()

                 ->filter(function ($instance) use ($request)
                 {
                     if (!empty($request->get('datebirth'))) {
                         // search Date of Birth
                         $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                             $inputfield_date = Carbon::parse($request->get('datebirth'))->format('d-M-Y');
                             $data_date = Carbon::parse($row['DBIRTH'])->format('d-M-Y');
                             return Str::contains($data_date, $inputfield_date) ? true : false;
                         });
                     }

                     if (!empty($request->get('lvdate'))) {
                        // search Last Visit Date
                        $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                            $inputfield_date = Carbon::parse($request->get('lvdate'))->format('d-M-Y');
                            $data_date= Carbon::parse($row['LASTVISITDATE'])->format('d-M-Y');
                            return Str::contains($data_date, $inputfield_date) ? true : false;
                        });
                     }

                     if (!empty($request->get('search'))) {
                         // search entire table
                         $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                            $tmp_search = $request->get('search');  // inputed string in Search field
                            $column_names = ['VMRNO', 'VNAME', 'DBIRTH', 'GENDER', 'LASTVISITDATE', 'VPHONENO', 'DOCTOR'];
                            for($i = 0; $i < count($column_names); $i++)
                            {
                               // Check if cell of $column_names[$i] contains $tmp_search
                               if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                            }
                            return false;
                         });
                     }
                 })

                ->addColumn('no', function($row){
                    return $row->No;
                })
                ->addColumn('ADMIN_ACTION', function($row){
                    if(Session::get('groupuser')[0] == 'ADM') return '<a data-id="'.$row->VMRNO.'" title="Upload Attachment" href="/account/booking/patientinfo/'.base64_encode($row->VBOOKINGNO.'#ptntlst').'#uplddoc"><i class="fa-paperclip fas"></i></a>';
                    else return '';
                })
                ->addColumn('action', function($row){
                    // $null['link'] = base64_encode($row->VBOOKINGNO); 
                    // $null['vmrno'] = $row->VMRNO;
                    return $row->VMRNO;
                })
                ->addColumn('dbirth', function($row){
                    return Carbon::parse($row->DBIRTH)->format('Ymd');
                })
                ->addColumn('lastvisitdate', function($row){
                    return Carbon::parse($row->LASTVISITDATE)->format('Ymd');
                })
                ->rawColumns(['ADMIN_ACTION', 'action', 'dbirth'])
                ->make(true);
           
       
      
    }

    //==== Form for uploading attachment
    public function form($code_ = NULL){
        // Editing an existing schedule
        if($code_ != NULL){
            $code = base64_decode($code_);
                                         
            return view('home/bookingsch/attachmentform', ['code' => $code]);
        }
        // Adding a new schedule
        else{
            return view('home/bookingsch/attachmentform');
        }
    }

    //==== Export index table to excel file
	public function export_excel(Request $request){
        if(!$request){
            $tmp = "";
            return Excel::download(new PatientListExport($tmp),'PatientList.xls');
        }
        else{
            $clinic_code = Session::get('cliniccode');
            if($clinic_code == '') $clinic_code = 'HO';
            
        if($request->start_date != null) $start_date = $request->start_date;
        else $start_date = Carbon::now()->startofMonth()->format('Y-m-d'); 
        if($request->end_date != null) $end_date = $request->end_date;
        else $end_date = Carbon::now()->endOfMonth()->format('Y-m-d'); 

            if($clinic_code == '')$user_id = 'ALL';
            else $user_id = Session::get('id');
            $no = $request->no;
            $mrno = $request->mrno;
            $patientname = $request->patientname;
            if(!$request->datebirth) $datebirth = '';     
            else $datebirth = Carbon::parse($request->datebirth)->format('d-M-Y');
            $gender = $request->gender;
            if(!$request->lvdate) $lvdate = '';
            else $lvdate = Carbon::parse($request->lvdate)->format('d-M-Y');
            $phoneno = $request->phoneno;
            $doctor = $request->doctor;
            $search = $request->search;
// return response()->json([$clinic_code,$start_date,$end_date,$user_id,$no,$mrno,$patientname,$datebirth,$gender,$lvdate,$phoneno,$doctor,$search],400);
            return Excel::download(new PatientListExport($clinic_code,$start_date,$end_date,$user_id,$no,$mrno,$patientname,$datebirth,$gender,$lvdate,$phoneno,$doctor,$search),'PatientList.xls');
        }
    }

    //==== Convert DOC file to PDF
    public function DocToPDFConverter()
    {
        $domPdfPath = base_path('vendor/dompdf/dompdf');

        \PhpOffice\PhpWord\Settings::setPdfRendererPath($domPdfPath);
        \PhpOffice\PhpWord\Settings::setPdfRendererName('DomPDF');

        // Load word file
        $Content =  \PhpOffice\PhpWord\IOFactory::load('C:\xampp\htdocs\clinic\public\healthcertificate.docx', 'Word2007');
        // Save it into PDF
        $PDFWriter = \PhpOffice\PhpWord\IOFactory::createWriter($Content,'PDF');
        
        $PDFWriter->save('document.pdf');

        // $domPdfPath = base_path('vendor/dompdf/dompdf');
        // \PhpOffice\PhpWord\Settings::setPdfRendererPath($domPdfPath);
        // \PhpOffice\PhpWord\Settings::setPdfRendererName('DomPDF');
        // //Load word file
        // $Content = \PhpOffice\PhpWord\IOFactory::load('C:\xampp\htdocs\clinic\public\Untitled document.docx'); 
        // //Save it into PDF
        // $PDFWriter = \PhpOffice\PhpWord\IOFactory::createWriter($Content,'PDF');
        // // return response()->json($Content, 400);
        // // dd($PDFWriter);
        // $PDFWriter->save('result.pdf'); 
    }
}
