<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use app\Mstsettings;
use App\Mstdrugs;
use app\Mstdrugslogs;
use app\Mstgnrl;
use App\MEDSYS_ICDDIAGNOSIS;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str;
use App\Exports\DrugsExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use DB;

class DrugsController extends Controller
{

    public function ajax(Request $request){

        $docts = \App\Mstdrugs::all();
        $view = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY MONTH(MODIFY_DATE) DESC,YEAR(MODIFY_DATE) DESC,MODIFY_DATE ASC) AS No, 
        a.DRUGS_CODE, a.DRUGS_CONTAIN, a.DRUGS_BRAND, a.DRUGS_VENDOR, a.DRUGS_UOM, a.DRUGS_PRICE, a.PBF_TYPE, a.STATUS, a.MODIFY_DATE, a.MODIFY_NAME, b.VGNRLDESC AS DRUGS_TYPE, c.VGNRLDESC AS UOM_DESC
        FROM vw_mstdrugs a
        LEFT JOIN MEDSYS_MSTGENERALS b ON a.DRUGS_TYPE = b.VGNRLCODE AND b.VGNRLTYPE = 'DRUGSTYPE'
        LEFT JOIN MEDSYS_MSTGENERALS c ON a.DRUGS_UOM = c.VGNRLCODE AND c.VGNRLTYPE = 'MSUREUNIT'");
        return Datatables::of($view)
            ->addIndexColumn()
            ->filter(function ($instance) use ($request) {
                if (!empty($request->get('date'))) {
                
                    $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                        $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
                        return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                    
                    });
                
                }
                if (!empty($request->get('search'))) {
                    // search entire table
                    $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                        $tmp_search = $request->get('search');  // inputed string in Search field
                        $column_names = ['No', 'DRUGS_CODE', 'DRUGS_TYPE', 'DRUGS_CONTAIN', 'DRUGS_BRAND', 'DRUGS_VENDOR', 'DRUGS_UOM', 'DRUGS_PRICE', 'PBF_TYPE', 'STATUS', 'MODIFY_NAME', 'MODIFY_DATE'];
                        for($i = 0; $i < count($column_names); $i++)
                        {
                            // Check if cell of $column_names[$i] contains $tmp_search
                            if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                        }
                        return false;
                    });
                }
            })
            ->addColumn('no', function($row){
                return $row->No;
            })
            ->addColumn('action', function($row){
                if(RoleAccessController::FunctionAccessCheck('U', 'F13')) return $row->DRUGS_CODE;
                else return null;
            })
            ->addColumn('DRUGS_PRICE', function($row){
                return number_format($row->DRUGS_PRICE, 2, '.', ',');
            })
            ->addColumn('modify_date', function($row){
                return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
            })
            ->rawColumns(['action','no'])
            ->make(true);
    }

    public function insert(){

        $pbf = \App\Mstsettings::select('VSETDESC','VSETCODE')->where('VSETID','=','PRMPBF')->get();
        $uom = \App\Mstgnrl::select('VGNRLCODE', 'VGNRLDESC')->where('VGNRLTYPE', '=', 'MSUREUNIT')->orderby('VGNRLDESC')->get();

        return view('home/drugs/add',['pbf'=>$pbf, 'uom'=>$uom]);
    }

    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'VDRUGSTYPE' =>'required|max:20',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        // Check if data with current inputted Drugs Type, Contain, Brand is exist
        $is_exists = $this->CheckTypeContainBrandExists($request->VDRUGSTYPE, $request->cont, $request->brand);
        if($is_exists) return response()->json(['error'=>"Data with current inputted Drugs Type, Contain, and Brand is already exists!"], 400);

        $countjax = DB::select(DB::raw("SELECT COUNT(*) AS NLASTNO FROM MEDSYS_MSTDRUGS"))[0];
        $datenow = carbon::now();

        $years =  $datenow->format('Y');
        $months = $datenow->format('m');
        $dayu = $datenow->format('d');

        $stringds = substr($years,2);
        $stringm = substr($months, 0, 2);
        // $stringds = subasstr($years, 0, 2);
        $stringd = substr($dayu, 0, 2);
        $jumlah = $countjax->NLASTNO + 1;
        $count1 =  str_pad($jumlah, 4, '0', STR_PAD_LEFT);

        $nodrug  = $stringds . $stringm . $dayu . $count1;

        /// get dari model  
        DB::table('MEDSYS_MSTDRUGS')->insert([
            'VDRUGSCODE' => $nodrug,
            'VDRUGSTYPE' => $request->VDRUGSTYPE,
            'VCONTAIN' => $request->cont,
            'VBRAND' => $request->brand,
            'VPHARMACY' => $request->pharmacy,
            'VUOM' => $request->uom,
            'NPRICE' => str_replace(",",'',$request->NPRICE),
            'PBF' =>  $request->pbf,
            'BACTIVE' => '1',
            'VCREA' => session::get("id"),
            'VMODI' => session::get("id"),
        ]);

        DB::table('MEDSYS_MSTDRUGLOGS')->insert([
            'VDRUGSCODE' => $nodrug,
            'VDRUGSTYPE' => $request->VDRUGSTYPE,
            'VCONTAIN' => $request->cont,
            'VBRAND' => $request->brand,
            'VPHARMACY' => $request->pharmacy,
            'VUOM' => $request->uom,
            'NPRICE' => str_replace(",",'',$request->NPRICE),
            'PBF' =>  $request->pbf,
            'BACTIVE' => '1',
            'VUSER' => session::get("id"),
        ]);

        return response()-> json(['succsess'], 200);
    }

    public function update(Request $request)
    {
        $drugsel = \App\Mstdrugs::where('VDRUGSCODE','=',$request->code);
        $drugsel1 = \App\Mstdrugslogs::where('VDRUGSCODE','=',$request->code);
        
        $validator = Validator::make($request->all(), [
            'VDRUGSTYPE' =>'required|max:20',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {
            return response()->json($error, 400);
        }
        DB::table('MEDSYS_MSTDRUGS')->where('VDRUGSCODE', $request->code)->update([
            'VDRUGSCODE' => $request->code,
            'VDRUGSTYPE' => $request->VDRUGSTYPE,
            'VCONTAIN' => $request->cont,
            'VBRAND' => $request->brand,
            'VPHARMACY' => $request->pharmacy,
            'VUOM' => $request->uom,
            'NPRICE' => str_replace(",",'',$request->rp),
            'BACTIVE'  => $request->BACTIVEs,
            'PBF'  => $request->pbf,
            'DMODI'  => carbon::now(),
            'VMODI'  => Session::get('id'),
        ]);
        
        $drugsel1->insert([
            'VDRUGSCODE' => $request->code,
            'VDRUGSTYPE' => $request->VDRUGSTYPE,
            'VCONTAIN' => $request->cont,
            'VBRAND' => $request->brand,
            'VPHARMACY' => $request->pharmacy,
            'VUOM' => $request->uom,
            'NPRICE' => str_replace(",",'',$request->rp),
            'BACTIVE'  => $request->BACTIVEs,
            'PBF'  => $request->pbf,
            'VUSER' => session::get("id"),

        ]);
        return response()->json(['succsess'], 200);
    }
    
    public function edit($id){

        $ids = base64_decode($id);
        $drugs = \DB::select(" SELECT * FROM MEDSYS_MSTDRUGS A 
        LEFT JOIN MEDSYS_MSTGENERALS B ON B.VGNRLTYPE = 'DRUGSTYPE' AND B.VGNRLCODE = A.VDRUGSTYPE
        WHERE A.VDRUGSCODE = '$ids' ")[0];
        $pbf1 = \App\Mstsettings::where('VSETID','=','PRMPBF')->get();
        $pbf = \App\Mstsettings::where('VSETID','=','PRMPBF')->where('VSETCODE',$drugs->PBF)->where('BACTIVE','=','1')->first();
        $uom = \App\Mstgnrl::select('VGNRLCODE', 'VGNRLDESC')->where('VGNRLTYPE', '=', 'MSUREUNIT')->orderby('VGNRLDESC')->get();

        return view('home/drugs/update',['pbf1'=>$pbf1],compact('drugs','pbf','uom'));
    }

    public function getdrugslookup()
	{
        $db = \App\Mstgnrl::select('VGNRLCODE','VGNRLDESC')->where('VGNRLTYPE', '=','DRUGSTYPE')->where('BACTIVE','=','1')->get();

		return response()->json(['data' => $db]);
    }
    public function getdrugslookup1($id = NULL)
	{


         $VCLINICCODE = $id; 
         $ASOFDATE = date("Y-m-d"); 

        //  return response()->json([$VCLINICCODE, $ASOFDATE], 400); // DEBUG
         $sp = \DB::select("EXEC sp_ItemBalance ?,?", array($VCLINICCODE,$ASOFDATE));
        //  $db = db::select("SELECT a.DRUGS_CODE, a.DRUGS_CONTAIN, a.DRUGS_BRAND, a.DRUGS_VENDOR, a.DRUGS_UOM, a.DRUGS_PRICE, a.PBF_TYPE, a.STATUS, a.MODIFY_DATE, a.MODIFY_NAME, b.VGNRLDESC AS DRUGS_TYPE
        //  FROM vw_mstdrugs a
        //  LEFT JOIN MEDSYS_MSTGENERALS b ON a.DRUGS_TYPE = b.VGNRLCODE WHERE b.VGNRLTYPE = 'DRUGSTYPE' AND a.STATUS = 'Active'");

           return Datatables::of($sp)
           ->addIndexColumn()

           ->make(true);

    }

    public function getdrugslookupexamination($id = NULL){

        $VCLINICCODE = $id; 
        $ASOFDATE = date("Y-m-d"); 

       //  return response()->json([$VCLINICCODE, $ASOFDATE], 400); // DEBUG
        $sp = \DB::select("EXEC sp_ItemBalance ?,?", array($VCLINICCODE,$ASOFDATE));


       //  $db = db::select("SELECT a.DRUGS_CODE, a.DRUGS_CONTAIN, a.DRUGS_BRAND, a.DRUGS_VENDOR, a.DRUGS_UOM, a.DRUGS_PRICE, a.PBF_TYPE, a.STATUS, a.MODIFY_DATE, a.MODIFY_NAME, b.VGNRLDESC AS DRUGS_TYPE
       //  FROM vw_mstdrugs a
       //  LEFT JOIN MEDSYS_MSTGENERALS b ON a.DRUGS_TYPE = b.VGNRLCODE WHERE b.VGNRLTYPE = 'DRUGSTYPE' AND a.STATUS = 'Active'");
        $data = array();
        foreach ($sp AS $key => $val)
        {

                if ($val->STOCK <= 0)
                {

                }
                else
                {
                    $data[] = $val;

                }
            

        }
          return Datatables::of($data)
          ->addIndexColumn()

          ->make(true);

    }
    public function itemiuses($id){
        $ids = base64_decode($id);
        $db = db::select("SELECT  a.DRUGS_CODE, a.DRUGS_CONTAIN, a.DRUGS_BRAND,c.VGNRLDESC, a.DRUGS_VENDOR, a.DRUGS_UOM, a.DRUGS_PRICE, a.PBF_TYPE, a.STATUS, a.MODIFY_DATE, a.MODIFY_NAME, b.VGNRLDESC AS DRUGS_TYPE, c.VGNRLDESC AS UOM_DESC
        FROM vw_mstdrugs a
        LEFT JOIN MEDSYS_MSTGENERALS b ON a.DRUGS_TYPE = b.VGNRLCODE AND b.VGNRLTYPE = 'DRUGSTYPE'
        LEFT JOIN MEDSYS_MSTGENERALS c ON a.DRUGS_UOM = c.VGNRLCODE AND c.VGNRLTYPE = 'MSUREUNIT'
        WHERE b.VGNRLTYPE = 'DRUGSTYPE' AND a.STATUS = 'Active' AND a.DRUGS_CODE = '".$ids."' ");
        

		return response()->json(['data' => $db]);
    }
    public function geticddiagnosislookup(){

        $db = MEDSYS_ICDDIAGNOSIS::select('VDXCODE','VDXNAME')->get();
        
		return response()->json(['data' => $db]);

    }
	public function export_excel(Request $request)
	{
        if(!$request){

            $id = "";
            return Excel::download(new DrugsExport($id),'Drugs.xls');

        }else{
            $no = $request->no;
            $drugscode = $request->drugscode;
            $drugstype = $request->drugstype;
            $contain = $request->contain;
            $brand = $request->brand;
            $vendor = $request->vendor;
            $uom = $request->uom;
            $price = $request->price;
            $pbf = $request->pbf;
            $status = $request->status;
            $lmname = $request->lmname;
            
            if(!$request->lmdate)$lmdate = '';
            else$lmdate = Carbon::parse($request->lmdate)->format('d-M-Y');
            
            $search = $request->search;

            return Excel::download(new DrugsExport($no,$drugscode,$drugstype,$contain,$brand,$vendor,$uom,$price,$pbf,$status,$lmname,$lmdate,$search),'Drugs.xls');

        }
    }

    //==== Check if data with current inputted Drugs Type, Contain, Brand is exist
    public function CheckTypeContainBrandExists($_type, $_contain, $_brand)
    {
        $select = Mstdrugs::where("VDRUGSTYPE", $_type)->where("VCONTAIN", $_contain)->where("VBRAND", $_brand)->get();
        if(count($select) == 0) return false;
        else return true;
    }
}
