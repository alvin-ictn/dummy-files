<?php

namespace App\Http\Controllers;

use App\Mstclinicstaffs;
use App\Mstemployees;
use App\Mstsettings;
use App\Mstusers;
use App\Pwdhists;
use Hash;
use Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class MyProfileController extends Controller
{
    public function index()
    {
		$prmchar = Mstsettings::select('VSETDESC')->where('VSETID', 'PRMIT')->where('VSETCODE', 'CHAR')->first()->VSETDESC;
		if (Session::get('typeuser') == "E")
		{
			$user = DB::select("SELECT VEMPSAPID, VNAME, A.VUSRID, VUSRFLAG, G.VSETDESC VTYPEUSR, VMAIL, VDEPTHEADMAIL, VGNDRCODE, FORMAT (DBIRTH, 'dd-MM-yyyy') DBIRTH, I.VGNRLDESC VJOBPOSITION, J.VGNRLDESC VJOBAREA, VADDRESS, VPHONENO, CONCAT(C.VPRSNLAREACODE, ' - ', VPRSNLNAME) VPRSNL, CONCAT(H.VSUBPRSNLAREACODE, ' - ', VSUBPRSNLNAME) VSUBPRSNL, CONCAT(D.VCOSTCNTRCODE, ' - ', VCOSTCNTRNAME) VCOSTCNTR, COALESCE(B.VPACKAGECODE, E.VPACKAGECODE) VPACKAGECODE,K.VPCKGNAME, FORMAT (DHIRE, 'dd-MM-yyyy') DHIRE, F.VSETDESC VEMPTYPE, CASE WHEN BUSRLOCK = 1 THEN '1' WHEN A.BACTIVE = 1 THEN '2' END STATUS, BOTHERS
								FROM MEDSYS_MSTUSERS A
								LEFT JOIN MEDSYS_MSTEMPLOYEES B ON A.VUSRID = B.VUSRID AND B.BACTIVE = 1
								LEFT JOIN MEDSYS_MSTPERSONELAREAS C ON B.VPRSNLAREACODE = C.VPRSNLAREACODE
								LEFT JOIN MEDSYS_MSTCOSTCENTERS D ON B.VCOSTCNTRCODE = D.VCOSTCNTRCODE
								LEFT JOIN MEDSYS_MSTCOSTCENTERPACKAGES E ON D.VCOSTCNTRCODE = E.VCOSTCNTRCODE AND E.BACTIVE = 1
								LEFT JOIN MEDSYS_MSTPACKAGES K ON K.VPCKGCODE = E.VPACKAGECODE
								LEFT JOIN MEDSYS_MSTSETTINGS F ON B.VEMPTYPE = F.VSETCODE AND F.VSETID = 'EMPTYPE'
								LEFT JOIN MEDSYS_MSTSETTINGS G ON A.VTYPEUSR = G.VSETCODE AND G.VSETID = 'TYPEUSER'
								LEFT JOIN MEDSYS_MSTSUBPERSONELAREAS H ON B.VSUBPRSNLAREACODE = H.VSUBPRSNLAREACODE AND B.VPRSNLAREACODE = H.VPRSNLAREACODE AND H.BACTIVE = 1
								LEFT JOIN MEDSYS_MSTGENERALS I ON B.VJOBPOSITION = I.VGNRLCODE AND I.VGNRLTYPE = 'JOBPOSITION' AND I.BACTIVE = 1
								LEFT JOIN MEDSYS_MSTGENERALS J ON B.VJOBAREA = J.VGNRLCODE AND J.VGNRLTYPE = 'JOBAREA' AND J.BACTIVE = 1
								WHERE A.VUSRID = ?", [Session::get('id')])[0];
			$members = DB::select("SELECT B.VRELNAME, E.VSETDESC VRELATION, C.VSETDESC VRELGENDER, FORMAT (B.DRELBIRTH, 'dd-MM-yyyy') DRELBIRTH, B.VRELCTRYBIRTH, B.VRELCITYBIRTH, B.VBPJSNO, B.VJHTNO
									FROM MEDSYS_MSTUSERS A
									-- LEFT JOIN MEDSYS_MSTEMPMEMBERS B ON A.VUSRID = B.VUSRID
									LEFT JOIN MEDSYS_MSTEMPLOYEES D ON A.VUSRID = D.VUSRID
        							JOIN MEDSYS_MSTEMPMEMBERS B ON D.VEMPSAPID = B.VEMPSAPID
									LEFT JOIN MEDSYS_MSTSETTINGS E ON B.VRELATION = E.VSETCODE AND E.VSETID = 'RELATION'

									LEFT JOIN MEDSYS_MSTSETTINGS C ON B.VRELGENDER = C.VSETCODE AND C.VSETID = 'GENDER'
									WHERE D.VUSRID = ?
									ORDER BY ILINE", [Session::get('id')]);
			return view('home/myprofile/profile', ['user' => $user, 'members' => $members, 'prmchar' => $prmchar]);
		}
		elseif (Session::get('typeuser') == "NE")
		{
			$user = DB::select("SELECT VNAME, A.VUSRID, VUSRFLAG, VIDCARDNO, VMAIL, VGNDRCODE, FORMAT (DBIRTH, 'dd-MM-yyyy') DBIRTH, VADDRESS, VPHONENO, CASE WHEN BUSRLOCK = 1 THEN '1' ELSE '2' END STATUS
								FROM MEDSYS_MSTUSERS A
								LEFT JOIN MEDSYS_MSTCLINICSTAFFS B ON A.VUSRID = B.VUSRID
								WHERE A.VUSRID = ?", [Session::get('id')])[0];
			return view('home/myprofile/profile', ['user' => $user, 'prmchar' => $prmchar]);
		}
    }
	
	public function changepassword(Request $request)
	{
		$users = Mstusers::where('VUSRID', Session::get('id'));
		$user = $users->first();
		$message = '';
		if (!Hash::check($request->old, $user->VUSRPASS))
		{
			$message = 'Incorrect Old Password !';
		}
		else
		{
			if (Pwdhists::where('VUSRID', $user->VUSRID)->doesntExist())
			{
				$pwd = new Pwdhists();
				$pwd->VUSRID = Session::get('id');
				$pwd->VUSRPASS = $user->VUSRPASS;
				$pwd->VMODI = $user->DCREA;
				$pwd->save();
			}
			$check = parent::check_old_password(Session::get('id'), $request->new);
			if ($check[1] != '')
			{
				$message = $check[1];
			}
			if ($check[0])
			{
				$salt = bcrypt($request->new);
				DB::beginTransaction();
				try
				{
					$users->update([
						'VUSRPASS' => $salt
					]);
					parent::set_user_log($user);
					$pwd = new Pwdhists();
					$pwd->VUSRID = Session::get('id');
					$pwd->VUSRPASS = $salt;
					$pwd->save();
					DB::commit();
				}
				catch (\Exception $e)
				{
					DB::rollBack();
					$message = $e->errorInfo[2];
				}
			}
		}
		return response()->json($message);
    }
	
	public function update(Request $request)
	{
		$user_id = Session::get('id');
		$user = Mstusers::where('VUSRID', $user_id);
		if (Session::get('typeuser') == "E")
		{
			$emp = Mstemployees::where('VUSRID', $user_id)->where('BACTIVE', '1');
		}
		elseif (Session::get('typeuser') == "NE")
		{
			$emp = Mstclinicstaffs::where('VUSRID', $user_id);
		}
		DB::beginTransaction();
		try
		{
			$empUpdate = array("VMAIL" => $request->VMAIL, "VADDRESS" => $request->VADDRESS, "VPHONENO" => $request->VPHONENO);
			
			if (Session::get('typeuser') == "E")
			{
				// if changing the User ID
				if($request->VUSRID != $user_id)
				{
					// only update the User ID if LDAP authenticated
					//----LDAP Authentication
					$LDAP_AUTHENTICATED = false;
					
					// LDAP information
					$domain 			  = env('LDAP_DOMAIN');
					$ldap_username		  = env('LDAP_USERNAME');
					$ldap_password		  = env('LDAP_PASSWORD');
					$ldapconfig['host']   = env('LDAP_HOST');
					$ldapconfig['basedn'] = 'DC='.$domain.',DC=com';

					// Connect to LDAP
					$ldap = ldap_connect($ldapconfig['host']);
					ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
					ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);
					
					// Bind to LDAP
					try{
						$bind = ldap_bind($ldap, $domain ."\\".$ldap_username, $ldap_password);
						if ($bind) {
							$filter = "(sAMAccountName=".$request->VUSRID.")";
							$attributes = array("name", "telephonenumber", "mail", "samaccountname");
    						$result = ldap_search($ldap, $ldapconfig['basedn'], $filter, $attributes);
							$entries = ldap_get_entries($ldap, $result);  
							if(count($entries) == 1) $LDAP_AUTHENTICATED = true;
							else if(count($entries) == 0)
							{
								$response['error'] = "Wrong credential!";
								return response()->json($response, 400);
							}
							else
							{
								$response['error'] = "[ERROR] Possible duplicate User ID at LDAP/AD server!";
								return response()->json($response, 400);
							}
						} 
						else 
						{
							$response['error'] = "Failed to bind to LDAP server";
							return response()->json($response, 400);
						}
					}catch(\Exception $e){
						$response['error'] = "Failed to bind to LDAP server";
						return response()->json($response, 400);
					}

					// Close connection
					ldap_close($ldap);

					if($LDAP_AUTHENTICATED) $user_id = $request->VUSRID;	// set to change User ID

					$empUpdate["VUSRID"] = $user_id;

					// Update Master User Role
					$userrole = \App\Mstuserrole::where('VUSRID','=',Session::get('id'))->where('VROLEID','=',$user->first()->VGROUPUSR);
					$userrole->update(['VUSRID' => $user_id]);
				}

				$empUpdate["VDEPTHEADMAIL"] = $request->VDEPTHEADMAIL;
			}
			elseif (Session::get('typeuser') == "NE")
			{
				$empUpdate["VIDCARDNO"] = $request->VIDCARDNO;
			}

			$emp->update($empUpdate);
			$user->update([
				'VUSRID' => $user_id,
				'VUSRFLAG' => $request->VUSRFLAG
			]);
			$user = Mstusers::where('VUSRID', $user_id);	// Because ID Changed, to prevent set_user_log from failing to execute
			parent::set_user_log($user->first());
			DB::commit();
		}
		catch (\Exception $e)
		{
			DB::rollBack();
			if(isset($e->errorInfo))
			{
				if (strpos($e->errorInfo[2], "The duplicate key value is") !== FALSE)
				{
					$response['error'] = "User ID (" . $request->VUSRID . ") already exist";
					return response()->json($response, 400);
				}
				else
				{
					$response['error'] = $e->errorInfo[2];
					return response()->json($response, 400);
				}
			}
		}
		Session::put('id', $request->VUSRID);
		return response()->json(['success'], 200);
    }
}
