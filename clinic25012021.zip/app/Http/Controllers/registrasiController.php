<?php

namespace App\Http\Controllers;

use App\Doclists;
use App\Mstclinicstaffs;
use App\Mstcostcenter;
use App\Mstemployees;
use App\Mstempmembers;
use App\Mstgnrl;
use App\Mstpersonelareas;
use App\Mstsettings;
use App\Mstsubpersonelareas;
use App\Mstusers;
use App\Pwdhists;
use Carbon\Carbon;
use DataTables;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;
use Session;
use App\Exports\UsersExport;
use Maatwebsite\Excel\Facades\Excel;
use app\Mstpackages;

class RegistrasiController extends Controller
{
	public function store(Request $request)
    {
        //
        $salt = bcrypt($request->password);

        /// get dari model  
        $data =  new Mstusers();
        $data->VUSRFLAG = $request->VUSRFLAG;
        $data->VTYPEUSR = $request->typeuser;
     
        $data->VUSREMAIL = $request->emailuser;
        $data->VUSRNAME = $request->namauser;
        $data->VUSRID = $request->kodeuser;
		$data->VUSRPASS = $salt;
		$data->VMODI = Session::get('id');
		$data->DMODI = Carbon::now();
        $data->save();
		
		$pwd = new Pwdhists();
		$pwd->VUSRID = $request->kodeuser;
		$pwd->VUSRPASS = $salt;
		$pwd->save();
		
        return response()->json(['success'], 200);
    }

    public function show()
    {
		return view('home/users/index');
	}

    public function ajax(Request $request)
	{
		$usersel = DB::select("SELECT * FROM vw_mstuser");
		$views = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY MONTH(MODIFY_DATE) DESC,YEAR(MODIFY_DATE) DESC,MODIFY_DATE ASC) AS No, USERID, USERGROUP, USERNAME, USERMAIL, POSNAME, DRTYPE, SPCNAME, USERTYPE, LOGINDATE, STATUSKICK, STATUSLOCK, STATUS, MODIFY_DATE, MODIFY_NAME FROM vw_mstuser");

		return DataTables::of($views)
        ->addIndexColumn()
		->filter(function ($instance) use ($request) {
			if (!empty($request->get('date'))) {
			
				$instance->collection = $instance->collection->filter(function ($row) use ($request) {
					$dot = Carbon::parse($request->get('date'))->format('d-M-Y');
					return Str::contains($row['LOGINDATE'], $dot) ? true : false;
				
				});
			
			}
			if (!empty($request->get('lmdate'))) {
				$instance->collection = $instance->collection->filter(function ($row) use ($request) {
					$dota = Carbon::parse($request->get('lmdate'))->format('d-M-Y');
					return Str::contains($row['MODIFY_DATE'], $dota) ? true : false;
				
				});
			
			}

			if (!empty($request->get('search'))) {
				// search entire table
				$instance->collection = $instance->collection->filter(function ($row) use ($request) {
					$tmp_search = $request->get('search');  // inputed string in Search field
					$column_names = ['No', 'USERID', 'USERGROUP', 'USERNAME', 'USERMAIL', 'LOGINDATE', 'STATUS','MODIFY_DATE','MODIFY_NAME'];
					for($i = 0; $i < count($column_names); $i++)
					{
						// Check if cell of $column_names[$i] contains $tmp_search
						if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
					}
					return false;
				});
			}
		})
		
		->addColumn('ADMIN_ACTION', 
			function($row){ 
				$td = '';
				if($row->STATUSKICK === '1') $td .= '<i onClick="kick(this)" data-id="'.$row->USERID.'" type="submit" title="Kick" class="fa-user-times fas"></i>&nbsp';
				if($row->STATUSLOCK === 'Lock') $td .= '<i onClick="mylock(this)" data-id="'.$row->USERID.'" type="submit" title="Unlock" class="fa-unlock-alt fas"></i>&nbsp';
				
				return $td; 
			})
		->addColumn('no', function($row){
			return $row->No;
		})
		->addColumn('action', function($row){
			if(RoleAccessController::FunctionAccessCheck('U', 'F23')) return $row->USERID;
			else return null;
		})
		->addColumn('logindate', function($row){
			return Carbon::parse($row->LOGINDATE)->format('YmdHis');
		})
		->addColumn('modifydate', function($row){
			return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
		})
		->rawColumns(['ADMIN_ACTION','no','action'])
        ->make(true);
    }

    public function update_lock(Request $request)
	{
        $Mstusers = Mstusers::where('VUSRID','=',$request->id);
        $Mstusers->update([
			'ICOUNT' => 0,
            'BUSRLOCK' => '0',
            'BACTIVE'  => '1'
		]);
		parent::set_user_log($Mstusers->first());
        return response()->json(['success'], 200);
    }
    public function kick_user(Request $request)
	{
        $Mstusers = Mstusers::where('VUSRID','=',$request->id);
        $Mstusers->update([
            'DSIGNIN' => Carbon::now()->subDays(1)
		]);
		parent::set_user_log($Mstusers->first());
        return response()->json(['success'], 200);
    }
	
	public function form($user = NULL)
	{
		$VMARITALSTSS = Mstsettings::where('VSETID','=','MARITAL')->where('BACTIVE','=','1')->get();
		if ($user != NULL)
		{
			if(base64_decode($user) == "NullEmplyee") $user = $user = Mstusers::find('');	// Transferred Employee User 
			else $user = Mstusers::find(base64_decode($user));

			if ($user->VTYPEUSR == "E")
			{
				$VEMPTYPES = Mstsettings::where('VSETID','=','EMPTYPE')->where('BACTIVE','=','1')->get();
				$VPRSNLAREACODES = Mstpersonelareas::where('BACTIVE','=','1')->get();
				$VSUBPRSNLAREACODES = Mstsubpersonelareas::where('BACTIVE','=','1')->get();
				$VCOSTCNTRCODES = Mstcostcenter::where('BACTIVE','=','1')->get();
				$VJOBPOSITIONS = Mstgnrl::where('VGNRLTYPE','=','JOBPOSITION')->where('BACTIVE','=','1')->get();
				$VJOBAREAS = Mstgnrl::where('VGNRLTYPE','=','JOBAREA')->where('BACTIVE','=','1')->get();
				$FAMILY = Mstsettings::where('VSETID','=','RELATION')->where('BACTIVE','=','1')->get();
				$VUSRFLAG = $user->VUSRFLAG;
				$BOTHERS = $user->BOTHERS;
				$package = \App\Mstpackages::all();
				$user = Mstemployees::where('VUSRID', $user->VUSRID)->first();
				$members = DB::select("SELECT B.ILINE, B.VRELNAME, E.VSETDESC VRELATION, C.VSETDESC VRELGENDER, FORMAT (B.DRELBIRTH, 'dd-MM-yyyy') DRELBIRTH, B.VRELCTRYBIRTH, B.VRELCITYBIRTH, B.VBPJSNO VRELBPJSNO, B.VJHTNO VRELJHTNO
										FROM MEDSYS_MSTUSERS A
										LEFT JOIN MEDSYS_MSTEMPLOYEES D ON  A.VUSRID = D.VUSRID
										JOIN MEDSYS_MSTEMPMEMBERS B ON D.VEMPSAPID = B.VEMPSAPID
										LEFT JOIN MEDSYS_MSTSETTINGS C ON B.VRELGENDER = C.VSETCODE AND C.VSETID = 'GENDER'
										LEFT JOIN MEDSYS_MSTSETTINGS E ON B.VRELATION = E.VSETCODE AND E.VSETID = 'RELATION'
										WHERE A.VUSRID = ?
										ORDER BY ILINE", [$user->VUSRID]);
										
				return view('home/users/form', ['PACKAGE'=>$package,'FAMILY'=> $FAMILY, 'VMARITALSTSS' => $VMARITALSTSS, 'VEMPTYPES' => $VEMPTYPES, 'VPRSNLAREACODES' => $VPRSNLAREACODES, 'VSUBPRSNLAREACODES' => $VSUBPRSNLAREACODES, 'VCOSTCNTRCODES' => $VCOSTCNTRCODES, 'VJOBPOSITIONS' => $VJOBPOSITIONS, 'VJOBAREAS' => $VJOBAREAS, 'VUSRFLAG' => $VUSRFLAG, 'BOTHERS' => $BOTHERS, 'user' => $user, 'members' => $members]);
			}
			else
			{
				$VPOSCODES = Mstgnrl::where('VGNRLTYPE','=','USRPOSITION')->where('BACTIVE','=','1')->get();
				$VDRTYPES = Mstsettings::where('VSETID','=','TYPEDCTR')->where('BACTIVE','=','1')->get();
				$VSPCCODES = Mstgnrl::where('VGNRLTYPE','=','SPECIALIST')->where('BACTIVE','=','1')->get();
				$VDOCTYPES = Mstgnrl::where('VGNRLTYPE','=','DOCTYPE')->where('BACTIVE','=','1')->get();
				$VUSRFLAG = $user->VUSRFLAG;
				$user = Mstclinicstaffs::find($user->VUSRID);
				if($user->VCOORDINATOR != null) $coordinator_name = Mstclinicstaffs::where('VUSRID', $user->VCOORDINATOR)->select('VNAME')->first()->VNAME;
				else $coordinator_name = '';
				if ($user->VDOCID != NULL)
				{
					$docs = Doclists::where('VDOCID', $user->VDOCID)->leftjoin('MEDSYS_MSTGENERALS', function ($join) { $join->on('MEDSYS_DOCLISTS.VDOCTYPE', '=', 'MEDSYS_MSTGENERALS.VGNRLCODE')->where('MEDSYS_MSTGENERALS.VGNRLTYPE', 'DOCTYPE')->where('MEDSYS_MSTGENERALS.BACTIVE', '1'); })->get();
				}
				return view('home/users/form', ['VMARITALSTSS' => $VMARITALSTSS, 'VPOSCODES' => $VPOSCODES, 'VDRTYPES' => $VDRTYPES, 'VSPCCODES' => $VSPCCODES, 'VDOCTYPES' => $VDOCTYPES, 'VUSRFLAG' => $VUSRFLAG, 'user' => $user, 'coordinator_name' => $coordinator_name, 'docs' => $docs ?? NULL]);
			}
		}
		else
		{
			$VPOSCODES = Mstgnrl::where('VGNRLTYPE','=','USRPOSITION')->where('BACTIVE','=','1')->get();
			$VDRTYPES = Mstsettings::where('VSETID','=','TYPEDCTR')->where('BACTIVE','=','1')->get();
			$VSPCCODES = Mstgnrl::where('VGNRLTYPE','=','SPECIALIST')->where('BACTIVE','=','1')->get();
			$VDOCTYPES = Mstgnrl::where('VGNRLTYPE','=','DOCTYPE')->where('BACTIVE','=','1')->get();
			return view('home/users/form', ['VMARITALSTSS' => $VMARITALSTSS, 'VPOSCODES' => $VPOSCODES, 'VDRTYPES' => $VDRTYPES, 'VSPCCODES' => $VSPCCODES, 'VDOCTYPES' => $VDOCTYPES]);
		}
    }

    public function getcoordinatorlookup()
	{
		return response()->json(['data' => Mstclinicstaffs::where('BACTIVE','=','1')->select('VUSRID', 'VNAME')->get()]);
    }
	
	public function save(Request $request)
    {
		// return response()->json($request, 400);
		$response = NULL;
		if ($request->user != NULL)
		{
			$user = Mstusers::find($request->user);

			// Reset DLOGIN and DSIGNIN to NULL whene re-activating a user
			if($user->BACTIVE == "0" && $request->BACTIVE == "1") 
			{
				$user->DLOGIN = NULL;
				$user->DSIGNIN = NULL;
			}

			if ($user->VTYPEUSR == "E")
			{
				$employee = Mstemployees::where('VUSRID', $request->user)->first();
			}
			else
			{
				$clinicstaff = Mstclinicstaffs::find($request->user);
			}
		}
		else
		{
			$user = new Mstusers();
			$user->VTYPEUSR = "NE";
			$clinicstaff = new Mstclinicstaffs();
			
			$response['msg'] = "Please proceed to assign a role for this user.";
		}

		$user->VUSRID = $request->VUSRID;
		$user->VCREA = Session::get('id');

		if($request->BACTIVE != null) $user->BACTIVE = $request->BACTIVE;		// Status active/inactive
		$user->BOTHERS = isset($request->BOTHERS)? "1" : "0";					// Updating BOTHERS (Is Allow Create Others)
		
		if (isset($clinicstaff))
		{
			$clinicstaff->VUSRID = $request->VUSRID;
			$clinicstaff->VNAME = $request->VNAME;
			$clinicstaff->VMAIL = $request->VMAIL;
			$clinicstaff->VGNDRCODE = $request->VGNDRCODE;
			$clinicstaff->DBIRTH = $request->DBIRTH;
			$clinicstaff->VCITYBIRTH = $request->VCITYBIRTH;
			$clinicstaff->VMARITALSTS = $request->VMARITALSTS;
			$clinicstaff->VADDRESS = $request->VADDRESS;
			$clinicstaff->VDRTYPE = $request->VDRTYPE;
			$clinicstaff->VPOSCODE = $request->VPOSCODE;
			$clinicstaff->VSPCCODE = $request->VSPCCODE;
			$clinicstaff->VIDCARDNO = $request->VIDCARDNO;
			$clinicstaff->VPHONENO = $request->VPHONENO;
			$clinicstaff->NRATE = $request->NRATE;
			$clinicstaff->VMODI = Session::get('id');
			$clinicstaff->VCREA = Session::get('id');

			$clinicstaff->DMODI = Carbon::now();
			$clinicstaff->VCOORDINATOR = $request->VCOORDINATOR;
			$clinicstaff->BSAFETY = isset($request->BSAFETY) ? "1" : "0";
			$clinicstaff->BHYPERKES = isset($request->BHYPERKES) ? "1" : "0";
			$clinicstaff->BCONTRACT = isset($request->BCONTRACT) ? "1" : "0";
			if($request->BACTIVE != null) $clinicstaff->BACTIVE = $request->BACTIVE;				// Status active/inactive
		}
		else
		{
			$employee->VUSRID = $request->VUSRID;
			$employee->VEMPSAPID = $request->VEMPSAPID;
			$employee->VNAME = $request->VNAME;
			$employee->VMAIL = $request->VMAIL;
			$employee->VDEPTHEADMAIL = $request->VDEPTHEADMAIL;
			$employee->VGNDRCODE = $request->VGNDRCODE;
			$employee->DBIRTH = $request->DBIRTH;
			$employee->VCITYBIRTH = $request->VCITYBIRTH;
			$employee->VMARITALSTS = $request->VMARITALSTS;
			$employee->VADDRESS = $request->VADDRESS;
			$employee->DMARITAL = $request->DMARITAL;
			$employee->VPRSNLAREACODE = $request->VPRSNLAREACODE;
			$employee->VSUBPRSNLAREACODE = $request->VSUBPRSNLAREACODE;
			$employee->VEMPTYPE = $request->VEMPTYPE;
			$employee->VIDCARDNO = $request->VIDCARDNO;
			$employee->VPHONENO = $request->VPHONENO;
			$employee->VCOSTCNTRCODE = $request->VCOSTCNTRCODE;
			$employee->VBUSSTITLE = $request->VBUSSTITLE;
			$employee->VPACKAGECODE = $request->VPACKAGECODE;
			$employee->VJOBPOSITION = $request->VJOBPOSITION;
			$employee->VJOBAREA = $request->VJOBAREA;
			$employee->DHIRE = $request->DHIRE;
			$employee->DENDCNTRCT = $request->DENDCNTRCT;
			$employee->VBPJSNO = $request->VBPJSNO;
			$employee->VJHTNO = $request->VJHTNO;
			$employee->VCREA = Session::get('id');

			$employee->VMODI = Session::get('id');
			$employee->DMODI = Carbon::now();
			$employee->VCNTRYBIRTH = $request->VCNTRYBIRTH;
			if($request->BACTIVE != null) $employee->BACTIVE = $request->BACTIVE;				// Status active/inactive
		}
		DB::beginTransaction();
		try
		{
			$user->save();
			parent::set_user_log($user);
			if (isset($clinicstaff))
			{
				if (isset($request->VDOCFILENAME))
				{
					for ($x = 0; $x < count($request->VDOCFILENAME); $x++)
					{
						$is_update = false;
						if (strlen($request->VID[$x]) != 13)
						{
							$doc = Doclists::find($request->VID[$x]);
							$is_update = true;
							$old_file = $doc->VDOCFILENAME;
						}
						else
						{
							$doc = new Doclists();
							$doc->VDOCID = 'MEDSYS_MSTCLINICSTAFFS/' . $request->VUSRID;
							$doc->VCREA = Session::get('id');
						}
						$doc->VDOCTYPE = $request->VDOCTYPE[$x];
						$doc->VDOCNO = $request->VDOCNO[$x];
						if ($request->VDOCFILENAME[$x] != '')
						{
							$doc->VDOCFILENAME = $request->VDOCFILENAME[$x];
						}
						$doc->DPERIODFR = $request->DPERIODFR[$x];
						$doc->DPERIODTO = $request->DPERIODTO[$x];
						$doc->VMODI = Session::get('id');
						$doc->DMODI = Carbon::now();
						$doc->save();
						if ($request->VDOCFILENAME[$x] != '')
						{
							if ($is_update)
							{
								Storage::delete('public' . Mstsettings::where('VSETID', 'USERDOC')->where('VSETCODE', 'USRDOC')->where('BACTIVE', '1')->first()->VSETDESC . '/' . strtolower($doc->VID . substr($old_file, strrpos($old_file, '.'))));
							}
							$request->file('files')[$x]->storeAs(Mstsettings::where('VSETID', 'USERDOC')->where('VSETCODE', 'USRDOC')->where('BACTIVE', '1')->first()->VSETDESC, $doc->VID . '.' . $request->file('files')[$x]->extension() );
						}
						$clinicstaff->VDOCID = $doc->VDOCID;
					}
				}
				$clinicstaff->save();
			}
			else
			{
				if (isset($request->ILINE))

				{
					for ($x = 0; $x < count($request->ILINE); $x++)
					{
						if (strlen($request->ILINE[$x]) != 13)
						{
							$member = Mstempmembers::where('VEMPSAPID', $request->VEMPSAPID)->where('ILINE', $request->ILINE[$x])->first();
						}
						else
						{
							$member = new Mstempmembers();
							$member->VEMPSAPID = $request->VEMPSAPID;
							$member->VCREA = Session::get('id');
						}
						$member->VRELATION = $request->VRELATIONS[$x];
						$member->VRELNAME = $request->VRELNAME[$x];
						$member->VRELGENDER = $request->VRELGENDER[$x];
						$member->DRELBIRTH = $request->DRELBIRTH[$x];
						$member->VRELCITYBIRTH = $request->VRELCITYBIRTH[$x];
						$member->VRELCTRYBIRTH = $request->VRELCTRYBIRTH[$x];
						$member->VBPJSNO = $request->VRELBPJSNO[$x];
						$member->VJHTNO = $request->VRELJHTNO[$x];
						$member->VMODI = Session::get('id');
						$member->DMODI = Carbon::now();
						$member->save();
					}
				}
				$employee->save();
			}
			DB::commit();
		}
		catch (\Exception $e)
		{
			DB::rollBack();
			if (!isset($e->errorInfo))
			{
				return response()->json($e, 500);
			}
			elseif (strpos($e->errorInfo[2], "The duplicate key value is") !== FALSE)
			{
				return response()->json("User ID (" . $request->VUSRID . ") already exist", 500);
			}
			else
			{
				return response()->json($e->errorInfo[2], 500);
			}
		}
		return response()->json(['response' => $response], 200);
    }

    public function deldoc($id)
	{
		$doc = Doclists::find($id);
		Storage::delete('public' . Mstsettings::where('VSETID', 'USERDOC')->where('VSETCODE', 'USRDOC')->where('BACTIVE', '1')->first()->VSETDESC . '/' . strtolower($id . substr($doc->VDOCFILENAME, strrpos($doc->VDOCFILENAME, '.'))));
		$doc->delete();
		return response()->json(['success'], 200);
	}
	
	//==== Export index table to excel file
	public function export_excel(Request $request){
		if(!$request){
			$tmp = "";
			return Excel::download(new UsersExport($tmp),'Users.xls');
		}
		else{
			$no = $request->no;
			$userid = $request->userid;
			$usergroup = $request->usergroup;
			$username = $request->username;
			$useremail = $request->useremail;
			$posname = $request->posname;
			$drtype = $request->drtype;
			$spcname = $request->spcname;
			$usertype = $request->usertype;
			$status = $request->status;
			
            if (!$request->date) $date = '';
			else $date = Carbon::parse($request->date)->format('d-M-Y');

			$lmname = $request->lmname;
            if(!$request->lmdate) $lmdate = '';
			else $lmdate = Carbon::parse($request->lmdate)->format('d-M-Y');
			

			$search = $request->search;

			return Excel::download(new UsersExport($no,$userid,$usergroup,$username,$useremail,$posname,$drtype,$spcname,$usertype,$date,$status,$search,$lmname,$lmdate),'Users.xls');
		}
	}
}
