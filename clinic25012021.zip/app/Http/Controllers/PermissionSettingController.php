<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PermissionSettingController extends Controller
{
    public function index()
    {
		$groups = array("1" => "IT Administrator", "2" => "Doctor");
		$menus = array(array("key" => "masterdata", "value" => "Master Data", "access" => array("V", "C", "U", "D/C")), array("key" => "letters", "value" => "Letters", "access" => array("V", "C", "U", "D/C", "P")));
		return view('home/usermanagement/permissionsetting', ['groups' => $groups, 'menus' => $menus]);
    }
	
	public function group($id)
	{
		$menus = array();
		if ($id == "1")
		{
			$menus[] = array("key" => "masterdata", "access" => array("V", "C", "U", "D/C"));
		}
		elseif ($id == "2")
		{
			$menus[] = array("key" => "letters", "access" => array("V", "C", "U", "D/C"));
		}
		return response()->json($menus);
    }
	
	public function update(Request $request)
	{
		return response()->json(['success'], 200);
    }
}
