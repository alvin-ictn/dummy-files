<?php

namespace App\Http\Controllers;

use App\ClinicModel;
use App\Exports\InventoryRequestListExport;
use App\Invrequestdtllogs;
use App\Invrequestdtls;
use App\Invrequestlogs;
use App\Invrequests;
use App\Mstsettings;
use App\Wfinvreqhistlogs;
use App\Wfinvreqhists;
use Carbon\Carbon;
use DataTables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;
use Session;

class InventoryController extends Controller
{
    public function index()
    {
		return view('home/inventory/request/index', ['cancreate' => (parent::check_role("HRADM") && Mstsettings::where('VSETID', 'INVREQUEST')->where('VSETDESC', Session::get('id'))->where('BACTIVE', '1')->exists()) || parent::check_role("PMCY")]);
    }
	
	public function ajax(Request $request)
	{
		$VCLINICCODE = ClinicModel::find(Session::get('namaclinic') ?? 'HO')->VCLINICCODE;
		$inventorysel = DB::select("EXEC sp_RequestDashboard ?", [$VCLINICCODE]);
		return DataTables::of($inventorysel)
                ->addIndexColumn()
				->filter(function ($instance) use ($request) {
					if (!empty($request->get('date')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							$dot = Carbon::parse($request->get('date'))->format('d-M-Y');
							return Str::contains($row['DREQ'], $dot) ? true : false;
						});
					}
					if (!empty($request->get('search')))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							if (Str::contains(Str::lower($row['VREQNO']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DREQ']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VCLINICNAME']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['BSTATUS']), Str::lower($request->get('search'))))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['No']), Str::lower($request->get('search'))))
							{
								return true;
							}
							return false;
						});
					}
				})
				->addColumn('no', function($row){ return $row->No; })
                ->addColumn('action', function($row){ return $row->VREQNO; })
                ->rawColumns(['action','no'])
                ->make(true);
    }
	
	public function form($inventory = NULL)
	{
		if ($inventory != NULL)
		{
			$inventory = Invrequests::where('VREQNO', base64_decode($inventory))->join('MEDSYS_MSTCLINICS', 'MEDSYS_INVREQUESTS.VCLINICCODE', '=', 'MEDSYS_MSTCLINICS.VCLINICCODE')->select('MEDSYS_INVREQUESTS.*', 'MEDSYS_MSTCLINICS.VCLINICNAME')->first();
			$workflows = Wfinvreqhists::where('VREQNO', $inventory->VREQNO)->leftjoin('MEDSYS_MSTEMPLOYEES', function ($join) { $join->on('MEDSYS_MSTEMPLOYEES.VUSRID', '=', 'MEDSYS_WFINVREQHISTS.VRESPOND')->where('MEDSYS_MSTEMPLOYEES.BACTIVE', '1'); })->leftjoin('MEDSYS_MSTCLINICSTAFFS', 'MEDSYS_MSTCLINICSTAFFS.VUSRID', '=', 'MEDSYS_WFINVREQHISTS.VRESPOND')->select(DB::raw('COALESCE(MEDSYS_MSTEMPLOYEES.VNAME, MEDSYS_MSTCLINICSTAFFS.VNAME) AS VRESPOND'), 'MEDSYS_WFINVREQHISTS.VSIGN', 'MEDSYS_WFINVREQHISTS.VREMARKS', DB::raw("FORMAT(DRESPOND, 'dd-MMM-yyyy hh:mm:ss tt') AS DRESPOND"))->get();
			$clinics = ClinicModel::where('BACTIVE', '1')->where('VCLINICCODE', '<>', $inventory->VCLINICCODE)->get()->toArray();
			$VSIGN = parent::check_role("PMCY") ? 'submitted' : (parent::check_role("HRADM") && $inventory->BSTATUS == 'V' ? 'approved' : 'confirmed');
			$canconfirm = parent::check_role("HRADM") && $inventory->BSTATUS == 'O' && Mstsettings::where('VSETID', 'INVREQUEST')->where('VSETDESC', Session::get('id'))->where('BACTIVE', '1')->exists();
			$canapprove = parent::check_role("HRADM") && $inventory->BSTATUS == 'V' && Wfinvreqhists::where('VREQNO', $inventory->VREQNO)->orderBy('DRESPOND', 'desc')->first()->VNEXTRESPOND == Session::get('id');
			$canedit = ((Session::get('namaclinic') ?? 'HO') == $inventory->VCLINICCODE && ($inventory->BSTATUS == 'R' || ($inventory->BSTATUS == 'S' && (parent::check_role("HRADM") && Mstsettings::where('VSETID', 'INVREQUEST')->where('VSETDESC', Session::get('id'))->where('BACTIVE', '1')->exists() || parent::check_role("PMCY"))))) || (parent::check_role("HRADM") && $inventory->BSTATUS == 'O') || $canapprove;
			return view('home/inventory/request/form', ['inventory' => $inventory, 'workflows' => $workflows, 'clinics' => $clinics, 'canedit' => $canedit, 'VSIGN' => $VSIGN, 'VCLINICCODE' => $inventory->VCLINICCODE, 'canconfirm' => $canconfirm, 'canapprove' => $canapprove]);
		}
		else
		{
			$VCLINICNAME = ClinicModel::find(Session::get('namaclinic') ?? 'HO')->VCLINICNAME;
			$VCLINICCODE = Session::get('namaclinic') ?? 'HO';
			if (parent::check_role("PMCY"))
			{
				return view('home/inventory/request/form', ['VCLINICNAME' => $VCLINICNAME, 'workflows' => [], 'VSIGN' => 'submitted', 'canedit' => true, 'VCLINICCODE' => $VCLINICCODE]);
			}
			else
			{
				$clinics = ClinicModel::where('BACTIVE', '1')->get()->toArray();
				return view('home/inventory/request/form', ['VCLINICNAME' => $VCLINICNAME, 'workflows' => [], 'VSIGN' => 'confirmed', 'canedit' => true, 'clinics' => $clinics, 'VCLINICCODE' => $VCLINICCODE]);
			}
		}
    }
	
	public function save(Request $request)
    {
		$now = carbon::now();
		$oldstatus = NULL;
		if ($request->VREQNO != NULL)
		{
			$inventory = Invrequests::find($request->VREQNO);
			$inventory->VMODI = Session::get('id');
			$inventory->DMODI = $now;
			$oldstatus = $inventory->BSTATUS;
		}
		else
		{
			$inventory = new Invrequests();
			$yy = substr($now->format('Y'), 2, 2);
			$inventory->DREQ = $now;
			$inventory->VCLINICCODE = $request->VCLINICCODE;
			$inventory->VCREA = Session::get('id');
			$inventory->DCREA = $now;
		}
		$inventory->VBUY = $request->VBUY ?? 'HO';
		$wf = new Wfinvreqhists();
		$wf->VRESPOND = Session::get('id');
		$wf->VROLE = parent::check_role("PMCY") ? "PMCY" : "HRADM";
		$wf->VSIGN = $request->VSIGN;
		$wf->DRESPOND = $now;
		$wf->VREMARKS = $request->VREMARKS;
		$log = new Wfinvreqhistlogs();
		$log->VRESPOND = Session::get('id');
		$log->VROLE = parent::check_role("PMCY") ? "PMCY" : "HRADM";
		$log->VSIGN = $request->VSIGN;
		$log->DRESPOND = $now;
		$log->VREMARKS = $request->VREMARKS;
		if ($request->VSIGN == 'submitted')
		{
			$inventory->BSTATUS = 'O';
		}
		if ($request->VSIGN == 'confirmed')
		{
			$inventory->BSTATUS = 'V';
			$VNEXTRESPOND = Mstsettings::where('VSETID', 'INVREQUEST')->where('VSETDESC', Session::get('id'))->where('BACTIVE', '1')->first()->VSETDESC1;
			$wf->VNEXTRESPOND = $VNEXTRESPOND;
			$log->VNEXTRESPOND = $VNEXTRESPOND;
		}
		if ($request->VSIGN == 'revised')
		{
			$inventory->BSTATUS = 'R';
		}
		if ($request->VSIGN == 'approved')
		{
			$inventory->BSTATUS = 'A';
		}
		if ($request->VSIGN == 'rejected')
		{
			$inventory->BSTATUS = 'J';
		}
		if ($request->VSIGN == 'save')
		{
			$inventory->BSTATUS = 'S';
		}
		$reqlog = new Invrequestlogs();
		$reqlog->DREQ = $inventory->DREQ;
		$reqlog->VCLINICCODE = $inventory->VCLINICCODE;
		$reqlog->VBUY = $inventory->VBUY;
		$reqlog->BSTATUS = $inventory->BSTATUS;
		$reqlog->VUSER = Session::get('id');
		DB::beginTransaction();
		try
		{
			if ($inventory->VREQNO == NULL)
			{
				$rqno = DB::select("SELECT SUM(NLASTNO) NLASTNO FROM MEDSYS_MSTNOS WHERE VTRXCODE = 'RQ' AND NYEAR = '" . $yy . "'")[0]->NLASTNO;
				$inventory->VREQNO = ClinicModel::find(Session::get('namaclinic') ?? 'HO')->VCLINICINIT . 'RQ' . $yy . str_pad($rqno + 1, 4, '0', STR_PAD_LEFT);
				if ($rqno == NULL)
				{
					DB::table('MEDSYS_MSTNOS')->insert([ 'NLASTNO' => '1', 'NYEAR' => $yy, 'NMONTH' => '0', 'NDATE' => '0', 'VTRXCODE' => 'RQ', 'DCREA' => $now, 'VCREA' => Session::get('id') ]);
				}
				else
				{
					DB::table('MEDSYS_MSTNOS')->where('VTRXCODE', 'RQ')->where('NYEAR', $yy)->update([ 'NLASTNO' => $rqno + 1, 'DMODI' => $now, 'VMODI' => Session::get('id') ]);
				}
			}
			$inventory->save();
			if ($oldstatus == 'R' || $oldstatus == 'S')
			{
				Invrequestdtls::where('VREQNO', $inventory->VREQNO)->delete();
			}
			for ($x = 0; $x < count($request->ILINENO); $x++)
			{
				if ($request->ILINENO[$x] != '' && $oldstatus != 'R' && $oldstatus != 'S')
				{
					$line = Invrequestdtls::where('VREQNO', $inventory->VREQNO)->where('ILINENO', $request->ILINENO[$x])->first();
					$line->VMODI = Session::get('id');
					$line->DMODI = $now;
				}
				else
				{
					$line = new Invrequestdtls();
					$line->VREQNO = $inventory->VREQNO;
					$line->ILINENO = $x + 1;
					$line->VCREA = Session::get('id');
					$line->DCREA = $now;
				}
				$line->VDRUGSCODE = $request->VDRUGSCODE[$x];
				$line->IQTYREQ = $request->IQTYREQ[$x];
				$line->ISTOCK = $request->ISTOCK[$x];
				$line->IQTYIN = $request->IQTYIN[$x];
				$line->IQTYOUT = $request->IQTYOUT[$x];
				if (isset($request->IQTYVERIFY[$x]))
				{
					$line->IQTYVERIFY = $request->IQTYVERIFY[$x];
				}
				if (isset($request->VTRF[$x]))
				{
					$line->VTRF = $request->VTRF[$x];
					if ($line->VTRF == 'others')
					{
						$line->VTRFOTH = $request->VTRFOTH[$x];
					}
				}
				$line->save();
				$reqdtllog = new Invrequestdtllogs();
				$reqdtllog->VREQNO = $line->VREQNO;
				$reqdtllog->ILINENO = $line->ILINENO;
				$reqdtllog->VDRUGSCODE = $line->VDRUGSCODE;
				$reqdtllog->IQTYREQ = $line->IQTYREQ;
				$reqdtllog->ISTOCK = $line->ISTOCK;
				$reqdtllog->IQTYIN = $line->IQTYIN;
				$reqdtllog->IQTYOUT = $line->IQTYOUT;
				$reqdtllog->IQTYVERIFY = $line->IQTYVERIFY;
				$reqdtllog->VTRF = $line->VTRF;
				$reqdtllog->VUSER = Session::get('id');
				$reqdtllog->save();
			}
			$wf->VREQNO = $inventory->VREQNO;
			$wf->save();
			$log->VREQNO = $inventory->VREQNO;
			$log->save();
			$reqlog->VREQNO = $inventory->VREQNO;
			$reqlog->save();
			DB::commit();
		}
		catch (\Exception $e)
		{
			DB::rollBack();
			if (!isset($e->errorInfo))
			{
				$response['error'] = $e;
				return response()->json($response, 500);
			}
			else
			{
				$response['error'] = $e->errorInfo[2];
				return response()->json($response, 500);
			}
		}
		return response()->json(['success'], 200);
    }

    public function gettblreqdetail($inventory = NULL)
	{
		if ($inventory != NULL)
		{
			return response()->json(['data' => Invrequestdtls::where('VREQNO', $inventory)->leftjoin('MEDSYS_MSTDRUGS', 'MEDSYS_INVREQUESTDTLS.VDRUGSCODE', '=', 'MEDSYS_MSTDRUGS.VDRUGSCODE')->leftjoin('MEDSYS_MSTSETTINGS', function ($join) { $join->on('MEDSYS_MSTDRUGS.PBF', '=', 'MEDSYS_MSTSETTINGS.VSETCODE')->where('MEDSYS_MSTSETTINGS.VSETID', 'PRMPBF'); })->leftjoin('MEDSYS_MSTGENERALS', function ($join) { $join->on('MEDSYS_MSTDRUGS.VUOM', '=', 'MEDSYS_MSTGENERALS.VGNRLCODE')->where('MEDSYS_MSTGENERALS.VGNRLTYPE', 'MSUREUNIT')->where('MEDSYS_MSTGENERALS.BACTIVE', '1'); })->select('MEDSYS_INVREQUESTDTLS.*', 'MEDSYS_MSTDRUGS.VCONTAIN', 'MEDSYS_MSTDRUGS.VBRAND', 'MEDSYS_MSTDRUGS.VPHARMACY', 'MEDSYS_MSTDRUGS.NPRICE', 'MEDSYS_MSTGENERALS.VGNRLDESC AS VUOM', DB::raw('COALESCE(MEDSYS_INVREQUESTDTLS.ISTOCK, 0) AS ISTOCK'), 'MEDSYS_MSTSETTINGS.VSETDESC AS PBF', DB::raw('COALESCE(MEDSYS_INVREQUESTDTLS.IQTYIN, 0) AS IQTYIN'), DB::raw('COALESCE(MEDSYS_INVREQUESTDTLS.IQTYOUT, 0) AS IQTYOUT'))->get()]);
		}
		else
		{
			return response()->json(['data' => DB::select("EXEC sp_GenerateRequest ?", [Session::get('namaclinic') ?? 'HO'])]);
		}
    }
	
	public function export_excel(Request $request)
	{
        if (!$request)
		{
			return Excel::download(new InventoryRequestListExport(""), 'Inventory Request List.xls');
        }
		else
		{
            $no = $request->no;
            $request_no = $request->request_no;
            $date = $request->date;
            $request_by = $request->request_by;
            $status = $request->status;
            $search = $request->search;
			return Excel::download(new InventoryRequestListExport($no, $request_no, $date, $request_by, $status, $search), 'Inventory Request List.xls');
        }
    }
}
