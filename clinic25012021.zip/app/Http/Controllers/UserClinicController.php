<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mstuserclinic;
use App\ClinicModel;
use App\Mstclinicstaffs;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use App\Exports\UserClinicExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use DB;

class UserClinicController extends Controller
{
    public function  ajax(Request $request){

        $userclin = \App\Mstuserclinic::all();
        $views = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY MONTH(MODIFY_DATE) DESC,YEAR(MODIFY_DATE) DESC,MODIFY_DATE ASC) AS No, USERID, USERNAME, CLINICCODE, CLINICNAME, STATUS, MODIFY_DATE, MODIFY_NAME FROM vw_mstuserclinic");

        return Datatables::of($views)
        ->addIndexColumn()

        ->filter(function ($instance) use ($request) {

            if (!empty($request->get('date'))) {
            
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
                    return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                
                });
            
            }
            if (!empty($request->get('search'))) {
				// search entire table
				$instance->collection = $instance->collection->filter(function ($row) use ($request) {
					$tmp_search = $request->get('search');  // inputed string in Search field
					$column_names = ['No', 'USERNAME', 'CLINICNAME', 'STATUS', 'MODIFY_NAME', 'MODIFY_DATE'];
					for($i = 0; $i < count($column_names); $i++)
					{
						// Check if cell of $column_names[$i] contains $tmp_search
						if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
					}
                    return false;
                });
            }
        })
        ->addColumn('no', function($row){
            return $row->No;
        })
        ->addColumn('action', function($row){
			if(RoleAccessController::FunctionAccessCheck('U', 'F24')) return $row->USERNAME;
			else return null;
        })
        ->addColumn('modify_date', function($row){
            return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
        })
        ->rawColumns(['action','no'])
        ->make(true);

    }

    public function insert(){

        return view('home/userclinic/add');
    }
    
    public function add(Request $request){
        $Mstuserclinic = \App\Mstuserclinic::where('VUSRID','=',$request->VUSRID)->select('VCLINICCODE')->get()->toArray();
        $user_all_clinic = array_map(function ($value) {
            return $value['VCLINICCODE'];
        }, $Mstuserclinic);
        
        if(count($user_all_clinic) > 0)
        {
            if(in_array("HO", $user_all_clinic))
            {
                $response['error'] = "User assigned with HO<br>can't be assigned with other clinic!";
                return response()->json($response, 400);
            }
            else
            {
                if($request->VCLINICCODE == "HO")  
                {
                    $response['error'] = "This user can't be assign with HO";
                    return response()->json($response, 400);
                }
            }
        }

        $validatedData = $request->validate([
            'VUSRID' => 'required|max:50',
            'VCLINICCODE' => 'required|max:20',
        ]);
        /// get dari model  
        $data =  new \App\Mstuserclinic();
        $data->VUSRID = $request->VUSRID;
        $data->VCLINICCODE = $request->VCLINICCODE;
        $data->DMODI = carbon::now();
        $data->VCREA = Session::get('id');
        $data->VMODI = Session::get('id');
        $data->save();
        return response()->json(['success'], 200);
    }

    public function update(Request $request)
    {
        $userclinic = \App\Mstuserclinic::where('VUSRID','=',$request->userid)->where('VCLINICCODE','=', $request->code)->first();
        //$clinic = \App\ClinicModel::where('VCLINICCODE','=', $request->code);
        
        $validator = Validator::make($request->all(), [
            'name' => 'required|max:50',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        $userclinic->BACTIVE = $request->BACTIVEs;
        $userclinic->DMODI = carbon::now();
        $userclinic->VMODI = Session::get('id');
        $userclinic->save();

        // $userclinic->update([
        //     'BACTIVE'  => $request->BACTIVEs,
        //     'DMODI'  => carbon::now(),
        //     'VMODI'  => Session::get('id'),
   
        // ]);
        
        // $clinic->update([
        //    'BACTIVE'  => $request->BACTIVEs,
        //    'DMODI'  => carbon::now(),
        //    'VMODI'  => Session::get('id'),

        // ]);
        return response()->json(['success'], 200);
    }

    public function edit($id){
        $base = base64_decode($id);
        list($x,$y) = explode(",",$base);
        
        $userclinic = \DB::select("SELECT * FROM vw_mstuserclinic WHERE USERID = '$x' AND CLINICCODE = '$y'")[0];
        return view('home/userclinic/update',compact('userclinic'));
    }

    public function getcliniclookup()
	{
        $db = DB::select("SELECT A.VNAME, A.VUSRID FROM MEDSYS_MSTCLINICSTAFFS A WHERE A.BACTIVE = '1' UNION SELECT B.VNAME, B.VUSRID FROM MEDSYS_MSTEMPLOYEES B WHERE  B.BACTIVE = '1' ");
		return response()->json(['data' => $db]);
    }

    public function getclinic2lookup()
	{
		return response()->json(['data' => DB::table('MEDSYS_MSTCLINICS')->select('VCLINICCODE','VCLINICNAME')->get()]);
    }
    
	public function export_excel(Request $request)
	{
        if(!$request){
            $id = "";
            return Excel::download(new UserClinicExport($id),'UserClinic.xls');

        }else{
            $no = $request->no;
            $username = $request->username;
            $clinicnames = $request->clinicname;
            $status = $request->status;
            $lastmoname = $request->lastmoname;
            
            if (!$request->modifiedt)$modifiedt = '';
            else $modifiedt = Carbon::parse($request->modifiedt)->format('d-M-Y');
            
            $search = $request->search;

            return Excel::download(new UserClinicExport($no,$clinicnames,$username,$status,$modifiedt,$lastmoname,$search),'UserClinic.xls');


        }
    }
}
