<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use app\Mstpersonelareas;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use App\Exports\PersonnelExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use DB;

class PersonnelAreaController extends Controller
{
    public function  ajax(Request $request){

    $view = \App\Mstpersonelareas::all();
    $views = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY  MONTH(MODIFY_DATE) DESC,YEAR(MODIFY_DATE) DESC,MODIFY_DATE ASC) AS No, PERSONELCODE, PERSONELNAME, STATUS, MODIFY_DATE, MODIFY_NAME 
                        FROM vw_mstpersonelarea");

    return Datatables::of($views)
        ->addIndexColumn()
        
        ->filter(function ($instance) use ($request) {
            if (!empty($request->get('date'))) {
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
                    return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                });
            }
            if (!empty($request->get('search'))) {
                // search entire table
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $tmp_search = $request->get('search');  // inputed string in Search field
                    $column_names = ['No', 'PERSONELCODE', 'PERSONELNAME', 'STATUS', 'MODIFY_NAME', 'MODIFY_DATE'];
                    for($i = 0; $i < count($column_names); $i++)
                    {
                        // Check if cell of $column_names[$i] contains $tmp_search
                        if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                    }
                    return false;
                });
            }
        })
        ->addColumn('no', function($row){
            return $row->No;
        })
        ->addColumn('action', function($row){
            if(RoleAccessController::FunctionAccessCheck('U', 'F18')) return $row->PERSONELCODE;
            else return null;
        })
        ->addColumn('modify_date', function($row){
            return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
        })
        ->rawColumns(['action','no'])
        ->make(true);

    }

    public function insert(){

        return view('home/personal/add');
    }
    
    public function add(Request $request){

        $validator = Validator::make($request->all(), [
            'code' =>'required|max:20',
            'name' =>'required|max:50',
        ]);

        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        /// get dari model  
        $data =  new \App\Mstpersonelareas();
        $data->VPRSNLAREACODE = $request->code;
        $data->VPRSNLNAME = $request->name;
        $data->BACTIVE = '1';
        $data->DMODI = Carbon::now();
        $data->VCREA = Session::get('id');
        $data->VMODI = Session::get('id');
        $data->save();
        return response()-> json(['succsess'], 200);

    }

    public function update(Request $request)
    {
        $menusel = \App\Mstpersonelareas::where('VPRSNLAREACODE','=',$request->code);
        
        $validator = Validator::make($request->all(), [
            'name' => 'required|max:50',
        ]);

        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        $menusel->update([
            'VPRSNLNAME' => $request->name,
            'BACTIVE'  => $request->BACTIVEs,
            'DMODI'  => carbon::now(),
            'VMODI'  => Session::get('id'),
            
        ]);
        return response()->json(['succsess'], 200);
    }

    public function edit($id){

        $ids = base64_decode($id);
        $personel = \App\Mstpersonelareas::where('VPRSNLAREACODE',$ids)->first();

        return view('home/personal/update',compact('personel'));
    }

    public function export_excel(Request $request)
	{
        if(!$request){

            $request = "";
            return Excel::download(new PersonnelExport($request),'PersonnelArea.xls');

        }else{
            $no = $request->no;
            $perscode = $request->perscode;
            $persname = $request->persname;
            $status = $request->status;
            if(!$request->lastmo){
                $lastmo = '';
            }else{
                
                $lastmo = Carbon::parse($request->lastmo)->format('d-M-Y');

            }
            $status = $request->status;
            $modifiedn = $request->modifiedn;
            $search = $request->search;


            return Excel::download(new PersonnelExport($no,$perscode,$persname,$status,$lastmo,$modifiedn,$search),'Personnel.xls');

        }
    }
}
