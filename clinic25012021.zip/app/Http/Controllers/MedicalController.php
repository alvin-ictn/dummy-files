<?php

namespace App\Http\Controllers;

use app\Mstmedical;
use app\Mstmedicallogs;
use app\Mstgnrl;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Illuminate\Http\Request;
use Validator;
use Illuminate\Support\Str;
use App\Exports\MedicalExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use DB;

class MedicalController extends Controller
{
    public function ajax(Request $request)
    {
        $insertins = \App\Mstmedical::all();
        $view = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY MONTH(MODIFY_DATE) DESC,YEAR(MODIFY_DATE) DESC,MODIFY_DATE ASC) AS No, REG_NO, MTRL_CODE, ASSET_NO, INSTR_NAME, INSTR_BRAND, PURCHASE_DATE, SUBMIT_DATE, LOCATION_NAME, BUSINESS_UNIT, CALIBRATE_DATE, Status, CRITERIA, QTY, REMARKS, MODIFY_DATE, MODIFY_NAME FROM vw_mstmdclinst");

        return Datatables::of($view)
            ->addIndexColumn()

            ->filter(function ($instance) use ($request) {
                if (!empty($request->get('purchase_date'))) {
                
                    $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                        $dot = Carbon::parse($request->get('purchase_date'))->format('d-M-Y');
                        return Str::contains($row['PURCHASE_DATE'], $dot) ? true : false;
                    
                    });
                
                }
                if (!empty($request->get('submit_date'))) {
                
                    $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                        $dot = Carbon::parse($request->get('submit_date'))->format('d-M-Y');
                        return Str::contains($row['SUBMIT_DATE'], $dot) ? true : false;
                    
                    });
                
                }
                if (!empty($request->get('calibrate_date'))) {
                
                    $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                        $dot = Carbon::parse($request->get('calibrate_date'))->format('d-M-Y');
                        return Str::contains($row['CALIBRATE_DATE'], $dot) ? true : false;
                    
                    });
                
                }
                if (!empty($request->get('date'))) {
                
                    $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                        $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
                        return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                    
                    });
                
                }
                if (!empty($request->get('search'))) {
                    // search entire table
                    $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                        $tmp_search = $request->get('search');  // inputed string in Search field
                        $column_names = ['No', 'REG_NO', 'MTRL_CODE', 'ASSET_NO', 'INSTR_NAME', 'INSTR_BRAND', 'PURCHASE_DATE', 'SUBMIT_DATE', 
                        'LOCATION_NAME', 'BUSINESS_UNIT', 'CALIBRATE_DATE', 'Status', 'CRITERIA', 'QTY', 'REMARKS', 'MODIFY_NAME', 'MODIFY_DATE'];
                        for($i = 0; $i < count($column_names); $i++)
                        {
                            // Check if cell of $column_names[$i] contains $tmp_search
                            if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                        }
                        return false;
                    });
                }
            })
            ->addColumn('no', function($row){
                return $row->No;
            })
            ->addColumn('action', function($row){
                if(RoleAccessController::FunctionAccessCheck('U', 'F15')) return $row->REG_NO;
                else return null;
            })
            ->addColumn('purchase_date', function($row){
                return Carbon::parse($row->PURCHASE_DATE)->format('Ymd');
            })
            ->addColumn('submit_date', function($row){
                return Carbon::parse($row->SUBMIT_DATE)->format('Ymd');
            })
            ->addColumn('calibrate_date', function($row){
                return Carbon::parse($row->CALIBRATE_DATE)->format('Ymd');
            })
            ->addColumn('modify_date', function($row){
                return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
            })
            ->rawColumns(['action','no'])
            ->make(true);
    }
    
    
    public function view($id){

        $base = base64_decode($id);
        $ins['user'] = \App\Mstmedical::where('VINSCODE','=', $base)->first();
        
        return response()->json($ins);
    }

    public function insert(){

        return view('home/medical/add');
    }

    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'material' =>'required|max:20',
            'VCLINICCODE'=>'required'
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        
        if($request->DCALIBRATE != '') $dclbrt = carbon::parse($request->DCALIBRATE)->format('Y-m-d');
        else $dclbrt = null;

        $countjax = DB::select(DB::raw("SELECT COUNT(*) AS NLASTNO FROM MEDSYS_MSTMDCLINSTRS"))[0];
        $datenow = carbon::now();

        $years =  $datenow->format('Y');
        $months = $datenow->format('m');
        $dayu = $datenow->format('d');

        $stringds = substr($years,2);
        $stringm = substr($months, 0, 2);
        // $stringds = subasstr($years, 0, 2);
        $stringd = substr($dayu, 0, 2);
        $jumlah = $countjax->NLASTNO + 1;
        $count1 =  str_pad($jumlah, 4, '0', STR_PAD_LEFT);

        $nodrug  = 'AL' . $stringds . $stringm . $count1;

        /// get dari model  
        $data =  new \App\Mstmedical();
        $data->VREGISTNO = $nodrug;
        $data->VMTRLCODE = $request->material;
        $data->VASSETNO = $request->asset;
        $data->VINSTRNAME = $request->kitsname;
        $data->VINSTRBRAND = $request->kitsbrand;
        $data->DPURCHASE = carbon::parse($request->DPURCHASE)->format('Y-m-d');
        $data->DSUBMIT = carbon::parse($request->DSUBMIT)->format('Y-m-d');
        $data->VLOCATION = $request->loc;
        $data->VBU = $request->business;
        $data->DLASTCLBRT = $dclbrt;
        $data->NTOTAL = $request->quantity;
        $data->VREMARKS = $request->remarks;
        $data->BCRITERIA = $request->cryteria;
        $data->VCLINICCODE = $request->VCLINICCODE;
        $data->BSTATUS = $request->status;
        $data->VCREA = Session::get('id');
        $data->VMODI = Session::get('id');
        $data->save();

        $data1 =  new \App\Mstmedicallogs();
        $data1->VREGISTNO = $nodrug;
        $data1->VMTRLCODE = $request->material;
        $data1->VASSETNO = $request->asset;
        $data1->VINSTRNAME = $request->kitsname;
        $data1->VINSTRBRAND = $request->kitsbrand;
        $data1->DPURCHASE = carbon::parse($request->DPURCHASE)->format('Y-m-d');
        $data1->DSUBMIT = carbon::parse($request->DSUBMIT)->format('Y-m-d');
        $data1->VLOCATION = $request->loc;
        $data1->VBU = $request->business;
        $data1->DLASTCLBRT = $dclbrt;
        $data1->NTOTAL = $request->quantity;
        $data1->VREMARKS = $request->remarks;
        $data1->BCRITERIA = $request->cryteria;
        $data1->VCLINICCODE = $request->VCLINICCODE;
        $data1->BSTATUS = $request->status;
        $data1->VUSER = Session::get('id');
        $data1->save();

        return response()-> json(['succsess'], 200);
    }

    public function update(Request $request)
    {
        $medicalsel = \App\Mstmedical::where('VREGISTNO','=',$request->regist);
        $medicalsel1 = \App\Mstmedicallogs::where('VREGISTNO','=',$request->regist);
        $validator = Validator::make($request->all(), [
            'material' => 'required|max:20',
            'VCLINICCODE'=>'required'
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        if($request->DCALIBRATE != '') $dclbrt = carbon::parse($request->DCALIBRATE)->format('Y-m-d');
        else $dclbrt = null;

        $medicalsel->update([
            'VREGISTNO' => $request->regist,
            'VMTRLCODE' => $request->material,
            'VASSETNO' => $request->asset,
            'VINSTRNAME' => $request->kitsname,
            'VINSTRBRAND' => $request->kitsbrand,
            'DPURCHASE' => carbon::parse($request->DPURCHASE)->format('Y-m-d'),
            'DSUBMIT' => carbon::parse($request->DSUBMIT)->format('Y-m-d'),
            'VLOCATION' => $request->loc,
            'VBU' => $request->business,
            'DLASTCLBRT' => $dclbrt,
            'NTOTAL' => $request->quantity,
            'VREMARKS' => $request->remarks,
            'BCRITERIA' => $request->cry,
            'VCLINICCODE' => $request->VCLINICCODE,
            'BSTATUS'  => $request->status,
            'DMODI'  => carbon::now(),
            'VMODI'  => Session::get('id'),
            
        ]);

        $medicalsel1->insert([
            'VREGISTNO' => $request->regist,
            'VMTRLCODE' => $request->material,
            'VASSETNO' => $request->asset,
            'VINSTRNAME' => $request->kitsname,
            'VINSTRBRAND' => $request->kitsbrand,
            'DPURCHASE' => carbon::parse($request->DPURCHASE)->format('Y-m-d'),
            'DSUBMIT' => carbon::parse($request->DSUBMIT)->format('Y-m-d'),
            'VLOCATION' => $request->loc,
            'VBU' => $request->business,
            'DLASTCLBRT' => $dclbrt,
            'NTOTAL' => $request->quantity,
            'VREMARKS' => $request->remarks,
            'BCRITERIA' => $request->cry,
            'VCLINICCODE' => $request->VCLINICCODE,
            'BSTATUS'  => $request->status,
            'VUSER' => session::get("id"),
            
        ]);
        return response()->json(['succsess'], 200);
    }

    public function edit($id){

        $ids = base64_decode($id);
        $medical = \App\Mstmedical::where('VREGISTNO',$ids)->leftjoin('MEDSYS_MSTCLINICS', function ($join) {$join->on('MEDSYS_MSTMDCLINSTRS.VCLINICCODE','=','MEDSYS_MSTCLINICS.VCLINICCODE')->select('MEDSYS_MSTCLINICS.VCLINICNAME');})->first();
        $status1 = DB::table('MEDSYS_MSTMDCLINSTRS')->where('BSTATUS')->get();

        $medical->DPURCHASE = Carbon::parse($medical->DPURCHASE)->format('d-m-Y');
        $medical->DSUBMIT = Carbon::parse($medical->DSUBMIT)->format('d-m-Y');
        if($medical->DLASTCLBRT != null) $medical->DCALIBRATE = Carbon::parse($medical->DCALIBRATE)->format('d-m-Y');
        if($medical->BSTATUS === "0"){

            $status = "Damage";
        }else{
            $status = "Good";
        }
        $status = DB::table('vw_mstmdclinst')->where('Status',$status)->first();

        $cryteria1 = DB::table('MEDSYS_MSTMDCLINSTRS')->where('BCRITERIA')->get();

        if($medical->BCRITERIA === "0"){

            $cryteria = "Calibration Not Required";
        }else{
            $cryteria = "Calibration Required";
        }
        $cryteria = DB::table('vw_mstmdclinst')->where('CRITERIA',$cryteria)->first();

        
        $general = \App\Mstgnrl::where('VGNRLTYPE', '=' , 'BUSSUNIT')->first();

        if($general->VGNRLCODE === "IF"){
            $desc1 = "Indra Fiber";
        }else if($general->VGNRLCODE === "KF"){
            $desc1 = "Kampar Fiber";
        }else if($general->VGNRLCODE === "RF"){
            $desc1 = "Riau Fiber";
        }else if($general->VGNRLCODE === "DF"){
            $desc1 = "Dumai Fiber";
        }else if($general->VGNRLCODE === "RPL"){
            $desc1 = "Riau Pulp";
        }

        $desc = DB::table('vw_mstmdclinst')->where('BUSINESS_UNIT',$desc1)->first();

        return view('home/medical/update',['cryteria1'=>$cryteria1, 'status1'=>$status1],compact('status','cryteria','medical','general','desc'));
    }

	public function export_excel(Request $request)
	{
        if(!$request){

            $request = "";
            return Excel::download(new MedicalExport($request),'Medical Kits.xls');

        }else{
            $no = $request->no;
            $rn = $request->rn;
            $mc = $request->mc;
            $ass = $request->ass;
            $insn = $request->insn;
            $insb = $request->insb;
            if(!$request->pd) $pd = '';
            else $pd = Carbon::parse($request->pd)->format('d-M-Y'); 
            if(!$request->sd) $sd = '';
            else $sd = Carbon::parse($request->sd)->format('d-M-Y');
            $ln = $request->ln;
            $bu = $request->bu;
            if(!$request->cd) $cd = '';
            else $cd = Carbon::parse($request->cd)->format('d-M-Y'); 
            $sta = $request->sta;
            $crit = $request->crit;
            $ques = $request->ques;
            $rmrks = $request->rmrks;
            if(!$request->lastmo) $lastmo = '';
            else $lastmo = Carbon::parse($request->lastmo)->format('d-M-Y'); 
            $modifiedn = $request->modifiedn;
            $search = $request->search;


            return Excel::download(new MedicalExport($no,$rn,$mc,$ass,$insn,$insb,$pd,$sd,$ln,$bu,$cd,$sta,$crit,$ques,$rmrks,$lastmo,$modifiedn,$search),'Medical Kits.xls');

        }
    }
}
