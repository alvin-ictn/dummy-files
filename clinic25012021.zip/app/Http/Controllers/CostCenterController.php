<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use app\Mstcostcenter;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use App\Exports\CostCenterExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use DB;

class CostCenterController extends Controller
{
    
    public function getajaxcostcenter($id){

        $i = base64_decode($id);
         $select = DB::select("SELECT COUNT(*) AS hitung FROM vw_mstcostcenter WHERE CC_CODE = '".$i."' ")[0];
         if($select->hitung <= 0){
            $null['data'] = "";
         }else{
            $null['data'] = "already";
         }
         return response()->json($null, 200);
    }

    public function ajax(Request $request)
    {
        $costcenters = \App\Mstcostcenter::all();
        $views = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY MONTH(MODIFY_DATE) DESC,YEAR(MODIFY_DATE) DESC,MODIFY_DATE ASC) AS No, CC_CODE, CC_NAME, STATUS, MODIFY_DATE, MODIFY_NAME 
                              FROM vw_mstcostcenter");
        return Datatables::of($views)
        ->addIndexColumn()
        
        ->filter(function ($instance) use ($request) {

            if (!empty($request->get('date'))) {
            
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
                    return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                
                });
            
            }
            if (!empty($request->get('search'))) {
                // search entire table
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                   $tmp_search = $request->get('search');  // inputed string in Search field
                   $column_names = ['No', 'CC_CODE', 'CC_NAME', 'STATUS', 'MODIFY_NAME', 'MODIFY_DATE'];
                   for($i = 0; $i < count($column_names); $i++)
                   {
                      // Check if cell of $column_names[$i] contains $tmp_search
                      if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                   }
                   return false;
                });
            }
        })
        
        ->addColumn('no', function($row){
            return $row->No;
        })
        ->addColumn('action', function($row){
            if(RoleAccessController::FunctionAccessCheck('U', 'F09')) return $row->CC_CODE;
            else return null;
        })
        ->addColumn('modify_date', function($row){
            return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
        })
        ->rawColumns(['action','no'])
        ->make(true);
    }

    public function insert(){
        return view('home/costcenter/add');
    }

    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'ccentercode' => 'required|max:20',
            'ccentername' =>'required|max:50',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        /// get dari Model  
        $data =  new \App\Mstcostcenter();
        $data->VCOSTCNTRCODE = $request->ccentercode;
        $data->VCOSTCNTRNAME = $request->ccentername;
        $data->BACTIVE = '1';
        $data->DMODI = Carbon::now();
        $data->VCREA = Session::get('id');
        $data->VMODI = Session::get('id');
        $data->save();
        return response()-> json(['succsess'], 200);
    }

    public function update(Request $request)
    {
        $costcentersel = \App\Mstcostcenter::where('VCOSTCNTRCODE','=',$request->ccentercode);
        
        $validator = Validator::make($request->all(), [
            'ccentername' => 'required|max:50',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        $costcentersel->update([
            'VCOSTCNTRCODE' => $request->ccentercode,
            'VCOSTCNTRNAME' => $request->ccentername,
            'BACTIVE' => $request->BACTIVEs,
            'DMODI'  => carbon::now(),
            'VMODI'  => Session::get('id'),
            
        ]);
        return response()->json(['succsess'], 200);
    }
    
    public function edit($id){
        $ids = base64_decode($id);
        $costcenter = \App\Mstcostcenter::where('VCOSTCNTRCODE',$ids)->first();

        return view('home/costcenter/update',compact('costcenter'));
    }
    
	public function export_excel(Request $request)
	{
        if(!$request){

            $request = "";
            return Excel::download(new CostCenterExport($request),'CostCenter.xls');

        }else{
            $no = $request->no;
            $cececo = $request->cececo;
            $ccname = $request->ccname;
            $statusc = $request->statusc;
            if(!$request->modifiedt){
                $lastmo = '';
            }else{
                
                $lastmo = Carbon::parse($request->modifiedt)->format('d-M-Y');

            }
            $lmname = $request->lmname;
            $search = $request->search;


            return Excel::download(new CostCenterExport($no,$cececo,$ccname,$statusc,$lastmo,$lmname,$search),'CostCenter.xls');

        }
    }
}
