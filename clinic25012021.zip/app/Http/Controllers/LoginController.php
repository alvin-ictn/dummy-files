<?php

namespace App\Http\Controllers;

use App\Mstclinicstaffs;
use App\Mstsettings;
use App\Mstuserclinic;
use App\Mstusers;
use App\Pwdhists;
use Hash;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Crypt;

class LoginController extends Controller
{
	protected $redirectTo = 'home/index';

    use AuthenticatesUsers;

	protected function credentials(Request $request)
	{
		return [
			'uid' => $request->get('username'),
			'password' => $request->get('password'), 	
		];
	}

    public function index($code_ = NULL)
    {
		if($code_)
		{
			return view('auth/login', ['prmchar' => Mstsettings::select('VSETDESC')->where('VSETID','PRMIT')->where('VSETCODE','CHAR')->first()->VSETDESC]);
		}
		else
		{
			if (Auth::check())
			{
				return redirect('/account/home');
			}
			else
			{
				return view('auth/login', ['prmchar' => Mstsettings::select('VSETDESC')->where('VSETID','PRMIT')->where('VSETCODE','CHAR')->first()->VSETDESC]);
			}
		}
    }
	
    public function updatetype(Request $request)
    {
		Mstusers::where('VUSRID', '=', $request->id)->update([ 'VUSRFLAG' => $request->typeuser ]);
		return response()->json(['success'], 200);
    }
	
	protected function hasTooManyLoginAttempts(Request $request)
    {
        return $this->limiter()->tooManyAttempts( $this->throttleKey($request), Mstsettings::select('VSETDESC')->where('VSETID','PRMIT')->where('VSETCODE','LOCK')->first()->VSETDESC );
    }

	public function login(Request $request)
    {
		$datad = Mstusers::where('MEDSYS_MSTUSERS.VUSRID', $request->username)
					->leftjoin('MEDSYS_MSTEMPLOYEES', function ($join) { $join->on('MEDSYS_MSTEMPLOYEES.VUSRID', '=', 'MEDSYS_MSTUSERS.VUSRID')->where('MEDSYS_MSTEMPLOYEES.BACTIVE', '1'); })
					->leftjoin('MEDSYS_MSTCLINICSTAFFS', 'MEDSYS_MSTCLINICSTAFFS.VUSRID', '=', 'MEDSYS_MSTUSERS.VUSRID')
					->join('MEDSYS_MSTUSERROLES', 'MEDSYS_MSTUSERROLES.VUSRID', '=', 'MEDSYS_MSTUSERS.VUSRID')->where('MEDSYS_MSTUSERROLES.BACTIVE', '=', '1')
					->select('MEDSYS_MSTUSERS.*', DB::raw('COALESCE(MEDSYS_MSTEMPLOYEES.VNAME, MEDSYS_MSTCLINICSTAFFS.VNAME) AS VNAME'))
					->first();
		if (isset($request->allow))
		{
			$datad->VUSRPASS = $request->password;
			parent::set_session($datad);
			return response()->json(['success']);
		}
		
		if ($datad)
		{
            if (!$datad->VUSRFLAG)
			{
                $null['id'] = $datad->VUSRID;
				$null['null'] = "NULL";
            }
			elseif ($datad->VUSRFLAG === 'AD')
			{
				//----LDAP Authentication
				$LDAP_AUTHENTICATED = false;
				
				// LDAP information
				$domain 			  = env('LDAP_DOMAIN');
				$ldap_username		  = env('LDAP_USERNAME');
				$ldap_password		  = env('LDAP_PASSWORD');
				$ldapconfig['host']   = env('LDAP_HOST');
				$ldapconfig['basedn'] = 'DC='.$domain.',DC=com';

				// Connect to LDAP
				$ldap = ldap_connect($ldapconfig['host']);
				ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
				ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);
				
				// Bind to LDAP
				try{
					$bind = ldap_bind($ldap, $domain ."\\".$ldap_username, $ldap_password);
					if ($bind) {
						$filter = "(sAMAccountName=".$request->username.")";
						$attributes = array("name", "telephonenumber", "mail", "samaccountname");
						$result = ldap_search($ldap, $ldapconfig['basedn'], $filter, $attributes);
						$entries = ldap_get_entries($ldap, $result);  
						$userDN = $entries[0]["name"][0];  
						try{
							$ldapBindUser = ldap_bind($ldap, $userDN, $request->password);
							$LDAP_AUTHENTICATED = true;
						}
						catch(\Exception $e){
							$null['null'] = 'PW';
							$null['pesan'] = 'Wrong credential!';
						}
					} else {
						$null['null'] = 'PW';
						$null['pesan'] = 'Failed to bind to LDAP server.';
					}
				}
				catch(\Exception $e){
					$null['null'] = 'PW';
					$null['pesan'] = 'Failed to bind to LDAP server.';
				}

				// Close connection
				ldap_close($ldap);

                if ($datad->BUSRLOCK != 1 && $datad->BACTIVE != 0)
				{
					if($LDAP_AUTHENTICATED)
					{
						if ($datad->DSIGNIN != NULL && (time()-60 * Mstsettings::select('VSETDESC')->where('VSETID','PRMIT')->where('VSETCODE','LOGOUT')->first()->VSETDESC) <= strtotime($datad->DSIGNIN))
						{
							$null['null'] = 'PW';
							$null['pesan'] = 'You have already logged in on another device.';
						}
						else
						{
							$datad->VUSRPASS = $request->password;
							parent::set_session($datad);
							$null['null'] = 'AD';
						}
					}
                }
				else
				{
					$null['null'] = 'PW';
                    $null['pesan'] = 'Account is locked, please contact your Administrator.';
                }
            }
			elseif ($datad->VUSRFLAG === "NAD")
			{
				if ($datad->BUSRLOCK != 1 && $datad->BACTIVE != 0)
				{
					if ($request->password == "")
					{
						$null['null'] = 'PW';
						$null['pesan'] = 'Password Required!';
					}
                    elseif (Hash::check($request->password, $datad->VUSRPASS))
					{
                        if (Pwdhists::where('VUSRID', $datad->VUSRID)->doesntExist())
						{
							$pwd = new Pwdhists();
							$pwd->VUSRID = $datad->VUSRID;
							$pwd->VUSRPASS = $datad->VUSRPASS;
							$pwd->VMODI = $datad->DCREA;
							$pwd->save();
						}
						if ($datad->DSIGNIN != NULL && (time()-60 * Mstsettings::select('VSETDESC')->where('VSETID','PRMIT')->where('VSETCODE','LOGOUT')->first()->VSETDESC) <= strtotime($datad->DSIGNIN))
						{
							$null['null'] = 'PW';
							$null['pesan'] = 'You have already logged in on another device.';
						}
						elseif ($datad->DLOGIN != NULL && (time()-86400 * Mstsettings::select('VSETDESC')->where('VSETID','PRMIT')->where('VSETCODE','DLOGIN')->first()->VSETDESC) > strtotime($datad->DLOGIN))
						{
							Mstusers::where('VUSRID', $datad->VUSRID)->update(['BACTIVE' => '0']);
							Mstclinicstaffs::where('VUSRID', $datad->VUSRID)->update(['BACTIVE' => '0']);

							$null['null'] = 'PW';
							$null['pesan'] = 'Account is inactive, please contact your Administrator.';
						}
						elseif ((time()-86400 * Mstsettings::select('VSETDESC')->where('VSETID','PRMIT')->where('VSETCODE','CP')->first()->VSETDESC) > strtotime(Pwdhists::where('VUSRID', $datad->VUSRID)->orderBy('VMODI', 'desc')->first()->VMODI))
						{
							$null['null'] = 'CP';
							$null['id'] = $datad->VUSRID;
						}
						elseif ((time()-86400 * (Mstsettings::select('VSETDESC')->where('VSETID','PRMIT')->where('VSETCODE','CP')->first()->VSETDESC - Mstsettings::select('VSETDESC')->where('VSETID','PRMIT')->where('VSETCODE','RCP')->first()->VSETDESC)) > strtotime(Pwdhists::where('VUSRID', $datad->VUSRID)->orderBy('VMODI', 'desc')->first()->VMODI))
						{
							$null['null'] = 'RCP';
							$null['id'] = $datad->VUSRID;

							$now = \Carbon\Carbon::now();		// Today
							$date = \Carbon\Carbon::parse(Pwdhists::where('VUSRID', $datad->VUSRID)->orderBy('VMODI', 'desc')->first()->VMODI);	// Last changed password date
							$diff = $date->diffInDays($now);	// difference(in day(s)) between Today and last changed password date
							$null['dayleft'] = (int)Mstsettings::select('VSETDESC')->where('VSETID','PRMIT')->where('VSETCODE','CP')->first()->VSETDESC - (int)$diff;	// daysleft

							if ($datad->VTYPEUSR == "NE")
							{
								$null['data'] = $this->listclinic($datad->VUSRID)['data'];
							}
						}
						else
						{
							if ($datad->VTYPEUSR == "NE")
							{
								$null = $this->listclinic($datad->VUSRID);
							}
							else
							{
								$datad->VUSRPASS = $request->password;
								parent::set_session($datad);
								$null['null'] = 'NAD';
							}
						}
						
						// Reset every time user(now) entered the correct password
						$this->resetAttemptCounter($datad->VUSRID);
                    }
					else
					{
						// if ($this->hasTooManyLoginAttempts($request))
						// {
						// 	Mstusers::where('VUSRID', $datad->VUSRID)->update(['BUSRLOCK' => '1', 'BACTIVE' => '0']);
						// 	$null['null'] = 'PW';
						// 	$null['pesan'] = 'Account is locked, please contact your Administrator.';
                        // }
						// else
						// {
						// 	$this->incrementLoginAttempts($request);
						// 	$null['null'] = 'PW';
						// 	$null['pesan'] = 'Incorrect Password! You have entered "' . ($this->maxAttempts() - $this->limiter()->retriesLeft($this->throttleKey($request), $this->maxAttempts())) . '" times wrong!';
						// }

						// When entered a wrong password
						$this->incrementAttemptCounter($datad->VUSRID);	// Increment attempt counter
						$null['null'] = 'PW';
						$null['pesan'] = 'Incorrect Password! You have entered "' . ($this->getAttemptCounter($datad->VUSRID)) . '" times wrong!';
						if ($this->checkTooManyAttempts($datad->VUSRID))	// If attempt counter reached limit number, lock the user
						{
							Mstusers::where('VUSRID', $datad->VUSRID)->update(['BUSRLOCK' => '1']);
							$null['null'] = 'PW';
							$null['pesan'] = 'Account is locked, please contact your Administrator.';
						}
					}
                }
				else
				{
					$null['null'] = 'PW';
                    $null['pesan'] = 'Account is locked, please contact your Administrator.';
                }
                return response()->json($null);
			}
		}
		else
		{
			$null['null'] = 'PW';
			$null['pesan'] = 'Invalid User ID, please contact your Administrator.';
			//$this->incrementLoginAttempts($request);
            //$null['null'] = 'PW';
            //$null['pesan'] = 'Incorrect Username! You have entered "' . ($this->maxAttempts() - $this->limiter()->retriesLeft($this->throttleKey($request), $this->maxAttempts())) . '" times wrong!';
		}
        return response()->json($null);
    }

    public function listclinic($user)
	{
		$null['null'] = "cc";
		$null['data'] = Mstuserclinic::where('VUSRID', $user)->where('MEDSYS_MSTUSERCLINICS.BACTIVE', '1')->join('MEDSYS_MSTCLINICS', 'MEDSYS_MSTUSERCLINICS.VCLINICCODE', '=', 'MEDSYS_MSTCLINICS.VCLINICCODE')->select('MEDSYS_MSTCLINICS.VCLINICCODE', 'MEDSYS_MSTCLINICS.VCLINICNAME')->get();
		return $null;
	}
	

	
    public function logindoctor(Request $request)
	{
		$datad = Mstclinicstaffs::where('MEDSYS_MSTCLINICSTAFFS.VUSRID', $request->id)->join('MEDSYS_MSTUSERS', 'MEDSYS_MSTCLINICSTAFFS.VUSRID', '=', 'MEDSYS_MSTUSERS.VUSRID')->select('MEDSYS_MSTUSERS.VUSRID', 'MEDSYS_MSTCLINICSTAFFS.VNAME', 'MEDSYS_MSTUSERS.VTYPEUSR')->first();
		$Mstclinics = \DB::select("SELECT VCLINICNAME, VCLINICCODE FROM MEDSYS_MSTCLINICS WHERE VCLINICCODE = '$request->typeclinic'")[0];
		
		$datad->VUSRPASS = $request->password;
		
		parent::set_session($datad, ['namaclinic' => $request->typeclinic]);		// bukan nama -> harusnya code
		parent::set_session($datad, ['cliniccode' => $Mstclinics->VCLINICCODE]);	// Clinic code
		parent::set_session($datad, ['clinicname' => $Mstclinics->VCLINICNAME]);	// Clinic name
		
		return redirect('/account/home');
    }
	
    public function changepassword(Request $request)
	{
		$Users = Mstusers::where('VUSRID', $request->email);
		if ($Users->first()->VUSRPASS != NULL)
		{
			$check = parent::check_old_password($request->email, $request->new);
			if (!$check[0])
			{
				$null['null'] = "cp";
				$null['pesan'] = $check[1];
				return response()->json($null);
			}
		}
		$salt = bcrypt($request->new);
		$Users->update([
            'VUSRFLAG' => $request->typeuser,
			'VUSRPASS' => $salt
        ]);
		$pwd = new Pwdhists();
		$pwd->VUSRID = $request->email;
		$pwd->VUSRPASS = $salt;
		$pwd->save();
		if ($Users->first()->VTYPEUSR == "NE")
		{
			return response()->json($this->listclinic($Users->first()->VUSRID));
		}
		$null['null'] = "NULL";
		$datad = Mstusers::where('MEDSYS_MSTUSERS.VUSRID', $request->email)->leftjoin('MEDSYS_MSTEMPLOYEES', function ($join) { $join->on('MEDSYS_MSTEMPLOYEES.VUSRID', '=', 'MEDSYS_MSTUSERS.VUSRID')->where('MEDSYS_MSTEMPLOYEES.BACTIVE', '1'); })->select('MEDSYS_MSTUSERS.VUSRID', 'MEDSYS_MSTUSERS.VTYPEUSR', 'MEDSYS_MSTEMPLOYEES.VNAME')->first();
		$datad->VUSRPASS = $request->new;
		parent::set_session($datad);
		return response()->json($null);
	}
	
	//==== Change Password when Forgot Password
	public function ChngPwdForgotPassword(Request $request)
	{
		$Users = Mstusers::where('VUSRID', $request->email);
		if ($Users->first()->VUSRPASS != NULL)
		{
			$check = parent::check_old_password($request->email, $request->new);
			if (!$check[0])
			{
				$null['null'] = "cp";
				$null['msg'] = $check[1];
				return response()->json($null, 400);
			}
		}
		$salt = bcrypt($request->new);
		$Users->update([
            //'VUSRFLAG' => $request->typeuser,
			'VUSRPASS' => $salt
        ]);
		$pwd = new Pwdhists();
		$pwd->VUSRID = $request->email;
		$pwd->VUSRPASS = $salt;
		$pwd->save();

		return response()->json(['success'], 200);
	}

	//==== Login Attempt
	// Get number of attempts
	public function getAttemptCounter($userid)
	{
		$attempts = Mstusers::select('ICOUNT')->where('VUSRID', $userid)->first()->ICOUNT;
		if($attempts == null) Mstusers::where('VUSRID', $userid)->update(['ICOUNT' => 0]);
		return $attempts;
	}

	// Check if number of attempts has passed the limit of login attempt
	public function checkTooManyAttempts($userid)
	{
		$limit = Mstsettings::select('VSETDESC')->where('VSETID','PRMIT')->where('VSETCODE','LOCK')->first()->VSETDESC;
		$attempts = Mstusers::select('ICOUNT')->where('VUSRID', $userid)->first()->ICOUNT;
		return $limit <= $attempts;
	}

	// Increment number of attempts
	public function incrementAttemptCounter($userid)
	{
		$attempts = Mstusers::select('ICOUNT')->where('VUSRID', $userid)->first()->ICOUNT;
		$attempts++;
		Mstusers::where('VUSRID', $userid)->update(['ICOUNT' => $attempts]);
	}

	// Reset number of attempts (When successfully logged in)
	public function resetAttemptCounter($userid)
	{
		Mstusers::where('VUSRID', $userid)->update(['ICOUNT' => 0]);
	}
}