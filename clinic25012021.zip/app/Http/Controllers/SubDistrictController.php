<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use app\Mstsubdistrict;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use App\Exports\SubdistrictExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use DB;
class SubDistrictController extends Controller
{

    public function ajax(Request $request){

        $subdist = \App\Mstsubdistrict::all()->first();
        $view = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY MONTH(MODIFY_DATE) DESC,YEAR(MODIFY_DATE) DESC,MODIFY_DATE ASC) AS No, SUBDISTRICTCODE, SUBDISTRICTNAME, DISTRICT_NAME, STATUS, MODIFY_DATE, MODIFY_NAME 
                                FROM vw_mstsubdistrict");

        return Datatables::of($view)
        ->addIndexColumn()
        
        ->filter(function ($instance) use ($request) {
            if (!empty($request->get('date'))) {
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
                    return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                
                });
            }
            if (!empty($request->get('search'))) {
                // search entire table
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $tmp_search = $request->get('search');  // inputed string in Search field
                    $column_names = ['No', 'SUBDISTRICTCODE', 'SUBDISTRICTNAME', 'DISTRICT_NAME', 'STATUS', 'MODIFY_NAME', 'MODIFY_DATE'];
                    for($i = 0; $i < count($column_names); $i++)
                    {
                        // Check if cell of $column_names[$i] contains $tmp_search
                        if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                    }
                    return false;
                });
            }
        })

        ->addColumn('no', function($row){
            return  $row->No;
        })
        ->addColumn('action', function($row){
            if(RoleAccessController::FunctionAccessCheck('U', 'F21')) return $row->SUBDISTRICTCODE;
            else return null;
        })
        ->addColumn('modify_date', function($row){
            return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
        })
        ->rawColumns(['action','no'])
        ->make(true);
    }
    
    public function insert(){
        $disc = \App\Mstdistrict::where('BACTIVE','=','1')->get();

        return view('home/subdistrict/add')->with('disc',$disc);
    }
    
    public function edit($id){

        $ids = base64_decode($id);
        $subdistrict = \App\Mstsubdistrict::where('VSUBDISTRICTCODE',$ids)->leftJoin('MEDSYS_MSTDISTRICTS', function ($join) { $join->on('MEDSYS_MSTSUBDISTRICTS.VDISTRICTCODE', '=', 'MEDSYS_MSTDISTRICTS.VDISTRICTCODE')->select('MEDSYS_MSTDISTRICTS.VDISTRICTNAME'); })->first();

        return view('home/subdistrict/update',compact('subdistrict'));
    }

    
    public function update(Request $request)
    {
        $subdistrictsel = \App\Mstsubdistrict::where('VSUBDISTRICTCODE','=',$request->subdistcode);
        
        $validator = Validator::make($request->all(), [
            'subdistname' => 'required|max:50',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        $subdistrictsel->update([
            'VSUBDISTRICTNAME' => $request->subdistname,
            'BACTIVE'  => $request->BACTIVEs,
            'DMODI'  => carbon::now(),
            'VMODI'  => Session::get('id'),
            
            
        ]);
        return response()->json(['succsess'], 200);
    }

    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'subdistcode' => 'required|max:5',
            'subdistname' =>'required|max:50',
            'distcode' =>'required|max:5',

        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        /// get dari model  
        $data =  new \App\Mstsubdistrict();
        $data->VSUBDISTRICTCODE = $request->subdistcode;
        $data->VSUBDISTRICTNAME = $request->subdistname;
        $data->VDISTRICTCODE = $request->distcode;
        $data->BACTIVE = '1';
        $data->DMODI = Carbon::now();
        $data->VCREA =  Session::get('id');
        $data->VMODI =  Session::get('id');
        $data->save();
        return response()-> json(['succsess'], 200);
    }
    public function getajaxsubdistrict($id){

        $subdistrictsel = \App\Mstsubdistrict::where('VDISTRICTCODE','=',$id)->get();
        $subdistrict ="";
        foreach($subdistrictsel as $a){

            $subdistrict .="<option value=".$a->VSUBDISTRICTCODE.">".$a->VSUBDISTRICTNAME."</option>";
        }
    return response()->json($subdistrict, 200);

    }
    
	public function export_excel(Request $request)
	{
        if(!$request){

            $id ="";
            return Excel::download(new SubdistrictExport($id),'SubDistrict.xls');


        }else{
            $no = $request->no;
            $subdistcode = $request->subdistcode;
            $subdistname = $request->subdistname;
            $distname = $request->distname;
            $status = $request->status;
            $lmname = $request->lmname;
            if(!$request->lmdate){
                $lmdate = '';
            }else{
                
                $lmdate = Carbon::parse($request->lmdate)->format('d-M-Y');
                
            }
            $search = $request->search;

            return Excel::download(new SubdistrictExport($no,$subdistcode,$subdistname,$distname,$status,$lmname,$lmdate,$search),'SubDistrict.xls');

        }
    }
}
