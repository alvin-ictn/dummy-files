<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use app\Mstsettings;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Crypt;
use App\Doclists;
use app\Mstuserrole;
use App\MEDSYS_EXAMINATIONS;
use App\MEDSYS_EXAMINATIONDTLS;
use App\MEDSYS_EXAMINATIONLOGS;
use App\MEDSYS_EXAMINATIONDTLLOGS;
use App\ClinicModel;
use App\Invmovedtllogs;
use App\Invmovedtls;
use App\Invmovehdrlogs;
use App\Invmovehdrs;
use App\Invrequestdtls;
use App\Invrequests;
use App\Mstdrugs;
use App\Treatment;
use PDF;
use DateTime;
use App\Mstclinicstaffs;
use JasperPHP;

class BookingController extends Controller
{
    //
    public function view_print($id)
    {

        $treatment = DB::select("SELECT b.VCONTAIN FROM MEDSYS_TREATMENTS a JOIN MEDSYS_MSTDRUGS b ON a.VDRUGSCODE = b.VDRUGSCODE WHERE a.VBOOKINGNO = '" . $id . "' ");
        $drugs = DB::select(DB::raw("SELECT b.VNAME,a.DVISIT FROM MEDSYS_SCHBOOKS a JOIN MEDSYS_MSTCLINICSTAFFS b ON a.VDRID = b.VUSRID WHERE a.VBOOKINGNO = '" . $id . "' ")) [0];

        return view('Pdf/treatment', ['treatment' => $treatment], compact('drugs'));

    }
    public function getDateFormat()
    {
        return 'Y-d-m H:i:s';
    }
    public function addbooking()
    {
        $clinic = DB::select("SELECT VCLINICCODE,VCLINICINIT,VCLINICNAME FROM MEDSYS_MSTCLINICS WHERE BACTIVE = '1' AND BDISPLAY = '1' ");
        return view('home/bookingsch/add', ['clinic' => $clinic]);
    }
    public function viewbook()
    {

        $book = DB::table('MEDSYS_MSTPATIENT')->get();

        return Datatables::of($book)->addIndexColumn()->addColumn('action', function ($row)
        {

            // return '<a class="btn btn-link btn-sm" href="doctors/edit/'.Crypt::encryptString($row->VDRCODE).'">'.$row->VDRCODE.'</a>';
            return '<a class="btn btn-link btn-sm" href="#">' . $row->VDRCODE . '</a>';
        })->addColumn('BACTIVE', function ($row)
        {

            if ($row->BACTIVE === '1')
            {

                $return = '<span class="badge badge-pill badge-success">Active</span>';
            }
            else
            {

                $return = '<span class="badge badge-pill badge-danger">Non active</span>';
            }
            return $return;
        })->rawColumns(['action', 'BACTIVE'])
            ->make(true);
    }
    public function ajaxdoctor($id)
    {

        $base64 = base64_decode($id);
        $clinic = DB::select("SELECT VCLINICCODE,VCLINICINIT,VCLINICNAME FROM MEDSYS_MSTCLINICS");
        $setting = \App\Mstsettings::where('VSETID', 'TYPEDCTR')->orderby('DCREA', 'ASC')
            ->get();

        return response()
            ->json($setting);
    }
    public function choosedoctor($id)
    {
        $ida = base64_decode($id);
        list($x, $y, $c) = explode(",", $ida);
        if ($x === "UMUM")
        {

            $null['null'] = "";
            $null['null'] .= "U";
            $type = base64_encode("U" . ',' . ' ' . ',' . $c . ',' . 'UMUM');
            $null['crypt'] = Crypt::encryptString($type);
            $null['VCLINICCODE'] = $c;
        }
        elseif ($x === "GIGI")
        {

            $null['null'] = "";
            $null['null'] .= "G";

            $type = base64_encode("G" . ',' . ' ' . ',' . $c . ',' . "GIGI");
            $null['crypt'] = Crypt::encryptString($type);
            $null['VCLINICCODE'] = $c;
        }
        elseif ($x === "SPCL")
        {
            $booking = DB::select("SELECT DISTINCT  MEDSYS_SCHDCTRHDRS.VCLINICCODE, MEDSYS_SCHDCTRHDRS.VUSRID, MEDSYS_MSTCLINICSTAFFS.VNAME FROM MEDSYS_SCHDCTRHDRS
                                LEFT JOIN MEDSYS_MSTUSERS ON MEDSYS_SCHDCTRHDRS.VUSRID = MEDSYS_MSTUSERS.VUSRID
                                LEFT JOIN MEDSYS_MSTCLINICSTAFFS  ON MEDSYS_MSTCLINICSTAFFS.VUSRID = MEDSYS_MSTUSERS.VUSRID
                                LEFT JOIN MEDSYS_SCHDCTRDTLS ON MEDSYS_SCHDCTRHDRS.VSCHCODE = MEDSYS_SCHDCTRDTLS.VSCHCODE
                                WHERE MEDSYS_SCHDCTRHDRS.VSPCCODE = '" . $y . "' AND MEDSYS_SCHDCTRHDRS.VCLINICCODE = '" . $c . "' AND MEDSYS_SCHDCTRHDRS.BACTIVE = '1'");
            $null['null'] = "";
            if (!$booking)
            {
                $null['null'] = "<div class='row'>
            <div class='col-xl-12 col-sm-12'>
              <div class='card'>
               <div class='card-header  card-rounded'>No doctors available</div>
               </div>
            </div>
               ";
            }
            else
            {
                foreach ($booking as $a)
                {

                    $null['null'] .= "<div class='row'>
             <div class='col-xl-10 col-sm-12'>
               <div class='card'>
                <div class='card-header  card-rounded'>" . $a->VNAME . "</div>
                  <div class='card-body card-rounded'>
                     <div class='table-responsive'>
                        <table class='table'>
                        <thead>
                             <tr>
                        ";
                    $daysmorning = DB::select("SELECT
                                                MAX(CASE WHEN VSCHDAY = 'SUNDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '24:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) = '12:00' THEN ' - 'WHEN VSCHDAY = 'SUNDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', '12:00') WHEN VSCHDAY = 'SUNDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '01:00' AND '12:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'SUNDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '22:00' THEN ' - ' ELSE ' - ' END) as 'SUNDAY',
                                                MAX(CASE WHEN VSCHDAY = 'MONDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '24:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) = '12:00' THEN ' - 'WHEN VSCHDAY = 'MONDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', '12:00') WHEN VSCHDAY = 'MONDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '01:00' AND '12:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'MONDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '22:00' THEN ' - ' ELSE ' - ' END) as 'MONDAY',
                                                MAX(CASE WHEN VSCHDAY = 'TUESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '24:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) = '12:00' THEN ' - 'WHEN VSCHDAY = 'TUESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', '12:00') WHEN VSCHDAY = 'TUESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '01:00' AND '12:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'TUESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '22:00' THEN ' - ' ELSE ' - ' END) as 'TUESDAY',
                                                MAX(CASE WHEN VSCHDAY = 'WEDNESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '24:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) = '12:00' THEN ' - ' WHEN VSCHDAY = 'WEDNESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', '12:00') WHEN VSCHDAY = 'WEDNESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '01:00' AND '12:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'WEDNESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '22:00' THEN ' - ' ELSE ' - ' END) as 'WEDNESDAY',
                                                MAX(CASE WHEN VSCHDAY = 'THURSDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '24:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) = '12:00' THEN ' - ' WHEN VSCHDAY = 'THURSDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', '12:00') WHEN VSCHDAY = 'THURSDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '01:00' AND '12:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'THURSDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '22:00' THEN ' - ' ELSE ' - ' END) as 'THURSDAY',
                                                MAX(CASE WHEN VSCHDAY = 'FRIDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '24:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) = '12:00' THEN ' - 'WHEN VSCHDAY = 'FRIDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', '12:00') WHEN VSCHDAY = 'FRIDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '01:00' AND '12:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'FRIDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '22:00' THEN ' - ' ELSE ' - ' END) as 'FRIDAY',
                                                MAX(CASE WHEN VSCHDAY = 'SATURDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '24:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) = '12:00' THEN ' - 'WHEN VSCHDAY = 'SATURDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', '12:00') WHEN VSCHDAY = 'SATURDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '01:00' AND '12:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'SATURDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '12:00' AND '22:00' THEN ' - ' ELSE ' - ' END) as 'SATURDAY'
                                                FROM MEDSYS_SCHDCTRDTLS JOIN MEDSYS_SCHDCTRHDRS ON MEDSYS_SCHDCTRHDRS.VSCHCODE = MEDSYS_SCHDCTRDTLS.VSCHCODE
                                                WHERE  MEDSYS_SCHDCTRHDRS.VUSRID = '" . $a->VUSRID . "' AND MEDSYS_SCHDCTRHDRS.VCLINICCODE = '" . $a->VCLINICCODE . "' AND MEDSYS_SCHDCTRDTLS.BACTIVE = '1'
                                                -- AND convert(time, MEDSYS_SCHDCTRDTLS.TSCHSTART) >= '03:00:00' and convert(time, MEDSYS_SCHDCTRDTLS.TSCHEND) < '11:59:00'
                                            ");
                    $daysafternoon = DB::select("SELECT
                                                    MAX(CASE WHEN VSCHDAY = 'SUNDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) = '12:00' THEN ' - ' WHEN VSCHDAY = 'SUNDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT('12:00',' - ',CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'SUNDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) ELSE ' - ' END) as 'SUNDAY',
                                                    MAX(CASE WHEN VSCHDAY = 'MONDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) = '12:00' THEN ' - '  WHEN VSCHDAY = 'MONDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT('12:00',' - ',CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'MONDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) ELSE ' - ' END) as 'MONDAY',
                                                    MAX(CASE WHEN VSCHDAY = 'TUESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) = '12:00' THEN ' - '  WHEN VSCHDAY = 'TUESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT('12:00',' - ',CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'TUESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) ELSE ' - ' END) as 'TUESDAY',
                                                    MAX(CASE WHEN VSCHDAY = 'WEDNESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) = '12:00' THEN ' - '  WHEN VSCHDAY = 'WEDNESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT('12:00',' - ',CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'WEDNESDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) ELSE ' - ' END) as 'WEDNESDAY',
                                                    MAX(CASE WHEN VSCHDAY = 'THURSDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) = '12:00' THEN ' - '  WHEN VSCHDAY = 'THURSDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT('12:00',' - ',CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'THURSDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) ELSE ' - ' END) as 'THURSDAY',
                                                    MAX(CASE WHEN VSCHDAY = 'FRIDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) = '12:00' THEN ' - '  WHEN VSCHDAY = 'FRIDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT('12:00',' - ',CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'FRIDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) ELSE ' - ' END) as 'FRIDAY',
                                                    MAX(CASE WHEN VSCHDAY = 'SATURDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) = '12:00' THEN ' - '  WHEN VSCHDAY = 'SATURDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108) BETWEEN '01:00' AND '12:00' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT('12:00',' - ',CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) WHEN VSCHDAY = 'SATURDAY' AND CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108) BETWEEN '12:00' AND '23:00' THEN CONCAT(CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHSTART, 108), ' - ', CONVERT(char(5), MEDSYS_SCHDCTRDTLS.TSCHEND, 108)) ELSE ' - ' END) as 'SATURDAY'
                                                    FROM MEDSYS_SCHDCTRDTLS JOIN MEDSYS_SCHDCTRHDRS ON MEDSYS_SCHDCTRHDRS.VSCHCODE = MEDSYS_SCHDCTRDTLS.VSCHCODE
                                                    WHERE  MEDSYS_SCHDCTRHDRS.VUSRID = '" . $a->VUSRID . "' AND MEDSYS_SCHDCTRHDRS.VCLINICCODE = '" . $a->VCLINICCODE . "' AND MEDSYS_SCHDCTRDTLS.BACTIVE = '1'
                                                    --   AND convert(time, MEDSYS_SCHDCTRDTLS.TSCHSTART) >= '12:00:00' and convert(time, MEDSYS_SCHDCTRDTLS.TSCHEND) < '23:59:00'
                                                ");
                    $null['null'] .= "<th scope='col'>Sunday</th>
                            <th scope='col'>Monday</th>
                            <th scope='col'>Tuesday</th>
                            <th scope='col'>Wednesday</th>
                            <th scope='col'>Thursday</th>
                            <th scope='col'>Friday</th>
                            <th scope='col'>Saturday</th>

                            </tr>
                           </thead>
                           <tbody>";

                    foreach ($daysmorning as $d)
                    {
                        /// Pagi
                        $null['null'] .= "<tr>";
                        $null['null'] .= "<td scope='col'>" . $d->SUNDAY . "</td>";
                        $null['null'] .= "<td scope='col'>" . $d->MONDAY . "</td>";
                        $null['null'] .= "<td scope='col'>" . $d->TUESDAY . "</td>";
                        $null['null'] .= "<td scope='col'>" . $d->WEDNESDAY . "</td>";
                        $null['null'] .= "<td scope='col'>" . $d->THURSDAY . "</td>";
                        $null['null'] .= "<td scope='col'>" . $d->FRIDAY . "</td>";
                        $null['null'] .= "<td scope='col'>" . $d->SATURDAY . "</td>";
                        $null['null'] .= "</tr>";
                    }
                    foreach ($daysafternoon as $d)
                    {
                        // Siang
                        $null['null'] .= "<tr>";
                        $null['null'] .= "<td scope='col'>" . $d->SUNDAY . "</td>";
                        $null['null'] .= "<td scope='col'>" . $d->MONDAY . "</td>";
                        $null['null'] .= "<td scope='col'>" . $d->TUESDAY . "</td>";
                        $null['null'] .= "<td scope='col'>" . $d->WEDNESDAY . "</td>";
                        $null['null'] .= "<td scope='col'>" . $d->THURSDAY . "</td>";
                        $null['null'] .= "<td scope='col'>" . $d->FRIDAY . "</td>";
                        $null['null'] .= "<td scope='col'>" . $d->SATURDAY . "</td>";
                        $null['null'] .= "</tr>";

                    }

                    //   }
                    //$null['null'] .="<th scope='col'>".$days->VSCHDAY." ".Carbon::parse($days->TSCHSTART)->format('H:i')."-".Carbon::parse($days->TSCHEND)->format('H:i')."</th>";


                    $null['null'] .= "
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
            <div class='col-xl-2 col-sm-12'>
               <a href='add/appointment/" . Crypt::encryptString(base64_encode("S" . ',' . $a->VUSRID . ',' . $c . ',' . 'SPCL')) . "' type='button' class='btn btn-sz btn-primary btn-block'>Create Appointment</a>
            </div>
        </div>";
                }
            }
        }
        return response()->json($null);
    }
    public function appointment($id)
    {

        $decrypt = Crypt::decryptString($id);
        $base = base64_decode($decrypt);
        list($x, $y, $c, $i) = explode(",", $base);
        $user = DB::SELECT("SELECT MEDSYS_MSTUSERS.VTYPEUSR,MEDSYS_MSTEMPLOYEES.VEMPSAPID,
                                    MEDSYS_MSTEMPLOYEES.VNAME,MEDSYS_MSTEMPLOYEES.VCITYBIRTH
                                    ,FORMAT (MEDSYS_MSTEMPLOYEES.DBIRTH, 'yyyy-MM-dd') DBIRTH ,MEDSYS_MSTEMPLOYEES.VPHONENO
                                    FROM MEDSYS_MSTUSERS LEFT JOIN MEDSYS_MSTEMPLOYEES ON MEDSYS_MSTEMPLOYEES.VUSRID = MEDSYS_MSTUSERS.VUSRID WHERE MEDSYS_MSTUSERS.VUSRID = ?", [Session::get('id') ]) [0];
        if ($x === "U")
        {

            $day = $y;
            $code = 'U';
            $mstclinic = DB::table("MEDSYS_MSTCLINICS")->select('VCLINICINIT', 'VCLINICCODE')
                ->where("VCLINICCODE", $c)->first();
            $setting2 = \App\Mstsettings::select('VSETDESC')->where('VSETID', 'PRMRGST')
                ->where('VSETCODE', 'DOWN')
                ->orderby('DCREA', 'ASC')
                ->first();

            return view('home/bookingsch/appointment', ['day' => $day, 'code' => $code, 'user' => $user, 'mstclinic' => $mstclinic, 'setting2' => $setting2, 'typedctr' => $i]);
        }
        else if ($x === "G")
        {

            $day = $y;
            $code = 'G';
            $mstclinic = DB::table("MEDSYS_MSTCLINICS")->select('VCLINICINIT', 'VCLINICCODE')
                ->where("VCLINICCODE", $c)->first();
            $setting2 = \App\Mstsettings::select('VSETDESC')->where('VSETID', 'PRMRGST')
                ->where('VSETCODE', 'DOWN')
                ->orderby('DCREA', 'ASC')
                ->first();

            return view('home/bookingsch/appointment', ['day' => $day, 'code' => $code, 'user' => $user, 'mstclinic' => $mstclinic, 'setting2' => $setting2, 'typedctr' => $i]);
        }
        else if ($x === "S")
        {
            $day = DB::table("MEDSYS_SCHDCTRHDRS")->select('VUSRID', 'VSCHCODE')
                ->where("VUSRID", $y)->first();
            $mstclinic = DB::table("MEDSYS_MSTCLINICS")->select('VCLINICINIT', 'VCLINICCODE')
                ->where("VCLINICCODE", $c)->first();

            $setting2 = \App\Mstsettings::select('VSETDESC')->where('VSETID', 'PRMRGST')
                ->where('VSETCODE', 'DOWN')
                ->orderby('DCREA', 'ASC')
                ->first();
            Session::put('SAPID', $user->VEMPSAPID);
            Session::put('VINAME', $user->VNAME);
            Session::put('VCITYBIRTH', $user->VCITYBIRTH);
            Session::put('DBIRTH', $user->DBIRTH);
            Session::put('VPHONENO', $user->VPHONENO);
            return view('home/bookingsch/appointment', ['typedctr' => $i], compact('day', 'setting2', 'user', 'mstclinic'));
        }
    }
    public function ajaxdetaildoctor($id)
    {
        $ids = base64_decode($id);

        list($x, $y) = explode(",", $ids);
        if ($x === 'U')
        {
            $day = 'U';
            return response()->json($day);
        }
        else if ($x === 'G')
        {
            /// gigi
            $ab = DB::select(DB::raw("SELECT
         MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'SUNDAY' THEN '0' ELSE ''  END ) AS 'a',
         MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'MONDAY' THEN '1' ELSE ''   END ) AS 'b',
         MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'TUESDAY' THEN '2' ELSE ''   END ) AS 'c',
         MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'WEDNESDAY' THEN '3'  ELSE ''  END ) AS 'd',
         MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'THURSDAY' THEN '4' ELSE ''   END ) AS 'e',
         MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'FRIDAY' THEN '5'  ELSE ''  END ) AS 'f',
         MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'SATURDAY' THEN '6' ELSE '' END ) AS 'g'
        FROM MEDSYS_SCHDCTRDTLS JOIN MEDSYS_SCHDCTRHDRS ON MEDSYS_SCHDCTRHDRS.VSCHCODE = MEDSYS_SCHDCTRDTLS.VSCHCODE
                WHERE  MEDSYS_SCHDCTRHDRS.VSPCCODE IS NULL AND MEDSYS_SCHDCTRHDRS.VCLINICCODE = '" . $y . "' AND MEDSYS_SCHDCTRDTLS.BACTIVE = '1' ")) [0];

            if ($ab->a === '0')
            {
                $a = '';
            }
            else
            {
                $a = '0';
            }
            if ($ab->b === '1')
            {
                $b = '';
            }
            else
            {
                $b = '1';
            }
            if ($ab->c === '2')
            {
                $c = '';
            }
            else
            {
                $c = '2';
            }
            if ($ab->d === '3')
            {
                $d = '';
            }
            else
            {
                $d = '3';
            }
            if ($ab->e === '4')
            {
                $e = '';
            }
            else
            {
                $e = '4';
            }
            if ($ab->f === '5')
            {
                $f = '';
            }
            else
            {
                $f = '5';
            }
            if ($ab->g === '6')
            {
                $g = '';
            }
            else
            {
                $g = '6';
            }
            $day = array(

                '0' => $a,
                '1' => $b,
                '2' => $c,
                '3' => $d,
                '4' => $e,
                '5' => $f,
                '6' => $g,
            );
            $dctr = 'G';

            return response()->json([$day, $dctr]);
        }
        else
        {
            /// spesialist
            $ab = DB::select(DB::raw("SELECT
        MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'SUNDAY' THEN '0' ELSE ''  END ) AS 'a',
        MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'MONDAY' THEN '1' ELSE ''   END ) AS 'b',
        MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'TUESDAY' THEN '2' ELSE ''   END ) AS 'c',
        MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'WEDNESDAY' THEN '3'  ELSE ''  END ) AS 'd',
        MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'THURSDAY' THEN '4' ELSE ''   END ) AS 'e',
        MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'FRIDAY' THEN '5'  ELSE ''  END ) AS 'f',
        MAX(CASE WHEN MEDSYS_SCHDCTRDTLS.VSCHDAY = 'SATURDAY' THEN '6' ELSE '' END ) AS 'g'
       FROM MEDSYS_SCHDCTRDTLS JOIN MEDSYS_SCHDCTRHDRS ON MEDSYS_SCHDCTRHDRS.VSCHCODE = MEDSYS_SCHDCTRDTLS.VSCHCODE
               WHERE  MEDSYS_SCHDCTRHDRS.VUSRID = '" . $x . "' AND MEDSYS_SCHDCTRHDRS.VCLINICCODE = '" . $y . "' AND MEDSYS_SCHDCTRDTLS.BACTIVE = '1' ")) [0];

            if ($ab->a === '0')
            {
                $a = '';
            }
            else
            {
                $a = '0';
            }
            if ($ab->b === '1')
            {
                $b = '';
            }
            else
            {
                $b = '1';
            }
            if ($ab->c === '2')
            {
                $c = '';
            }
            else
            {
                $c = '2';
            }
            if ($ab->d === '3')
            {
                $d = '';
            }
            else
            {
                $d = '3';
            }
            if ($ab->e === '4')
            {
                $e = '';
            }
            else
            {
                $e = '4';
            }
            if ($ab->f === '5')
            {
                $f = '';
            }
            else
            {
                $f = '5';
            }
            if ($ab->g === '6')
            {
                $g = '';
            }
            else
            {
                $g = '6';
            }
            $day = array(

                '0' => $a,
                '1' => $b,
                '2' => $c,
                '3' => $d,
                '4' => $e,
                '5' => $f,
                '6' => $g,
            );
            $dctr = 'S';
            return response()->json([$day, $dctr]);
        }
    }
    public function ajaxtime($id)
    {

        $ids = base64_decode($id);
        list($iu, $y, $z, $a) = explode(",", $ids);

        if ($y === 'U')
        {
        }
        else if ($y === 'G')
        {
            /// untuk doctor gigi
            $no = 1;
            $morningday = DB::select(DB::raw("SELECT MIN(MEDSYS_SCHDCTRDTLS.TSCHSTART) AS TSCHSTART, MAX(MEDSYS_SCHDCTRDTLS.TSCHEND) AS TSCHEND
         FROM MEDSYS_SCHDCTRDTLS JOIN MEDSYS_SCHDCTRHDRS ON MEDSYS_SCHDCTRHDRS.VSCHCODE = MEDSYS_SCHDCTRDTLS.VSCHCODE
         WHERE  MEDSYS_SCHDCTRDTLS.VSCHDAY = '" . $iu . "' AND MEDSYS_SCHDCTRHDRS.VSPCCODE IS NULL AND MEDSYS_SCHDCTRHDRS.VCLINICCODE = '" . $z . "' AND  MEDSYS_SCHDCTRHDRS.BACTIVE = '1' ")) [0];
            $setting = \App\Mstsettings::select('VSETDESC')->where('VSETID', 'PRMRGST')
                ->where('VSETCODE', 'DENTIST')
                ->orderby('DCREA', 'ASC')
                ->first();
            $getjamterakhir = \App\Mstsettings::select('VSETDESC')->where('VSETID', 'PRMRGST')
                ->where('VSETCODE', 'UP')
                ->orderby('DCREA', 'ASC')
                ->first();

            $start1 = Carbon::parse($a);
            $start2 = $start1->format('Y-m-d');
            $start = $morningday->TSCHSTART;
            $end = $morningday->TSCHEND;
            $int = $setting->VSETDESC;
            $int *= 60;

            $sp = \DB::select("EXEC sp_LastBookingTime ?,?,?", array(
                $z,
                'GIGI',
                $iu
            ));
            $data = array();
            foreach ($sp as $key => $val)
            {
                $datalast = carbon::parse($val->LASTBOOKING)
                    ->format('H:i');
            }
            $start = strtotime($start);
            $end = strtotime($end);
            //   $endif = strtotime($datalast);
            for ($i = $start;$i < $end;)
            {
                // $db = DB::select("SELECT DVISIT FROM MEDSYS_SCHBOOKS  WHERE  CONVERT(varchar,DVISIT, 103) = '". $a ." ".date("H:i", $i)."' ")->first();
                $book = DB::select(DB::raw("SELECT COUNT(*) AS counts FROM MEDSYS_SCHBOOKS JOIN MEDSYS_SCHDCTRHDRS ON MEDSYS_SCHDCTRHDRS.VCLINICCODE = MEDSYS_SCHBOOKS.VCLINICCODE WHERE MEDSYS_SCHDCTRHDRS.VSPCCODE IS NULL  AND MEDSYS_SCHBOOKS.DVISIT = '" . $start2 . " " . date("H:i", $i) . "' AND MEDSYS_SCHBOOKS.VCLINICCODE = '" . $z . "'")) [0];
                if ($book->counts !== '0')
                {

                    $dbw = DB::select(DB::raw("SELECT COUNT(*) AS jams FROM MEDSYS_SCHBOOKS   JOIN MEDSYS_SCHDCTRHDRS ON MEDSYS_SCHDCTRHDRS.VCLINICCODE = MEDSYS_SCHBOOKS.VCLINICCODE WHERE MEDSYS_SCHDCTRHDRS.VSPCCODE IS NULL  AND  MEDSYS_SCHBOOKS.DVISIT = '" . $start2 . " " . date("H:i", $i) . "' AND MEDSYS_SCHBOOKS.BSTATUS = 'O' AND MEDSYS_SCHBOOKS.VCLINICCODE = '" . $z . "'")) [0];
                    if ($dbw->jams !== '0')
                    {
                        $dbf = DB::select("SELECT DVISIT FROM MEDSYS_SCHBOOKS  WHERE  DVISIT = '" . $start2 . " " . date("H:i", $i) . "'  ");

                        foreach ($dbf as $r)
                        {
                            $datas = $r->DVISIT;
                            $startrow = Carbon::parse($datas);
                            $startend = $startrow->format('H:i');
                        }
                        $data[] = $startend;
                        for ($x = 0;$x < count($data);$x++)
                        {
                            $ar = $data[$x];
                        }
                    }
                    else
                    {
                        $ar = "";
                    }
                }
                else
                {
                    $ar = "00:00";
                }
                if ($ar === date("H:i", $i) || $datalast < date("H:i", $i) || carbon::parse(carbon::now())->format('Y-m-d H:i') > $start2 . ' ' . date("H:i", $i))
                {
                    // if (Session::get('typeuser') === 'NE')
                    // {

                        // $res[] = '<option value="' . base64_encode(date("H:i", $i) . ';' . $no++) . '">' . date("H:i", $i) . "-" . date("H:i", $i + $int) . '</option>';

                    // }
                    $res[] = '<option value="' . base64_encode(date("H:i", $i) . ';' . $no++) . '"   style="background: #FF0000; color: #FFF;" disabled>' . date("H:i", $i) . "-" . date("H:i", $i + $int) . '</option>';
                }
                else
                {

                    $res[] = '<option value="' . base64_encode(date("H:i", $i) . ';' . $no++) . '">' . date("H:i", $i) . "-" . date("H:i", $i + $int) . '</option>';

                }
                $i += $int;
            }

            return response()->json($res);

        }
        else
        {
            /// untuk doctor spesialist
            $morningday = DB::select(DB::raw("SELECT  MIN(MEDSYS_SCHDCTRDTLS.TSCHSTART) AS TSCHSTART, MAX(MEDSYS_SCHDCTRDTLS.TSCHEND) AS TSCHEND
            FROM MEDSYS_SCHDCTRDTLS JOIN MEDSYS_SCHDCTRHDRS ON MEDSYS_SCHDCTRHDRS.VSCHCODE = MEDSYS_SCHDCTRDTLS.VSCHCODE
            WHERE  MEDSYS_SCHDCTRDTLS.VSCHDAY = '" . $iu . "' AND MEDSYS_SCHDCTRHDRS.VUSRID = '" . $y . "' AND MEDSYS_SCHDCTRHDRS.VCLINICCODE = '" . $z . "' AND  MEDSYS_SCHDCTRHDRS.BACTIVE = '1' ")) [0];

            $setting = \App\Mstsettings::select('VSETDESC')->where('VSETID', 'PRMRGST')
                ->where('VSETCODE', 'DCTR')
                ->orderby('DCREA', 'ASC')
                ->first();
            $no = 1;

            $start1 = Carbon::parse($a);
            $start2 = $start1->format('Y-m-d');
            $start = $morningday->TSCHSTART;
            $end = $morningday->TSCHEND;
            $int = $setting->VSETDESC;
            $int *= 60;
            $start = strtotime($start);
            $end = strtotime($end);
            $no = 1;
            $sp = \DB::select("EXEC sp_LastBookingTime ?,?,?", array(
                $z,
                'SPCL',
                $iu
            ));
            $rows = '00:00';
            foreach ($sp as $key => $val)
            {
                $rows = carbon::parse($val->LASTBOOKING)
                    ->format('H:i');

            }
            for ($i = $start;$i < $end;)
            {

                // $db = DB::select("SELECT DVISIT FROM MEDSYS_SCHBOOKS  WHERE  CONVERT(varchar,DVISIT, 103) = '". $a ." ".date("H:i", $i)."' ")->first();
                $book = DB::select(DB::raw("SELECT COUNT(*) AS counts FROM MEDSYS_SCHBOOKS  WHERE  DVISIT = '" . $start2 . " " . date("H:i", $i) . "' AND VCLINICCODE = '" . $z . "' ")) [0];

                if ($book->counts !== '0')
                {

                    $dbw = DB::select(DB::raw("SELECT COUNT(*) AS jams FROM MEDSYS_SCHBOOKS  WHERE  DVISIT = '" . $start2 . " " . date("H:i", $i) . "' AND BSTATUS = 'O' AND VCLINICCODE = '" . $z . "' ")) [0];
                    if ($dbw->jams !== '0')
                    {
                        $dbf = DB::select("SELECT DVISIT FROM MEDSYS_SCHBOOKS  WHERE  DVISIT = '" . $start2 . " " . date("H:i", $i) . "'  AND VCLINICCODE = '" . $z . "' ");

                        foreach ($dbf as $r)
                        {
                            $datas = $r->DVISIT;
                            $startrow = Carbon::parse($datas);
                            $startend = $startrow->format('H:i');
                        }
                        $data[] = $startend;
                        for ($x = 0;$x < count($data);$x++)
                        {
                            $ar = $data[$x];
                        }
                    }
                    else
                    {
                        $ar = "";
                    }
                }
                else
                {
                    $ar = "00:00";
                }
                if ($ar === date("H:i", $i) || $rows < date("H:i", $i) || carbon::parse(carbon::now())->format('Y-m-d H:i') > $start2 . ' ' . date("H:i", $i))
                {
                    // if (Session::get('typeuser') === 'NE')
                    // {

                        //$res[] = '<option value="' . base64_encode(date("H:i", $i) . ';' . $no++) . '">' . date("H:i", $i) . "-" . date("H:i", $i + $int) . '</option>';

                    // }
                    // else
                    // {
                        $res[] = '<option value="' . base64_encode(date("H:i", $i) . ';' . $no++) . '"   style="background: #FF0000; color: #FFF;" disabled>' . date("H:i", $i) . "-" . date("H:i", $i + $int) . '</option>';

                    // }
                }
                else
                {
                    $res[] = '<option value="' . base64_encode(date("H:i", $i) . ';' . $no++) . '">' . date("H:i", $i) . "-" . date("H:i", $i + $int) . '</option>';
                }
                $i += $int;

            }
            return response()->json($res);

        }
    }
    public function ajaxfamily($id, $idx = NULL)
    {
        $base = base64_decode($id);
        $count = DB::select("SELECT COUNT(*) AS counts
                            FROM MEDSYS_MSTUSERS
                            LEFT JOIN MEDSYS_MSTEMPLOYEES ON MEDSYS_MSTUSERS.VUSRID = MEDSYS_MSTEMPLOYEES.VUSRID
                            JOIN MEDSYS_MSTEMPMEMBERS ON MEDSYS_MSTEMPLOYEES.VEMPSAPID = MEDSYS_MSTEMPMEMBERS.VEMPSAPID
                            WHERE MEDSYS_MSTEMPLOYEES.VEMPSAPID  = '" . $base . "' ") [0];
        $ab = DB::select("SELECT MEDSYS_MSTEMPMEMBERS.VRELNAME,MEDSYS_MSTEMPMEMBERS.ILINE,MEDSYS_MSTEMPLOYEES.VNAME,FORMAT (MEDSYS_MSTEMPLOYEES.DBIRTH, 'yyyy-MM-dd') DBIRTH
                            FROM MEDSYS_MSTUSERS
                            LEFT JOIN MEDSYS_MSTEMPLOYEES ON MEDSYS_MSTUSERS.VUSRID = MEDSYS_MSTEMPLOYEES.VUSRID
                            JOIN MEDSYS_MSTEMPMEMBERS ON MEDSYS_MSTEMPLOYEES.VEMPSAPID = MEDSYS_MSTEMPMEMBERS.VEMPSAPID
                            WHERE MEDSYS_MSTEMPLOYEES.VEMPSAPID  = '" . $base . "' ");
        if($idx == NULL){

                    $countbox = DB::select(DB::raw("SELECT count(*) AS nos FROM MEDSYS_MSTUSERS
                            JOIN MEDSYS_MSTEMPLOYEES ON MEDSYS_MSTUSERS.VUSRID = MEDSYS_MSTEMPLOYEES.VUSRID
                            JOIN MEDSYS_MSTEMPMEMBERS ON MEDSYS_MSTEMPLOYEES.VEMPSAPID = MEDSYS_MSTEMPMEMBERS.VEMPSAPID
                            WHERE MEDSYS_MSTEMPLOYEES.VEMPSAPID  = '" . $base . "' ")) [0];
                    if ($countbox->nos > 0)
                    {
                        $ab2 = DB::select(DB::raw("SELECT MEDSYS_MSTEMPLOYEES.VNAME,FORMAT (MEDSYS_MSTEMPLOYEES.DBIRTH, 'dd-MM-yyyy') DBIRTH ,MEDSYS_MSTEMPMEMBERS.VRELCITYBIRTH,MEDSYS_MSTEMPLOYEES.VPHONENO
                                                FROM MEDSYS_MSTUSERS
                                                    JOIN MEDSYS_MSTEMPLOYEES ON MEDSYS_MSTUSERS.VUSRID = MEDSYS_MSTEMPLOYEES.VUSRID
                                                    JOIN MEDSYS_MSTEMPMEMBERS ON MEDSYS_MSTEMPLOYEES.VEMPSAPID = MEDSYS_MSTEMPMEMBERS.VEMPSAPID
                                                    WHERE MEDSYS_MSTEMPLOYEES.VEMPSAPID  = '" . $base . "' ")) [0];

                        $null['data'] = $ab2;
                    
                        foreach ($ab as $value)
                        {
                            $ba[] = "<option value=" . $value->ILINE . ">" . $value->VRELNAME . "</option>";
                        }
                
                        $null['array'] = $ba;
                        return response()->json($null);
                }
                else
                {
                    $ab2 = DB::select(DB::raw("SELECT MEDSYS_MSTEMPLOYEES.VPHONENO,MEDSYS_MSTEMPLOYEES.VCITYBIRTH,MEDSYS_MSTEMPLOYEES.VNAME,FORMAT (MEDSYS_MSTEMPLOYEES.DBIRTH, 'dd-MM-yyyy') DBIRTH
                                                FROM MEDSYS_MSTUSERS
                                                LEFT JOIN MEDSYS_MSTEMPLOYEES ON MEDSYS_MSTUSERS.VUSRID = MEDSYS_MSTEMPLOYEES.VUSRID
                                                LEFT JOIN MEDSYS_MSTEMPMEMBERS ON MEDSYS_MSTEMPLOYEES.VEMPSAPID = MEDSYS_MSTEMPMEMBERS.VEMPSAPID
                                                WHERE MEDSYS_MSTEMPLOYEES.VEMPSAPID  = '" . $base . "' ")) [0];
                    $null['data'] = $ab2;

                    return response()->json($null);

                }
        }else{
        if ($idx === 'e')
        {
            if ($ab === NULL)
            {

                return response()->json(400);

            }
            else
            {
                $countbox = DB::select(DB::raw("SELECT count(*) AS nos FROM MEDSYS_MSTUSERS
                            JOIN MEDSYS_MSTEMPLOYEES ON MEDSYS_MSTUSERS.VUSRID = MEDSYS_MSTEMPLOYEES.VUSRID
                            JOIN MEDSYS_MSTEMPMEMBERS ON MEDSYS_MSTEMPLOYEES.VEMPSAPID = MEDSYS_MSTEMPMEMBERS.VEMPSAPID
                            WHERE MEDSYS_MSTEMPLOYEES.VEMPSAPID  = '" . $base . "' ")) [0];
                if ($countbox->nos > 0)
                {
                    $ab2 = DB::select(DB::raw("SELECT MEDSYS_MSTEMPLOYEES.VNAME,FORMAT (MEDSYS_MSTEMPLOYEES.DBIRTH, 'dd-MMM-yyyy') DBIRTH ,MEDSYS_MSTEMPLOYEES.VCITYBIRTH,MEDSYS_MSTEMPLOYEES.VPHONENO
                                                FROM MEDSYS_MSTUSERS
                                                JOIN MEDSYS_MSTEMPLOYEES ON MEDSYS_MSTUSERS.VUSRID = MEDSYS_MSTEMPLOYEES.VUSRID
                                                JOIN MEDSYS_MSTEMPMEMBERS ON MEDSYS_MSTEMPLOYEES.VEMPSAPID = MEDSYS_MSTEMPMEMBERS.VEMPSAPID
                                                WHERE MEDSYS_MSTEMPLOYEES.VEMPSAPID  = '" . $base . "' ")) [0];

                    $null['data'] = $ab2;

                    foreach ($ab as $value)
                    {
                        $ba[] = "<option value=" . $value->ILINE . ">" . $value->VRELNAME . "</option>";
                    }

                    $null['array'] = $ba;
                    return response()->json($null);
                }
                else
                {
                    $ab2 = DB::select(DB::raw("SELECT MEDSYS_MSTEMPLOYEES.VPHONENO,MEDSYS_MSTEMPLOYEES.VCITYBIRTH,MEDSYS_MSTEMPLOYEES.VNAME,FORMAT (MEDSYS_MSTEMPLOYEES.DBIRTH, 'dd-MMM-yyyy') DBIRTH
                                                FROM MEDSYS_MSTUSERS
                                                LEFT JOIN MEDSYS_MSTEMPLOYEES ON MEDSYS_MSTUSERS.VUSRID = MEDSYS_MSTEMPLOYEES.VUSRID
                                                LEFT JOIN MEDSYS_MSTEMPMEMBERS ON MEDSYS_MSTEMPLOYEES.VEMPSAPID = MEDSYS_MSTEMPMEMBERS.VEMPSAPID
                                                WHERE MEDSYS_MSTEMPLOYEES.VEMPSAPID  = '" . $base . "' ")) [0];
                    $null['data'] = $ab2;

                    return response()->json($null);

                }
            }

        }
        else
        {
            $ab2 = DB::select(DB::raw("SELECT VNAME,FORMAT (DBIRTH, 'dd-MM-yyyy') DBIRTH ,VCITYBIRTH,VPHONENO FROM MEDSYS_PATIENTS WHERE MEDSYS_PATIENTS.VIDCARDNO  = '" . $base . "' ")) [0];
            $null['data'] = $ab2;

            return response()->json($null);
        }
        }
    }
    public function ajaxcategory($id)
    {

        if ($id === "e")
        {
            $null[] = '<style>
            #inner {
                display: table;
                margin: 0 auto;
              }

              #outer {
                width:50%
              }</style>
               <div class="row">
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group required">
                              <label class="req control-label col-sm-12">SAP ID</label>
                           </div>
                        </div>

                  <div class="col-sm-4">
                     <input type="text" class="form-control" name="sapid" id="sapid" placeholder="SAP ID" required>
                  </div>
               </div>
               <div class="row">
                        <label for="inputPassword" class="col-sm-2 col-form-label"></label>
                     <div class="col-sm-4">
                        <div class="row">
                           <div class="col-sm-4">
                              <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="fma" type="checkbox" id="checkbox" value="family">
                                    <label class="form-check-label" for="fm">Family</label>
                              </div>
                           </div>
                           <div class="col-sm-8">
                              <select class="form-control" name="fmax" id="familyt">
                                 <option>-</option>
                              </select>
                           </div>
                        </div>
                     </div>
               </div>
               <br />
               <div class="row">
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group required">
                              <label class="req control-label col-sm-12">Full Name</label>
                           </div>
                        </div>

                  <div class="col-sm-4">
                        <input type="text" class="form-control" placeholder="Full Name" name="name" id="fullname" required readonly>
                  </div>
               </div>
               <div class="row">
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group required">
                              <label class="req control-label col-sm-12">Place/Date of birth</label>
                           </div>
                        </div>

                     <div class="col-sm-2">
                        <input type="text" class="form-control" name="city" id="country"  required readonly>
                     </div>
                     <div class="col-sm-2">
                        <div class="form-group">
                            <div class="input-group" data-target-input="nearest">
                              <input type="text" name="dtgl" class="form-control" id="dateofbirth"  readonly required/>
                                 <div class="input-group-append" >
                                       <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                 </div>
                           </div>
                        </div>
                     </div>
               </div>
               <div class="row">
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group">
                              <label class="control-label col-sm-12">Phone No.</label>
                           </div>
                        </div>

                     <div class="col-sm-1">
                        <input type="text" class="form-control" value="+62" id="no" readonly>
                     </div>
                     <div class="col-sm-3">
                        <input type="number" class="form-control" name="tlpn" id="tlp" readonly>
                     </div>
               </div>

         <div id="outer">
                <div id="inner">
                  <div class="form-group row">
                     <div class="col-sm-12">
                        <button id="startDiv" type="submit" class="align-middle btn-primary btn btn-sz">Confirm</button>
                        <a href="/account/bookingsm" class="btn btn btn-light btn-sz" type="submit" id="redirct">Close</a>
                     </div>
                  </div>
                </div>
         </div>

         <script>
         $(".btn-closed").hide();
        //  $(function() {
        //     $("#dateofbirth").datetimepicker({

        //         format: "DD-MMM-YYYY",
        //         ignoreReadonly: true,
        //         maxDate: moment(),
        //         useCurrent: false,
        //     });
        // });
         $("input#checkbox").click(function() {
            if ($(this).is(":checked")) {
                $("#familyt").attr("disabled", false);
            } else {
                $("#familyt").attr("disabled", true);
                var id = btoa($("#sapid").val());
                var idx = $("input[name=cate]:checked").val();

                $.ajax({
                dataType: "json",
                type: "GET",
                url: "/ajaxfamily/" + id +"/"+ idx,
                success: function(result) {
                  $("#fullname").val(result.data.VNAME);
                  document.getElementById("fullname").readOnly = true;

                  $("#country").val(result.data.VCITYBIRTH);
                  $("#tlp").val(result.data.VPHONENO);
                  $("#dateofbirth").val(result.data.DBIRTH);

                  //var u = JSON.parse(JSON.stringify(result.data.DBIRTH));
                  //$("#dateofbirth").datetimepicker("date", moment(u, "DD/MM/YYYY"));
                 }


                });

            }
        });
         $("#familyt").attr("disabled", true);
         $("input#sapid").keyup(function() {
            var idx = $("input[name=cate]:checked").val();

            var id = btoa($("#sapid").val());
            $.ajax({
            dataType: "json",
            type: "GET",
            url: "/ajaxfamily/" + id +"/"+ idx,
            success: function(result) {

             if (!result) {
               $("#fullname").val(result.data.VNAME);
                $("#familyt").html("");
                $("#familyt").attr("disabled", true);

               $("#formbooking")[0].reset();
             }else{
                 $("#fullname").val(result.data.VNAME);
                 document.getElementById("fullname").readOnly = true;

                 $("#country").val(result.data.VCITYBIRTH);
                 document.getElementById("country").readOnly = true;

                 $("#tlp").val(result.data.VPHONENO);
                 //var u = JSON.parse(JSON.stringify(result.data.DBIRTH));
                 $("#dateofbirth").val(result.data.DBIRTH);

                 //$("#dateofbirth").datetimepicker("date", moment(u, "DD-MMM-YYYY"),);

                 var html = "";
                 var i;
                     html += "<option>---</option>";
                     html += result.array;

                    $("#familyt").html(html);
            }
             }


            });


         });
         $("#familyt").change(function() {
            var idr = btoa($(this).val());
            $.ajax({
               dataType: "json",
               type: "GET",
               url: "/ajaxmember/" + idr,
               success: function(result) {
                  $("#dateofbirth").datetimepicker("minDate", false);

                if (!result) {
                   $("#familyt").html("");
                   $("#familyt").attr("disabled", true);
                  $("#formbooking")[0].reset();
                }else{

                    $("#fullname").val(result.fullname);
                    document.getElementById("fullname").readOnly = true;

                    $("#country").val(result.city);
                    document.getElementById("country").readOnly = true;

                    // var u = JSON.parse(JSON.stringify(result.date));
                    // console.log(u);
                    $("#dateofbirth").val(result.date);

                    
                    //$("#dateofbirth").datetimepicker("date", moment(result.date, "DD/MM/YYYY"));
               }
                }


               });
         });
         </script>
         ';
        }
        else
        {

            $null[] = '<style>
            #inner {
                display: table;
                margin: 0 auto;
              }

              #outer {
                width:50%
              }</style>
               <div class="row">
                  <div class="col-lg-2 col-sm-12">
                     <div class="form-group required">
                        <label class="req control-label col-sm-12">ID Card</label>
                     </div>
                  </div>

                  <div class="col-sm-4">
                        <input type="text" class="form-control" id="idcard" name="idcard" required>
                  </div>
               </div>
               <div class="row">
                  <div class="col-lg-2 col-sm-12">
                     <div class="form-group required">
                        <label class="req control-label col-sm-12">Full Name</label>
                     </div>
                  </div>

                  <div class="col-sm-4">
                     <input type="text" class="form-control" id="fullname" name="name" required>
                  </div>
               </div>
               <div class="row">
                  <div class="col-lg-2 col-sm-12">
                     <div class="form-group required">
                        <label class="req control-label col-sm-12">Place/Date Of Birth</label>
                     </div>
                  </div>

                  <div class="col-sm-2">
                     <input type="text" class="form-control"  id="country" name="city" required>
                  </div>
                  <div class="col-sm-2">
                     <div class="form-group">
                        <div class="input-group date" id="dateofbirth" data-target-input="nearest">
                           <input type="text" name="dtgl" class="form-control datetimepicker-input" data-target="#dateofbirth"  readonly required/>
                              <div class="input-group-append" data-target="#dateofbirth" data-toggle="datetimepicker">
                                 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                              </div>
                        </div>
                     </div>
                  </div>
               </div>

               <div class="row">
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group">
                              <label class="control-label col-sm-12">Phone No.</label>
                           </div>
                        </div>

                     <div class="col-sm-1">
                        <input type="text" class="form-control" value="+62" id="no" readonly>
                     </div>
                     <div class="col-sm-3">
                        <input type="number" class="form-control" name="tlpn" id="tlp">
                     </div>
               </div>
         <div id="outer">
             <div id="inner">
                  <div class="form-group row">
                     <div class="col-sm-12">
                        <button id="startDiv" type="submit" class="align-middle btn-primary btn btn-sz">Confirm</button>
                        <button class="btn btn btn-light btn-sz" type="submit" id="redirct">Close</button>
                     </div>
                  </div>

            </div>
         </div>
         <script>
         $(".btn-closed").hide();
         $(function() {
            $("#dateofbirth").datetimepicker({

                format: "DD-MMM-YYYY",
                ignoreReadonly: true,
                maxDate: moment(),
                useCurrent: false,

            });
        });
         $("input#checkbox").click(function() {
            if ($(this).is(":checked")) {
                $("#familyt").attr("disabled", false);
            } else {
                $("#familyt").attr("disabled", true);
            }
        });
         $("input#idcard").keyup(function() {
            var id = btoa($("#idcard").val());
            $.ajax({
            dataType: "json",
            type: "GET",
            url: "/ajaxfamily/" + id,
            success: function(result) {
             if (!result) {
                $("#familyt").html("");
                $("#familyt").attr("disabled", true);

             }else{
                 $("#fullname").val(result.data.VNAME);
                 document.getElementById("fullname").readOnly = true;

                 $("#country").val(result.data.VCITYBIRTH);
                 document.getElementById("country").readOnly = true;

                 $("#tlp").val(result.data.VPHONENO);
                 var u = JSON.parse(JSON.stringify(result.data.DBIRTH));
                 $("#dateofbirth").datetimepicker("date", moment(u, "DD-MMM-YYYY"));


                var html = "";
                for (i = 0; i < result.length; i++) {

                  html += "<option value=" +  result[i].array+ ">" + result[i].array+ "</option>";
               }

                    $("#familyt").html(html);
            }
             }


            });
        });
         </script>
         ';
        }
        return response()->json($null);
    }
    public function choose($id)
    {
        $decode = base64_decode($id);
        $specis = DB::select("SELECT * FROM MEDSYS_MSTGENERALS WHERE VGNRLTYPE = 'SPECIALIST' ");
        $null['data'] = '';

        foreach ($specis as $n)
        {

            $null['data'] .= "<option value='" . $n->VGNRLCODE . "'>Specialist " . $n->VGNRLDESC . "</option>";
        }

        return response()
            ->json($null);
    }
    public function addpointment(Request $request)
    {
       
        /// extract Decode
        if ($request->timefirst === "Please pick date first")
        {
            $timefirste = '';
            $count = DB::select(DB::raw("SELECT count(IQUEUENO) AS countdvisit FROM MEDSYS_SCHBOOKS WHERE  CONVERT(varchar, DVISIT, 103) = '" . $request->datech . "' AND MEDSYS_SCHBOOKS.VCLINICCODE = '" . $request->cliniccode . "' ")) [0];

            $queque = $count->countdvisit + 1;

        }
        else
        {
            $idr = base64_decode($request->timefirst);
            list($timefirste, $queque) = explode(";", $idr);

        }

        ///
        $datenow = carbon::now();

        $years = $datenow->format('Y');
        $months = $datenow->format('m');
        $dayu = $datenow->format('d');

        /////
        $year = Carbon::createFromFormat('d-M-Y', $request->datech)
            ->format('Y');
        $month = Carbon::createFromFormat('d-M-Y', $request->datech)
            ->format('m');
        $days = Carbon::createFromFormat('d-M-Y', $request->datech)
            ->format('d');

        $stringds = substr($years, 2);
        $stringm = substr($month, 0, 2);
        // $stringds = substr($years, 0, 2);
        $stringms = substr($months, 0, 2);
        // hitung time first
        $countjax = DB::select(DB::raw("SELECT  SUM(NLASTNO) AS NLASTNO FROM MEDSYS_MSTNOS WHERE VTRXCODE = 'B' AND NYEAR ='" . $stringds . "' ")) [0];

        $countmr = DB::select(DB::raw("SELECT SUM(NLASTNO) AS NLASTNO FROM MEDSYS_MSTNOS WHERE VTRXCODE = 'MR'  AND  NYEAR ='" . $stringds . "' ")) [0];
        $jumlah = $countjax->NLASTNO + 1;
        $jumlahmr = $countmr->NLASTNO + 1;

        $clinic1 = DB::select(DB::raw("SELECT COUNT(*) AS countdatav  FROM MEDSYS_MSTCLINICS LEFT JOIN MEDSYS_SCHDCTRHDRS ON MEDSYS_MSTCLINICS.VCLINICCODE = MEDSYS_SCHDCTRHDRS.VCLINICCODE LEFT JOIN MEDSYS_MSTCLINICSTAFFS ON MEDSYS_MSTCLINICSTAFFS.VUSRID = MEDSYS_SCHDCTRHDRS.VUSRID WHERE MEDSYS_SCHDCTRHDRS.VSCHCODE =  '" . $request->VSCHCODE . "'")) [0];

        $setting = \App\Mstsettings::select('VSETDESC')->where('VSETID', 'VNOTES')->where('VSETCODE', 'BOOKING')
            ->orderby('DCREA', 'ASC')
            ->first();
        if ($request->timefirst === "Please pick date first")
        {
            $timefirst = Carbon::createFromFormat('d-M-Y', $request->datech)
                ->format('l, d F Y ');
            $timef = Carbon::createFromFormat('d-M-Y', $request->datech)
                ->format('Y-m-d');
            $timec = Carbon::createFromFormat('d-M-Y', $request->datech)
                ->format('Y-m-d');
        }
        else
        {

            $timefirst = Carbon::createFromFormat('d-M-Y H:i', $request->datech . $timefirste)->format('l, d F Y H:i');
            $timef = Carbon::createFromFormat('d-M-Y H:i', $request->datech . $timefirste)->format('Y-m-d H:i');
            $timec = Carbon::createFromFormat('d-M-Y H:i', $request->datech . $timefirste)->format('Y-m-d H:i');
        }
        if ($clinic1->countdatav <= 0)
        {
            $clinic = DB::select(DB::raw("SELECT MEDSYS_MSTCLINICS.VCLINICINIT,' ' AS VUSRID , ' ' AS VNAME  FROM MEDSYS_MSTCLINICS LEFT JOIN MEDSYS_SCHDCTRHDRS ON MEDSYS_SCHDCTRHDRS.VCLINICCODE = MEDSYS_SCHDCTRHDRS.VCLINICCODE LEFT JOIN MEDSYS_MSTCLINICSTAFFS ON MEDSYS_MSTCLINICSTAFFS.VUSRID = MEDSYS_SCHDCTRHDRS.VUSRID WHERE MEDSYS_MSTCLINICS.VCLINICINIT = '" . $request->VSCHCODE . "'")) [0];
        }
        else
        {
            $clinic = DB::select(DB::raw("SELECT MEDSYS_MSTCLINICS.VCLINICINIT,MEDSYS_SCHDCTRHDRS.VUSRID,MEDSYS_MSTCLINICSTAFFS.VNAME  FROM MEDSYS_MSTCLINICS LEFT JOIN MEDSYS_SCHDCTRHDRS ON MEDSYS_SCHDCTRHDRS.VCLINICCODE = MEDSYS_MSTCLINICS.VCLINICCODE LEFT JOIN MEDSYS_MSTCLINICSTAFFS ON MEDSYS_MSTCLINICSTAFFS.VUSRID = MEDSYS_SCHDCTRHDRS.VUSRID WHERE MEDSYS_SCHDCTRHDRS.VSCHCODE = '" . $request->VSCHCODE . "'")) [0];
        }
        $count1 = str_pad($jumlahmr, 4, '0', STR_PAD_LEFT);

        $checkbooking = DB::select(DB::raw("SELECT COUNT(*) AS countbook FROM MEDSYS_MSTNOS WHERE NYEAR ='" . $stringds . "' AND VTRXCODE = 'B' ")) [0];
        $checkmr = DB::select(DB::raw("SELECT COUNT(*) AS countmr FROM MEDSYS_MSTNOS WHERE NYEAR ='" . $stringds . "' AND VTRXCODE = 'MR' ")) [0];
        $countbooking = str_pad($jumlah, 5, '0', STR_PAD_LEFT);

        // check family
        if ($request->fma === 'family')
        {

            $id = $request->fmax;

            $family = DB::select(DB::raw("SELECT VRELNAME,VRELATION FROM MEDSYS_MSTEMPMEMBERS WHERE  ILINE =  '" . $id . "'")) [0];
            $name = $family->VRELNAME;
            $vrelation = $family->VRELATION;
            //$VMRNOE = $clinic->VCLINICINIT.$stringd.$count1.$vrelation;

        }
        else
        {
            $name = $request->name;
            $no = "E0";

            //$VMRNOE = $clinic->VCLINICINIT.$stringd.$count1.$no;

        }
        //check category
        if ($request->cate === 'e')
        {

            $cate = DB::table('MEDSYS_MSTSETTINGS')->select('VSETCODE')
                ->where('VSETID', 'TYPEPATIENT')
                ->where('VSETCODE', 'E')
                ->first();
        }
        else if ($request->cate === 'c')
        {

            $cate = DB::table('MEDSYS_MSTSETTINGS')->select('VSETCODE')
                ->where('VSETID', 'TYPEPATIENT')
                ->where('VSETCODE', 'C')
                ->first();
        }
        else
        {

            $cate = DB::table('MEDSYS_MSTSETTINGS')->select('VSETCODE')
                ->where('VSETID', 'TYPEPATIENT')
                ->where('VSETCODE', 'R')
                ->first();
        }
        // $checkvrmno = DB::select(DB::raw("SELECT count(*) from MEDSYS_SCHBOOKS where  VNAME = '".$name."' "))[0];
        // if($checkvrmno < '1'){
        //    $checkvrmno1 = DB::select(DB::raw("SELECT VMRNO from MEDSYS_SCHBOOKS where  AND VNAME = '".$name."' "))[0];
        //    $VMRNO = $checkvrmno1->VMRNO;
        // }else{


        // }
        $dctri = '';
        if ($request->dctr === "U")
        {
            $dctri = 'UMUM';
            $day_lookup = '';
        }
        else if ($request->dctr === "G")
        {
            $dctri = 'GIGI';
            $create_day = Carbon::createFromFormat('d-M-Y', $request->datech)
                ->format('Y-m-d');

            $day_lookup = Carbon::parse($create_day)->format('l');

        }
        else
        {
            $dctri = 'SPCL';
            $create_day = Carbon::createFromFormat('d-M-Y', $request->datech)
                ->format('Y-m-d');

            $day_lookup = Carbon::parse($create_day)->format('l');

        }
        $sp = \DB::select("EXEC sp_LookUpDoctor ?,?,?", array(
            $request->cliniccode,
            $dctri,
            $day_lookup
        ));
        // LookupDoctor & check lookup
        if (count($sp) === 0)
        {

            $null['pesan'] = "doctors at this clinic are not available!";
            return response()->json($null, 404);

        }
        else
        {

            if (!$request->sapid)
            {
                $id = $request->idcard;
                $checkpoint = DB::select(DB::RAW("SELECT COUNT(*) AS COUNTSAPID FROM MEDSYS_SCHBOOKS WHERE VIDCARDNO = '" . $id . "' ")) [0];

                if ($request->dctr === "U" || $request->dctr === "G")
                {
                    $checkdate = DB::select(DB::RAW("SELECT COUNT(*) AS COUNTSAPID FROM MEDSYS_SCHBOOKS WHERE  DVISIT = '" . $timec . "'   AND VDRID = '" . $clinic->VUSRID . "' AND VIDCARDNO = '" . $id . "' AND BSTATUS  = 'O' ")) [0];

                }
                else
                {
                    $checkdate = DB::select(DB::RAW("SELECT COUNT(*) AS COUNTSAPID FROM MEDSYS_SCHBOOKS WHERE  CONVERT(varchar,DVISIT,120) = '" . $timec . ":00'   AND VDRID = '" . $clinic->VUSRID . "' AND BSTATUS  = 'O' ")) [0];

                }
                if ($checkpoint->COUNTSAPID <= 0)
                {

                    $no = "N0";
                    $VMRNO = $request->clinicint . $stringds . $count1 . $no;
                    $VBOOKING = 'B' . $request->clinicint . $stringds . $countbooking;
                    $checkpatient = DB::select(DB::raw("SELECT COUNT(*) AS countp FROM MEDSYS_PATIENTS where VMRNO =  '" . $VMRNO . "' ")) [0];

                    // patient logs
                    DB::table('MEDSYS_PATIENTLOGS')->insert([

                    'VMRNO' => $VMRNO, 'VNAME' => $name, 'DBIRTH' => carbon::parse($request->dtgl)
                        ->format('Y-m-d') , 'VSAPID' => '', 'VCITYBIRTH' => $request->city, 'VGNDRCODE' => '', 'VIDCARDNO' => $id, 'VTYPEPATIENT' => $cate->VSETCODE, 'VTYPEUSR' => 'NE', 'VPICPOSTALCODE' => '', 'VUSER' => Session::get('id') , 'VDOCID' => $clinic->VUSRID, 'VPHONENO' => '+62' . $request->tlpn, ]);
                    // insert ke table patient
                    DB::statement("SET NOCOUNT ON ; EXEC sp_UpdatePatient ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?", [$VMRNO, $name, $request->city, carbon::parse($request->dtgl)
                        ->format('Y-m-d') , '', '', '', '', '', '', '', '', '+62' . $request->tlpn, $id, '', '', '', '', $cate->VSETCODE, 'NE', $request->sapid, '', '', '', '', '', '', '', '', '', '', '', '', Session::get('id') ]);
                    /// insert MEDSYS_PATIENTS
                    // if ($checkpatient->countp <= 0) {
                    //    DB::table('MEDSYS_PATIENTS')->insert([
                    //       'VMRNO' => $VMRNO,
                    //       'VNAME' => $name,
                    //       'DBIRTH' => carbon::parse($request->dtgl)->format('Y-m-d'),
                    //       'VSAPID' => '',
                    //       'VCITYBIRTH' => $request->city,
                    //       'VGNDRCODE' => '',
                    //       'VIDCARDNO' => $id,
                    //       'VTYPEPATIENT' =>  $cate->VSETCODE,
                    //       'VTYPEUSR' => 'NE',
                    //       'VPICPOSTALCODE' => '',
                    //       'VCREA' => Session::get('id'),
                    //       'VMODI' => Session::get('id'),
                    //       'VPHONENO' => '+62' . $request->tlpn,
                    //    ]);
                    // } else {
                    //    DB::table('MEDSYS_PATIENTS')->where('VMRNO', $VMRNO)->update([
                    //       'VMRNO' => $VMRNO,
                    //       'VNAME' => $name,
                    //       'VSAPID' => '',
                    //       'DBIRTH' => carbon::parse($request->dtgl)->format('Y-m-d'),
                    //       'VGNDRCODE' => '',
                    //       'VCITYBIRTH' => $request->city,
                    //       'VIDCARDNO' => $id,
                    //       'VTYPEPATIENT' =>  $cate->VSETCODE,
                    //       'VTYPEUSR' => 'NE',
                    //       'VPICPOSTALCODE' => '',
                    //       'DMODI' => Carbon::now(),
                    //       'VMODI' => Session::get('id'),
                    //       'VPHONENO' => '+62' . $request->tlpn,
                    //    ]);
                    // }
                    if ($checkdate->COUNTSAPID === '0')
                    {
                        /// update BOOKING.NO
                        //check booking
                        if ($checkmr->countmr <= 0)
                        {
                            DB::table('MEDSYS_MSTNOS')
                                ->insert([

                            'NLASTNO' => '0', 'VTRXCODE' => 'MR', 'NYEAR' => $stringds, 'NMONTH' => '0', 'NDATE' => '0', 'DMODI' => Carbon::now() , 'VMODI' => Session::get('id') ,

                            ]);

                        }
                        else
                        {
                            DB::table('MEDSYS_MSTNOS')->where('VTRXCODE', 'MR')
                                ->where('NYEAR', $stringds)->update(['NLASTNO' => $jumlahmr, 'NMONTH' => '0', 'NDATE' => '0', 'DMODI' => Carbon::now() , 'VMODI' => Session::get('id') ,

                            ]);
                        }
                        //check booking
                        if ($checkbooking->countbook === '0')
                        {

                            DB::table('MEDSYS_MSTNOS')
                                ->insert([ //mengisi data di database
                            'NLASTNO' => '0', 'NYEAR' => $stringds, 'NMONTH' => $months, 'NDATE' => $dayu, 'VTRXCODE' => 'B', 'DCREA' => Carbon::now() , 'VCREA' => Session::get('id') ,

                            ]);

                            DB::table('MEDSYS_MSTNOS')->where('NYEAR', $stringds)->delete();

                        }
                        else
                        {
                            // $checkbulan = DB::select("SELECT COUNT ")
                            DB::table('MEDSYS_MSTNOS')
                                ->where('VTRXCODE', 'B')
                                ->where('NYEAR', $stringds)->update(['NLASTNO' => $jumlah, 'NYEAR' => $stringds, 'NMONTH' => $months, 'NDATE' => $dayu, 'DMODI' => Carbon::now() , 'VMODI' => Session::get('id') ,

                            ]);
                        }
                        // insert SP booking
                        DB::statement("SET NOCOUNT ON ; EXEC sp_UpdateBooking ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?", [$VBOOKING, $VMRNO, $name, $timef, $queque, $request->idcard, $request->typedctr,NULL, $request->cliniccode, $clinic->VUSRID,NULL,NULL, '+62' . $request->tlpn, $request->city,NULL,NULL, carbon::parse($request->dtgl)
                            ->format('Y-m-d') , Session::get('id') ]);

                        // DB::table('MEDSYS_SCHBOOKS')->insert([
                        //    'VBOOKINGNO' => $VBOOKING,
                        //    'VMRNO' => $VMRNO,
                        //    'VNAME' => $name,
                        //    'VIDCARDNO' => $request->idcard,
                        //    'DVISIT' =>  $timef,
                        //    'DBIRTH' => carbon::parse($request->dtgl)->format('Y-m-d'),
                        //    'IQUEUENO' => $queque,
                        //    'VCLINICCODE' => $request->cliniccode,
                        //    'VCITYBIRTH' => $request->city,
                        //    'VDRID' => $clinic->VUSRID,
                        //    'VPOSCODE' => $request->typedctr,
                        //    'VPHONENO' => '+62' . $request->tlpn,
                        //    'BSTATUS' => 'O',
                        //    'VCREA' => Session::get('id'),
                        //    'VMODI' => Session::get('id'),
                        // ]);
                        $pull['MRN'] = $VMRNO;
                        $pull['QUEQU'] = $queque;
                        $pull['doctor'] = $clinic->VNAME;
                        $pull['dvisit'] = $timefirst;
                        $pull['setting'] = $setting->VSETDESC;
                        return response()->json($pull);
                    }
                    else
                    {

                        $null['pesan'] = "this schedule already booked!";
                        return response()->json($null, 404);
                    }
                }
                else
                {
                    $id = $request->idcard;
                    $VBOOKING = 'B' . $request->clinicint . $stringds . $countbooking;

                    // $checkid = DB::select(DB::RAW("SELECT VBOOKINGNO FROM MEDSYS_SCHBOOKSc WHERE VIDCARDNO = '".$id."'  AND VNAME = '".$name."' "))[0];
                    if ($request->dctr === "U" || $request->dctr === "G")
                    {
                        $checkdate = DB::select(DB::RAW("SELECT COUNT(*) AS COUNTSAPID FROM MEDSYS_SCHBOOKS WHERE  DVISIT = '" . $timec . "'   AND VDRID = '" . $clinic->VUSRID . "' AND VIDCARDNO = '" . $id . "' AND BSTATUS  = 'O' ")) [0];

                    }
                    else
                    {
                        $checkdate = DB::select(DB::RAW("SELECT COUNT(*) AS COUNTSAPID FROM MEDSYS_SCHBOOKS WHERE  CONVERT(varchar,DVISIT,120) = '" . $timec . ":00'   AND VDRID = '" . $clinic->VUSRID . "' AND BSTATUS  = 'O' ")) [0];

                    }
                    if ($checkdate->COUNTSAPID === '0')
                    {
                        $checkpoint = DB::select(DB::RAW("SELECT VMRNO FROM MEDSYS_SCHBOOKS WHERE VIDCARDNO = '" . $id . "' ")) [0];
                        $VMRNO = $checkpoint->VMRNO;
                        $checkpatient = DB::select(DB::raw("SELECT COUNT(*) AS countp FROM MEDSYS_PATIENTS where VMRNO =  '" . $VMRNO . "' ")) [0];

                        // patient logs
                        DB::table('MEDSYS_PATIENTLOGS')->insert([

                        'VMRNO' => $VMRNO, 'VNAME' => $name, 'DBIRTH' => carbon::parse($request->dtgl)
                            ->format('Y-m-d') , 'VSAPID' => '', 'VCITYBIRTH' => $request->city, 'VGNDRCODE' => '', 'VIDCARDNO' => $id, 'VTYPEPATIENT' => $cate->VSETCODE, 'VTYPEUSR' => 'NE', 'VPICPOSTALCODE' => '', 'VUSER' => Session::get('id') , 'VDOCID' => $clinic->VUSRID, 'VPHONENO' => '+62' . $request->tlpn, ]);

                        // insert ke table patient
                        // insert ke table patient
                        DB::statement("SET NOCOUNT ON ; EXEC sp_UpdatePatient ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?", [$VMRNO, $name, $request->city, carbon::parse($request->dtgl)
                            ->format('Y-m-d') ,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL, '+62' . $request->tlpn, $id,NULL,NULL,NULL,NULL, $cate->VSETCODE, 'NE', $request->sapid,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL, Session::get('id') ]);
                        // if ($checkpatient->countp <= 0) {
                        //    DB::table('MEDSYS_PATIENTS')->insert([
                        //       'VMRNOs' => $VMRNO,
                        //       'VNAME' => $name,
                        //       'DBIRTH' => carbon::parse($request->dtgl)->format('Y-m-d'),
                        //       'VSAPID' =>'',
                        //       'VCITYBIRTH' => $request->city,
                        //       'VGNDRCODE' => '',
                        //       'VIDCARDNO' => $id,
                        //       'VTYPEPATIENT' =>  $cate->VSETCODE,
                        //       'VTYPEUSR' => 'E',
                        //       'VPICPOSTALCODE' => '',
                        //       'VCREA' => Session::get('id'),
                        //       'VMODI' => Session::get('id'),
                        //       'VPHONENO' => '+62' . $request->tlpn,
                        //    ]);
                        // } else {
                        //    DB::table('MEDSYS_PATIENTS')->where('VMRNO', $VMRNO)->update([
                        //       'VMRNO' => $VMRNO,
                        //       'VNAME' => $name,
                        //       'VSAPID' => '',
                        //       'DBIRTH' => carbon::parse($request->dtgl)->format('Y-m-d'),
                        //       'VGNDRCODE' => '',
                        //       'VCITYBIRTH' => $request->city,
                        //       'VIDCARDNO' => $id,
                        //       'VTYPEPATIENT' =>  $cate->VSETCODE,
                        //       'VTYPEUSR' => 'E',
                        //       'VPICPOSTALCODE' => '',
                        //       'VCREA' => '',
                        //       'VMODI' => '',
                        //       'VPHONENO' => '+62' . $request->tlpn,
                        //       'DMODI' => Carbon::now(),
                        //       'VMODI' => Session::get('id'),
                        //    ]);
                        // }
                        //check booking
                        if ($checkbooking->countbook === '0')
                        {

                            DB::table('MEDSYS_MSTNOS')
                                ->insert([ //mengisi datadi database
                            'NLASTNO' => '0', 'NYEAR' => $stringds, 'NMONTH' => $months, 'NDATE' => $dayu, 'VTRXCODE' => 'B', 'VCREA' => Session::get('id') ,

                            ]);
                        }
                        else
                        {
                            // $checkbulan = DB::select("SELECT COUNT ")
                            DB::table('MEDSYS_MSTNOS')->where('VTRXCODE', 'B')
                                ->where('NYEAR', $stringds)->update(['NLASTNO' => $jumlah, 'NYEAR' => $stringds, 'NMONTH' => $months, 'NDATE' => $dayu, 'DMODI' => Carbon::now() , 'VMODI' => Session::get('id') ,

                            ]);
                        }

                        // insert SP booking
                        DB::statement("SET NOCOUNT ON ; EXEC sp_UpdateBooking ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?", [$VBOOKING, $VMRNO, $name, $timef, $queque, $request->idcard, $request->typedctr,NULL, $request->cliniccode, $clinic->VUSRID,NULL,NULL, '+62' . $request->tlpn, $request->city,NULL,NULL,NULL, carbon::parse($request->dtgl)
                            ->format('Y-m-d') , Session::get('id') ]);
                        // DB::table('MEDSYS_SCHBOOKS')->insert([
                        //    'VBOOKINGNO' => $VBOOKING,
                        //    'VMRNO' => $VMRNO,
                        //    'VNAME' => $name,
                        //    'VIDCARDNO' => $request->idcard,
                        //    'DVISIT' =>  $timef,
                        //    'VPOSCODE' => $request->typedctr,
                        //    'DBIRTH' => carbon::parse($request->dtgl)->format('Y-m-d'),
                        //    'IQUEUENO' => $queque,
                        //    'VCITYBIRTH' => $request->city,
                        //    'VCLINICCODE' => $request->cliniccode,
                        //    'VDRID' => $clinic->VUSRID,
                        //    'VPHONENO' => '+62' . $request->tlpn,
                        //    'BSTATUS' => 'O',
                        //    'VCREA' => Session::get('id'),
                        //    'VMODI' => Session::get('id'),
                        // ]);
                        $pull['MRN'] = $VMRNO;
                        $pull['QUEQU'] = $queque;
                        $pull['doctor'] = $clinic->VNAME;
                        $pull['dvisit'] = $timefirst;
                        $pull['setting'] = $setting->VSETDESC;
                        return response()->json($pull);
                    }
                    else
                    {

                        $null['pesan'] = "this schedule already booked!";
                        return response()->json($null, 404);
                    }
                }
                ///// untuk VEMSAPID

            }
            else
            {
                $id = $request->sapid;

                $checkpoint = DB::select("SELECT COUNT(*) AS COUNTSAPID FROM MEDSYS_SCHBOOKS WHERE VEMPSAPID  = '" . $id . "'  AND VNAME = '" . $name . "' ") [0];

                // get user post Schedule Book
                if ($request->fma === 'family')
                {
                    $id = $request->fmax;

                    $fcheck = DB::select(DB::raw("SELECT VRELNAME,VRELATION,VRELGENDER,VEMPSAPID,VBPJSNO FROM MEDSYS_MSTEMPMEMBERS WHERE  ILINE =  '" . $id . "'")) [0];
                    $userclinic = DB::select(DB::raw("SELECT VADDRESS FROM MEDSYS_MSTEMPLOYEES WHERE  VEMPSAPID =  '" . $fcheck->VEMPSAPID . "'")) [0];

                    $nama_lengkap = $fcheck->VRELNAME;
                    $gender = $fcheck->VRELGENDER;
                    $bpjs = $fcheck->VBPJSNO;

                    if ($userclinic->VADDRESS != null) $alamat = $userclinic->VADDRESS;
                    else $alamat = '';
                    $VMARITALSTS = '';

                }
                else
                {
                    $userclinics = DB::select(DB::raw("SELECT VNAME,VADDRESS,VGNDRCODE,VMARITALSTS,VBPJSNO FROM MEDSYS_MSTEMPLOYEES WHERE  VEMPSAPID =  '" . $id . "'")) [0];

                    $nama_lengkap = $userclinics->VNAME;
                    $gender = $userclinics->VGNDRCODE;
                    $bpjs = $userclinics->VBPJSNO;
                    $alamat = $userclinics->VADDRESS;
                    $VMARITALSTS = $userclinics->VMARITALSTS;

                }

                // check doctor UMUM atau GIGI
                if ($request->dctr === "U" || $request->dctr === "G")
                {
                    $checkdate = DB::select(DB::RAW("SELECT COUNT(*) AS COUNTSAPID FROM MEDSYS_SCHBOOKS WHERE  DVISIT = '" . $timec . "'   AND VDRID = '" . $clinic->VUSRID . "' AND VEMPSAPID = '" . $id . "' AND BSTATUS  = 'O' ")) [0];

                }
                else
                {
                    $checkdate = DB::select("SELECT COUNT(*) AS COUNTSAPID FROM MEDSYS_SCHBOOKS WHERE DVISIT = '" . $timec . "' AND VDRID = '" . $clinic->VUSRID . "' AND BSTATUS  = 'O' ") [0];

                }
                if ($checkpoint->COUNTSAPID <= 0)
                {

                    if ($request->fma === 'family')
                    {

                        $id = $request->fmax;

                        $family = DB::select(DB::raw("SELECT VRELNAME,VRELATION,VRELGENDER FROM MEDSYS_MSTEMPMEMBERS WHERE  ILINE =  '" . $id . "'")) [0];

                        $name = $family->VRELNAME;
                        $vgndrl = $family->VRELGENDER;

                        $vrelation = $family->VRELATION;
                        if ($vrelation === 'S')
                        {

                            $v = 'SO';
                        }
                        else
                        {

                            $data = DB::select("SELECT COUNT(*) AS COUNTSAPID FROM MEDSYS_SCHBOOKS JOIN MEDSYS_MSTEMPMEMBERS ON MEDSYS_MSTEMPMEMBERS.VEMPSAPID =  MEDSYS_SCHBOOKS.VEMPSAPID WHERE MEDSYS_SCHBOOKS.VEMPSAPID  = '" . $request->sapid . "' AND MEDSYS_MSTEMPMEMBERS.VRELATION = 'C' ") [0];

                            $t = $data->COUNTSAPID - 1 + 1;

                            if ($t === '0')
                            {
                                $r = '1';
                            }
                            else
                            {
                                $r = $t;
                            }
                            $v = "C" . $r;
                        }

                        $VMRNO = $request->clinicint . $stringds . $count1 . $v;
                        // patient logs

                    }
                    else
                    {
                        $name = $request->name;
                        if ($request->cate === "e")
                        {
                            $no = "E0";
                        }
                        else
                        {

                            $no = "NO";
                        }
                        $VMRNO = $request->clinicint . $stringds . $count1 . $no;
                    }

                    $id = $request->sapid;

                    $VBOOKING = 'B' . $request->clinicint . $stringds . $countbooking;
                    DB::table('MEDSYS_PATIENTLOGS')->insert([

                    'VMRNO' => $VMRNO, 'VNAME' => $name, 'DBIRTH' => carbon::parse($request->dtgl)
                        ->format('Y-m-d') , 'VSAPID' => $request->sapid, 'VCITYBIRTH' => $request->city, 'VGNDRCODE' => $gender, 'VIDCARDNO' => '', 'VTYPEPATIENT' => $cate->VSETCODE, 'VTYPEUSR' => 'E', 'VPICPOSTALCODE' => '', 'VADDRESS' => $alamat, 'VUSER' => Session::get('id') , 'VDOCID' => $clinic->VUSRID, 'VPHONENO' => '+62' . $request->tlpn, ]);

                    // check patients
                    $checkpatient = DB::select(DB::raw("SELECT COUNT(*) AS countp FROM MEDSYS_PATIENTS where VMRNO =  '" . $VMRNO . "' ")) [0];

                    // insert ke table patient
                    DB::statement("SET NOCOUNT ON ; EXEC sp_UpdatePatient ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?", [$VMRNO, $nama_lengkap, $request->city, carbon::parse($request->dtgl)
                        ->format('Y-m-d') , $gender,NULL, $VMARITALSTS, $alamat,NULL,NULL,NULL,NULL, '+62' . $request->tlpn,NULL,NULL, $bpjs,NULL,NULL, $cate->VSETCODE, 'E', $request->sapid,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL, Session::get('id') ]);

                    // if ($checkpatient->countp <= 0) {
                    //    DB::table('MEDSYS_PATIENTS')->insert([
                    //       'VMRNO' => $VMRNO,
                    //       'VNAME' => $nama_lengkap,
                    //       'DBIRTH' => carbon::parse($request->dtgl)->format('Y-m-d'),
                    //       'VSAPID' => $request->sapid,
                    //       'VCITYBIRTH' => $request->city,
                    //       'VGNDRCODE' => $gender,
                    //       'VIDCARDNO' => '',
                    //       'VTYPEPATIENT' => $cate->VSETCODE,
                    //       'VTYPEUSR' => 'E',
                    //       'VPICPOSTALCODE' => '',
                    //       'VCREA' => Session::get('id'),
                    //       'VMODI' => Session::get('id'),
                    //       'VBPJSNO' => $bpjs,
                    //       'VPHONENO' => '+62' . $request->tlpn,
                    //       'VADDRESS' =>$alamat,
                    //       'VMARITALSTS' =>$VMARITALSTS,
                    //    ]);
                    // } else {
                    //    DB::table('MEDSYS_PATIENTS')->where('VMRNO', $VMRNO)->update([
                    //       'VMRNO' => $VMRNO,
                    //       'VNAME' => $nama_lengkap,
                    //       'VSAPID' => $request->sapid,
                    //       'DBIRTH' => carbon::parse($request->dtgl)->format('Y-m-d'),
                    //       'VGNDRCODE' => $gender,
                    //       'VCITYBIRTH' => $request->city,
                    //       'VIDCARDNO' => '',
                    //       'VTYPEPATIENT' => $cate->VSETCODE,
                    //       'VTYPEUSR' => 'E',
                    //       'VPICPOSTALCODE' => '',
                    //       'VBPJSNO' => $bpjs,
                    //       'DMODI' => Carbon::now(),
                    //       'VMODI' => Session::get('id'),
                    //       'VPHONENO' => '+62' . $request->tlpn,
                    //       'VADDRESS' =>$alamat,
                    //       'VBPJSNO' => $bpjs,
                    //       'VMARITALSTS' =>$VMARITALSTS,
                    //    ]);
                    // }
                    if ($checkdate->COUNTSAPID <= 0)
                    {
                        // update MrNO.
                        if ($checkmr->countmr <= 0)
                        {
                            DB::table('MEDSYS_MSTNOS')
                                ->insert([

                            'NLASTNO' => '0', 'VTRXCODE' => 'MR', 'NYEAR' => $stringds, 'NMONTH' => '0', 'NDATE' => '0', 'DCREA' => Carbon::now() , 'VCREA' => Session::get('id') ,

                            ]);
                        }
                        else
                        {
                            DB::table('MEDSYS_MSTNOS')->where('VTRXCODE', 'MR')
                                ->where('NYEAR', $stringds)->update(['NLASTNO' => $jumlahmr, 'NMONTH' => '0', 'NDATE' => '0', 'DMODI' => Carbon::now() , 'VMODI' => Session::get('id') ,

                            ]);
                        }
                        //check booking
                        if ($checkbooking->countbook === '0')
                        {

                            DB::table('MEDSYS_MSTNOS')
                                ->insert([ //mengisi datadi database
                            'NLASTNO' => '0', 'NYEAR' => $stringds, 'NMONTH' => $months, 'NDATE' => $dayu, 'VTRXCODE' => 'B', 'DCREA' => Carbon::now() , 'VCREA' => Session::get('id') ,

                            ]);
                        }
                        else
                        {
                            // $checkbulan = DB::select("SELECT COUNT ")
                            DB::table('MEDSYS_MSTNOS')->where('VTRXCODE', 'B')
                                ->where('NYEAR', $stringds)->update(['NLASTNO' => $jumlah, 'NYEAR' => $stringds, 'NMONTH' => $months, 'NDATE' => $dayu, 'DMODI' => Carbon::now() , 'VMODI' => Session::get('id') ,

                            ]);
                        }
                        DB::statement("SET NOCOUNT ON ; EXEC sp_UpdateBooking ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?", [$VBOOKING, $VMRNO, $nama_lengkap, $timef, $queque, '', $request->typedctr, $request->sapid, $request->cliniccode, $clinic->VUSRID,NULL, $gender, '+62' . $request->tlpn, $request->city, $bpjs,NULL, carbon::parse($request->dtgl)
                            ->format('Y-m-d') , Session::get('id') ]);

                        // DB::table('MEDSYS_SCHBOOKS')->insert([
                        //    'VBOOKINGNO' => $VBOOKING,
                        //    'VMRNO' => $VMRNO,
                        //    'VNAME' => $nama_lengkap,
                        //    'VEMPSAPID' => $request->sapid,
                        //    'DVISIT' =>  $timef,
                        //    'VGNDRCODE' => $gender,
                        //    'DBIRTH' => carbon::parse($request->dtgl)->format('Y-m-d'),
                        //    'IQUEUENO' => $queque,
                        //    'VCITYBIRTH' => $request->city,
                        //    'VCLINICCODE' => $request->cliniccode,
                        //    'VDRID' => $clinic->VUSRID,
                        //    'VPOSCODE' => $request->typedctr,
                        //    'VPHONENO' => '+62' . $request->tlpn,
                        //    'BSTATUS' => 'O',
                        //    'VCREA' => Session::get('id'),
                        //    'VMODI' => Session::get('id'),
                        //    'VBPJSNO' => $bpjs,
                        // ]);
                        $pull['MRN'] = $VMRNO;
                        $pull['QUEQU'] = $queque;
                        $pull['doctor'] = $clinic->VNAME;
                        $pull['dvisit'] = $timefirst;
                        $pull['setting'] = $setting->VSETDESC;
                        return response()
                            ->json($pull);
                        // check patients



                    }
                    else
                    {

                        $null['pesan'] = "this schedule already booked!";
                        return response()->json($null, 404);
                    }
                }
                else
                {
                    $id = $request->sapid;
                    $VBOOKING = 'B' . $request->clinicint . $stringds . $countbooking;

                    // $checkdate = DB::select(DB::RAW("SELECT COUNT(*) AS COUNTSAPID FROM MEDSYS_SCHBOOKS WHERE DVISIT = '" . $timec . "' AND VDRID = '" . $clinic->VUSRID . "' AND BSTATUS  = 'O'"))[0];
                    if ($request->dctr === "U" || $request->dctr === "G")
                    {
                        $checkdate = DB::select(DB::RAW("SELECT COUNT(*) AS COUNTSAPID FROM MEDSYS_SCHBOOKS WHERE  DVISIT = '" . $timec . "'   AND VDRID = '" . $clinic->VUSRID . "' AND VEMPSAPID = '" . $id . "' AND BSTATUS  = 'O' ")) [0];

                    }
                    else
                    {
                        $checkdate = DB::select("SELECT COUNT(*) AS COUNTSAPID FROM MEDSYS_SCHBOOKS WHERE DVISIT = '" . $timec . "' AND VDRID = '" . $clinic->VUSRID . "' AND BSTATUS  = 'O' ") [0];

                    }

                    $checkpoint = DB::select(DB::RAW("SELECT VMRNO,VGNDRCODE FROM MEDSYS_SCHBOOKS WHERE VEMPSAPID  = '" . $id . "' AND VNAME = '" . $name . "'  ")) [0];
                    $VMRNO = $checkpoint->VMRNO;
                    $GNDRCODE = $checkpoint->VGNDRCODE;
                    if (!$GNDRCODE)
                    {
                        $GNDRCODE = '';
                    }
                    else
                    {
                        $GNDRCODE = $GNDRCODE;
                    }
                    // check patients
                    $checkpatient = DB::select(DB::raw("SELECT COUNT(*) AS countp FROM MEDSYS_PATIENTS where VMRNO =  '" . $VMRNO . "' ")) [0];
                    // patient logs
                    DB::table('MEDSYS_PATIENTLOGS')->insert(['VMRNO' => $VMRNO, 'VNAME' => $name, 'DBIRTH' => carbon::parse($request->dtgl)
                        ->format('Y-m-d') , 'VSAPID' => $request->sapid, 'VCITYBIRTH' => $request->city, 'VGNDRCODE' => $GNDRCODE, 'VIDCARDNO' => '', 'VTYPEPATIENT' => $cate->VSETCODE, 'VTYPEUSR' => 'E', 'VPICPOSTALCODE' => '', 'VUSER' => Session::get('id') , 'VDOCID' => $clinic->VUSRID, 'VPHONENO' => '+62' . $request->tlpn]);

                    // insert ke table patient
                    DB::statement("SET NOCOUNT ON ; EXEC sp_UpdatePatient ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?", [$VMRNO, $nama_lengkap, $request->city, carbon::parse($request->dtgl)
                        ->format('Y-m-d') , $gender,NULL, $VMARITALSTS, $alamat,NULL,NULL,NULL,NULL, '+62' . $request->tlpn,NULL,NULL, $bpjs,NULL,NULL, $cate->VSETCODE, 'E', $request->sapid,NULL,NULL,NULL,NULL,NULL, NULL,NULL,NULL,NULL,NULL,NULL,NULL, Session::get('id') ]);

                    // if ($checkpatient->countp <= 0) {
                    //    DB::table('MEDSYS_PATIENTS')->insert([
                    //       'VMRNO' => $VMRNO,
                    //       'VNAME' => $nama_lengkap,
                    //       'DBIRTH' => carbon::parse($request->dtgl)->format('Y-m-d'),
                    //       'VSAPID' => $request->sapid,
                    //       'VCITYBIRTH' => $request->city,
                    //       'VGNDRCODE' => $gender,
                    //       'VIDCARDNO' => '',
                    //       'VTYPEPATIENT' => $cate->VSETCODE,
                    //       'VTYPEUSR' => 'E',
                    //       'VPICPOSTALCODE' => '',
                    //       'VCREA' => Session::get('id'),
                    //       'VMODI' => Session::get('id'),
                    //       'VBPJSNO' => $bpjs,
                    //       'VPHONENO' => '+62' . $request->tlpn,
                    //       'VADDRESS' =>$alamat,
                    //       'VMARITALSTS' =>$VMARITALSTS,
                    //    ]);
                    // } else {
                    //    DB::table('MEDSYS_PATIENTS')->where('VMRNO', $VMRNO)->update([
                    //       'VMRNO' => $VMRNO,
                    //       'VNAME' => $nama_lengkap,
                    //       'VSAPID' => $request->sapid,
                    //       'DBIRTH' => carbon::parse($request->dtgl)->format('Y-m-d'),
                    //       'VGNDRCODE' => $gender,
                    //       'VCITYBIRTH' => $request->city,
                    //       'VIDCARDNO' => '',
                    //       'VTYPEPATIENT' => $cate->VSETCODE,
                    //       'VTYPEUSR' => 'E',
                    //       'VPICPOSTALCODE' => '',
                    //       'VBPJSNO' => $bpjs,
                    //       'DMODI' => Carbon::now(),
                    //       'VMODI' => Session::get('id'),
                    //       'VPHONENO' => '+62' . $request->tlpn,
                    //       'VADDRESS' =>$alamat,
                    //       'VBPJSNO' => $bpjs,
                    //       'VMARITALSTS' =>$VMARITALSTS,


                    //    ]);
                    // }
                    if ($checkdate->COUNTSAPID <= 0)
                    {
                        //check booking
                        if ($checkbooking->countbook === '0')
                        {

                            DB::table('MEDSYS_MSTNOS')
                                ->insert([ //mengisi datadi database
                            'NLASTNO' => '0', 'NYEAR' => $stringds, 'NMONTH' => $months, 'NDATE' => $dayu, 'VTRXCODE' => 'B', 'VCREA' => Session::get('id') , ]);
                        }
                        else
                        {
                            // $checkbulan = DB::select("SELECT COUNT ")
                            DB::table('MEDSYS_MSTNOS')->where('VTRXCODE', 'B')
                                ->where('NYEAR', $stringds)->update(['NLASTNO' => $jumlah, 'NYEAR' => $stringds, 'NMONTH' => $months, 'NDATE' => $dayu, 'DMODI' => Carbon::now() , 'VMODI' => Session::get('id') , ]);
                        }

                        DB::statement("SET NOCOUNT ON ; EXEC sp_UpdateBooking ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?", [$VBOOKING, $VMRNO, $nama_lengkap, $timef, $queque,NULL, $request->typedctr, $request->sapid, $request->cliniccode, $clinic->VUSRID,NULL, $gender, '+62' . $request->tlpn, $request->city, $bpjs, '', carbon::parse($request->dtgl)
                            ->format('Y-m-d') , Session::get('id') ]);

                        // DB::table('MEDSYS_SCHBOOKS')->insert([
                        //    'VBOOKINGNO' => $VBOOKING,
                        //    'VMRNO' => $VMRNO,
                        //    'VNAME' => $nama_lengkap,
                        //    'VEMPSAPID' => $request->sapid,
                        //    'DVISIT' =>  $timef,
                        //    'VGNDRCODE' => $gender,
                        //    'DBIRTH' => carbon::parse($request->dtgl)->format('Y-m-d'),
                        //    'IQUEUENO' => $queque,
                        //    'VCITYBIRTH' => $request->city,
                        //    'VCLINICCODE' => $request->cliniccode,
                        //    'VDRID' => $clinic->VUSRID,
                        //    'VPOSCODE' => $request->typedctr,
                        //    'VPHONENO' => '+62' . $request->tlpn,
                        //    'BSTATUS' => 'O',
                        //    'VCREA' => Session::get('id'),
                        //    'VMODI' => Session::get('id'),
                        //    'VBPJSNO' => $bpjs,
                        // ]);
                        $pull['MRN'] = $VMRNO;
                        $pull['QUEQU'] = $queque;
                        $pull['doctor'] = $clinic->VNAME;
                        $pull['dvisit'] = $timefirst;
                        $pull['setting'] = $setting->VSETDESC;
                        return response()
                            ->json($pull);
                    }
                    else
                    {

                        $null['pesan'] = "this schedule already booked!";
                        return response()->json($null, 404);
                    }

                    // $VMRNO = $checkid->VMRNO;
                    // echo $VMRNO;
                    // echo "sss";

                }
            }

        }
    
        ///check patient
       

    }
    public function cancelbooking($id)
    {
        $encode = base64_decode($id);
        DB::table('MEDSYS_SCHBOOKS')->where('VBOOKINGNO', $encode)->update(['BSTATUS' => 'C', 'DMODI' => Carbon::now() , 'VMODI' => Session::get('id') , ]);

        return response()
            ->json(200);
    }

    public function ajaxmember($id)
    {

        $y = base64_decode($id);
        $countfamily = DB::select(DB::RAW("SELECT COUNT(*) AS countas FROM MEDSYS_MSTEMPMEMBERS WHERE ILINE =  '" . $y . "' ")) [0];

        $family = DB::select(DB::RAW("SELECT * FROM MEDSYS_MSTEMPMEMBERS WHERE ILINE =  '" . $y . "' ")) [0];

        $day = array(

            'fullname' => $family->VRELNAME,
            'date' => carbon::parse($family->DRELBIRTH)->format('d-M-Y'),
            'city' => $family->VRELCITYBIRTH,
            'telepon' => '',

        );

        return response()
            ->json($day);
    }
    public function ajaxbooking(Request $request)
    {
        // if($_GET['DFROM'] != null) $DFROM = $_GET['DFROM'];
        // else $DFROM = Carbon::now()->startofMonth()->format('d-m-Y');
        // if($_GET['DTO'] != null)  $DTO =  $_GET['DTO'];
        // else $DTO = Carbon::now()->endOfMonth()->format('d-m-Y');


        if (Session::get('typeuser') === "E")
        {
            $all = 'ALL';
            $user = Session::get('id');
            $clinic = 'ALL';
        }
        else
        {
            $userrole = \App\Mstuserrole::where('VUSRID', '=', Session::get('id'))->where('BACTIVE', '1')
                ->first();
            if ($userrole->VROLEID === "DCTR")
            {
                $all = Session::get('id');
                $user = 'ALL';
                $clinic = Session::get('namaclinic');

            }
            else
            {
                $all = 'ALL';
                $user = 'ALL';
                $clinic = Session::get('namaclinic');

            }

        }
        $booking = \DB::select("EXEC sp_PatientQueue ?,?,?", array(
            $clinic,
            $all,
            $user
        ));
        return Datatables::of($booking)->addIndexColumn()->addColumn('action', function ($row)
        {
            $userrole = \App\Mstuserrole::where('VUSRID', '=', Session::get('id'))->where('BACTIVE', '1')->first();
            // ====
            // check doctor atau paramedic
            if ($userrole->VROLEID === "DCTR")
            {

                $html = '';
                $html .= '<button onclick="mulai(' . $row->QueueNo . ');" class="btn btn-sz btn-link btn-disabled" id="btn-bel' . $row->QueueNo . '"><i class="fa fa-microphone"></i></button> ';
                if ($row->QueueNo < 20)
                {
                    $html .= '<audio id="suarabel' . $row->QueueNo . '" src="/audio/' . $row->QueueNo . '.wav" ></audio>';

                }
                else
                {
                    $html .= '<audio class="suarabel' . substr($row->QueueNo, 0, 1) . '" src="/audio/' . substr($row->QueueNo, 0, 1) . '.wav" ></audio>';

                    if (substr($row->QueueNo, 1, 2) === NULL)
                    {

                        $html .= '';

                    }
                    else if ($row->QueueNo < 100)
                    {
                        $html .= '<audio class="suarabel" id="suarabel' . substr($row->QueueNo, 1, 2) . '" src="/audio/' . substr($row->QueueNo, 1, 2) . '.wav" ></audio>';

                    }

                }
                return $html;
            }
            else
            {

                if ($row->Status === 'Close')
                {
                    $html = "";
                }
                else if ($row->Status === 'Open')
                {
                    $day = carbon::now()->format('d-m');
                    $visit = carbon::parse($row->VisitDate)->format('d-m');
                    if ($day === $visit)
                    {

                        $html = '';

                    }
                    else
                    {
                        if(RoleAccessController::FunctionAccessCheck('D/C', 'F01')) {
                        $html = '<form data-url="/booking/cancel" data-id="' . base64_encode($row->VBOOKINGNO) . '" class="btncancel">
                                 <input type="hidden" value="' . base64_encode($row->VBOOKINGNO) . '" class="id">
                                 <button type="submit" class="btn btn btn-link btn-sm deletebooking"><i class="fas fa-times"></i></button></form>';
                        }else{

                            $html = '';
                        }

                    }

                }
                else
                {

                    $html = '';

                }
                return $html;
            }

        })->addColumn('visitdate', function ($row)
        {
            return Carbon::parse($row->VisitDate)
                ->format('YmdHia');

            // return carbon::parse($row->VisitDate)->format('d-M-yy H:i A');

        })->addColumn('visitdates', function ($row)
        {
            if($row->VPOSCODE == 'UMUM'){
                return carbon::parse($row->VisitDate)
                ->format('d-M-Y');
            }else{
                return carbon::parse($row->VisitDate)
                ->format('d-M-Y H:i A');
            }

        })->addColumn('DBIRTH', function ($row)
        {

            return carbon::parse($row->DateOfBirth)
                ->format('d-M-Y');
        })->addColumn('BSTATUS', function ($row)
        {

            return $row->Status;
        })->addColumn('MRNOA', function ($row)
        {

            return '<a href="booking/patientinfo/' . base64_encode($row->VBOOKINGNO) . '" >' . $row->MRNo . '</a>';
        })->addColumn('GROUP', function ($row)
        {

            return $row->Category;
        })
            ->rawColumns(['action', 'BSTATUS', 'visitdate', 'GROUP', 'DVISIT', 'MRNOA'])
            ->make(true);
    }
    public function getdistrictlookup($id)
    {
        $ida = base64_decode($id);
        list($x, $y) = explode(" - ", $ida);
        $lookup = DB::select("SELECT VDISTRICTCODE,VDISTRICTNAME FROM MEDSYS_MSTDISTRICTS WHERE VPROVCODE = '" . $x . "'");

        return response()->json(['data' => $lookup]);
    }
    public function getprovincelookup()
    {
        $lookup = DB::select('SELECT PROVCODE,PROVNAME FROM vw_mstprovince');
        return response()->json(['data' => $lookup]);
    }
    public function updategeneral(Request $request)
    {

        DB::table('MEDSYS_PATIENTS')->where('VMRNO', $request->VMRNO)
            ->update(['VPROFESSION' => $request->VPROFESSION, 'VBLOODTYPE' => $request->VBLOODTYPE, 'VBPJSNO' => $request->VBPJS, 'VINSCODE' => $request->VSTSX, 'VMARITALSTS' => $request->VSTS, 'VINSNO' => $request->VINSURANCENO, 'VTYPEPATIENT' => $request->VGRPPATIENT, 'VNAME' => $request->VPatientName, 'VGNDRCODE' => $request->VGNDRCODEX, 'VADDRESS' => $request->VADDRESSX, 'VPOSTALCODE' => $request->VPOSTALCODEX, 'VPHONENO' => $request->VPHONENO, 'VPROVCODE' => $request->province, 'VDISTRICTCODE' => $request->district, 'VSUBDISTRICTCODE' => $request->subdistrict, 'VIDCARDNO' => $request->idcard, 'VPROFESSION' => $request->VPROFESSION, 'VPICNAME' => $request->VPICNAME, 'VPICIDCARDNO' => $request->VPICIDCARDNO, 'VPICPOSTALCODE' => $request->VPICPOSTALCODE, 'VPICADDRESS' => $request->VPICADDRESS, 'VPICPROVCODE' => $request->VPICPROVCODE, 'VPICDISTRICTCODE' => $request->VPICDISTRICTCODE, 'VPICSUBDISTRICTCODE' => $request->VPICSUBDISTRICTCODE, 'VPICRELATION' => $request->VPICRELATION,

        'DMODI' => carbon::now() , 'VMODI' => Session::get('id') ,

        ]);
        $data = '#tabgeneral';
        return response()->json($data, 200);
    }
    public function alternativedoctorlookup($id)
    {

        $e = base64_decode($id);
        $schbooks = DB::select(DB::raw("SELECT a.VCLINICCODE AS VCLINICCODE,a.DVISIT as DVISIT,a.VDRID AS VDIRDS,a.VPOSCODE AS VPOSCODE,ISNULL(g.VGNRLDESC, '') as VGNRLDESC FROM MEDSYS_SCHBOOKS a left JOIN  MEDSYS_MSTCLINICSTAFFS b ON a.VDRID = b.VUSRID left join MEDSYS_MSTGENERALS g on g.VGNRLTYPE='SPECIALIST' and b.VSPCCODE = g.VGNRLCODE WHERE a.VBOOKINGNO = '" . $e . "' "));

        if (!empty($schbooks)) $booking = $schbooks[0];
        if (!empty($schbooks)) if ($booking->VPOSCODE === 'UMUM')
        {
            $day = '';
        }
        else
        {
            $now = date_create($booking->DVISIT);
            $day = Carbon::parse($now)->format('l');
        }

        //   if(Carbon::parse($now)->format('H:i') == '00:00'){
        //      $cate = 'UMUM';
        //   }else{
        //      $cate = 'GIGI';
        //   }
        $now = carbon::now();
        $nows = $now->format('D');
        $sp = \DB::select("EXEC sp_LookUpDoctor ?,?,?", array(
            $booking->VCLINICCODE,
            $booking->VPOSCODE,
            $day
        ));
        $data = array();
        foreach ($sp AS $key => $val)
        {
            if ($booking->VGNRLDESC === $val->VGNRLDESC)
            {
                if ($booking->VDIRDS === $val->VUSRID)
                {

                }
                else
                {
                    $data[] = $val;

                }
            }

        }
        return Datatables::of($data)->addIndexColumn()
            ->make(true);

    }
    public function postExamination(Request $request)
    {
        $checkexam = DB::select(DB::raw("SELECT COUNT(*) AS hasil FROM MEDSYS_EXAMINATIONS where VBOOKINGNO = '" . $request->vbooking . "' ")) [0];

        $checkclinic = DB::select(DB::raw("SELECT VCLINICCODE FROM MEDSYS_SCHBOOKS where VBOOKINGNO = '" . $request->vbooking . "'")) [0];

        $checksum = DB::select(DB::raw("SELECT COUNT(*)  AS hasil FROM MEDSYS_EXAMINATIONS ")) [0];
        $hasil = $checksum->hasil + 1;

        if ($checkexam->hasil < 1)
        {
            $examination = new MEDSYS_EXAMINATIONS;

        }else{
            $examination = MEDSYS_EXAMINATIONS::find($request->vbooking);

        }
        $examination->VBOOKINGNO = $request->vbooking;
        $examination->NHEIGHT = $request->patienth;
        $examination->NWEIGHT = $request->patientwe;
        $examination->NBREATHFREQ = $request->NBREATHFREQ;
        $examination->NBLOOD = $request->NBLOOD;
        $examination->NPULSE = $request->NPLUSE;
        $examination->NTEMPERATURE = $request->NTEMPERATURE;
        $examination->VDRUGALLERGIES = $request->VDRUGALLERGIES;
        $examination->VAMNESIS = $request->VAMNESIS;
        $examination->VNOTES = $request->VNOTES;
        $examination->BWORKDISEASE = $request->BWORKDISEASE;
        $examination->VICDCODE = $request->mydiagnosisi;
        if (Session::get('groupuser') [0] === 'DCTR')
        {
            $examination->VDRID = Session::get('id');
        }
        else
        {
            $examination->VDRID = '';

        }

        // $examination->VLETTERID = $request->NWEIGHT;
        $examination->BREST = $request->istirahat;
        $examination->IRESTDAY = $request->jmlahhari;
        $examination->VINSCODE = $request->rujukan;
        $examination->VPROVIDER = $request->provider;
        $examination->VREFERENCE = $request->profil;

        $examination->DMODI = Carbon::now();
        $examination->DCREA = Carbon::now();

        $examination->VCREA = Session::get('id');
        $examination->VMODI = Session::get('id');
        $examination->save();

        /// Logs
        $logsexaminations = DB::select(DB::raw("SELECT COUNT(*) AS nos FROM MEDSYS_EXAMINATIONLOGS WHERE VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
        // if ($checkexam->hasil <= '1')
        // {
        //     $examinatios = MEDSYS_EXAMINATIONLOGS::find($checkexam->hasil);

        // }else{
        //     $examinations = new MEDSYS_EXAMINATIONLOGS;

        // }
        // $examinatios = MEDSYS_EXAMINATIONLOGS::find($checkexam->hasil);

        $examinations = new MEDSYS_EXAMINATIONLOGS;
        // $examinations->ILINE =  $logsexaminations->nos + 1;
        $examinations->VBOOKINGNO = $request->vbooking;
        $examinations->NHEIGHT = $request->patienth;
        $examinations->NWEIGHT = $request->patientwe;
        $examinations->NBREATHFREQ = $request->NBREATHFREQ;
        $examinations->NBLOOD = $request->NBLOOD;
        $examinations->NPULSE = $request->NPLUSE;
        $examinations->NTEMPERATURE = $request->NTEMPERATURE;
        $examinations->VDRUGALLERGIES = $request->VDRUGALLERGIES;
        $examinations->VAMNESIS = $request->VAMNESIS;
        $examinations->VNOTES = $request->VNOTES;
        $examinations->BWORKDISEASE = $request->BWORKDISEASE;
        $examinations->VICDCODE = $request->mydiagnosisi;
        $examinations->BREST = $request->istirahat;
        $examinations->IRESTDAY = $request->jmlahhari;
        $examinations->VINSCODE = $request->rujukan;
        $examinations->VPROVIDER = $request->provider;
        $examinations->VREFERENCE = $request->profil;
        // $examination->VLETTERID = $request->NWEIGHT;
        $examinations->VUSER = Session::get('id');
        $examinations->save();

        if (Session::get('groupuser') [0] === 'DCTR')
        {

            $checkdrid = DB::select(DB::raw("SELECT VDRID FROM MEDSYS_EXAMINATIONS where VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
            $patient = DB::select(DB::raw("SELECT a.VTYPEPATIENT As VTYPEPATIENT FROM MEDSYS_PATIENTS a JOIN MEDSYS_SCHBOOKS b ON a.VMRNO = b.VMRNO WHERE b.VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
            $dctr = DB::select(DB::raw("SELECT COUNT(*) as nos FROM MEDSYS_BILLS  WHERE VBOOKINGNO = '" . $request->vbooking . "' AND VITEMNAME = 'Doctor Fee' ")) [0];
            $dctrs = DB::select(DB::raw("SELECT COUNT(*) as nos FROM MEDSYS_BILLS  WHERE VBOOKINGNO = '" . $request->vbooking . "' ")) [0];

            $doctorfee = Mstclinicstaffs::where('VUSRID', Session::get('id'))->select('NRATE')->first();
            if ($dctr->nos < 1)
            {
                DB::table('MEDSYS_BILLS')->insert(['ILINENO' => $dctrs->nos + 1, 'VBOOKINGNO' => $request->vbooking, 'VITEMCODE' => '', 'VITEMNAME' => 'Doctor Fee', 'IQTY' => '1', 'NPRICE' => $doctorfee->NRATE, 'VTYPE' => $patient->VTYPEPATIENT, 'VREMARKS' => '[]', 'VCREA' => Session::get('id') , 'VMODI' => '', 'DCREA' => Carbon::now() , 'DMODI' => '',]);
    
            }else{
    
            }
              
        }


        // $examinationu = MEDSYS_EXAMINATIONS::find($request->vbooking);
        // $examinationu->NHEIGHT = $request->patienth;
        // $examinationu->NWEIGHT = $request->patientwe;
        // $examinationu->NBREATHFREQ = $request->NBREATHFREQ;
        // $examinationu->NBLOOD = $request->NBLOOD;
        // $examinationu->NPULSE = $request->NPLUSE;
        // $examinationu->NTEMPERATURE = $request->NTEMPERATURE;
        // $examinationu->VDRUGALLERGIES = $request->VDRUGALLERGIES;
        // $examinationu->VAMNESIS = $request->VAMNESIS;
        // $examinationu->VNOTES = $request->VNOTES;
        // $examinationu->BWORKDISEASE = $request->BWORKDISEASE;
        // $examinationu->VICDCODE = $request->mydiagnosisi;
        // if (Session::get('groupuser') [0] === 'DCTR')
        // {
        //     $examinationu->VDRID = Session::get('id');
        // }
        // else
        // {
        //     $examinationu->VDRID = '';

        // }
        // // $examinationu->VDRID = $request->DOCTR;
        // // $examination->VLETTERID = $request->NWEIGHT;
        // $examinationu->BREST = $request->istirahat;
        // $examinationu->IRESTDAY = $request->jmlahhari;
        // $examinationu->VINSCODE = $request->rujukan;
        // $examinationu->VPROVIDER = $request->provider;
        // $examinationu->VREFERENCE = $request->profil;
        // $examinationu->DMODI = Carbon::now();
        // $examinationu->VMODI = Session::get('id');

        // $examinationu->save();
        // if (Session::get('groupuser') [0] === 'DCTR')
        // {

        //     $checkdrid = DB::select(DB::raw("SELECT VDRID FROM MEDSYS_EXAMINATIONS where VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
        //     $patient = DB::select(DB::raw("SELECT a.VTYPEPATIENT As VTYPEPATIENT FROM MEDSYS_PATIENTS a JOIN MEDSYS_SCHBOOKS b ON a.VMRNO = b.VMRNO WHERE b.VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
        //     $dctr = DB::select(DB::raw("SELECT COUNT(*) as nos FROM MEDSYS_BILLS  WHERE VBOOKINGNO = '" . $request->vbooking . "' ")) [0];

        //     if ($dctr->nos < 1)
        //     {

        //         $doctorfee = Mstclinicstaffs::where('VUSRID', Session::get('id'))->select('NRATE')
        //             ->first()->NRATE;
        //         DB::table('MEDSYS_BILLS')
        //             ->insert(['ILINENO' => $dctr->nos + 1, 'VBOOKINGNO' => $request->vbooking, 'VITEMCODE' => '', 'VITEMNAME' => 'Doctor Fee', 'IQTY' => '1', 'NPRICE' => $doctorfee, 'VTYPE' => $patient->VTYPEPATIENT, 'VREMARKS' => '[]', 'VCREA' => Session::get('id') , 'VMODI' => '', 'DCREA' => Carbon::now() , 'DMODI' => '',

        //         ]);
        //     }

        // }
        if (isset($request->drugcode))
        {
            $now = carbon::now();
            $iud = str_replace('B', 'E', $request->vbooking);

            $find = Invmovehdrs::find($iud);
            if($find != NULL){
                $inventory = $find;

            }else{
                $inventory = new Invmovehdrs();

            }
            $yy = substr($now->format('Y'), 2, 2);
            $inventory->VCLINICCODE = $checkclinic->VCLINICCODE;
            $inventory->VTYPE = 'EXM';
            $inventory->VREQNO = '';
            $inventory->DTRX = $now;
            $inventory->VCREA = Session::get('id');
            $inventory->DCREA = $now;
            $inventory->VMODI = Session::get('id');
            $movelog = new Invmovehdrlogs();
            $movelog->VCLINICCODE = $inventory->VCLINICCODE;
            $movelog->VTYPE = $inventory->VTYPE;
            $movelog->VREQNO = $inventory->VREQNO;
            $movelog->DTRX = $inventory->DTRX;
            $movelog->VUSER = Session::get('id');


            DB::beginTransaction();
  
            try
            {
                $inventory->VTRXNO = str_replace('B', 'E', $request->vbooking);
                $inventory->save();
                $lineno = 1;
                for ($x = 0;$x < count($request->drugcode);$x++)
                {
                    $check = DB::select(DB::raw("SELECT COUNT(*) AS nos FROM MEDSYS_EXAMINATIONDTLS WHERE VITEMCODE = '" . $request->drugcode[$x] . "' AND VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
                    if ($check->nos === '1')
                    {
                        $check = DB::select(DB::raw("SELECT NPRICE,VCONTAIN,VDRUGSCODE FROM MEDSYS_MSTDRUGS WHERE VDRUGSCODE = '" . $request->drugcode[$x] . "' ")) [0];
                        
                        $name = $check->VCONTAIN;
                        
                        $error['error'] = 'Drugs by the same brand can only be added once.';
                        return response()->json($error, 400);
                    }
                    else
                    {
                        $nov = DB::select(DB::raw("SELECT MAX(ILINENO) AS countno FROM MEDSYS_INVMOVEDTLS WHERE VTRXNO = '" . $inventory->VTRXNO . "'")) [0];
                        $now = carbon::now();
                        $yy = substr($now->format('Y') , 2, 2);
                        $line = new Invmovedtls();
                        $line->VTRXNO = $inventory->VTRXNO;
                        $line->ILINENO = $nov->countno + 1;
                        $line->VCREA = Session::get('id');
                        $line->DCREA = $now;
                        $line->VDRUGSCODE = $request->drugcode[$x];
                        $line->IQTY =  $request->qty[$x];
                            $sql = DB::select("EXEC sp_IssueStock ?, ?, ?", [$checkclinic->VCLINICCODE,$request->drugcode[$x], substr($request->qty[$x], 1) ]);
                            
                            if (count($sql) == 0)
                            {
                                return response()->json(['error' => 'No Stock for ' . $request->drugcode[$x]], 500);
                            }
                            $dexp = NULL;
                            $iqty = 0;
                            $arrnew = array();
                            foreach ($sql as $key => $val)
                            {
                                if (!isset($line->DEXPIRED))
                                {
                                    if ($request->qty[$x] > $val->BALANCE)  // ke-lwt balance
                                    {
                                        $iqty += $val->BALANCE;
                                        $arrnew[] = ['qty' => $val->BALANCE, 'expired' => $val->DEXPIRED];
                                    }
                                    else
                                    {
                                        // dd("sini");
                                        $line->DEXPIRED = $val->DEXPIRED;
                                        $dexp = $val->DEXPIRED;
                                        $iqty = $request->qty[$x];
                                        break;
                                    }
                                }
                                else
                                {
                                    // if DEXPIRED is set(exists)
                                    if (substr($line->DEXPIRED, 0, 10) == $val->DEXPIRED)
                                    {
                                        if ($request->qty[$x] > $val->BALANCE)
                                        {
                                            DB::rollBack();
                                            return response()
                                            ->json(['error' => 'Max Qty ' . $val->VDRUGSCODE . ' at Expired Date ' . date_format(DateTime::createFromFormat('Y-m-d', $val->DEXPIRED) , "d-M-Y") . ' is ' . $val->BALANCE], 500);
                                        }
                                        else
                                        {
                                            $line->DEXPIRED = $val->DEXPIRED;
                                            $dexp = $val->DEXPIRED;
                                            $iqty = $line->IQTY;
                                            break;
                                        }
                                    }
                                }
                            }
                            if ($iqty < substr($line->IQTY, 1))
                            {
                                DB::rollBack();
                                return response()->json(['error' => 'Max Qty ' . $line->VDRUGSCODE . ' is ' . $iqty], 500);
                            }
                            if (substr($line->DEXPIRED, 0, 10) != $dexp)
                            {
                                DB::rollBack();
                                return response()->json(['error' => 'No Expired Date at ' . date_format($line->DEXPIRED, "d-M-Y") . ' for ' . $line->VDRUGSCODE], 500);
                            }
                            if (count($arrnew) > 0)
                            {
                                        foreach ($arrnew as $k => $v)
                                        {
                                            $lineno++;
                                            $addline = new Invmovedtls();
                                            $addline->VTRXNO = $inventory->VTRXNO;
                                            $addline->ILINENO = $lineno;
                                            $addline->VCREA = Session::get('id');
                                            $addline->DCREA = $now;
                                            $addline->VMODI = Session::get('id');
                                            $addline->VDRUGSCODE = $request->VDRUGSCODE[$x];
                                            $addline->DEXPIRED = $v['expired'];
                                            $addline->IQTY = $v['qty'] * -1;
                                            $addline->save();
                                            $addmovedtllog = new Invmovedtllogs();
                                            $addmovedtllog->VTRXNO = $addline->VTRXNO;
                                            $addmovedtllog->ILINENO = $addline->ILINENO;
                                            $addmovedtllog->VDRUGSCODE = $addline->VDRUGSCODE;
                                            $addmovedtllog->DEXPIRED = $addline->DEXPIRED;
                                            $addmovedtllog->IQTY = $addline->IQTY;
                                            $addmovedtllog->VUSER = Session::get('id');
                                            $addmovedtllog->save();
                                            $iqty -= $v['qty'];
                                        }
                                        // $line->IQTY = '-'.$iqty;
                            }
                        //dd($line);
                        $line->IQTY = '-'.$iqty;
                        $line->save();
                        // if($x == 0) dd($line);
                    }

                    //$inventory->VTRXNO = $request->vbooking;
                    $logsexaminationdtls = DB::select(DB::raw("SELECT COUNT(*) AS nos FROM MEDSYS_EXAMINATIONDTLS WHERE VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
                    $examindtls = new MEDSYS_EXAMINATIONDTLS;
                    $examindtls->ILINENO = $logsexaminationdtls->nos + 1;
                    $examindtls->VBOOKINGNO = $request->vbooking;
                    $examindtls->VITEMCODE = $request->drugcode[$x];
                    $examindtls->IQTY = $request->qty[$x];
                    $examindtls->DMODI = Carbon::now();
                    $examindtls->VCREA = Session::get('id');
                    $examindtls->VMODI = Session::get('id');
                    $examindtls->DCREA = Carbon::now();
                    $examindtls->save();
                    //logs
                    $logsexaminationdtls = DB::select(DB::raw("SELECT COUNT(*) AS nos FROM MEDSYS_EXAMINATIONDTLLOGS  WHERE VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
                    $examindtlslogs = new MEDSYS_EXAMINATIONDTLLOGS;
                    $examindtlslogs->ILINENO = $logsexaminationdtls->nos + 1;
                    $examindtlslogs->VBOOKINGNO = $request->vbooking;
                    $examindtlslogs->VITEMCODE = $request->drugcode[$x];
                    $examindtlslogs->IQTY = $request->qty[$x];
                    $examindtlslogs->VUSER = Session::get('id');
                    $examindtlslogs->save();
                        
                }
            }

            catch(\Exception $e)
            {
                DB::rollBack();
                if (!isset($e->errorInfo))
                {
                    return response()->json($e, 500);
                }
                else
                {
                    return response()->json($e->errorInfo[2], 500);
                }
            }

            DB::commit();
        }
        $data = '#tabexamination';
        return response()->json($data, 200);
    }
        public function doctorlistlookup($id)
        {
            $e = base64_decode($id);
            list($TIME, $DOCTOR, $VCLINICCODE) = explode(";", $e);
            // $cate = '';
            $now = date_create($TIME);
            $day = Carbon::parse($now)->format('l');
            // dd($TIME);
            if ($DOCTOR === 'UMUM')
            {
                $day = '';
            }
            else
            {
                $now = date_create($TIME);
                $day = Carbon::parse($now)->format('l');
            }
            $now = carbon::now();
            $nows = $now->format('D');
            $sp = \DB::select("EXEC sp_LookUpDoctor ?,?,?", array(
                $VCLINICCODE,
                $DOCTOR,
                $day
            ));

            return response()->json(['data' => $sp]);
            // $booking = DB::select(DB::raw("SELECT VCLINICCODE FROM MEDSYS_SCHBOOKS WHERE VBOOKINGNO = '".$e."' "))[0];
            // $schdtr = DB::select("SELECT MEDSYS_MSTCLINICSTAFFS.VNAME,MEDSYS_MSTCLINICSTAFFS.VUSRID FROM MEDSYS_SCHDCTRHDRS JOIN MEDSYS_MSTCLINICSTAFFS ON MEDSYS_SCHDCTRHDRS.VUSRID = MEDSYS_MSTCLINICSTAFFS.VUSRID
            //           WHERE MEDSYS_SCHDCTRHDRS.VCLINICCODE = '".$booking->VCLINICCODE."' AND MEDSYS_SCHDCTRHDRS.BACTIVE = '1' ");
            // dd($schdtr);

        }
        public function postTreatment(Request $request)
        {
            // var_dump($request);
            
            if ($request->hasilbarcode1 === NULL)
            {
                
                for ($x = 0;$x < count($request->drugcode);$x++)
                {
                
                                $VCLINICCODE = $request->vcliniccode;
                                $ASOFDATE = date("Y-m-d");

                                $no = DB::select(DB::raw("SELECT MAX(ILINENO) AS countno FROM MEDSYS_TREATMENTS WHERE VBOOKINGNO = '" . $request->vbooking . "'")) [0];

                                $price = DB::select(DB::raw("SELECT NPRICE,VCONTAIN,VDRUGSCODE FROM MEDSYS_MSTDRUGS WHERE VDRUGSCODE = '" . $request->drugcode[$x] . "' ")) [0];
                                $VTRXNOW = DB::select(DB::raw("SELECT VCLINICCODE FROM MEDSYS_SCHBOOKS WHERE VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
                                // dd($price->NPRICE);
                                $check = DB::select(DB::raw("SELECT COUNT(*) AS nos FROM MEDSYS_TREATMENTS WHERE VDRUGSCODE = '" . $request->drugcode[$x] . "' AND VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
                                if ($check->nos === '1')
                                {
                                    $check = DB::select(DB::raw("SELECT NPRICE,VCONTAIN,VDRUGSCODE FROM MEDSYS_MSTDRUGS WHERE VDRUGSCODE = '" . $request->drugcode[$x] . "' ")) [0];

                                    $name = $check->VCONTAIN;
                                    $error['error'] = 'Drugs by the same brand can only be added once.';
                                    return response()->json($error, 400);
                                }
                                else
                                {
                                    // $nov = DB::select(DB::raw("SELECT COUNT(*) AS countno FROM MEDSYS_INVMOVEDTLS WHERE VTRXNO = '" . $request->vbooking . "'")) [0];
                                    $now = carbon::now();
                                    $yy = substr($now->format('Y') , 2, 2);
                                    // check Movement
    
                                    $iud = str_replace('B', 'T', $request->vbooking);

                                    $find = Invmovehdrs::find($iud);
                                    if($find != NULL){
                                        $inventory = $find;
                        
                                    }else{
                                        $inventory = new Invmovehdrs();
                        
                                    }
                                    $inventory->VCLINICCODE = $VCLINICCODE;
                                    $inventory->VTYPE = 'TRM';
                                    $inventory->VREQNO = '';
                                    $inventory->DTRX = $now;
                                    $inventory->VCREA = Session::get('id');
                                    $inventory->DCREA = $now;
                                    $inventory->VMODI = Session::get('id');
                                    $movelog = new Invmovehdrlogs();
                                    $movelog->VCLINICCODE = $inventory->VCLINICCODE;
                                    $movelog->VTYPE = $inventory->VTYPE;
                                    $movelog->VREQNO = '';
                                    $movelog->DTRX = $inventory->DTRX;
                                    $movelog->VUSER = Session::get('id');
                                    DB::beginTransaction();
                                    try
                                    {
                                        $nov = DB::select(DB::raw("SELECT MAX(ILINENO) AS countno FROM MEDSYS_INVMOVEDTLS WHERE VTRXNO = '" . $iud . "' ")) [0];
                                       
                                        $inventory->VTRXNO = $iud;
                                        $line = new Invmovedtls();
                                        $line->VTRXNO = $inventory->VTRXNO;
                                        $line->ILINENO = $nov->countno+1;
                                        $line->VCREA = Session::get('id');
                                        $line->DCREA = $now;
                                        $line->VDRUGSCODE = $request->drugcode[$x];
                                        // $line->DEXPIRED = '';
                                        $line->IQTY = $request->qtyS[$x];
                                        $sql = DB::select("EXEC sp_IssueStock ?, ?, ?", [$VCLINICCODE, $line->VDRUGSCODE, substr($line->IQTY, 1) ]);
                                        if (count($sql) == 0)
					                    {
						                    return response()->json(['error' => 'No Stock for ' . $line->VDRUGSCODE], 500);
					                    }
                                        $dexp = NULL;
                                        $iqty = 0;
                                        $arrnew = array();
                                        foreach ($sql as $key => $val)
                                        {
                                            // if ($val->ISSUE == 0)
                                            // {
                                            //     continue;
                                            // }
                                            // else {dd($val->ISSUE);}
                                            if (!isset($line->DEXPIRED))
                                            {
                                                if ($line->IQTY > $val->BALANCE)
                                                {
                                                    $iqty += $val->BALANCE;
                                                    $arrnew[] = ['qty' => $val->BALANCE, 'expired' => $val->DEXPIRED];
                                                }
                                                else
                                                {
                                                    $line->DEXPIRED = $val->DEXPIRED;
                                                    $dexp = $val->DEXPIRED;
                                                    $iqty = $line->IQTY;
                                                    break;
                                                }
                                            }
                                            else
                                            {
                                                if (substr($line->DEXPIRED, 0, 10) == $val->DEXPIRED)
                                                {
                                                    if ($line->IQTY > $val->BALANCE)
                                                    {
                                                        DB::rollBack();
                                                        return response()->json(['error' => 'Max Qty ' . $val->VDRUGSCODE . ' at Expired Date ' . date_format(DateTime::createFromFormat('Y-m-d', $val->DEXPIRED), "d-M-Y") . ' is ' . $val->BALANCE], 500);
                                                    }
                                                    else
                                                    {
                                                        $dexp = $val->DEXPIRED;
                                                        $iqty = $line->IQTY;

                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    
                                        if ($iqty < $line->IQTY)
                                        {
                                            DB::rollBack();
                                            return response()->json(['error' => 'Max Qty ' . $line->VDRUGSCODE . ' is ' . $iqty], 500);
                                        }
                                        if (substr($line->DEXPIRED, 0, 10) != $dexp)
                                        {
                                            DB::rollBack();
                                            return response()->json(['error' => 'No Expired Date at ' . date_format($line->DEXPIRED, "d-M-Y") . ' for ' . $line->VDRUGSCODE], 500);
                                        }
                                        if (count($arrnew) > 0)
                                        {
                                            foreach ($arrnew as $k => $v)
                                            {
                                                $lineno++;
                                                $addline = new Invmovedtls();
                                                $addline->VTRXNO = $inventory->VTRXNO;
                                                $addline->ILINENO = $lineno;
                                                $addline->VCREA = Session::get('id');
                                                $addline->DCREA = $now;
                                                $addline->VMODI = Session::get('id');
                                                $addline->VDRUGSCODE = $request->VDRUGSCODE[$x];
                                                $addline->DEXPIRED = $v['expired'];
                                                $addline->IQTY = $v['qty'] * -1;
                                                $addline->save();
                                                $addmovedtllog = new Invmovedtllogs();
                                                $addmovedtllog->VTRXNO = $addline->VTRXNO;
                                                $addmovedtllog->ILINENO = $addline->ILINENO;
                                                $addmovedtllog->VDRUGSCODE = $addline->VDRUGSCODE;
                                                $addmovedtllog->DEXPIRED = $addline->DEXPIRED;
                                                $addmovedtllog->IQTY = '-'.$addline->IQTY;
                                                $addmovedtllog->VUSER = Session::get('id');
                                                $addmovedtllog->save();
                                                $iqty -= $v['qty'];
                                            }
                                        }                        
                                        $line->IQTY = '-'.$iqty;
                                        $line->save();
                                        $movedtllog = new Invmovedtllogs();
                                        $movedtllog->VTRXNO = $line->VTRXNO;
                                        $movedtllog->ILINENO = $line->ILINENO;
                                        $movedtllog->VDRUGSCODE = $line->VDRUGSCODE;
                                        $movedtllog->DEXPIRED = $line->DEXPIRED;
                                        $movedtllog->IQTY = $line->IQTY;
                                        $movedtllog->VUSER = Session::get('id');
                                        $movedtllog->save();
                                        $NTOTAL = $price->NPRICE * $request->qtyS[$x];
                                        $checktreat = DB::select(DB::raw("SELECT MAX(ILINENO) AS countno FROM MEDSYS_TREATMENTS WHERE VBOOKINGNO = '" . $request->vbooking . "' ")) [0];

                                        DB::table('MEDSYS_TREATMENTS')->insert([
                                            'ILINENO' => $checktreat->countno + 1,
                                            'VBOOKINGNO' => $request->vbooking,
                                            'VDRUGSCODE' => $request->drugcode[$x],
                                            'VSCANNAME' => '',
                                            'VDOSAGE' => $request->dosaggeS[$x],
                                            'IQTY' => $request->qtyS[$x],
                                            'NPRICE' => $price->NPRICE,
                                            'NTOTALPRICE' => $NTOTAL,
                                            'VREMARKS' => $request->remarksS[$x],
                                            'VCREA' => Session::get('id') ,
                                            'VMODI' => '',
                                            'DCREA' => Carbon::now() ,
                                            'DMODI' => '',

                                        ]);

                                        // $rqno = DB::select("SELECT SUM(NLASTNO) NLASTNO FROM MEDSYS_MSTNOS WHERE VTRXCODE = 'TM' AND NYEAR = '" . $yy . "'")[0]->NLASTNO;
                                        // $VTRXNO = ClinicModel::find($VTRXNOW->VCLINICCODE)->VCLINICINIT . 'TM' . $yy . str_pad($rqno + 1, 4, '0', STR_PAD_LEFT);
                                        // if ($rqno == NULL)
                                        // {
                                        // 	DB::table('MEDSYS_MSTNOS')->insert([ 'NLASTNO' => '1', 'NYEAR' => $yy, 'NMONTH' => '0', 'NDATE' => '0', 'VTRXCODE' => 'TM', 'DCREA' => $now, 'VCREA' => Session::get('id') ]);
                                        // }
                                        // else
                                        // {
                                        // 	DB::table('MEDSYS_MSTNOS')->where('VTRXCODE', 'TM')->where('NYEAR', $yy)->update([ 'NLASTNO' => $rqno + 1, 'DMODI' => $now, 'VMODI' => Session::get('id') ]);
                                        // }


                                        $treatmentlogs = DB::select(DB::raw("SELECT COUNT(*) AS NO FROM MEDSYS_TREATMENTLOGS")) [0];
                                        DB::table('MEDSYS_TREATMENTLOGS')->insert(['VBOOKINGNO' => $request->vbooking, 'VDRUGSCODE' => $request->drugcode[$x], 'VSCANNAME' => '', 'VDOSAGE' => $request->dosaggeS[$x], 'IQTY' => $request->qtyS[$x], 'NPRICE' => $price->NPRICE, 'NTOTPRICE' => $NTOTAL, 'VREMARKS' => $request->remarksS[$x], 'VUSER' => Session::get('id') ,

                                        ]);
                                        $bills = DB::select(DB::raw("SELECT MAX(ILINENO) AS counts FROM MEDSYS_BILLS WHERE VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
                                        $books = DB::select(DB::raw("SELECT VMRNO FROM MEDSYS_SCHBOOKS WHERE VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
                                        $patient = DB::select(DB::raw("SELECT VTYPEPATIENT FROM MEDSYS_PATIENTS WHERE VMRNO = '" . $books->VMRNO . "' ")) [0];
                                        
                                        DB::table('MEDSYS_BILLS')->insert(['ILINENO' => $bills->counts + 1, 'VBOOKINGNO' => $request->vbookings[$x], 'VITEMCODE' => $request->drugcode[$x], 'VITEMNAME' => $price->VCONTAIN, 'IQTY' => $request->qtyS[$x], 'NPRICE' => $price->NPRICE, 'VTYPE' => $patient->VTYPEPATIENT, 'VREMARKS' => $request->remarksS[$x], 'VCREA' => Session::get('id') , 'VMODI' => '', 'DCREA' => Carbon::now() , 'DMODI' => '',

                                        ]);
                                        $movelog->VTRXNO = $inventory->VTRXNO;
                                        $movelog->save();
                                        DB::commit();
                                    }
                                    catch(\Exception $e)
                                    {
                                        DB::rollBack();
                                        if (!isset($e->errorInfo))
                                        {
                                            return response()
                                                ->json($e, 500);
                                        }
                                        else
                                        {
                                            return response()->json($e->errorInfo[2], 500);
                                        }
                                    }
                                   
                                };

                        //     }

                        // }

                    //}

                }
                $data = '#tabtreatment';
                return response()->json($data, 200);
            }
            else
            {

                for ($i = 0;$i < count($request->hasilbarcode1);$i++)
                {
                    DB::table('MEDSYS_TREATMENTS')->where('VBOOKINGNO', $request->vbookingnos[$i])->where('ILINENO', $request->ilinenos[$i])->update(['VSCANNAME' => $request->hasilbarcode1[$i], ]);

                }

                $data = '#tabtreatment';
                return response()->json($data, 200);

            }

        }
        public function patientbooking(Request $request)
        {

            DB::table('MEDSYS_SCHBOOKS')->where('VBOOKINGNO', $request->vbooking)
                ->update([

            'DMODI' => Carbon::now() , 'VMODI' => Session::get('id') , 'VOTHDRID' => $request->ALTERNATIVES, 'VDRID' => $request->DOCTR, ]);
            return response()
                ->json(200);
        }

        public function print_treatment($id)
        {

            $decrypt = Crypt::decryptString($id);
            $nbooking = base64_decode($decrypt);

            $treatment = DB::select("SELECT b.VCONTAIN FROM MEDSYS_TREATMENTS a JOIN MEDSYS_MSTDRUGS b ON a.VDRUGSCODE = b.VDRUGSCODE WHERE a.VBOOKINGNO = '" . $nbooking . "' ");
            $drugs = DB::select(DB::raw("SELECT b.VNAME,a.DVISIT FROM MEDSYS_SCHBOOKS a JOIN MEDSYS_MSTCLINICSTAFFS b ON a.VDRID = b.VUSRID WHERE a.VBOOKINGNO = '" . $nbooking . "' ")) [0];
            $patient = DB::select(DB::raw("SELECT MEDSYS_PATIENTS.VNAME,MEDSYS_PATIENTS.VMRNO, MEDSYS_PATIENTS.VPICRELATION,MEDSYS_PATIENTS.VPICPROVCODE,MEDSYS_PATIENTS.VPICSUBDISTRICTCODE,MEDSYS_PATIENTS.VPICDISTRICTCODE,MEDSYS_PATIENTS.VPICNAME,MEDSYS_PATIENTS.VPICIDCARDNO,MEDSYS_PATIENTS.VPICADDRESS,MEDSYS_PATIENTS.VPICPOSTALCODE,
      MEDSYS_PATIENTS.VINSCODE,MEDSYS_PATIENTS.VINSNO,MEDSYS_PATIENTS.VBPJSNO AS BPJS,MEDSYS_PATIENTS.VPROFESSION AS profesi,MEDSYS_PATIENTS.VBLOODTYPE AS VBLOODTYPE,MEDSYS_PATIENTS.VSUBDISTRICTCODE AS VSUBDISTRICTCODES,MEDSYS_PATIENTS.VDISTRICTCODE AS VDISTRICTCODES,MEDSYS_PATIENTS.VPROVCODE AS VPROVCODE,MEDSYS_PATIENTS.VGNDRCODE AS gender,
      MEDSYS_PATIENTS.VMARITALSTS,MEDSYS_PATIENTS.VPHONENO,MEDSYS_PATIENTS.VSAPID,MEDSYS_PATIENTS.VIDCARDNO AS idcard,MEDSYS_PATIENTS.VADDRESS,MEDSYS_PATIENTS.VTYPEPATIENT,MEDSYS_PATIENTS.VPOSTALCODE, MEDSYS_SCHBOOKS.VPHONENO AS nohp, FORMAT (MEDSYS_SCHBOOKS.DBIRTH, 'MM/dd/yyyy') DBIRTHS, FORMAT (MEDSYS_SCHBOOKS.DCREA, 'MM/dd/yyyy') DCREAS,MEDSYS_MSTCLINICSTAFFS.VNAME AS NAMADOCTOR, MEDSYS_SCHBOOKS.*
      FROM MEDSYS_SCHBOOKS LEFT JOIN MEDSYS_MSTCLINICSTAFFS ON MEDSYS_MSTCLINICSTAFFS.VUSRID = MEDSYS_SCHBOOKS.VDRID
      LEFT JOIN MEDSYS_PATIENTS ON MEDSYS_PATIENTS.VMRNO = MEDSYS_SCHBOOKS.VMRNO
      WHERE MEDSYS_SCHBOOKS.VBOOKINGNO = '" . $nbooking . "'")) [0];
            $y = DateTime::createFromFormat('d/m/Y', $patient->DBIRTHS)
                ->diff(new DateTime('now'))->y;
            $m = DateTime::createFromFormat('d/m/Y', $patient->DBIRTHS)
                ->diff(new DateTime('now'))->m;
            $d = DateTime::createFromFormat('d/m/Y', $patient->DBIRTHS)
                ->diff(new DateTime('now'))->d;
            $age = $y . ' Year ' . $m . ' Month ' . $d . ' Day ';
            $pdf = PDF::loadview('Pdf/treatment', ['treatment' => $treatment, 'age' => $age], compact('drugs', 'patient'));
            return $pdf->stream('treatment_' . $nbooking . '_' . carbon::parse(Carbon::now())->format('Y/m/d') . '.pdf');

        }

        public function UpdateTreatment(Request $request)
        {

            if($request->VDRUGSCODE_OLDS == $request->VDRUGSCODES){
                $price = DB::select(DB::raw("SELECT NPRICE,VCONTAIN FROM MEDSYS_MSTDRUGS WHERE VDRUGSCODE = '" . $request->VDRUGSCODES . "' ")) [0];
                $NTOTAL = $price->NPRICE * $request->QTY;
                $dbf = DB::select(DB::raw("SELECT VCLINICCODE FROM MEDSYS_SCHBOOKS  WHERE  VBOOKINGNO = '" . $request->vbooking . "'  ")) [0];
                $ASOFDATE = date("Y-m-d");
                $now = carbon::now();
                $VCLINICCODE = $dbf->VCLINICCODE;
                $VTRXNO =str_replace('B', 'T', $request->vbooking);
                $lineno = 1;
                $line = Invmovedtls::where([['VTRXNO','=',$VTRXNO],['VDRUGSCODE','=',$request->VDRUGSCODE_OLDS]])->first();
                //$line->VTRXNO = $VTRXNO;
                //$line->ILINENO = $request->ILINENOS;
                $line->VCREA = Session::get('id');
                $line->DCREA = $now;
                $line->VMODI = Session::get('id');
                $line->VDRUGSCODE = $request->VDRUGSCODES;
                $line->IQTY = $request->QTY;
                $sql = DB::select("EXEC sp_IssueStock ?, ?, ?", [$VCLINICCODE, $line->VDRUGSCODE, substr($line->IQTY, 1) ]);
                    if (count($sql) == 0)
                    {
                        return response()->json(['error' => 'No Stock for ' . $line->VDRUGSCODE], 500);
                    }
                    $dexp = NULL;
                    $iqty = 0;
                    $arrnew = array();
                    foreach ($sql as $key => $val)
                    {
                        if (!isset($line->DEXPIREDS))
                        {
                            if ($line->IQTY > $val->BALANCE)
                            {

                                $iqty += $val->BALANCE;
                                $arrnew[] = ['qty' => $val->BALANCE, 'expired' => $val->DEXPIRED];
                            }
                            else
                            {
                                $line->DEXPIRED = $val->DEXPIRED;
                                $dexp = $val->DEXPIRED;
                                $iqty = $line->IQTY;
                                break;
                            }
                        }
                        else
                        {
                            if (substr($line->DEXPIRED, 0, 10) == $val->DEXPIRED)
                            {
                                if ($line->IQTY > $val->BALANCE)
                                {
                                    return response()->json(['error' => 'Max Qty ' . $val->VDRUGSCODE . ' at Expired Date ' . date_format(DateTime::createFromFormat('Y-m-d', $val->DEXPIRED), "d-M-Y") . ' is ' . $val->BALANCE], 500);
                                }
                                else
                                {
                                    $dexp = $val->DEXPIRED;
                                    $iqty = $line->IQTY;
                                    break;
                                }
                            }
                        }
                    }
                    if ($iqty < $line->IQTY)
                    {
                        return response()->json(['error' => 'Max Qty ' . $line->VDRUGSCODE . ' is ' . $iqty], 500);
                    }
                    if (substr($line->DEXPIRED, 0, 10) != $dexp)
                    {
                        return response()->json(['error' => 'No Expired Date at ' . date_format($line->DEXPIRED, "d-M-Y") . ' for ' . $line->VDRUGSCODE], 500);
                    }
                    if (count($arrnew) > 0)
                    {
                        foreach ($arrnew as $k => $v)
                        {
                            $lineno++;
                            $addline = Invmovedtls::where([['VTRXNO','=',$VTRXNO],['VDRUGSCODE','=',$request->VDRUGSCODE_OLDS]])->first();
                            $addline->VTRXNO = $VTRXNO;
                            $addline->ILINENO = $lineno;
                            $addline->VCREA = Session::get('id');
                            $addline->DCREA = $now;
                            $addline->VMODI = Session::get('id');
                            $addline->VDRUGSCODE = $request->VDRUGSCODE;
                            $addline->DEXPIRED = $v['expired'];
                            $addline->IQTY = $v['qty'] * -1;
                            $addline->save();
                            $addmovedtllog = new Invmovedtllogs();
                            $addmovedtllog->VTRXNO = $addline->VTRXNO;
                            $addmovedtllog->ILINENO = $addline->ILINENO;
                            $addmovedtllog->VDRUGSCODE = $addline->VDRUGSCODE;
                            $addmovedtllog->DEXPIRED = $addline->DEXPIRED;
                            $addmovedtllog->IQTY = $addline->IQTY;
                            $addmovedtllog->VUSER = Session::get('id');
                             $addmovedtllog->save();
                            $iqty -= $v['qty'];
                         }

                             $line->IQTY = '-'.$iqty;
                             $line->save();
                             $movedtllog = new Invmovedtllogs();
                             $movedtllog->VTRXNO = $line->VTRXNO;
                             $movedtllog->ILINENO = $line->ILINENO;
                             $movedtllog->VDRUGSCODE = $line->VDRUGSCODE;
                              $movedtllog->DEXPIRED = $line->DEXPIRED;
                             $movedtllog->IQTY = $line->IQTY;
                             $movedtllog->VUSER = Session::get('id');
                             $movedtllog->save();
                             $lineno++;

                    }
                                    DB::table('MEDSYS_TREATMENTS')->where('VBOOKINGNO', $request->vbooking)->where('VDRUGSCODE', $request->VDRUGSCODE_OLDS)
                                    ->update([

                                        'VDRUGSCODE' => $request->VDRUGSCODES, 'VDOSAGE' => $request->VDOSAGE, 'IQTY' => $line->IQTY, 'NPRICE' => $price->NPRICE, 'NTOTALPRICE' => $NTOTAL, 'VREMARKS' => $request->VREMARKS, 'VMODI' => Session::get('id') , 'DMODI' => Carbon::now()
                                    ]);
                                    $treatmentlogs = DB::select(DB::raw("SELECT COUNT(*) AS NO FROM MEDSYS_TREATMENTLOGS")) [0];
                                    DB::table('MEDSYS_TREATMENTLOGS')->insert(['VBOOKINGNO' => $request->vbooking, 'VDRUGSCODE' => $request->ILINENOS, 'VSCANNAME' => '', 'VDOSAGE' => $request->VDOSAGE, 'IQTY' => $line->IQTY, 'NPRICE' => $price->NPRICE, 'NTOTPRICE' => $NTOTAL, 'VREMARKS' => $request->VREMARKS, 'VUSER' => Session::get('id')
                                    ]);

                                    DB::table('MEDSYS_BILLS')
                                    ->where('VBOOKINGNO', $request->vbooking)
                                    ->where('VITEMCODE', $request->VDRUGSCODE_OLDS)
                                    ->update([

                                        'VITEMCODE' => $request->VDRUGSCODES, 'IQTY' => $line->IQTY, 'VREMARKS' => $request->VREMARKS, 'VMODI' => Session::get('id') , 'DMODI' => Carbon::now() , 'NPRICE' => $price->NPRICE, 'VITEMNAME' => $price->VCONTAIN,

                                    ]);

                $data = '#tabtreatment';
                return response()->json($data, 200);

            }else{
                $price = DB::select(DB::raw("SELECT NPRICE,VCONTAIN FROM MEDSYS_MSTDRUGS WHERE VDRUGSCODE = '" . $request->VDRUGSCODES . "' ")) [0];
                $NTOTAL = $price->NPRICE * $request->QTY;
                $check = DB::select(DB::raw("SELECT COUNT(*) AS nos FROM MEDSYS_TREATMENTS WHERE VDRUGSCODE = '" . $request->VDRUGSCODES . "' AND VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
                if ($check->nos === '1')
                {
                    $check = DB::select(DB::raw("SELECT NPRICE,VCONTAIN,VDRUGSCODE FROM MEDSYS_MSTDRUGS WHERE VDRUGSCODE = '" . $request->VDRUGSCODES . "' ")) [0];
    
                    $name = $check->VCONTAIN;
                    $error['error'] = 'Drugs by the same brand can only be added once.';
                    return response()->json($error, 400);
                }
                else
                {
                    $dbf = DB::select(DB::raw("SELECT VCLINICCODE FROM MEDSYS_SCHBOOKS  WHERE  VBOOKINGNO = '" . $request->vbooking . "'  ")) [0];
                    $ASOFDATE = date("Y-m-d");
                    $now = carbon::now();
                    $VCLINICCODE = $dbf->VCLINICCODE;
                    $VTRXNO =str_replace('B', 'T', $request->vbooking);
                    $lineno = 1;
                    $line = Invmovedtls::where([['VTRXNO','=',$VTRXNO],['VDRUGSCODE','=',$request->VDRUGSCODE_OLDS]])->first();
                    //$line->VTRXNO = $VTRXNO;
                    //$line->ILINENO = $request->ILINENOS;
                    $line->VCREA = Session::get('id');
                    $line->DCREA = $now;
                    $line->VMODI = Session::get('id');
                    $line->VDRUGSCODE = $request->VDRUGSCODES;
                    $line->IQTY = $request->QTY;
                    $sql = DB::select("EXEC sp_IssueStock ?, ?, ?", [$VCLINICCODE, $line->VDRUGSCODE, substr($line->IQTY, 1) ]);
                        if (count($sql) == 0)
                        {
                            return response()->json(['error' => 'No Stock for ' . $line->VDRUGSCODE], 500);
                        }
                        $dexp = NULL;
                        $iqty = 0;
                        $arrnew = array();
                        foreach ($sql as $key => $val)
                        {
                            if (!isset($line->DEXPIREDS))
                            {
                                if ($line->IQTY > $val->BALANCE)
                                {
    
                                    $iqty += $val->BALANCE;
                                    $arrnew[] = ['qty' => $val->BALANCE, 'expired' => $val->DEXPIRED];
                                }
                                else
                                {
                                    $line->DEXPIRED = $val->DEXPIRED;
                                    $dexp = $val->DEXPIRED;
                                    $iqty = $line->IQTY;
                                    break;
                                }
                            }
                            else
                            {
                                if (substr($line->DEXPIRED, 0, 10) == $val->DEXPIRED)
                                {
                                    if ($line->IQTY > $val->BALANCE)
                                    {
                                        return response()->json(['error' => 'Max Qty ' . $val->VDRUGSCODE . ' at Expired Date ' . date_format(DateTime::createFromFormat('Y-m-d', $val->DEXPIRED), "d-M-Y") . ' is ' . $val->BALANCE], 500);
                                    }
                                    else
                                    {
                                        $dexp = $val->DEXPIRED;
                                        $iqty = $line->IQTY;
                                        break;
                                    }
                                }
                            }
                        }
                        if ($iqty < $line->IQTY)
                        {
                            return response()->json(['error' => 'Max Qty ' . $line->VDRUGSCODE . ' is ' . $iqty], 500);
                        }
                        if (substr($line->DEXPIRED, 0, 10) != $dexp)
                        {
                            return response()->json(['error' => 'No Expired Date at ' . date_format($line->DEXPIRED, "d-M-Y") . ' for ' . $line->VDRUGSCODE], 500);
                        }
                        if (count($arrnew) > 0)
                        {
                            foreach ($arrnew as $k => $v)
                            {
                                $lineno++;
                                $addline = Invmovedtls::where([['VTRXNO','=',$VTRXNO],['VDRUGSCODE','=',$request->VDRUGSCODE_OLDS]])->first();
                                $addline->VTRXNO = $VTRXNO;
                                $addline->ILINENO = $lineno;
                                $addline->VCREA = Session::get('id');
                                $addline->DCREA = $now;
                                $addline->VMODI = Session::get('id');
                                $addline->VDRUGSCODE = $request->VDRUGSCODE;
                                $addline->DEXPIRED = $v['expired'];
                                $addline->IQTY = $v['qty'] * -1;
                                $addline->save();
                                $addmovedtllog = new Invmovedtllogs();
                                $addmovedtllog->VTRXNO = $addline->VTRXNO;
                                $addmovedtllog->ILINENO = $addline->ILINENO;
                                $addmovedtllog->VDRUGSCODE = $addline->VDRUGSCODE;
                                $addmovedtllog->DEXPIRED = $addline->DEXPIRED;
                                $addmovedtllog->IQTY = $addline->IQTY;
                                $addmovedtllog->VUSER = Session::get('id');
                                 $addmovedtllog->save();
                                $iqty -= $v['qty'];
                             }
    
                                 $line->IQTY = '-'.$iqty;
                                 $line->save();
                                 $movedtllog = new Invmovedtllogs();
                                 $movedtllog->VTRXNO = $line->VTRXNO;
                                 $movedtllog->ILINENO = $line->ILINENO;
                                 $movedtllog->VDRUGSCODE = $line->VDRUGSCODE;
                                  $movedtllog->DEXPIRED = $line->DEXPIRED;
                                 $movedtllog->IQTY = $line->IQTY;
                                 $movedtllog->VUSER = Session::get('id');
                                 $movedtllog->save();
                                 $lineno++;
    
                        }
                                        DB::table('MEDSYS_TREATMENTS')->where('VBOOKINGNO', $request->vbooking)->where('VDRUGSCODE', $request->VDRUGSCODE_OLDS)
                                        ->update([
    
                                            'VDRUGSCODE' => $request->VDRUGSCODES, 'VDOSAGE' => $request->VDOSAGE, 'IQTY' => $line->IQTY, 'NPRICE' => $price->NPRICE, 'NTOTALPRICE' => $NTOTAL, 'VREMARKS' => $request->VREMARKS, 'VMODI' => Session::get('id') , 'DMODI' => Carbon::now()
                                        ]);
                                        $treatmentlogs = DB::select(DB::raw("SELECT COUNT(*) AS NO FROM MEDSYS_TREATMENTLOGS")) [0];
                                        DB::table('MEDSYS_TREATMENTLOGS')->insert(['VBOOKINGNO' => $request->vbooking, 'VDRUGSCODE' => $request->ILINENOS, 'VSCANNAME' => '', 'VDOSAGE' => $request->VDOSAGE, 'IQTY' => $line->IQTY, 'NPRICE' => $price->NPRICE, 'NTOTPRICE' => $NTOTAL, 'VREMARKS' => $request->VREMARKS, 'VUSER' => Session::get('id')
                                        ]);
    
                                        DB::table('MEDSYS_BILLS')
                                        ->where('VBOOKINGNO', $request->vbooking)
                                        ->where('VITEMCODE', $request->VDRUGSCODE_OLDS)
                                        ->update([
    
                                            'VITEMCODE' => $request->VDRUGSCODES, 'IQTY' => $line->IQTY, 'VREMARKS' => $request->VREMARKS, 'VMODI' => Session::get('id') , 'DMODI' => Carbon::now() , 'NPRICE' => $price->NPRICE, 'VITEMNAME' => $price->VCONTAIN,
    
                                        ]);
    
                    $data = '#tabtreatment';
                    return response()->json($data, 200);
                }


            }
   

        }


        public function DeleteTreatment($id)
        {

            $ida = base64_decode($id);
            list($x, $y) = explode(",", $ida);
            
            $r = str_replace('B', 'T', $x);
            $checkclinic = DB::select(DB::raw("SELECT VCLINICCODE FROM MEDSYS_SCHBOOKS where VBOOKINGNO = '" . $x . "'")) [0];
            DB::table('MEDSYS_TREATMENTS')->where('VBOOKINGNO', $x)->where('VDRUGSCODE', $y)->delete();
            DB::table('MEDSYS_BILLS')->where('VBOOKINGNO', $x)->where('VITEMCODE', $y)->delete();
            DB::table('MEDSYS_INVMOVEDTLS')->where('VTRXNO', $r)->where('VDRUGSCODE', $y)->delete();
            
            // delete hdrs when dtls == 0
            $checkdhrs =  DB::table('MEDSYS_INVMOVEDTLS')->where('VTRXNO', $r)->where('VDRUGSCODE', $y)->get();

            if(count($checkdhrs) == 0){
            
            
                DB::table('MEDSYS_INVMOVEHDRS')->where('VTRXNO', $r)->where('VCLINICCODE', $checkclinic->VCLINICCODE)->delete();

            }

            //   DB::table('MEDSYS_INVMOVEDTLS')->where('VTRXNO', $x)->where('ILINENO', $y)->delete();
            $data = '#tabtreatment';
            return response()->json($data, 200);

        }
        public function scanbarcode($id)
        {

            $ida = base64_decode($id);
            list($x, $y, $z) = explode(",", $ida);
            $treatment = DB::select(DB::raw("SELECT COUNT(*) as countas FROM MEDSYS_TREATMENTS WHERE VBOOKINGNO = '" . $y . "' AND ILINENO = '" . $x . "' AND VDRUGSCODE = '" . $z . "'")) [0];
            if ($treatment->countas === '0')
            {

                return response()
                    ->json('', 400);

            }
            else
            {
                // DB::table('MEDSYS_TREATMENTS')->where('VBOOKINGNO', $y)->where('ILINENO',$x)->update([
                //    'VSCANNAME' => $z,
                // ]);
                $mstdrug = DB::select(DB::raw("SELECT VDRUGSCODE,VCONTAIN FROM MEDSYS_MSTDRUGS WHERE  VDRUGSCODE = '" . $z . "'")) [0];

                $row['VCONTAIN'] = $mstdrug->VCONTAIN;
                $row['VDRUGSCODE'] = $mstdrug->VDRUGSCODE;

                return response()
                    ->json($row, 200);

            }
        }

        public function updateExamination(Request $request)
        {
            if($request->VDRUGSCODE_OLD == $request->VDRUGSCODE){
                $now = carbon::now();
                $checkclinic = DB::select(DB::raw("SELECT VCLINICCODE FROM MEDSYS_SCHBOOKS where VBOOKINGNO = '" . $request->VBOOKINGNO . "'")) [0];
                $examination = DB::select(DB::raw("SELECT COUNT(*)  AS nos FROM MEDSYS_EXAMINATIONDTLS  WHERE VBOOKINGNO = '" . $request->VBOOKINGNO . "' ")) [0];
                $VTRXNO =str_replace('B', 'E', $request->VBOOKINGNO);
                $lineno = 1;
                $line = Invmovedtls::where([['VTRXNO','=',$VTRXNO],['VDRUGSCODE','=',$request->VDRUGSCODE]])->first();
                //$line->VTRXNO = $VTRXNO;
	            //$line->ILINENO = $request->ILINENO;
	            $line->VCREA = Session::get('id');
	            $line->DMODI = $now;
	            $line->VMODI = Session::get('id');
	            $line->VDRUGSCODE = $request->VDRUGSCODE;
                $line->IQTY = $request->IQYT;
                $sql = DB::select("EXEC sp_IssueStock ?, ?, ?", [$checkclinic->VCLINICCODE, $line->VDRUGSCODE, substr($line->IQTY, 1) ]);
                if (count($sql) == 0)
                {
                    return response()->json(['error' => 'No Stock for ' . $line->VDRUGSCODE], 500);
                }
                $dexp = NULL;
                $iqty = 0;
                $arrnew = array();
                foreach ($sql as $key => $val)
                {
                    if (!isset($line->DEXPIREDS))
                    {
                        if ($line->IQTY > $val->BALANCE)
                        {

                            $iqty += $val->BALANCE;
                            $arrnew[] = ['qty' => $val->BALANCE, 'expired' => $val->DEXPIRED];
                        }
                        else
                        {
                            $line->DEXPIRED = $val->DEXPIRED;
                            $dexp = $val->DEXPIRED;
                            $iqty = $line->IQTY;
                            break;
                        }
                    }
                    else
                    {
                        if (substr($line->DEXPIRED, 0, 10) == $val->DEXPIRED)
                        {
                            if ($line->IQTY > $val->BALANCE)
                            {
                                return response()->json(['error' => 'Max Qty ' . $val->VDRUGSCODE . ' at Expired Date ' . date_format(DateTime::createFromFormat('Y-m-d', $val->DEXPIRED), "d-M-Y") . ' is ' . $val->BALANCE], 500);
                            }
                            else
                            {
                                $dexp = $val->DEXPIRED;
                                $iqty = $line->IQTY;
                                break;
                            }
                        }
                    }
                }
                if ($iqty < $line->IQTY)
                {
                    return response()->json(['error' => 'Max Qty ' . $line->VDRUGSCODE . ' is ' . $iqty], 500);
                }
                if (substr($line->DEXPIRED, 0, 10) != $dexp)
                {
                    return response()->json(['error' => 'No Expired Date at ' . date_format($line->DEXPIRED, "d-M-Y") . ' for ' . $line->VDRUGSCODE], 500);
                }
                if (count($arrnew) > 0)
                {
                    foreach ($arrnew as $k => $v)
                    {
                        $lineno++;
                        $addline = Invmovedtls::where([['VTRXNO','=',$VTRXNO],['VITEMCODE','=',$request->VDRUGSCODE]])->first();
                        $addline->VTRXNO = $VTRXNO;
                        $addline->ILINENO = $lineno;
                        $addline->DMODI = $now;
                        $addline->VMODI = Session::get('id');
                        $addline->VDRUGSCODE = $request->VDRUGSCODE;
                        $addline->DEXPIRED = $v['expired'];
                        $addline->IQTY = $v['qty'] * -1;
                        $addline->save();
                        $addmovedtllog = new Invmovedtllogs();
                        $addmovedtllog->VTRXNO = $addline->VTRXNO;
                        $addmovedtllog->ILINENO = $addline->ILINENO;
                        $addmovedtllog->VDRUGSCODE = $addline->VDRUGSCODE;
                        $addmovedtllog->DEXPIRED = $addline->DEXPIRED;
                        $addmovedtllog->IQTY = '-'.$addline->IQTY;
                        $addmovedtllog->VUSER = Session::get('id');
                         $addmovedtllog->save();
                        $iqty -= $v['qty'];
                     }

                         $line->IQTY = '-'.$iqty;
                         $line->save();
                         $movedtllog = new Invmovedtllogs();
                         $movedtllog->VTRXNO = $line->VTRXNO;
                         $movedtllog->ILINENO = $line->ILINENO;
                         $movedtllog->VDRUGSCODE = $line->VDRUGSCODE;
                          $movedtllog->DEXPIRED = $line->DEXPIRED;
                         $movedtllog->IQTY = $line->IQTY;
                         $movedtllog->VUSER = Session::get('id');
                         $movedtllog->save();
                         $lineno++;

                }
                DB::table('MEDSYS_EXAMINATIONDTLS')
                ->where('VBOOKINGNO', $request->VBOOKINGNO)->where('VITEMCODE', $request->VDRUGSCODE_OLD)
                ->update(['ILINENO' => $request->ILINENO, 'VITEMCODE' => $request->VDRUGSCODE, 'IQTY' => $request->IQYT, 'VMODI' => Session::get('id') , 'DMODI' => Carbon::now() , ]);

            $logsexaminationdtls = DB::select(DB::raw("SELECT COUNT(*) AS nos FROM MEDSYS_EXAMINATIONDTLLOGS  WHERE VBOOKINGNO = '" . $request->VBOOKINGNO . "' ")) [0];
            $examindtlslogs = new MEDSYS_EXAMINATIONDTLLOGS;
            $examindtlslogs->ILINENO = $logsexaminationdtls->nos + 1;
            $examindtlslogs->VBOOKINGNO = $request->VBOOKINGNO;
            $examindtlslogs->VITEMCODE = $request->VDRUGSCODE;
            $examindtlslogs->IQTY = $request->IQYT;
            $examindtlslogs->VUSER = Session::get('id');
            $examindtlslogs->save();

            $data = '#tabexamination';
            return response()->json($data, 200);
            }else{
                $price = DB::select(DB::raw("SELECT NPRICE,VCONTAIN FROM MEDSYS_MSTDRUGS WHERE VDRUGSCODE = '" . $request->VDRUGSCODE . "' ")) [0];
                $NTOTAL = $price->NPRICE * $request->IQYT;
                $check = DB::select(DB::raw("SELECT COUNT(*) AS nos FROM MEDSYS_TREATMENTS WHERE VDRUGSCODE = '" . $request->VDRUGSCODE . "' AND VBOOKINGNO = '" . $request->VBOOKINGNO . "' ")) [0];
                if ($check->nos === '1')
                {
                    $check = DB::select(DB::raw("SELECT NPRICE,VCONTAIN,VDRUGSCODE FROM MEDSYS_MSTDRUGS WHERE VDRUGSCODE = '" . $request->VDRUGSCODE . "' ")) [0];
    
                    $name = $check->VCONTAIN;
                    $error['error'] = 'Drugs by the same brand can only be added once.';
                    return response()->json($error, 400);
                }
                else
                {
                    $now = carbon::now();
                    $checkclinic = DB::select(DB::raw("SELECT VCLINICCODE FROM MEDSYS_SCHBOOKS where VBOOKINGNO = '" . $request->VBOOKINGNO . "'")) [0];
                    $examination = DB::select(DB::raw("SELECT COUNT(*)  AS nos FROM MEDSYS_EXAMINATIONDTLS  WHERE VBOOKINGNO = '" . $request->VBOOKINGNO . "' ")) [0];
                    $VTRXNO =str_replace('B', 'E', $request->VBOOKINGNO);
                    $lineno = 1;
                    $line = Invmovedtls::where([['VTRXNO','=',$VTRXNO],['VDRUGSCODE','=',$request->VDRUGSCODE_OLD]])->first();
                    $line->VTRXNO = $VTRXNO;
                    //$line->ILINENO = $request->ILINENO;
                    $line->VCREA = Session::get('id');
                    $line->DMODI = $now;
                    $line->VMODI = Session::get('id');
                    $line->VDRUGSCODE = $request->VDRUGSCODE;
                    $line->IQTY = $request->IQYT;
                    $sql = DB::select("EXEC sp_IssueStock ?, ?, ?", [$checkclinic->VCLINICCODE, $line->VDRUGSCODE, substr($line->IQTY, 1) ]);
                    if (count($sql) == 0)
                    {
                        return response()->json(['error' => 'No Stock for ' . $line->VDRUGSCODE], 500);
                    }
                    $dexp = NULL;
                    $iqty = 0;
                    $arrnew = array();
                    foreach ($sql as $key => $val)
                    {
                        if (!isset($line->DEXPIREDS))
                        {
                            if ($line->IQTY > $val->BALANCE)
                            {
    
                                $iqty += $val->BALANCE;
                                $arrnew[] = ['qty' => $val->BALANCE, 'expired' => $val->DEXPIRED];
                            }
                            else
                            {
                                $line->DEXPIRED = $val->DEXPIRED;
                                $dexp = $val->DEXPIRED;
                                $iqty = $line->IQTY;
                                break;
                            }
                        }
                        else
                        {
                            if (substr($line->DEXPIRED, 0, 10) == $val->DEXPIRED)
                            {
                                if ($line->IQTY > $val->BALANCE)
                                {
                                    return response()->json(['error' => 'Max Qty ' . $val->VDRUGSCODE . ' at Expired Date ' . date_format(DateTime::createFromFormat('Y-m-d', $val->DEXPIRED), "d-M-Y") . ' is ' . $val->BALANCE], 500);
                                }
                                else
                                {
                                    $dexp = $val->DEXPIRED;
                                    $iqty = $line->IQTY;
                                    break;
                                }
                            }
                        }
                    }
                    if ($iqty < $line->IQTY)
                    {
                        return response()->json(['error' => 'Max Qty ' . $line->VDRUGSCODE . ' is ' . $iqty], 500);
                    }
                    if (substr($line->DEXPIRED, 0, 10) != $dexp)
                    {
                        return response()->json(['error' => 'No Expired Date at ' . date_format($line->DEXPIRED, "d-M-Y") . ' for ' . $line->VDRUGSCODE], 500);
                    }
                    if (count($arrnew) > 0)
                    {
                        foreach ($arrnew as $k => $v)
                        {
                            $lineno++;
                            $addline = Invmovedtls::where([['VTRXNO','=',$VTRXNO],['VITEMCODE','=',$request->VDRUGSCODE_OLD]])->first();
                            $addline->VTRXNO = $VTRXNO;
                            $addline->ILINENO = $lineno;
                            $addline->DMODI = $now;
                            $addline->VMODI = Session::get('id');
                            $addline->VDRUGSCODE = $request->VDRUGSCODE;
                            $addline->DEXPIRED = $v['expired'];
                            $addline->IQTY = $v['qty'] * -1;
                            $addline->save();
                            $addmovedtllog = new Invmovedtllogs();
                            $addmovedtllog->VTRXNO = $addline->VTRXNO;
                            $addmovedtllog->ILINENO = $addline->ILINENO;
                            $addmovedtllog->VDRUGSCODE = $addline->VDRUGSCODE;
                            $addmovedtllog->DEXPIRED = $addline->DEXPIRED;
                            $addmovedtllog->IQTY = $addline->IQTY;
                            $addmovedtllog->VUSER = Session::get('id');
                             $addmovedtllog->save();
                            $iqty -= $v['qty'];
                         }
    
                             $line->IQTY = '-'.$iqty;
                             $line->save();
                             $movedtllog = new Invmovedtllogs();
                             $movedtllog->VTRXNO = $line->VTRXNO;
                             $movedtllog->ILINENO = $line->ILINENO;
                             $movedtllog->VDRUGSCODE = $line->VDRUGSCODE;
                              $movedtllog->DEXPIRED = $line->DEXPIRED;
                             $movedtllog->IQTY = $line->IQTY;
                             $movedtllog->VUSER = Session::get('id');
                             $movedtllog->save();
                             $lineno++;
    
                    }
                    DB::table('MEDSYS_EXAMINATIONDTLS')
                    ->where('VBOOKINGNO', $request->VBOOKINGNO)->where('VITEMCODE', $request->VDRUGSCODE_OLD)
                    ->update(['ILINENO' => $request->ILINENO, 'VITEMCODE' => $request->VDRUGSCODE, 'IQTY' => $request->IQYT, 'VMODI' => Session::get('id') , 'DMODI' => Carbon::now() , ]);
    
                $logsexaminationdtls = DB::select(DB::raw("SELECT COUNT(*) AS nos FROM MEDSYS_EXAMINATIONDTLLOGS  WHERE VBOOKINGNO = '" . $request->vbooking . "' ")) [0];
                $examindtlslogs = new MEDSYS_EXAMINATIONDTLLOGS;
                $examindtlslogs->ILINENO = $logsexaminationdtls->nos + 1;
                $examindtlslogs->VBOOKINGNO = $request->VBOOKINGNO;
                $examindtlslogs->VITEMCODE = $request->VDRUGSCODE;
                $examindtlslogs->IQTY = $request->IQYT;
                $examindtlslogs->VUSER = Session::get('id');
                $examindtlslogs->save();
    
                $data = '#tabexamination';
                return response()->json($data, 200);

                }

            }
                

        }

        public function DeleteExamination($id)
        {

            $ida = base64_decode($id);
            list($x, $y) = explode(",", $ida);
            $r = str_replace('B', 'E', $x);
            $checkclinic = DB::select(DB::raw("SELECT VCLINICCODE FROM MEDSYS_SCHBOOKS where VBOOKINGNO = '" . $x . "'")) [0];
            DB::table('MEDSYS_EXAMINATIONDTLS')->where('VBOOKINGNO', $x)->where('VITEMCODE', $y)->delete();
            DB::table('MEDSYS_BILLS')
                ->where('VBOOKINGNO', $x)->where('VITEMCODE', $y)->delete();
            DB::table('MEDSYS_INVMOVEDTLS')->where('VTRXNO', $r)->where('VDRUGSCODE', $y)->delete();
            $checkdhrs =  DB::table('MEDSYS_INVMOVEDTLS')->where('VTRXNO', $r)->where('VDRUGSCODE', $y)->get();

            if(count($checkdhrs) == 0){
            
            
                DB::table('MEDSYS_INVMOVEHDRS')->where('VTRXNO', $r)->where('VCLINICCODE', $checkclinic->VCLINICCODE)->delete();

            }

            $data = '#tabexamination';
            return response()->json($data, 200);

        }
        // Upload document in Examination
        public function UploadDocumentExamination(Request $request)
        {

            $is_update = false;
            if ($request->VID != '')
            {

                $is_update = true;
                $doc = Doclists::find($request->VID);
                $old_file = $doc->VDOCFILENAME;
                $doc->DMODI = Carbon::now();
            }
            else
            {

                $doc = new Doclists();
                $doc->VDOCID = 'MEDSYS_MSTPATIENTS/' . $request->VBOOKINGNO;
                $doc->VCREA = Session::get('id');
            }

            //  Auto Generate
            $datenow = carbon::now();
            $years = $datenow->format('Y');
            $month = $datenow->format('m');
            $dd = $datenow->format('d');

            $stringm = substr($month, 0, 2);
            $stringds = substr($years, 2);
            $countjax = DB::select(DB::raw("SELECT  SUM(NLASTNO) AS NLASTNO FROM MEDSYS_MSTNOS WHERE VTRXCODE = 'DC' AND NYEAR ='" . $stringds . "' ")) [0];
            $jumlah = $countjax->NLASTNO + 1;

            DB::table('MEDSYS_MSTNOS')
                ->where('VTRXCODE', 'DC')
                ->where('NYEAR', $stringds)->update(['NLASTNO' => $jumlah, 'NYEAR' => $stringds, 'NMONTH' => $stringm, 'NDATE' => $dd, 'DMODI' => Carbon::now() , 'VMODI' => Session::get('id') ,

            ]);

            $generate = $request->VDOCTYPE . str_pad($jumlah, 5, '0', STR_PAD_LEFT);

            // DOCLISTS table
            $doc->VDOCTYPE = $request->VDOCTYPE;
            $doc->VDOCNO = $generate;
            if (isset($request->file)) $doc->VDOCFILENAME = $request->file('file')
                ->getClientOriginalName();
            $doc->DPERIODFR = null;
            $doc->DPERIODTO = null;
            $doc->VMODI = Session::get('id');
            $doc->save();

            // $doc->VDOCFILENAME = $request->file('file')->getClientOriginalName();
            // $doc->VDOCTYPE = $request->VDOCTYPE;
            // $doc->VDOCNO = $request->VDOCNO;
            // $doc->DPERIODFR = null;
            // $doc->DPERIODTO = null;
            // $doc->VMODI = Session::get('id');
            // $doc->save();


            $examinationu = MEDSYS_EXAMINATIONS::find($request->VBOOKINGNO);
            if($examinationu != NULL){
                $examination = $examinationu;
            }else{
                $examination = new MEDSYS_EXAMINATIONS();
                $examination->VBOOKINGNO = $request->VBOOKINGNO;
                $examination->VCREA = Carbon::now();

            }
            // dd($examinationu);
            $examination->VLETTERID = 'MEDSYS_MSTPATIENTS/' . $request->VBOOKINGNO;
            $examination->DMODI = Carbon::now();
            $examination->VMODI = Session::get('id');
            $examination->save();
            // Store file, delete old file if there is one(updating)
            if (isset($request->file))
            {

                if ($is_update)
                {
                    Storage::delete('public' . Mstsettings::where('VSETID', 'LETTERTYPE')->where('VSETCODE', $request->VDOCTYPE)->where('BACTIVE', '1')
                    ->first()->VSETDESC1 . '/' . strtolower($doc->VID . substr($old_file, strrpos($old_file, '.'))));
                }
                    $request->file('file')->storeAs(Mstsettings::where('VSETID', 'LETTERTYPE')->where('VSETCODE', $request->VDOCTYPE)->where('BACTIVE', '1')
                    ->first()->VSETDESC1, $doc->VID . '.' . $request->file('file')
                    ->extension());

                    $data = '#tabexamination';
                    return response()->json($data, 200);
            }
            $data = '#tabexamination';
            return response()->json($data, 200);
        }

        //==== Upload document in Patient Information, Document List tab
        public function UploadDocument(Request $request)
        {
            //return response()->json($request, 400);
            if (isset($request->VDOCFILENAME))
            {
                for ($x = 0;$x < count($request->VDOCFILENAME);$x++)
                {
                    // Initialization
                    $is_update = false;
                    if (strlen($request->VID[$x]) != 13)
                    {
                        $doc = Doclists::find($request->VID[$x]);

                        $is_update = true;
                        $old_file = $doc->VDOCFILENAME;
                        $doc->DMODI = Carbon::now();
                    }
                    else
                    {
                        $doc = new Doclists();
                        $doc->VDOCID = 'MEDSYS_MSTPATIENTS/' . $request->VBOOKINGNO;
                        $doc->VCREA = Session::get('id');
                    }

                    // DOCLISTS table
                    $doc->VDOCTYPE = $request->VDOCTYPE[$x];
                    $doc->VDOCNO = $request->VDOCNO[$x];
                    if ($request->VDOCFILENAME[$x] != '')
                    {
                        $doc->VDOCFILENAME = $request->VDOCFILENAME[$x];
                    }
                    $doc->DPERIODFR = null;
                    $doc->DPERIODTO = null;
                    $doc->VMODI = Session::get('id');
                    $doc->save();

                    // Store file, delete old file if there is one(updating)
                    if ($request->VDOCFILENAME[$x] != '')
                    {
                        if ($is_update)
                        {
                            Storage::delete('public' . Mstsettings::where('VSETID', 'LETTERTYPE')->where('VSETCODE', $request->VDOCTYPE[$x])->where('BACTIVE', '1')
                            ->first()->VSETDESC1 . '/' . strtolower($doc->VID . substr($old_file, strrpos($old_file, '.'))));
                        }
                        $request->file('files') [$x]->storeAs(Mstsettings::where('VSETID', 'LETTERTYPE')->where('VSETCODE', $request->VDOCTYPE[$x])->where('BACTIVE', '1')
                         ->first()->VSETDESC1, $doc->VID . '.' . $request->file('files') [$x]->extension());
                    }
                }
            }

            return response()
                ->json(['success'], 200);
        }

        //==== View Tab Result MR
        public function ResultMr(Request $request)
        {
            // $ids = base64_decode($id);
            $tmp = "";
            $desc = "";

            if ($_GET['DFROM'] != null) $DFROM = $_GET['DFROM'];
            else
            {
                $DFROM = Carbon::now()->startofMonth()
                    ->format('d-m-Y');
                $tmp = "TOP 3";
                $desc = "ORDER BY a.DVISIT DESC";
            }
            if ($_GET['DTO'] != null) $DTO = $_GET['DTO'];
            else $DTO = Carbon::now()->endOfMonth()
                ->format('d-m-Y');

            $booking = base64_decode($_GET['BOOKING']);
            $resultmr = DB::select("SELECT " . $tmp . " ROW_NUMBER()  OVER(ORDER BY a.DVISIT DESC) AS No,a.VBOOKINGNO,a.DVISIT,e.VCLINICNAME,c.VNAME,f.VDXNAME FROM MEDSYS_SCHBOOKS a
      JOIN MEDSYS_MSTCLINICSTAFFS c ON a.VDRID = c.VUSRID
      JOIN MEDSYS_EXAMINATIONS b ON a.VBOOKINGNO = b.VBOOKINGNO
      JOIN MEDSYS_MSTCLINICS e ON a.VCLINICCODE = e.VCLINICCODE
      LEFT JOIN MEDSYS_ICDDIAGNOSIS f ON f.VDXCODE = b.VICDCODE
      WHERE  format(a.DVISIT, 'dd-MM-yyyy')  BETWEEN '" . $DFROM . "' AND '" . $DTO . "' AND a.VMRNO = '" . $booking . "' AND a.BSTATUS = 'D'  " . $desc . "");
            return Datatables::of($resultmr)->addIndexColumn()->addColumn('visitdate', function ($row)
            {

                $date = carbon::parse($row->DVISIT)
                    ->format('d-M-yy H:i A');
                return '<button class="btn btn-link resultmr" data-id="' . base64_encode($row->DVISIT . ',' . $row->VBOOKINGNO) . '" >
                ' . $date . '
                  </button>';
            })->rawColumns(['visitdate'])

                ->make(true);
        }

        public function ResultMcu(Request $request)
        {
            if ($_GET['DFROM'] != null) $DFROM = $_GET['DFROM'];
            else $DFROM = Carbon::now()->startofMonth()
                ->format('Y-m-d');
            if ($_GET['DTO'] != null) $DTO = $_GET['DTO'];
            else $DTO = Carbon::now()->endOfMonth()
                ->format('Y-m-d');

            $VIDNO = base64_decode($_GET['VIDNO']);
            $sp = \DB::select("EXEC sp_ResultMCU ?,?,?,?", array(
                $VIDNO,
                'ALL',
                $DFROM,
                $DTO
            ));

            return Datatables::of($sp)->addIndexColumn()
                ->make(true);

        }

        public function historyMr($id)
        {
            $ida = base64_decode($id);
            list($a, $b) = explode(",", $ida);

            $HistoryMR = DB::select("SELECT a.VADDRESS as alamat_patient,a.VNAME as nama_patient,a.VCITYBIRTH as tempat_patient,a.DBIRTH as lahir_patient,a.VADDRESS as alamat_patient,b.DVISIT,d.VCLINICNAME,c.VNAME as nama_doctor,b.VPHONENO as no_hp FROM MEDSYS_PATIENTS a
                                       LEFT JOIN MEDSYS_SCHBOOKS b ON a.VMRNO = b.VMRNO
                                       LEFT JOIN MEDSYS_MSTCLINICSTAFFS c ON b.VDRID = c.VUSRID
                                       LEFT JOIN MEDSYS_MSTCLINICS d ON b.VCLINICCODE = d.VCLINICCODE
                                       WHERE b.VBOOKINGNO = '" . $b . "' AND b.DVISIT = '" . $a . "' ") [0];
            $Examination = DB::select("SELECT a.VLETTERID,b.VDXNAME,a.VAMNESIS FROM MEDSYS_EXAMINATIONS a LEFT JOIN MEDSYS_ICDDIAGNOSIS b ON a.VICDCODE = b.VDXCODE WHERE VBOOKINGNO = '" . $b . "'  ") [0];
            $treatment = DB::select("SELECT b.VCONTAIN,a.VDOSAGE,a.IQTY,a.VREMARKS,c.VGNRLDESC FROM MEDSYS_TREATMENTS a
                              LEFT JOIN MEDSYS_MSTDRUGS b ON a.VDRUGSCODE = b.VDRUGSCODE  LEFT JOIN MEDSYS_MSTGENERALS c ON c.VGNRLCODE = b.VUOM WHERE a.VBOOKINGNO = '" . $b . "' AND c.VGNRLTYPE = 'MSUREUNIT'  ");
            if (true) //$user->VDOCID == NULL

            {
                $doclist = Doclists::where('VDOCID', 'MEDSYS_MSTPATIENTS/' . $b)->leftjoin('MEDSYS_MSTSETTINGS', function ($join)
                {
                    $join->on('MEDSYS_DOCLISTS.VDOCTYPE', '=', 'MEDSYS_MSTSETTINGS.VSETCODE')
                        ->where('MEDSYS_MSTSETTINGS.VSETID', 'LETTERTYPE')
                        ->where('MEDSYS_MSTSETTINGS.BACTIVE', '1');
                })
                    ->get();
            }
            // DB::select("SELECT b.VDOCID,b.VDOCTYPE,b.VDOCNO,b.VDOCFILENAME from MEDSYS_EXAMINATIONS a left join MEDSYS_DOCLISTS b on a.VLETTERID = b.VDOCID where a.VBOOKINGNO = '".$b."' ");
            $html = '';
            $html .= '<div class="row">
                     <div class="col-lg-3 col-md-12">
                        <div class="form-group">
                              <label class="control-label col-md-12">Full Name</label>
                        </div>
                     </div>
                     <div class="col-lg-4 col-md-12">
                        <div class="form-group">
                           <div class="col-md-12">
                                 : ' . $HistoryMR->nama_patient . '
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-2 col-md-12">
                        <div class="form-group">
                           <label class="control-label col-md-12">Address</label>
                        </div>
                     </div>
                     <div class="col-lg-3 col-md-12">
                        <div class="form-group">
                           <div class="col-md-12">
                                 : ' . $HistoryMR->alamat_patient . '
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-3 col-md-12">
                        <div class="form-group">
                              <label class="control-label col-md-12">Place/Date Of Birth</label>
                        </div>
                     </div>
                     <div class="col-lg-4 col-md-12">
                        <div class="form-group">
                           <div class="col-md-12">
                                 : ' . $HistoryMR->tempat_patient . ',' . carbon::parse($HistoryMR->lahir_patient)
                ->format('d F Y') . '
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-2 col-md-12">
                        <div class="form-group">
                        </div>
                     </div>
                     <div class="col-lg-4 col-md-12">
                        <div class="form-group">
                           <div class="col-md-12">
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                  <div class="col-lg-3 col-md-12">
                     <div class="form-group">
                           <label class="control-label col-md-12">Email</label>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-12">
                     <div class="form-group">
                        <div class="col-md-12">
                                 :
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-2 col-md-12">
                     <div class="form-group">
                        <label class="control-label col-md-12">Phone No.</label>

                     </div>
                  </div>
                  <div class="col-lg-3 col-md-12">
                     <div class="form-group">
                        <div class="col-md-12">
                              : ' . $HistoryMR->no_hp . '

                        </div>
                     </div>
                  </div>
               </div>
               <div class="row">
               <div class="col-lg-3 col-md-12">
                  <div class="form-group">
                        <label class="control-label col-md-12">Visit Date</label>
                  </div>
               </div>
               <div class="col-lg-4 col-md-12">
                  <div class="form-group">
                     <div class="col-md-12">
                           : ' . carbon::parse($HistoryMR->DVISIT)
                ->format('d F Y H:i A') . '
                     </div>
                  </div>
               </div>
               <div class="col-lg-2 col-md-12">
                  <div class="form-group">
                           <label class="control-label col-md-12">Clinic</label>
                  </div>
               </div>
               <div class="col-lg-3 col-md-12">
                  <div class="form-group">
                     <div class="col-md-12">
                           : ' . $HistoryMR->VCLINICNAME . '

                     </div>
                  </div>
               </div>
               </div>
               <div class="row">
               <div class="col-lg-3 col-md-12">
                  <div class="form-group">
                        <label class="control-label col-md-12">Doctor</label>
                  </div>
               </div>
               <div class="col-lg-4 col-md-12">
                  <div class="form-group">
                     <div class="col-md-12">
                           : ' . $HistoryMR->nama_doctor . '
                     </div>
                  </div>
               </div>
               <div class="col-lg-2 col-md-12">
                  <div class="form-group">
                  </div>
               </div>
               <div class="col-lg-3 col-md-12">
                  <div class="form-group">
                     <div class="col-md-12">


                     </div>
                  </div>
               </div>
               </div>
               <div class="row">
               <div class="col-lg-3 col-md-12">
                  <div class="form-group">
                        <label class="control-label col-md-12">Clinical Diagnosis</label>
                  </div>
               </div>
               <div class="col-lg-4 col-md-12">
                  <div class="form-group">
                     <div class="col-md-12">
                           : ' . $Examination->VDXNAME . '
                     </div>
                  </div>
               </div>
               <div class="col-lg-2 col-md-12">
                  <div class="form-group">
                  </div>
               </div>
               <div class="col-lg-3 col-md-12">
                  <div class="form-group">
                     <div class="col-md-12">


                     </div>
                  </div>
               </div>
               </div>
               <div class="row">
               <div class="col-lg-3 col-md-12">
                  <div class="form-group">
                        <label class="control-label col-md-12">Anamnesis</label>
                  </div>
               </div>
               <div class="col-lg-4 col-md-12">
                  <div class="form-group">
                     <div class="col-md-12">
                           : ' . $Examination->VAMNESIS . '
                     </div>
                  </div>
               </div>
               <div class="col-lg-2 col-md-12">
                  <div class="form-group">
                  </div>
               </div>
               <div class="col-lg-3 col-md-12">
                  <div class="form-group">
                     <div class="col-md-12">


                     </div>
                  </div>
               </div>
               </div>

               </br>
               </br>
               <p style="background-color:#6dc7e1; color:white;" class="p-1">Treatment</p>
               <div id="dvData" class="table-responsive">
               <table id="modalMr" class="display" style="width:100%">
                  <thead>
                     <tr>
                        <th>
                           No
                        </th>
                        <th>
                           Item
                        </th>
                        <th>
                           Dossage
                        </th>
                        <th>
                           Qty
                        </th>
                        <th>
                           UoM
                        </th>
                        <th>
                           Remarks
                        </th>
                     </tr>
                  </thead>
                  <tbody>
                  ';

            foreach ($treatment as $key => $tr)
            {
                $inc = 1;
                $html .= '<tr>
                        <td>' . $inc . '</td>
                        <td>' . $tr->VCONTAIN . '</td>
                        <td>' . $tr->VDOSAGE . '</td>
                        <td>' . $tr->IQTY . '</td>
                        <td>' . $tr->VGNRLDESC . '</td>
                        <td>' . $tr->VREMARKS . '</td>

                       </tr>';
                $inc++;
            }

            $html .= '</tbody>
               </table>
               <br>

            </div>
            <div id="dvData" class="table-responsive"   style="width:40%">
                  <table id="modalletter" class="display" >
                     <thead>
                        <tr>
                           <th>Letter No. </th>
                           <th>Letter Name </th>
                        </tr>
                     </thead>
                     <tbody>';
            foreach ($doclist as $key => $doc)
            {
                $html .= '<tr>
                        <td><a href="/account/download/examination/' . strtolower($doc->VID . substr($doc->VDOCFILENAME, strrpos($doc->VDOCFILENAME, '.'))) . '">' . $doc->VDOCNO . '</a></td>
                        <td>' . $doc->VSETDESC??'Lab' . '</td>

                       </tr>';
            }
            $html .= '</tbody>

                  </table>
               </div>

         </div>
               <script>
               $("#modalMr").DataTable({
                  searching: false,
                  paging: true,
                  ordering: true,
               });
               $("#modalletter").DataTable({
                  searching: false,
                  paging: false,
                  ordering: false,
               });
               </script>
                  ';

            // $data['Treatment'] = DB::select("SELECT VDRUGSCODE,VDOSAGE,IQTY,VREMARKS FROM MEDSYS_TREATMENTS WHERE VBOOKINGNO = '".$b."'  ");
            // $data['Examination'] = DB::select("SELECT a.VLETTERID,b.VDXNAME,a.VAMNESIS FROM MEDSYS_EXAMINATIONS a LEFT JOIN MEDSYS_ICDDIAGNOSIS b ON a.VICDCODE = b.VDXCODE WHERE VBOOKINGNO = '".$b."'  ");
            // $data['Examinationdtls'] = DB::select("SELECT * FROM MEDSYS_EXAMINATIONDTLS WHERE VBOOKINGNO = '".$b."'  ");
            return response()->json($html, 200);

        }

        public function downloadletter($letter, $id)
        {

            $data = base64_decode($id);
            list($x, $y) = explode(",", $data);

            $book = DB::select(DB::raw("SELECT B.VPHONENO,B.VGNDRCODE,A.VEMPSAPID,A.DVISIT,B.VADDRESS,B.VMRNO,B.VNAME,C.VICDCODE,FORMAT (A.DBIRTH, 'MM/dd/yyyy') DBIRTH,C.NHEIGHT,C.NWEIGHT,B.VBPJSNO,C.NBLOOD,D.VCLINICNAME,C.NPULSE,C.NBREATHFREQ
                                        FROM MEDSYS_SCHBOOKS A JOIN MEDSYS_PATIENTS B ON A.VMRNO = B.VMRNO LEFT JOIN MEDSYS_EXAMINATIONS C ON C.VBOOKINGNO = A.VBOOKINGNO  JOIN MEDSYS_MSTCLINICS D ON A.VCLINICCODE = D.VCLINICCODE WHERE B.VMRNO = '" . $x . "' AND A.VBOOKINGNO ='" . $y . "' ")) [0];

            $check = DB::select(DB::raw("SELECT VNAME
      FROM MEDSYS_MSTCLINICSTAFFS  WHERE VUSRID = '" . Session::get('id') . "'  "));
            if (!empty($check)) $check = $check[0];
            if (!empty($check))

            // Age
            $y = DateTime::createFromFormat('d/m/Y', $book->DBIRTH)
                ->diff(new DateTime('now'))->y;
            $m = DateTime::createFromFormat('d/m/Y', $book->DBIRTH)
                ->diff(new DateTime('now'))->m;
            $d = DateTime::createFromFormat('d/m/Y', $book->DBIRTH)
                ->diff(new DateTime('now'))->d;
            $c = $y . ' Year ' . $m . ' Month ' . $d . ' Day ';

            if ($letter === 'healthcertificate')
            {

                $file = public_path('/letter/healthcertificate.docx');
                $phpword = new \PhpOffice\PhpWord\TemplateProcessor($file);
                $phpword->setValue('{{nama_lengkap}}', $book->VNAME);
                $phpword->setValue('{{ttl}}', Carbon::parse($book->DBIRTH)->format('d-M-Y'));
                $phpword->setValue('{{no_bpjs}}', $book->VBPJSNO);
                $phpword->setValue('{{bb}}', $book->NWEIGHT);
                $phpword->setValue('{{tb}}', $book->NHEIGHT);
                $phpword->setValue('{{gol_darah}}', $book->NBLOOD);
                $phpword->setValue('{{hr}}', $book->NPULSE);
                $phpword->setValue('{{rr}}', $book->NBREATHFREQ);

                $phpword->setValue('{{clinic_name}}', $book->VCLINICNAME);
                $phpword->setValue('{{nama_dokter}}', $check->VNAME);
                $phpword->setValue('{{ttl_sch}}', carbon::parse($book->DVISIT)->format('d F Y'));

                header("Content-Disposition: attachment; filename=healthcertificate-$book->VMRNO.docx");
                $phpword->saveAs('php://output');

            }
            else if ($letter === 'sicknessletter')
            {

                $file = public_path('/letter/sicknessletter.docx');
                $phpword = new \PhpOffice\PhpWord\TemplateProcessor($file);
                $phpword->setValue('{{nama_lengkap}}', $book->VNAME);
                $phpword->setValue('{{umur}}', $c);
                $phpword->setValue('{{no_bpjs}}', $book->VBPJSNO);
                $phpword->setValue('{{alamat}}', $book->VADDRESS);
                $phpword->setValue('{{clinic_names}}', $book->VCLINICNAME);
                $phpword->setValue('{{nama_dokter}}', $check->VNAME);
                $phpword->setValue('{{ttl_sch}}', carbon::parse($book->DVISIT)->format('d F Y'));

                header("Content-Disposition: attachment; filename=sicknessletter-$book->VMRNO.docx");
                $phpword->saveAs('php://output');

            }
            else if ($letter === 'referalletter')
            {

                $icdcount =  DB::select(DB::raw("SELECT count(*) as countvdx FROM MEDSYS_ICDDIAGNOSIS WHERE VDXCODE = '" . $book->VICDCODE . "'  "))[0];
                if($icdcount->countvdx == '1'){

                    $icd = DB::select(DB::raw("SELECT VDXNAME FROM MEDSYS_ICDDIAGNOSIS WHERE VDXCODE = '" . $book->VICDCODE . "'  "))[0];
                    $icds = $icd->VDXNAME;
                }else{
                    $icds = '';
                }

                // if (!empty($icd)) $icd = $icd[0];
                // if (!empty($icd))

                $files = public_path('/letter/referalletter.docx');
                $phpword = new \PhpOffice\PhpWord\TemplateProcessor($files);
                $phpword->setValue('{{nama_lengkap}}', $book->VNAME);
                $phpword->setValue('{{icd}}', $icds);
                $phpword->setValue('{{no_bpjs}}', $book->VBPJSNO);
                $phpword->setValue('{{alamat}}', $book->VADDRESS);
                $phpword->setValue('{{clinic_name}}', $book->VCLINICNAME);
                $phpword->setValue('{{nama_dokter}}', $check->VNAME);
                $phpword->setValue('{{ttl_sch}}', carbon::parse($book->DVISIT)
                    ->format('d F Y'));

                header("Content-Disposition: attachment; filename=referalletter-$book->VMRNO.docx");
                $phpword->saveAs('php://output');

            }
            else if ($letter === 'informedconsent')
            {
                $file = public_path('/letter/informedconsent.docx');
                $phpword = new \PhpOffice\PhpWord\TemplateProcessor($file);
                $phpword->setValue('{{nama_lengkap}}', $book->VNAME);
                $phpword->setValue('{{umur}}', $c);
                $phpword->setValue('{{ttl}}', Carbon::parse($book->DBIRTH)->format('d-M-Y'));
                $phpword->setValue('{{alamat}}', $book->VADDRESS);
                $phpword->setValue('{{clinic_name}}', $book->VCLINICNAME);
                $phpword->setValue('{{nama_dokter}}', $check->VNAME);
                $phpword->setValue('{{ttl_sch}}', carbon::parse($book->DVISIT)
                    ->format('d F Y'));
                $phpword->setValue('{{sap_id}}', $book->VEMPSAPID);
                $phpword->setValue('{{no_tlpn}}', $book->VPHONENO);

                header("Content-Disposition: attachment; filename=informedconsent-$book->VMRNO.docx");
                $phpword->saveAs('php://output');

            }
            else if ($letter === 'referallabletter')
            {
                $gender = DB::select(DB::raw("SELECT VSETDESC FROM MEDSYS_MSTSETTINGS WHERE VSETID = 'GENDER' AND VSETCODE = '" . $book->VGNDRCODE . "' "));

                if (!empty($gender)) $gender = $gender[0];
                if (!empty($gender)) $file = public_path('/letter/referallabletter.docx');
                $phpword = new \PhpOffice\PhpWord\TemplateProcessor($file);
                $phpword->setValue('{{nama_lengkap}}', $book->VNAME);
                $phpword->setValue('{{umur}}', $c);
                $phpword->setValue('{{ttl}}', Carbon::parse($book->DBIRTH)->format('d-M-Y'));
                $phpword->setValue('{{alamat}}', $book->VADDRESS);
                $phpword->setValue('{{clinic_name}}', $book->VCLINICNAME);
                $phpword->setValue('{{nama_dokter}}', $check->VNAME);
                $phpword->setValue('{{sap_id}}', $book->VEMPSAPID);
                $phpword->setValue('{{no_tlpn}}', $book->VPHONENO);
                $phpword->setValue('{{gender}}', $gender->VSETDESC);

                $phpword->setValue('{{date_now}}', Carbon::parse(carbon::now())->format('d-m-Y'));

                header("Content-Disposition: attachment; filename=referallabletter-$book->VMRNO.docx");
                $phpword->saveAs('php://output');
            }
        }
        public function report()
        {
            JasperPHP::compile(base_path('/vendor/cossou/jasperphp/examples/hello_world.jrxml'))
                ->execute();

        }

    }

