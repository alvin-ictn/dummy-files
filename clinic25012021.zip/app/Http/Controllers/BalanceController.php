<?php

namespace App\Http\Controllers;

use App\Exports\BalanceExport;
use Illuminate\Http\Request;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use Illuminate\Support\Facades\Crypt;
use Maatwebsite\Excel\Facades\Excel;

class BalanceController extends Controller
{
    //==== Ajax
    public function ajax(Request $request){
        $VCLINICCODE = Session::get('cliniccode') == "" ? "HO" : Session::get('cliniccode'); 
        
        $ASOFDATE = date("Y-m-d"); 
        //return response()->json([$VCLINICCODE, $ASOFDATE], 400); // DEBUG
        $sp = \DB::select("EXEC sp_ItemBalance ?,?", array($VCLINICCODE, $ASOFDATE));
        
        return Datatables::of($sp)
                ->addIndexColumn()

                // ->filter(function ($instance) use ($request)
                // {
                //     if (!empty($request->get('date'))) {
                //         // search Last Modified Date
                //         $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                //             $dot = Carbon::parse($request->get('lmdate'))->format('d-M-Y');
                //             return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                //         });
                //     }

                //     if (!empty($request->get('search'))) {
                //         // search entire table
                //         $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                //             $tmp_search = $request->get('search');  // inputed string in Search field
                //             $column_names = ['No', 'USERNAME', 'ROLENAME', 'STATUS', 'MODIFY_NAME', 'MODIFY_DATE'];
                //             for($i = 0; $i < count($column_names); $i++)
                //             {
                //                 // Check if cell of $column_names[$i] contains $tmp_search
                //                 if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                //             }
                //             return false;
                //         });
                //     }
                // })

                ->addColumn('no', function($row){
                    return $row->No;
                })
                ->addColumn('BALANCE', function($row){
                    return $row->STOCK + $row->REQUEST;
                })
                ->rawColumns(['no'])
                ->make(true);
    }

    //==== Export
    public function export_excel(Request $request)
    {
        if (!$request)
        {
            return Excel::download(new BalanceExport(""), 'Balance.xls');
        }
        else
        {
            $clinic_code = Session::get('cliniccode') == "" ? "HO" : Session::get('cliniccode'); 
            $date = date("Y-m-d"); 
            $no = $request->no;
            $itemcode = $request->itemcode;
            $contain = $request->contain;
            $brand = $request->brand;
            $uom = $request->uom;
            $stock = $request->stock;
            $_request = $request->_request;
            $balance = $request->balance;
            $search = $request->search;
            // return response()->json([$no, $itemcode, $contain, $brand, $uom, $stock, $request, $balance, $search], 400);
            return Excel::download(new BalanceExport($clinic_code, $date, $no, $itemcode, $contain, $brand, $uom, $stock, $_request, $balance, $search), 'Balance.xls');
        }
    }
}
