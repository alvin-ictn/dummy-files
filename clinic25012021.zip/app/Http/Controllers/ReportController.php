<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ClinicModel;
use App\Exports\CostCenterExport;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\RpengunjungExport;
use App\Mstemployees;
use App\Invrequests;


class ReportController extends Controller
{
    //
    public function reportkunjungan(){

        $regiontype = \App\Mstgnrl::where('VGNRLTYPE','=','REGIONTYPE')->where('BACTIVE','=','1')->get();
        $viewspersonalarea = \DB::select("SELECT  PERSONELCODE, PERSONELNAME FROM vw_mstpersonelarea WHERE status = 'Active' ");
        $viewscostcenter = \DB::select("SELECT CC_CODE, CC_NAME FROM vw_mstcostcenter WHERE  status = 'Active'");
        $employee = Mstemployees::all();
        return view('home/report/kunjungan',['employee'=>$employee,'regiontype'=>$regiontype,'personalarea'=>$viewspersonalarea,'costcenter'=>$viewscostcenter]);

    }

    public function getajaxbisnisunit($id){

        $ajax = ClinicModel::select('MEDSYS_MSTCLINICS.VBU','MEDSYS_MSTGENERALS.VGNRLDESC')->where('vregion',$id)->where('MEDSYS_MSTGENERALS.BACTIVE','1')->leftjoin('MEDSYS_MSTGENERALS','MEDSYS_MSTGENERALS.VGNRLCODE','=','MEDSYS_MSTCLINICS.VBU')->distinct()->get();
        $regions ="";
        $regions .="<option value='ALL'>ALL</option>";
        foreach($ajax as $a){

            $regions .="<option value=".$a->VBU.">".$a->VGNRLDESC."</option>";
        }
        return response()->json($regions, 200);
    }

    public function getajaxclinic($id){

        $clinic = ClinicModel::select('VCLINICCODE','VCLINICNAME')->where('VBU',$id)->distinct()->get();
        $rclinic ="";
        $rclinic .="<option value='ALL'>ALL</option>";

        foreach($clinic as $a){

            $rclinic .="<option value=".$a->VCLINICCODE.">".$a->VCLINICNAME."</option>";
        }
        return response()->json($rclinic, 200);
    }

    public function download_report(Request $request){

        switch($request->action) {

            case 'excel': 

                    return Excel::download(new RpengunjungExport(),'datapengunjung.xls');

                //action save here
            break;
        
            case 'pdf': 
                dd("pdf");

                //action for save-draft here
            break;
        }
    }
    public function reportdrugs(){
        $regiontype = \App\Mstgnrl::where('VGNRLTYPE','=','REGIONTYPE')->where('BACTIVE','=','1')->get();
        $viewspersonalarea = \DB::select("SELECT  PERSONELCODE, PERSONELNAME FROM vw_mstpersonelarea WHERE status = 'Active' ");
        $viewscostcenter = \DB::select("SELECT CC_CODE, CC_NAME FROM vw_mstcostcenter WHERE  status = 'Active'");
        return view('home/report/drugs',['regiontype'=>$regiontype,'personalarea'=>$viewspersonalarea,'costcenter'=>$viewscostcenter]);

    }
    public function reportdrugspurchase(){

        $regiontype = \App\Mstgnrl::where('VGNRLTYPE','=','REGIONTYPE')->where('BACTIVE','=','1')->get();
        $viewspersonalarea = \DB::select("SELECT  PERSONELCODE, PERSONELNAME FROM vw_mstpersonelarea WHERE status = 'Active' ");
        $viewscostcenter = \DB::select("SELECT CC_CODE, CC_NAME FROM vw_mstcostcenter WHERE  status = 'Active'");
        return view('home/report/drugspurchase',['regiontype'=>$regiontype,'personalarea'=>$viewspersonalarea,'costcenter'=>$viewscostcenter]);
    }
    public function getajaxreq($id){
        $b = base64_decode($id);
        $req = Invrequests::select('VREQNO')->where('VCLINICCODE',$b)->distinct()->get();
        $reqs ="";
        $reqs .="<option value='ALL'>ALL</option>";
        foreach($req as $a){

            $reqs .="<option value=".$a->VREQNO.">".$a->VREQNO."</option>";
        }
        return response()->json($reqs, 200);

    }
    public function reportMcus(){
        $employee = Mstemployees::all();
        $viewspersonalarea = \DB::select("SELECT  PERSONELCODE, PERSONELNAME FROM vw_mstpersonelarea WHERE status = 'Active' ");
        $viewscostcenter = \DB::select("SELECT CC_CODE, CC_NAME FROM vw_mstcostcenter WHERE  status = 'Active'");
        $regiontype = \App\Mstgnrl::where('VGNRLTYPE','=','REGIONTYPE')->where('BACTIVE','=','1')->get();
        $viewspersonalarea = \DB::select("SELECT  PERSONELCODE, PERSONELNAME FROM vw_mstpersonelarea WHERE status = 'Active' ");
        $viewscostcenter = \DB::select("SELECT CC_CODE, CC_NAME FROM vw_mstcostcenter WHERE  status = 'Active'");
        return view('home/report/resultmcu',['employee'=>$employee,'regiontype'=>$regiontype,'personalarea'=>$viewspersonalarea,'costcenter'=>$viewscostcenter]);


    }
    public function viewreport(){

        // $options = array(
        //     'username' => 'testing',
        //     'password' => 'password'
        // );
        
        // $ssrs = new \SSRS\Report('http://w2016a:8089/Reports/', $options);
        // $result = $ssrs->loadReport('/ssrs/RAPP');
        
        // $ssrs->setSessionId($result->executionInfo->ExecutionID);
        
        // $output = $ssrs->render('HTML4.0'); // PDF | XML | CSV
        // echo $output;
    $ssrs = new \SSRS\Report('http://w2016a:8089/Reports/Pages/ReportViewer.aspx?%2fRAPP%2fssrs&rs:Command=Render');
    $result = $ssrs->loadReport('/Reports/Reference_Report');

    // // $ssrs->setSessionId($result->executionInfo->ExecutionID);

    // $output = $ssrs->render('HTML4.0'); // PDF | XML | CSV
    // echo $output;
    }
	
    public function reportmcu()
	{
		return view('home/report/mcu', ['PAS' => \App\Mstpersonelareas::where('BACTIVE', '1')->get(), 'CCS' => \App\Mstcostcenter::where('BACTIVE', '1')->get()]);
    }
	
    public function reportvisit()
	{
		return view('home/report/visit', ['RS' => \App\Mstgnrl::where('VGNRLTYPE', 'REGIONTYPE')->where('BACTIVE', '1')->get(), 'BUS' => \App\Mstgnrl::where('VGNRLTYPE', 'BUSSUNIT')->where('BACTIVE', '1')->get(), 'PAS' => \App\Mstpersonelareas::where('BACTIVE', '1')->get(), 'CCS' => \App\Mstcostcenter::where('BACTIVE', '1')->get()]);
    }
	
	public function mcu(Request $request)
	{
		$data = array();
		$PA = $request->PA;
		$CC = $request->CC;
		$YFROM = $request->YFROM;
		$YTO = $request->YTO;
		$age = \DB::select("EXEC sp_DashboardMCUAge '" . $PA . "', '" . $CC . "', '" . $YFROM . "-01-01', '" . $YTO . "-12-31'");
		$bmi = \DB::select("EXEC sp_DashboardMCUBMI '" . $PA . "', '" . $CC . "', '" . $YFROM . "-01-01', '" . $YTO . "-12-31'");
		$color = \DB::select("EXEC sp_DashboardMCUColorVision '" . $PA . "', '" . $CC . "', '" . $YFROM . "-01-01', '" . $YTO . "-12-31'");
		$right = \DB::select("EXEC sp_DashboardMCUAudioRight '" . $PA . "', '" . $CC . "', '" . $YFROM . "-01-01', '" . $YTO . "-12-31'");
		$left = \DB::select("EXEC sp_DashboardMCUAudioLeft '" . $PA . "', '" . $CC . "', '" . $YFROM . "-01-01', '" . $YTO . "-12-31'");
		$spiro = \DB::select("EXEC sp_DashboardMCUSpirometri '" . $PA . "', '" . $CC . "', '" . $YFROM . "-01-01', '" . $YTO . "-12-31'");
		$data['age'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->Age : $e['Age']; }, $age), 'data' => array_map(function($e) { return is_object($e) ? $e->Person : $e['Person']; }, $age)];
		$data['bmi'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->BMI : $e['BMI']; }, $bmi), 'data' => array_map(function($e) { return is_object($e) ? $e->Person : $e['Person']; }, $bmi)];
		$data['color'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->ColorVision : $e['ColorVision']; }, $color), 'data' => array_map(function($e) { return is_object($e) ? $e->Person : $e['Person']; }, $color)];
		$data['right'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->AudiometriRight : $e['AudiometriRight']; }, $right), 'data' => array_map(function($e) { return is_object($e) ? $e->Person : $e['Person']; }, $right)];
		$data['left'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->AudiometriLeft : $e['AudiometriLeft']; }, $left), 'data' => array_map(function($e) { return is_object($e) ? $e->Person : $e['Person']; }, $left)];
		$data['spiro'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->Spirometri : $e['Spirometri']; }, $spiro), 'data' => array_map(function($e) { return is_object($e) ? $e->Person : $e['Person']; }, $spiro)];
		return response()->json($data, 200);
	}
	
	public function visit(Request $request)
	{
		$data = array();
		$R = $request->R;
		$BU = $request->BU;
		$PA = $request->PA;
		$CC = $request->CC;
		$DFROM = $request->DFROM;
		$DTO = $request->DTO;
		$employee = \DB::select("EXEC sp_DashboardVisitType '" . $R . "', '" . $BU . "', '" . $PA . "', '" . $CC . "', '" . $DFROM . "', '" . $DTO . "'");
		$employeeFam = \DB::select("EXEC sp_DashboardVisitFamily '" . $R . "', '" . $BU . "', '" . $PA . "', '" . $CC . "', '" . $DFROM . "', '" . $DTO . "'");
		$gender = \DB::select("EXEC sp_DashboardVisitGender '" . $R . "', '" . $BU . "', '" . $PA . "', '" . $CC . "', '" . $DFROM . "', '" . $DTO . "'");
		$referal = \DB::select("EXEC sp_DashboardVisitReferal '" . $R . "', '" . $BU . "', '" . $PA . "', '" . $CC . "', '" . $DFROM . "', '" . $DTO . "'");
		$accident = \DB::select("EXEC sp_DashboardVisitAccidentStatus '" . $R . "', '" . $BU . "', '" . $PA . "', '" . $CC . "', '" . $DFROM . "', '" . $DTO . "'");
		$days = \DB::select("EXEC sp_DashboardVisitSicknessDays '" . $R . "', '" . $BU . "', '" . $PA . "', '" . $CC . "', '" . $DFROM . "', '" . $DTO . "'");
		$letter = \DB::select("EXEC sp_DashboardVisitSicknessLetter '" . $R . "', '" . $BU . "', '" . $PA . "', '" . $CC . "', '" . $DFROM . "', '" . $DTO . "'");
		$age = \DB::select("EXEC sp_DashboardVisitorAge '" . $R . "', '" . $BU . "', '" . $PA . "', '" . $CC . "', '" . $DFROM . "', '" . $DTO . "'");
		$rujukan = \DB::select("EXEC sp_DashboardVisitRujukanProvider '" . $R . "', '" . $BU . "', '" . $PA . "', '" . $CC . "', '" . $DFROM . "', '" . $DTO . "'");
		$disease = \DB::select("EXEC sp_DashboardDiseases '" . $R . "', '" . $BU . "', '" . $PA . "', '" . $CC . "', '" . $DFROM . "', '" . $DTO . "'");
		$temp = $rujukan[0]->ProviderName;
		$rujukan_labels = array();
		$rujukan_bpjs = array();
		$rujukan_inhealth = array();
		$rujukan_labels[] = $temp;
		if (count(array_filter($rujukan, function ($var) use ($temp) { return $var->ProviderName == $temp && $var->Referal == 'BPJS'; })) === 0)
		{
			$rujukan_bpjs[] = 0;
		}
		else
		{
			$rujukan_bpjs[] = array_values(array_filter($rujukan, function ($var) use ($temp) { return $var->ProviderName == $temp && $var->Referal == 'BPJS'; }))[0]->Person;
		}
		if (count(array_filter($rujukan, function ($var) use ($temp) { return $var->ProviderName == $temp && $var->Referal == 'InHealth'; })) === 0)
		{
			$rujukan_inhealth[] = 0;
		}
		else
		{
			$rujukan_inhealth[] = array_values(array_filter($rujukan, function ($var) use ($temp) { return $var->ProviderName == $temp && $var->Referal == 'InHealth'; }))[0]->Person;
		}
		foreach ($rujukan as $val)
		{
			if ($val->ProviderName != $temp)
			{
				$temp = $val->ProviderName;
				$rujukan_labels[] = $temp;
				if (count(array_filter($rujukan, function ($var) use ($temp) { return $var->ProviderName == $temp && $var->Referal == 'BPJS'; })) === 0)
				{
					$rujukan_bpjs[] = 0;
				}
				else
				{
					$rujukan_bpjs[] = array_values(array_filter($rujukan, function ($var) use ($temp) { return $var->ProviderName == $temp && $var->Referal == 'BPJS'; }))[0]->Person;
				}
				if (count(array_filter($rujukan, function ($var) use ($temp) { return $var->ProviderName == $temp && $var->Referal == 'InHealth'; })) === 0)
				{
					$rujukan_inhealth[] = 0;
				}
				else
				{
					$rujukan_inhealth[] = array_values(array_filter($rujukan, function ($var) use ($temp) { return $var->ProviderName == $temp && $var->Referal == 'InHealth'; }))[0]->Person;
				}
			}
		}
		$data['employee'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->Type : $e['Type']; }, $employee), 'data' => array_map(function($e) { return is_object($e) ? $e->Person : $e['Person']; }, $employee)];
		$data['employeeFam'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->Family : $e['Family']; }, $employeeFam), 'data' => array_map(function($e) { return is_object($e) ? $e->Person : $e['Person']; }, $employeeFam)];
		$data['gender'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->Gender : $e['Gender']; }, $gender), 'data' => array_map(function($e) { return is_object($e) ? $e->Person : $e['Person']; }, $gender)];
		$data['referal'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->Referal : $e['Referal']; }, $referal), 'data' => array_map(function($e) { return is_object($e) ? $e->Person : $e['Person']; }, $referal)];
		$data['accident'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->AccidentStatus : $e['AccidentStatus']; }, $accident), 'data' => array_map(function($e) { return is_object($e) ? $e->CountVisit : $e['CountVisit']; }, $accident)];
		$data['days'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->RestDays : $e['RestDays']; }, $days), 'data' => array_map(function($e) { return is_object($e) ? $e->Letters : $e['Letters']; }, $days)];
		$data['letter'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->Letters : $e['Letters']; }, $letter), 'data' => array_map(function($e) { return is_object($e) ? $e->RestDays : $e['RestDays']; }, $letter)];
		$data['age'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->Age : $e['Age']; }, $age), 'data' => array_map(function($e) { return is_object($e) ? $e->Person : $e['Person']; }, $age)];
		$data['rujukan'] = ['labels' => $rujukan_labels, 'data' => [['label' => 'BPJS', 'backgroundColor' => 'rgba(54, 162, 235, 0.2)', 'data' => $rujukan_bpjs], ['label' => 'Inhealth', 'backgroundColor' => 'rgba(255, 206, 86, 0.2)', 'data' => $rujukan_inhealth]]];
		$data['disease'] = ['labels' => array_map(function($e) { return is_object($e) ? $e->Diagnosa : $e['Diagnosa']; }, $disease), 'data' => array_map(function($e) { return is_object($e) ? $e->Person : $e['Person']; }, $disease)];
		return response()->json($data, 200);
	}
}
