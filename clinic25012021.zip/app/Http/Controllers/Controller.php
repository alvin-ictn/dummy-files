<?php

namespace App\Http\Controllers;

use App\Mstsettings;
use App\Mstuserlogs;
use App\Mstuserrole;
use App\Mstusers;
use App\MstRoleAccess;

use App\Pwdhists;
use Carbon\Carbon;
use Hash;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Session;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
	
	public function __construct(Request $request)
    {
		$no_need_session = array("login", "logindoctor", "login/updatetype", "changepasword", "sendemail/forgotpassword", "changepasword/forgotpassword");
		if (Session::get('id') == NULL && in_array($request->path(), $no_need_session) === false)
		{
			Redirect::to('/')->send();
		}
		if (Session::get('id') != NULL)
		{
			if ((time()-60 * Mstsettings::select('VSETDESC')->where('VSETID','PRMIT')->where('VSETCODE','LOGOUT')->first()->VSETDESC) > strtotime(Mstusers::find(Session::get('id'))->DSIGNIN))
			{
				
			}
			else
			{
				Mstusers::where('VUSRID', Session::get('id'))->update(['DSIGNIN' => CARBON::NOW()]);
			}
		}
		// $general = array("account/home", "account/myprofile", "logout");
		// if (Session::get('id') != NULL && in_array($request->path(), $general) === false)
		// {
			// $granted = false;
			// foreach (Session::get('access') as $access)
			// {
				// if ((in_array($request->path(), $access['url']) !== false || in_array(str_replace("ajax", "account/", $request->path()), $access['url']) !== false) && in_array("V", $access['access']) !== false)
				// {
					// $granted = true;
					// break;
				// }
				// if ((in_array(str_replace("/add", "", $request->path()), $access['url']) !== false || in_array("account/" . str_replace("add", "", str_replace("/insert", "", $request->path())), $access['url']) !== false) && in_array("C", $access['access']) !== false)
				// {
					// $granted = true;
					// break;
				// }
				// if ((in_array(str_replace("/edit", "", substr($request->path(), 0, strrpos($request->path(), "/"))), $access['url']) !== false || in_array("account/" . str_replace("/edit", "", $request->path()), $access['url']) !== false) && in_array("U", $access['access']) !== false)
				// {
					// $granted = true;
					// break;
				// }
			// }
			// if (!$granted)
			// {
				// Redirect::to('account/home')->send();
			// }
		// }
    }
	
	protected function set_user_log($user)
    {
		$userlog = new Mstuserlogs();
		$userlog->VUSRID = $user->VUSRID;
		$userlog->VUSRFLAG = $user->VUSRFLAG;
		$userlog->VUSRPASS = $user->VUSRPASS;
		$userlog->DLOGIN = $user->DLOGIN;
		$userlog->VTYPEUSR = $user->VTYPEUSR;
		if ($user->BUSRLOCK != NULL)
		{
			$userlog->BUSRLOCK = $user->BUSRLOCK;
		}
		if ($user->BACTIVE != NULL)
		{
			$userlog->BACTIVE = $user->BACTIVE;
		}
		$userlog->BOTHERS = $user->BOTHERS;
		$userlog->VUSER = Session::get('id');
		$userlog->save();
    }
	
	protected function set_session($user, $arr = [])
    {
		Session::put('id', $user->VUSRID);
		Session::put('nameuser', $user->VNAME);
		Session::put('typeuser', $user->VTYPEUSR);
		$roles = array();
		foreach (Mstuserrole::where('VUSRID', $user->VUSRID)->where('BACTIVE', 1)->select('VROLEID')->get() as $val)
		{
			$roles[] = $val->VROLEID;
		}
		Session::put('groupuser', $roles);
		Session::put('access', array(array("key" => "masterdata", "access" => array("V", "C", "U", "D/C"), "url" => array("account/bank", "account/setting"))));
		//untuk ngambil master function 
		$this->roleaccess();
		///
		foreach ($arr as $key => $val)
		{
			Session::put($key, $val);
		}
		Mstusers::where('VUSRID', $user->VUSRID)->update(['DLOGIN' => CARBON::NOW(), 'DSIGNIN' => CARBON::NOW()]);
		Auth::loginUsingId($user->VUSRID);
		Auth::logoutOtherDevices($user->VUSRPASS, 'VUSRPASS');
    }
	
	protected function check_old_password($id, $pass)
    {
		$message = '';
		$pwd = Pwdhists::where('VUSRID', $id)->whereDate('VMODI', '>', Carbon::now()->subYear(1))->get();
		$update = true;
		foreach ($pwd as $rec)
		{
			if (Hash::check($pass, $rec->VUSRPASS))
			{
				$message = 'Cannot reuse a same password that has been used in one year!';
				$update = false;
				break;
			}
		}
		return [$update, $message];
    }
	
	public static function check_role($id)
    {
		foreach (Session::get('groupuser') as $val)
		{
			if (substr($val, 0, strlen($id)) === $id)
			{
				return true;
			}
		}
		return false;
	}

	protected function roleaccess(){
		$roleaccess_menu = MstRoleAccess::where('VROLEID',Session::get('groupuser')[0])
										->where(function ($query) {$query->where('BUSRVIEW','1')->orwhere('BUSRADD','1')->orwhere('BUSREDIT','1')->orwhere('BUSRCANCEL','1')->orwhere('BUSRPRINT','1')->orwhere('BUSREXPORT','1');})
										->leftjoin('MEDSYS_MSTFUNCTIONS', function($join) { $join->on('MEDSYS_MSTROLEACCESS.VFUNCCODE', 'MEDSYS_MSTFUNCTIONS.VFUNCCODE'); })
										->select('VMENUCODE')->groupby('VMENUCODE')->get();
		foreach($roleaccess_menu as $item)
		{ $array[] = $item->getOriginal('VMENUCODE'); }
		Session::put('roleaccess_menu', $array);

		$roleaccess_function = MstRoleAccess::where('VROLEID',Session::get('groupuser')[0])->get();
		foreach($roleaccess_function AS $item)
		{ $array[] = array( $item->VFUNCCODE => array('V'=>$item->BUSRVIEW,'C'=>$item->BUSRADD,'U'=>$item->BUSREDIT,'D/C'=>$item->BUSRCANCEL,'P'=>$item->BUSRPRINT,'E'=>$item->BUSREXPORT)); }
		Session::put('roleaccess', $array);	
	}

}