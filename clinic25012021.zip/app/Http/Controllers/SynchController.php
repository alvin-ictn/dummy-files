<?php

namespace App\Http\Controllers;

use App\ClinicModel;

use DataTables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Facades\Excel;
use Session;

class SynchController extends Controller
{
    //
    public function index()
    {
        //return view('home/synch/index', ['cancreate' => (in_array("HRADM", Session::get('groupuser')) !== false && Mstsettings::where('VSETID', 'INVREQUEST')->where('VSETDESC', Session::get('id'))->where('BACTIVE', '1')->exists()) || in_array("PMCY", Session::get('groupuser')) !== false]);
        
		return view('home/synch/index');
    }

    public function ajax()
	{
        $VCLINICCODE = DB::table('MEDSYS_MSTUSERCLINICS')->where('VUSRID',Session::get('id') ?? '')->first()->VCLINICCODE;
           
          if ($VCLINICCODE=='HO')
           {
            $clinicsel = ClinicModel::select("VCLINICNAME",DB::raw("FORMAT(DLASTSYNC, 'dd-MMM-yyyy hh:mm:ss tt') AS DLASTSYNC"))->where("BACTIVE","=","1")->get();
           }
          else
           {
             $clinicsel = ClinicModel::select("VCLINICNAME",DB::raw("FORMAT(DLASTSYNC, 'dd-MMM-yyyy hh:mm:ss tt') AS DLASTSYNC"))->where("VCLINICCODE","=", [$VCLINICCODE])->get();
			
           }
		return DataTables::of($clinicsel)
                ->addIndexColumn()
                ->addColumn('VCLINICNAME', function($row){ return $row->VCLINICNAME; })
                ->addColumn('action', function($row){       
                    $btn = '<a href="javascript:void(0)" class="edit btn btn-info btn-sm">Synchronize</a>';
                     return $btn;
             })
                ->addColumn('DLASTSYNC', function($row){ return $row->DLASTSYNC; })
                ->rawColumns(['VCLINICNAME','action','DLASTSYNC'])
                ->make(true);
    
    
    }

    public function dosynch(Request $request)
    {
        $VCLINICCODE = ClinicModel::find(Session::get('namaclinic') ?? 'HO')->VCLINICCODE;

		//$synchdo = DB::select("EXEC sp_ ?", [$VCLINICCODE]);
        return view('home/synch/index');
    }
}
