<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mstusers;
use App\Mstsettings;
use Hash;
use Session;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use DB;
use App\Doclists;
use DateTime;
use app\Mstdistrict;
use app\Mstsubdistrict;
use Illuminate\Support\Facades\Storage;
use App\MstRoleAccess;
use App\MstFunction;
use App\MEDSYS_EXAMINATIONS;
use App\MEDSYS_EXAMINATIONDTLS;
use App\MEDSYS_EXAMINATIONLOGS;
use App\MEDSYS_EXAMINATIONDTLLOGS;
use App\MEDSYS_ICDDIAGNOSIS;
use App\Treatment;
use app\Mstmedical;
use DataTables;
use Validator;
use Modeltoolscalibration;


class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function depan(){

        return view('index');

    }
    public function uploadckeditor(Request $request){
        if($request->hasFile('upload')) {
            $this->validate(request(), [
                'upload' => 'mimes:jpeg,jpg,gif,png'
            ]);
            $originName = $request->file('upload')->getClientOriginalName();
            $fileName = pathinfo($originName, PATHINFO_FILENAME);
            $extension = $request->file('upload')->getClientOriginalExtension();
            $fileName = $fileName.'_'.time().'.'.$extension;
        
            $request->file('upload')->move(public_path('images'), $fileName);
   
            $CKEditorFuncNum = $request->input('CKEditorFuncNum');
            $url = asset('images/'.$fileName); 
            $msg = 'Image uploaded successfully'; 
            $response = "<script>window.parent.CKEDITOR.tools.callFunction($CKEditorFuncNum, '$url', '$msg')</script>";
               
            @header('Content-type: text/html; charset=utf-8'); 
            echo $response;
        }

    }
    public function notifikasialert(){

		if(Session::get('groupuser')[0] === "HRADM"){
            $clinic = "ALL";
            $user = "ALL";
            $vclinic = "ALL";
        }else{
            $clinic = Session::get('cliniccode');
            $vclinic = "";
            $user =  Session::get('id');
        }
	

		// $clinic =  Mstuserclinic::select('VCLINICCODE')->where('VUSRID', $user)->where('MEDSYS_MSTUSERCLINICS.BACTIVE', '1')->join('MEDSYS_MSTCLINICS', 'MEDSYS_MSTUSERCLINICS.VCLINICCODE', '=', 'MEDSYS_MSTCLINICS.VCLINICCODE')->select('MEDSYS_MSTCLINICS.VCLINICCODE', 'MEDSYS_MSTCLINICS.VCLINICNAME')->first();
		// $clinic = Mstclinicstaffs::where('MEDSYS_MSTCLINICSTAFFS.VUSRID', $user)->join('MEDSYS_MSTUSERS', 'MEDSYS_MSTCLINICSTAFFS.VUSRID', '=', 'MEDSYS_MSTUSERS.VUSRID')->select('MEDSYS_MSTUSERS.VUSRID', 'MEDSYS_MSTCLINICSTAFFS.VNAME', 'MEDSYS_MSTUSERS.VTYPEUSR')->first();

		$ExpiredDoc = \DB::select("EXEC sp_ExpiredDoc ?,?", array($clinic, $user));
		$sp = \DB::select("EXEC sp_RcvStockReminder ?", array($vclinic));
        $LowStock = \DB::select("EXEC sp_LowStockReminder ?", array($vclinic));
		$tools = \DB::select("EXEC sp_ToolsCalibration ?", array($vclinic));
        
	
		if(count($ExpiredDoc) > 0){

			$null['null'] = "1";
		}else if(count($sp) > 0){

			$null['null'] = "1";

		}else if(count($LowStock) > 0){

			$null['null'] = "1";

		}else if(count($tools) > 0){

			$null['null'] = "1";
        }else{

			$null['null'] = '0';


		}
        return response()->json($null, 200);
		// $null['result'] = '';
		// foreach($ExpiredDoc as $p)
		// {
		// $null['result'] = $p->COLOR;
		// }
		// $null['null'] = "notifikasi";
		// $null['data'] = "alert";


	}
    public function index()
    {
        //
        $user = Mstusers::where('VUSRID','=',Session::get('id'))->first();
        return view('home/index', compact("user"));
    }
    public function paramedic(){

        
        return view('home/bookingsch/index');
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function toolscalibration($id = NULL){
        if(Session::get('groupuser')[0] === "HRADM"){
            $clinic = "ALL";
        }else{
            $clinic = "";
        }
        $sp = \DB::select("EXEC sp_ToolsCalibration ?", array($clinic));

        if($id != NULL)
        {
           
            $pon['result'] = '';
            foreach($sp as $p)
            {
                $pon['result'] = $p->COLOR;
    
    
            }

            return response()->json($pon, 200);

        }else{

            $spe = \DB::select("EXEC sp_ToolsCalibration ?", array($clinic));
                $pon['result'] = '';
            foreach($spe as $p)
            {
                $pon['result'] = $p->COLOR;


            }
                $sp = '';
            if($pon['result'] === "Red"){
                $sp = \DB::select("EXEC sp_ToolsCalibration ?", array($clinic));

            }else{
                $sp = \DB::select("EXEC sp_ToolsCalibration ?", array(''));
            }
            return Datatables::of($sp)
            ->addIndexColumn()
           
            ->make(true);
            // $tools = \App\Modeltoolscalibration::where('color','R');
            // return Datatables::of($mstmedical)
            // ->addIndexColumn()
            // ->addColumn('DLASTCLBRT', function ($row)
            // {
    
            //     return carbon::parse($row->DLASTCLBRT)
            //         ->format('d-M-yy');
            // })
            // ->make(true);

        }
        // dd(Carbon::now()->subMonth(3)->format('Y-m-d'));
    }
    public function legalcompliance($id = NULL){
        if(Session::get('groupuser')[0] === "HRADM"){
            $clinic = "ALL";
            $user = "ALL";
        }else{
            $clinic = Session::get('cliniccode');
            $user =  Session::get('id');
        }

        if($id != NULL)
        {
            $sp = \DB::select("EXEC sp_ExpiredDoc ?,?", array($clinic, $user));
            $pon['result'] = '';
            foreach($sp as $p)
            {
                $pon['result'] = $p->COLOR;


            }

            return response()->json($pon, 200);

            // $treemonth['tiga'] = \App\Mstmedical::where('DLASTCLBRT','<',$tmonth)->where('BSTATUS','1')->count();
            // $treemonth['dua'] = \App\Mstmedical::whereBetween('DLASTCLBRT', [$tmonth, $dmonth])->where('BSTATUS','1')->count();
            // $treemonth['satu'] = \App\Mstmedical::whereBetween('DLASTCLBRT', [$dmonth, $omonth])->where('BSTATUS','1')->count();


        }else{
            if(Session::get('groupuser')[0] === "HRADM"){
                $clinic = "ALL";
                $user = "ALL";
            }else{
                $clinic = Session::get('cliniccode');
                $user =  Session::get('id');
            }
            $spe = \DB::select("EXEC sp_ExpiredDoc ?,?", array($clinic, $user));
                $pon['result'] = '';
            foreach($spe as $p)
            {
                $pon['result'] = $p->COLOR;


            }
                $sp = '';
            if($pon['result'] === "Red"){
                $sp = \DB::select("EXEC sp_ExpiredDoc ?,?", array($clinic, $user));

            }else{
                $sp = \DB::select("EXEC sp_ExpiredDoc ?,?", array('',''));
            }
            return Datatables::of($sp)
            ->addIndexColumn()
           
            ->make(true);


        }

       


    }
    public function drugsreceive($id = NULL){
        if(Session::get('groupuser')[0] === "HRADM"){
            $clinic = "ALL";
        }else{
            $clinic = '';
        }
        $sp = \DB::select("EXEC sp_RcvStockReminder ?", array($clinic));
        if($id != NULL)
        {
            $sp = \DB::select("EXEC sp_RcvStockReminder ?", array($clinic));
            $pon['result'] = '';
            foreach($sp as $p)
            {
                $pon['result'] = 'Red';


            }

            return response()->json($pon, 200);

            // $treemonth['tiga'] = \App\Mstmedical::where('DLASTCLBRT','<',$tmonth)->where('BSTATUS','1')->count();
            // $treemonth['dua'] = \App\Mstmedical::whereBetween('DLASTCLBRT', [$tmonth, $dmonth])->where('BSTATUS','1')->count();
            // $treemonth['satu'] = \App\Mstmedical::whereBetween('DLASTCLBRT', [$dmonth, $omonth])->where('BSTATUS','1')->count();


        }else{
            if(Session::get('groupuser')[0] === "HRADM"){
                $clinic = "ALL";
            }else{
                $clinic = '';
            }
            $spe = \DB::select("EXEC sp_RcvStockReminder ?", array($clinic));
                $pon['result'] = '';
            foreach($spe as $p)
            {
                $pon['result'] = "Red";


            }
                $sp = '';
            if($pon['result'] === "Red"){
                $sp = \DB::select("EXEC sp_RcvStockReminder ?", array($clinic));

            }else{
                $sp = \DB::select("EXEC sp_RcvStockReminder ?", array(''));
            }
            return Datatables::of($sp)
            ->addIndexColumn()
           
            ->make(true);


        }
        
    }
    public function routinedrugs($id = NULL){
        if(Session::get('groupuser')[0] === "HRADM"){
            $clinic = "ALL";
        }else{
            $clinic = '';
        }

        $sp = \DB::select("EXEC sp_LowStockReminder ?", array($clinic));
        if($id != NULL)
        {
            $sp = \DB::select("EXEC sp_LowStockReminder ?", array($clinic));
            $pon['result'] = '';
            foreach($sp as $p)
            {
                $pon['result'] = 'Red';


            }

            return response()->json($pon, 200);

            // $treemonth['tiga'] = \App\Mstmedical::where('DLASTCLBRT','<',$tmonth)->where('BSTATUS','1')->count();
            // $treemonth['dua'] = \App\Mstmedical::whereBetween('DLASTCLBRT', [$tmonth, $dmonth])->where('BSTATUS','1')->count();
            // $treemonth['satu'] = \App\Mstmedical::whereBetween('DLASTCLBRT', [$dmonth, $omonth])->where('BSTATUS','1')->count();


        }else{
            if(Session::get('groupuser')[0] === "HRADM"){
                $clinic = "ALL";
            }else{
                $clinic = '';
            }
            $spe = \DB::select("EXEC sp_LowStockReminder ?", array($clinic));
                $pon['result'] = '';
            foreach($spe as $p)
            {
                $pon['result'] = "Red";


            }
                $sp = '';

            if($pon['result'] === "Red"){
    
                $sp = \DB::select("EXEC sp_LowStockReminder ?", array($clinic));

            }else{
                $sp = \DB::select("EXEC sp_LowStockReminder ?", array(''));
            }
            return Datatables::of($sp)
            ->addIndexColumn()
           
            ->make(true);


        }

    }
    public function clinic(){

        return view('home/clinic/index');


    }
    public function patientinfo($id){
        $db = base64_decode($id);
        
        // Split MR No and Hash(#ptntlst)
        if(str_contains($db, '#')) list($db, $hash) = explode("#", $db);
        else $hash = "";

        $patient = DB::select(DB::raw("SELECT MEDSYS_SCHBOOKS.VDRID,MEDSYS_SCHBOOKS.VPOSCODE,MEDSYS_SCHBOOKS.VCLINICCODE,MEDSYS_PATIENTS.VPICRELATION,MEDSYS_PATIENTS.VPICPROVCODE,MEDSYS_PATIENTS.VPICSUBDISTRICTCODE,MEDSYS_PATIENTS.VPICDISTRICTCODE,MEDSYS_PATIENTS.VPICNAME,MEDSYS_PATIENTS.VPICIDCARDNO,MEDSYS_PATIENTS.VPICADDRESS,MEDSYS_PATIENTS.VPICPOSTALCODE,
                                            MEDSYS_PATIENTS.VINSCODE,MEDSYS_PATIENTS.VINSNO,MEDSYS_PATIENTS.VBPJSNO AS BPJS,MEDSYS_PATIENTS.VPROFESSION AS profesi,MEDSYS_PATIENTS.VBLOODTYPE AS VBLOODTYPE,MEDSYS_PATIENTS.VSUBDISTRICTCODE AS VSUBDISTRICTCODES,MEDSYS_PATIENTS.VDISTRICTCODE AS VDISTRICTCODES,MEDSYS_PATIENTS.VPROVCODE AS VPROVCODE,MEDSYS_PATIENTS.VGNDRCODE AS gender,
                                            MEDSYS_PATIENTS.VMARITALSTS,MEDSYS_PATIENTS.VPHONENO,MEDSYS_PATIENTS.VSAPID,MEDSYS_PATIENTS.VIDCARDNO AS idcard,MEDSYS_PATIENTS.VADDRESS,MEDSYS_PATIENTS.VTYPEPATIENT,MEDSYS_PATIENTS.VPOSTALCODE, MEDSYS_SCHBOOKS.VPHONENO AS nohp, FORMAT (MEDSYS_SCHBOOKS.DBIRTH, 'MM/dd/yyyy') DBIRTHS, FORMAT (MEDSYS_SCHBOOKS.DCREA, 'MM/dd/yyyy') DCREAS,MEDSYS_MSTCLINICSTAFFS.VNAME AS NAMADOCTOR,format(MEDSYS_SCHBOOKS.DVISIT,'dd-MMM-yy hh:mm') as VisitDate, MEDSYS_SCHBOOKS.*,
                                            (SELECT b.VNAME FROM MEDSYS_SCHBOOKS a LEFT JOIN MEDSYS_MSTCLINICSTAFFS b ON b.VUSRID = a.VOTHDRID WHERE a.VBOOKINGNO = '".$db."') AS VOTHDRID1
                                        
                                        FROM MEDSYS_SCHBOOKS LEFT JOIN MEDSYS_MSTCLINICSTAFFS ON MEDSYS_MSTCLINICSTAFFS.VUSRID = MEDSYS_SCHBOOKS.VDRID 
                                        LEFT JOIN MEDSYS_PATIENTS ON MEDSYS_PATIENTS.VMRNO = MEDSYS_SCHBOOKS.VMRNO
                                        WHERE MEDSYS_SCHBOOKS.VBOOKINGNO = '".$db."'"))[0];
        $asurance = DB::select("SELECT VGNRLDESC,VGNRLCODE FROM MEDSYS_MSTGENERALS WHERE VGNRLTYPE = 'INSURANCE' AND BACTIVE = '1' ");
        $now = Carbon::now();
        $y = DateTime::createFromFormat('d/m/Y', $patient->DBIRTHS)
               ->diff(new DateTime('now'))->y;
        $m = DateTime::createFromFormat('d/m/Y', $patient->DBIRTHS)
               ->diff(new DateTime('now'))->m;  
        $d = DateTime::createFromFormat('d/m/Y', $patient->DBIRTHS)
               ->diff(new DateTime('now'))->d;      
        $c = $y.' Year '.$m.' Month '.$d.' Day ';
        if($patient->VPOSCODE === "UMUM"){
            $visitdate = carbon::parse($patient->VisitDate)->format('d-M-Y');
        }else{
            $visitdate = carbon::parse($patient->VisitDate)->format('d-M-Y H:i A');

        }
        $dbirth = carbon::parse($patient->DBIRTHS)->format('d-M-Y');
        $DCREAS = carbon::parse($patient->DCREAS)->format('d-M-Y');
        $datese = carbon::parse($patient->DCREAS)->subMonthNoOverflow()->endOfMonth()->subMonth();// June
        $province = DB::select("SELECT VPROVCODE,VPROVNAME FROM MEDSYS_MSTPROVS WHERE BACTIVE ='1' ");
        $setting = Mstsettings::where('VSETID','MARITAL')->where('BACTIVE','1')->get();
        $relation = \App\Mstsettings::where('VSETID','RELATION')->where('BACTIVE','1')->get();
        $district = \App\Mstdistrict::select('VDISTRICTCODE','VDISTRICTNAME')->where('BACTIVE','1')->get();
        $subdistrict = \App\Mstsubdistrict::select('VSUBDISTRICTCODE','VSUBDISTRICTNAME')->where('BACTIVE','=','1')->get();
        $exame =  MEDSYS_EXAMINATIONS::where('VBOOKINGNO',$db)->first();
        if($exame != null)$diag =  MEDSYS_ICDDIAGNOSIS::where('VDXCODE',$exame->VICDCODE)->first();
        else $diag = null;
        // $examdtls = MEDSYS_EXAMINATIONDTLS::where('VBOOKINGNO',$db)->leftjoin('MEDSYS_MSTDRUGS','MEDSYS_MSTDRUGS.VDRUGSCODE','=','MEDSYS_EXAMINATIONDTLS.VITEMCODE')->leftjoin('MEDSYS_MSTGENERALS','MEDSYS_MSTGENERALS.VGNRLCODE','MEDSYS_MSTDRUGS.VDRUGSTYPE')->leftjoin('MEDSYS_MSTGENERALS','MEDSYS_MSTGENERALS.VGNRLCODE','MEDSYS_MSTDRUGS.VUOM')->where('MEDSYS_MSTGENERALS.VGNRLTYPE','DRUGSTYPE')->where('MEDSYS_MSTGENERALS.VGNRLTYPE','MSUREUNIT')->get();
        $examdtls = \DB::select("SELECT d.ILINENO,d.IQTY,
        a.DRUGS_CODE, a.DRUGS_CONTAIN, a.DRUGS_BRAND as DRUGS_BRAND, a.DRUGS_VENDOR, a.DRUGS_UOM, a.DRUGS_PRICE, a.PBF_TYPE, a.STATUS, a.MODIFY_DATE, a.MODIFY_NAME, b.VGNRLDESC AS DRUGS_TYPE
        FROM vw_mstdrugs a
        LEFT JOIN MEDSYS_EXAMINATIONDTLS d on d.VITEMCODE = a.DRUGS_CODE
        LEFT JOIN MEDSYS_MSTGENERALS b ON a.DRUGS_TYPE = b.VGNRLCODE AND b.VGNRLTYPE = 'DRUGSTYPE'
        -- LEFT JOIN MEDSYS_MSTGENERALS c ON a.DRUGS_UOM = c.VGNRLCODE AND c.VGNRLTYPE = 'MSUREUNIT'
        WHERE d.VBOOKINGNO = '".$db."'
        ");
        // ->where('MEDSYS_MSTGENERALS.VGNRLTYPE','MSUREUNIT')->->leftjoin('MEDSYS_MSTGENERALS','MEDSYS_MSTGENERALS.VGNRLCODE','MEDSYS_MSTDRUGS.VUOM')
        $treatment = DB::table('MEDSYS_TREATMENTS')
                    ->leftjoin('vw_mstdrugs','vw_mstdrugs.DRUGS_CODE','=','MEDSYS_TREATMENTS.VDRUGSCODE')
                    ->where('MEDSYS_TREATMENTS.VBOOKINGNO',$db)->get();
        // dd($treatment);
        $doctypes = \App\Mstsettings::where('VSETID','LETTERTYPE')->where('BACTIVE','1')->get();
        if (true) //$user->VDOCID == NULL
        {
            $docs = Doclists::where('VDOCID', 'MEDSYS_MSTPATIENTS/'.$db)->leftjoin('MEDSYS_MSTSETTINGS', function ($join) { $join->on('MEDSYS_DOCLISTS.VDOCTYPE', '=', 'MEDSYS_MSTSETTINGS.VSETCODE')->where('MEDSYS_MSTSETTINGS.VSETID', 'LETTERTYPE')->where('MEDSYS_MSTSETTINGS.BACTIVE', '1'); })->get();
        	$members = DB::select("SELECT D.VNAME NAMA,D.VEMPSAPID,B.ILINE, B.VRELNAME, E.VSETDESC VRELATION , C.VSETDESC VRELGENDER, FORMAT (B.DRELBIRTH, 'dd-MM-yyyy') DRELBIRTH, B.VRELCTRYBIRTH, B.VRELCITYBIRTH, B.VBPJSNO VRELBPJSNO, B.VJHTNO VRELJHTNO
										FROM MEDSYS_MSTUSERS A
										LEFT JOIN MEDSYS_MSTEMPLOYEES D ON  A.VUSRID = D.VUSRID
										JOIN MEDSYS_MSTEMPMEMBERS B ON D.VEMPSAPID = B.VEMPSAPID
										LEFT JOIN MEDSYS_MSTSETTINGS C ON B.VRELGENDER = C.VSETCODE AND C.VSETID = 'GENDER'
                                        LEFT JOIN MEDSYS_MSTSETTINGS E ON B.VRELATION = E.VSETCODE AND E.VSETID = 'RELATION'

										WHERE b.VEMPSAPID = ?
                                        ORDER BY ILINE", [$patient->VSAPID]);
            $countvsapid = DB::select(db::raw("SELECT COUNT(*) as jumlah  FROM MEDSYS_MSTUSERS A
            LEFT JOIN MEDSYS_MSTEMPLOYEES D ON  A.VUSRID = D.VUSRID WHERE D.VEMPSAPID =  '".$patient->VSAPID."'"))[0];
            if($countvsapid->jumlah == 1){
                $vsapid = DB::select(db::raw("SELECT D.VNAME  FROM MEDSYS_MSTUSERS A
                LEFT JOIN MEDSYS_MSTEMPLOYEES D ON  A.VUSRID = D.VUSRID WHERE D.VEMPSAPID =  '".$patient->VSAPID."'"))[0];
            }else{

                $vsapid = NULL;
            }
            
                                        
        }
        // return response()->json($docs, 400);
        // Treatment::where('VBOOKINGNO',$db)->select('VCONTAIN')->leftjoin('MEDSYS_MSTDRUGS','MEDSYS_MSTDRUGS.VDRUGSCODE','=','MEDSYS_TREATMENTS.VDRUGSCODE')->get();
        return view('home/bookingsch/patientinfo',compact('province','district','subdistrict','db','hash','exame','diag','vsapid'),['members' => $members,'treatment'=>$treatment,'examdtls'=>$examdtls,'dater'=>$datese,'DCREAS'=>$DCREAS,'DBIRTH'=>$dbirth,'asurance'=>$asurance,'patient'=>$patient,'y'=>$c,'visitdate'=>$visitdate,'setting'=>$setting,'relation'=>$relation,'doctypes'=>$doctypes,'docs'=>$docs]);
    }

    public function patientlist()
    {
        return view('home/bookingsch/patientlist');
    }
    public function getnotif($id){


    }
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }
    public function setting(){
  
        return view('home/setting/index');
        
        

    }
    public function bank(){

        return view('home/bank/index');

    }

    public function district(){

        return view('home/district/index');

    }

    public function subdistrict(){

        return view('home/subdistrict/index');

    }
    public function scheduleMCU(){

        return view('home/schmcu/index');
    }
    public function content(){

        return view('home/content/index');

    }

    public function medical(){

        return view('home/medical/index');

    }
    
    public function drugs(){

        return view('home/drugs/index');

    }

    public function specialist(){

        return view('home/specialist/index');

    }

    public function prop(){

        return view('home/prop/index');

    }
    
    public function subpersonal(){

        return view('home/subpersonal/index');

    }
    
    public function personal(){

        return view('home/personal/index');

    }
    
    public function useraccess(){

        return view('home/useraccess/index');

    }
    
    public function userclin(){

        return view('home/userclinic/index');

    }

    public function userlogs(){

        return view('home/userlogs/index');

    }

    public function userrole(){

        return view('home/userrole/index');

    }

    public function costcenter(){

        return view('home/costcenter/index');

    }

    public function packages(){

        return view('home/packages/index');

    }

    public function ccenterpackages(){

        return view('home/costcenterpackages/index');

    }

    public function packageslist(){

        return view('home/packageslist/index');

    }

    public function checklistmcu(){

        return view('home/checklist/index');

    }

    public function general(){

        return view('home/general/index');

    }

    public function scheduledoctors(){

        return view('home/scheduledoctors/index');

    }

    public function roleaccess(){

        return view('home/roleaccess/index');

    }

    public function movementinquiry(){

        return view('home/movementinquiry/index');

    }

    public function payment(){

		$pts = \App\Mstsettings::select('VSETCODE','VSETDESC')->where('VSETID','=','TYPEPATIENT')->get();
		
        return view('home/payment/index', ["pts" => $pts]);

    }

    public function balance(){

        return view('home/balance/index');

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function logout()
	{
        Mstusers::where('VUSRID', Session::get('id'))->update(['DSIGNIN' => CARBON::NOW()->subDays(1)]);
        Session::flush();
        Auth::logout();
        return redirect('/')->with('alert','Kamu sudah logout');
    }
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
	
	public function download($id)
	{
		$doc = Doclists::find($id);
		if (explode("/", $doc->VDOCID)[0] == "MEDSYS_MSTCLINICSTAFFS")
		{
			$path = Mstsettings::where('VSETID', 'USERDOC')->where('VSETCODE', 'USRDOC')->where('BACTIVE', '1')->first()->VSETDESC;
		}else{

            $path = Mstsettings::where('VSETID', 'CLINICDOC')->where('VSETCODE', 'CLNCDOC')->where('BACTIVE', '1')->first()->VSETDESC;

        }
		return response()->download(Storage::disk('c-drive')->path($path . '/' . $id), $doc->VDOCFILENAME);
    }
    public function download_examination($id){
		$doc = Doclists::find($id);
        
        $path = Mstsettings::where('VSETID', 'LETTERTYPE')->where('VSETCODE', $doc->VDOCTYPE)->where('BACTIVE', '1')->first()->VSETDESC1;
        return response()->download(Storage::disk('c-drive')->path($path . '/' . $id), $doc->VDOCFILENAME);

    }
}
