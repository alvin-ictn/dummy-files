<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\MstRoleAccess;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
// use App\Exports\ScheduleDoctorsExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;

class RoleAccessController extends Controller
{
    //==== Ajax
    public function ajax(Request $request){
        $docts = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS No, * FROM vw_roleaccess");

        return Datatables::of($docts)
                ->addIndexColumn()

                ->filter(function ($instance) use ($request)
                {
                //     if (!empty($request->get('lmdate'))) {
                //         // search Last Modified Date
                //         $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                //             $dot = Carbon::parse($request->get('lmdate'))->format('d-M-Y');
                //             return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                //         });
                //     }

                    if (!empty($request->get('search'))) {
                        // search entire table
                        $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                            $tmp_search = $request->get('search');  // inputed string in Search field
                            $column_names = ['No', 'ROLEID', 'ROLENAME'];
                            for($i = 0; $i < count($column_names); $i++)
                            {
                                // Check if cell of $column_names[$i] contains $tmp_search
                                if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                            }
                            return false;
                        });
                    }
                })

                ->addColumn('no', function($row){
                    return $row->No;
                })
                ->addColumn('action', function($row){
                    if(RoleAccessController::FunctionAccessCheck('U', 'F20')) return $row->ROLEID;
                    else return null;
                })
                ->rawColumns(['action','no'])
                ->make(true);
    }

    //==== When adding a new role access or editing an existing role access
    public function form($id_ = NULL){
        $mstmenus = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS No, VMENUCODE, VMENUNAME FROM MEDSYS_MSTMENUS"); 
        $mstfunctions = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS No, VFUNCCODE, CAST(TRIM('F' FROM VFUNCCODE) AS INT) AS CASTED_CODENUM, VFUNCNAME, VMENUCODE, VDISABLED FROM MEDSYS_MSTFUNCTIONS ORDER BY CASTED_CODENUM"); 

        // Array for options name
        $array_options = array('View' => 'BUSRVIEW', 'Add' => 'BUSRADD', 'Edit' => 'BUSREDIT', 'Cancel' => 'BUSRCANCEL', 'Print' => 'BUSRPRINT', 'Export' => 'BUSREXPORT' );

        // Editing an existing role access
        if($id_ != NULL){
            $roleid = base64_decode($id_);

            $role= \DB::select("SELECT * FROM vw_getrole WHERE ROLEID = '$roleid'")[0]; 
            $mstroleaccess = \DB::select("SELECT VFUNCCODE, BUSRVIEW, BUSRADD, BUSREDIT, BUSRCANCEL, BUSRPRINT, BUSREXPORT FROM MEDSYS_MSTROLEACCESS WHERE VROLEID = '$roleid'");
            $mstroleaccess = MstRoleAccess::where('VROLEID', $roleid)->get();   //!!!

            // Multidimensional array for functions flags(true/false)
            $array_mstroleaccess = [];
            foreach($mstroleaccess as $roleaccess)
            {
                $function_code = $roleaccess->VFUNCCODE;
                $array_mstroleaccess["$function_code"]['BUSRVIEW'] = ($roleaccess->BUSRVIEW) ? true : false;
                $array_mstroleaccess["$function_code"]['BUSRADD'] = ($roleaccess->BUSRADD) ? true : false;
                $array_mstroleaccess["$function_code"]['BUSREDIT'] = ($roleaccess->BUSREDIT) ? true : false;
                $array_mstroleaccess["$function_code"]['BUSRCANCEL'] = ($roleaccess->BUSRCANCEL) ? true : false;
                $array_mstroleaccess["$function_code"]['BUSRPRINT'] = ($roleaccess->BUSRPRINT) ? true : false;
                $array_mstroleaccess["$function_code"]['BUSREXPORT'] = ($roleaccess->BUSREXPORT) ? true : false;
            }
                                                         
            return view('home/roleaccess/form', ['role' => $role, 'array_mstroleaccess' => $array_mstroleaccess, 'array_options' => $array_options, 'mstmenus' => $mstmenus, 'mstfunctions' => $mstfunctions]);
        }
        // Adding a new role access
        else{
            return view('home/roleaccess/form', ['mstmenus' => $mstmenus, 'mstfunctions' => $mstfunctions, 'array_options' => $array_options]);
        }
    }
    
    //==== Save role access
    public function save(Request $request){
        // Validation
        $validator = Validator::make($request->all(), [
            'VROLEID' => 'required|max:10',
        ]);
        if ($validator->fails()) {   
            $response['error'] = "Please fill all required field(s)";
            return response()->json($response, 400);
        }
        
        $checkboxes = $request->input('checkbox');

        // Array for options name
        $array_options = array('View' => 'BUSRVIEW', 'Add' => 'BUSRADD', 'Edit' => 'BUSREDIT', 'Cancel' => 'BUSRCANCEL', 'Print' => 'BUSRPRINT', 'Export' => 'BUSREXPORT' );

        $functions = [];    // list of checked options for each function (key: function code, value: option names)
        $func_codes = [];   // list of function codes that have been edited(checked/unchecked) (value: function codes)

        // Get all functions by id for editing(when a box is unchecked)
        $Mstroleaccess = \DB::select("SELECT VFUNCCODE FROM MEDSYS_MSTROLEACCESS WHERE VROLEID = '$request->VROLEID'");
        $mstroleaccess = MstRoleAccess::where('VROLEID', $roleid)->pluck('VFUNCCODE')->get();   //!!!

        // Get all checked options of functions
        if($checkboxes != NULL)
        {
            foreach($checkboxes as $box_value)
            {
                list($func_code, $opt_name) = explode("-", $box_value); // spliting string, function code and option name
                if(isset($functions["$func_code"])) array_push($functions["$func_code"], $opt_name);
                else 
                {
                    $functions["$func_code"] = array($opt_name);
                    array_push($func_codes, $func_code);
                }
            }
        }

        // Add other function codes from MEDSYS_MSTROLEACCESS (for editing(unchecking an option))
        if($Mstroleaccess != NULL)
        {
            foreach($Mstroleaccess as $roleaccess)
            {
                if(!in_array("$roleaccess->VFUNCCODE", $func_codes)) array_push($func_codes, $roleaccess->VFUNCCODE);
            }
        }

        // Save data
        foreach($func_codes as $code)
        {
            // Get existing role access 
            $data = MstRoleAccess::where('VROLEID', $request->VROLEID)->where('VFUNCCODE', $code)->first();
            // Create a new role access
            if($data == NULL) 
            {
                $data = new MstRoleAccess();
                $data->VROLEID = $request->VROLEID;
                $data->VFUNCCODE = $code;
                $data->VCREA = Session::get('id');
            }

            // Edit the data
            foreach($array_options as $key=>$value)
            {
                if(isset($functions["$code"]) && in_array("$key", $functions["$code"])) $data["$value"] = true;
                else $data["$value"] = false;
            }
            $data->VMODI = Session::get('id');
            $data->DMODI = Carbon::now();
            $data->save();
        }

        return response()->json(['success'], 200);
    }

    //==== Get data for Role Name lookup table
    public function getrolenamelookup(){
        // select all role that doesn't have a role access yet
        $views = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS No, A.ROLEID, A.ROLEDESC FROM vw_getrole A
                              WHERE A.ROLEID NOT IN (SELECT B.VROLEID FROM MEDSYS_MSTROLEACCESS B)
        ");

        return response()->json(['data' => $views]);
    }

    //==== Check if role access for all Roles has already been created
    public static function AllAccessCreated()
    {
        $views = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS No, A.ROLEID, A.ROLEDESC FROM vw_getrole A
                              WHERE A.ROLEID NOT IN (SELECT B.VROLEID FROM MEDSYS_MSTROLEACCESS B)
        ");
        if(Count($views) == 0) return true;
        else return false;
    }

    //==== Check if function is disabled
    public static function CheckDisabled($disabled_str, $key)
    {
        if(!isset($disabled_str)) $disabled_str = "";

        // Array of VDISABLED
        if(str_contains($disabled_str, ",")) $array_disabled_str = explode(',', $disabled_str, -1);  
        else $array_disabled_str = [$disabled_str];

        $array_keys_translator = array('View' => 'V', 'Add' => 'C', 'Edit' => 'U', 'Cancel' => 'D/C', 'Print' => 'P', 'Export' => 'E' );
        foreach($array_disabled_str as $item)
        {
            if($item == '') continue;
            if(!in_array($item, $array_keys_translator)) return "ERROR";
        }

        if(in_array($array_keys_translator["$key"], $array_disabled_str)) return "TRUE";
        else return "FALSE";
    }

    //==== Check role access, check if current user has an access to menu by code of $menu_code
    public static function MenuAccessCheck($menu_code)
    {
        if($menu_code == '#') return true; // For Menu with not yet created menu code [DEBUG]

        if(in_array($menu_code, session::get('roleaccess_menu'))) return true;
        return false;
    }

    //==== Check role access (function access), check if passed $function_codes(can be multiple) have a $function_initial set to '1'
    // $function_initial : [ 'V' for View / 'C' for Add / 'U' for Edit / 'D/C' for Cancel / 'P' for Print / 'E' for Excel ]
    // $function_codes : Function code from MEDSYS_MSTFUNCTIONS (multiple codes can be passed) (use '#' for function that still has no function code)
    // example: 
    /*  -----[check if current user have access to View in PatientInfo tab General (F02 and F28)]-----
        <?php if(App\Http\Controllers\RoleAccessController::RoleAccessCheck('V', 'F02', 'F28')) { ?>
            <...code...>
        <?php } ?> 
        ----------------------------------------------------------------------------------------------  */
	public static function FunctionAccessCheck($function_initial, ...$function_codes)
	{ 
        if($function_codes[0] == '#') return true; // For function with not yet created function code [DEBUG]

        // merge role access of passed function code(s)
        $search = [];
        foreach($function_codes as $code)
        { $search = array_merge($search, array_column(session::get('roleaccess'), $code)); }

        // check if there is atleast one value in array:$search with '1' 
        if(in_array('1', array_unique(array_column($search, $function_initial)))) return true;
        return false;
	}
}
