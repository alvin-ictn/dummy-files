<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use app\Mstsettings;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use App\Exports\SettingExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;
use DB;

class SettingController extends Controller
{
   

    public function  ajax(Request $request){

        $setting = \App\Mstsettings::all();
        $views = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY MONTH(MODIFY_DATE) DESC,YEAR(MODIFY_DATE) DESC,MODIFY_DATE ASC) AS No,SETID, SETCODE, SETDESC, SETADDDESC, STATUS, MODIFY_NAME, MODIFY_DATE 
        FROM vw_mstparameter");
        return Datatables::of($views)
        ->addIndexColumn()
        
        ->filter(function ($instance) use ($request) {
        
            if (!empty($request->get('date'))) {
            
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $dot = Carbon::parse($request->get('date'))->format('d-M-Y');
                    return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                
                });
             
            }
            if (!empty($request->get('search'))) {
                // search entire table
                $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                    $tmp_search = $request->get('search');  // inputed string in Search field
                    $column_names = ['No', 'SETID', 'SETCODE', 'SETDESC', 'SETADDDESC', 'MODIFY_NAME', 'MODIFY_DATE'];
                    for($i = 0; $i < count($column_names); $i++)
                    {
                        // Check if cell of $column_names[$i] contains $tmp_search
                        if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                    }
                    return false;
                });
            }
        })
        ->addColumn('no', function($row){
            return $row->No;
        })
        // ->editColumn('modify_at', function ($row) {
        //      return [
        //         'display' =>$row->MODIFY_DATE,
        //         'timestamp' => strtotime(carbon::parse($row->MODIFY_DATE)->format('d-m-Y H:m:s A'))
        //      ];;
        //  })

        ->addColumn('action', function($row){
            if(RoleAccessController::FunctionAccessCheck('U', 'F16'))
            {
                $null['base'] = base64_encode($row->SETID.','.$row->SETCODE);
                $null['id'] = $row->SETID;
                return $null;
            }
            else return null;
        })
        ->addColumn('modify_date', function($row){
            return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
        })
       
        ->rawColumns(['action','no'])
        ->make(true);

    }

    public function view($id){

        $base = base64_decode($id);
        $setting['setting'] = \App\Mstsettings::where('VSETID','=',$base)->first();
        return response()->json($setting);
    }

    public function update(Request $request)
    {
        $settingsel = \App\Mstsettings::where('VSETID','=',$request->settingidss)->where('VSETCODE','=',$request->settingcodes);
        
        $validator = Validator::make($request->all(), [
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        $settingsel->update([
            'VSETDESC' => $request->deskripsis,
            'VSETDESC1'  => $request->deskripsi1s,
            'BSETDISPL' => '1',
            'BACTIVE'  => '1',
            'DMODI'  => carbon::now(),
            'VCREA'  => Session::get('id'),
            'VMODI'  => Session::get('id'),
            
        ]);
        return response()->json(['success'], 200);
    }

    public function edit($id){

        $base = base64_decode($id);
        list($x,$y) = explode(",",$base);

        $setting = \App\Mstsettings::where('VSETID',$x)->where('VSETCODE',$y)->first();

        return view('home/setting/update',compact('setting'));
    }

    public function insert(){

        return view('home/setting/add');
    }
    
    public function add(Request $request){
        $validatedData = $request->validate([
            'settingidss' => 'required|max:20',
            'settingcodes' => 'required|max:10',
        ]);
        /// get dari model  
        $data =  new \App\Mstsettings();
        $data->VSETID = $request->settingidss;
        $data->VSETCODE = $request->settingcodes;
        $data->VSETDESC = $request->deskripsis;
        $data->VSETDESC1 = $request->deskripsi1s;
        $data->BSETDISPL = '1';
        $data->BACTIVE = '1';
        $data->DMODI = Carbon::now();
        $data->VCREA = Session::get('id');
        $data->VMODI = Session::get('id');
        $data->save();
        return response()->json(['success'], 200);
    }
    
	public function export_excel(Request $request)
	{
        if(!$request){

            $id ="";
            return Excel::download(new SettingExport($id),'Parameter.xls');

        }else{
            $no = $request->no;
            $pmid = $request->pmid;
            $pmcode = $request->pmcode;
            $desc = $request->desc;
            $addesc = $request->addesc;
            $lmname = $request->lmname;
            
            if (!$request->modifiedt) $modifiedt = '';
            else $modifiedt = Carbon::parse($request->modifiedt)->format('d-M-Y');
            
            $search = $request->search;

            return Excel::download(new SettingExport($no,$pmid,$pmcode,$desc,$addesc,$lmname,$modifiedt,$search),'Parameter.xls');

        }
    }
}
