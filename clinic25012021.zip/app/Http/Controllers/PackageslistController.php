<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use app\Mstpackageslist;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use Illuminate\Support\Facades\Crypt;
use DB;

class PackageslistController extends Controller
{
    public function ajax(Request $request)
    {
        $packageslist = \App\Mstpackageslist::all();
        $packagelist = \App\Mstpackageslist::all()->first();

        return Datatables::of($packageslist)
                ->addIndexColumn()

                ->addColumn('no', function($row){
                    return '';
                })
                ->addColumn('action', function($row){

                    return '<a class="btn btn-link btn-sm" href="packagelist/edit/'.Crypt::encryptString($row->VPACKAGECODE).'">'.$row->VPACKAGECODE.'</a>';

                })
                ->addColumn('BACTIVE', function($row){

                    if($row->BACTIVE === '1'){

                        $return = 'Active';
                    }else{

                        $return = 'InActive';
                    }
                    return $return;

                })
                ->rawColumns(['action','no'])
                ->make(true);
    }
    
    public function insert(){
        return view('home/packageslist/add');
    }

    public function add(Request $request){
        $validator = Validator::make($request->all(), [
            'packcode' => 'required|max:20',
            'checkcode' =>'required|max:20',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }

        /// get dari Model  
        $data =  new \App\Mstpackageslist();
        $data->VPACKAGECODE = $request->packcode;
        $data->VCHCKCODE = $request->checkcode;
        $data->BACTIVE = '1';
        $data->DMODI = Carbon::now();
        $data->VCREA = Session::get('id');
        $data->VMODI = Session::get('id');
        $data->save();
        return response()-> json(['succsess'], 200);
    }

    public function update(Request $request)
    {
        $packagelistsel = \App\Mstpackageslist::where('VPACKAGECODE','=',$request->packcode);
        
        $validator = Validator::make($request->all(), [
            'packcode' => 'required|max:50',
        ]);
        $error['eror'] = $validator->messages();
        if ($validator->fails()) {    
            return response()->json($error, 400);
        }
        $packagelistsel->update([
            'VPACKAGECODE' => $request->packcode,
            'VCHCKCODE' => $request->checkcode,
            'BACTIVE'  => $request->BACTIVEs,
            'DMODI'  => carbon::now(),
            'VCREA'  => Session::get('id'),
            'VMODI'  => Session::get('id'),
            
        ]);
        return response()->json(['succsess'], 200);
    }
    
    public function edit($id){
        $ids =  base64_decode($id);
        $packageslist = \App\Mstpackageslist::where('VPACKAGECODE',$ids)->first();

        return view('home/packageslist/update',compact('packageslist'));
    }
}
