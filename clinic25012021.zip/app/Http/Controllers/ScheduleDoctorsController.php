<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mstscheduledoctors;
use App\Mstscheduledoctordtls;
use App\Mstgnrl;
use App\Mstclinicstaffs;
use Hash;
use Session;
use Carbon\Carbon;
use DataTables;
use Validator;
use Illuminate\Support\Str; 
use App\Exports\ScheduleDoctorsExport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Crypt;

class ScheduleDoctorsController extends Controller
{
    //==== Ajax
    public function ajax(Request $request){
        $user_clinic_name = Session::get('clinicname');
        if($user_clinic_name == '') $user_clinic_name = 'HO';    
        
        $clinic_filter = "";    // For all clinic (without clinic name filter)
        if($user_clinic_name != 'HO') $clinic_filter = " WHERE CLINICNAME = '$user_clinic_name'";   // Use clinic filter (current user clinic)

        $docts = \DB::select("SELECT ROW_NUMBER() OVER(ORDER BY (SELECT 1)) AS No, * FROM vw_schdctrs" . $clinic_filter);

        return Datatables::of($docts)
                ->addIndexColumn()

                ->filter(function ($instance) use ($request)
                {
                    if (!empty($request->get('lmdate'))) {
                        // search Last Modified Date
                        $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                            $dot = Carbon::parse($request->get('lmdate'))->format('d-M-Y');
                            return Str::contains($row['MODIFY_DATE'], $dot) ? true : false;
                        });
                    }

                    if (!empty($request->get('search'))) {
                        // search entire table
                        $instance->collection = $instance->collection->filter(function ($row) use ($request) {
                            $tmp_search = $request->get('search');  // inputed string in Search field
                            $column_names = ['No', 'SCHEDULECODE', 'CLINICNAME', 'DOCTORNAME', 'SPECIALIST', 'STATUS', 'MODIFY_NAME', 'MODIFY_DATE'];
                            for($i = 0; $i < count($column_names); $i++)
                            {
                                // Check if cell of $column_names[$i] contains $tmp_search
                                if(Str::contains(Str::lower($row[$column_names[$i]]), Str::lower($tmp_search))) return true;
                            }
                            return false;
                        });
                    }
                })

                ->addColumn('no', function($row){
                    return $row->No;
                })
                ->addColumn('action', function($row){
                    if(RoleAccessController::FunctionAccessCheck('U', 'F12')) return $row->SCHEDULECODE;
                    else return null;
                })
                ->addColumn('modify_date', function($row){
                    return Carbon::parse($row->MODIFY_DATE)->format('YmdHis');
                })
                ->rawColumns(['action','no'])
                ->make(true);
    }

    //==== When adding a new schedule or editing an existing schedule
    public function form($code_ = NULL){
        // Editing an existing schedule
        if($code_ != NULL){
            $code = base64_decode($code_);

            // Schedule header
            $schedule = \DB::select("SELECT * FROM MEDSYS_SCHDCTRHDRS A WHERE A.VSCHCODE = '$code'")[0]; 
            $mstclinic = \DB::select("SELECT CLINICNAME FROM vw_mstclinic A WHERE A.CLINICCODE = '$schedule->VCLINICCODE' and A.status = 'Active' and a.BDISPLAY = '1' ")[0];     // Clinic Name
            $mstclinicstaff = \DB::select("SELECT VNAME FROM MEDSYS_MSTCLINICSTAFFS A WHERE A.VUSRID = '$schedule->VUSRID'")[0];    // Doctor Name
            $mstgenerals = \DB::select("SELECT VGNRLDESC FROM MEDSYS_MSTGENERALS A WHERE A.VGNRLCODE = '$schedule->VSPCCODE' AND A.VGNRLTYPE = 'SPECIALIST'");  
            if(!empty($mstgenerals)) $VGNRLDESC = $mstgenerals[0]->VGNRLDESC; // Specialist
            else $VGNRLDESC = '';
            //return response()->json($VGNRLDESC, 400);

            // Schedule doctor details
            $members = \DB::select("SELECT ILINENO, VSCHDAY, TSCHSTART, TSCHEND, BACTIVE FROM MEDSYS_SCHDCTRDTLS A WHERE A.VSCHCODE = '$code' ORDER BY ILINENO");
                                                            
            return view('home/scheduledoctors/form', ['schedule' => $schedule, 'members' => $members, 'mstclinic' => $mstclinic , 'mstclinicstaff' => $mstclinicstaff, 'VGNRLDESC' => $VGNRLDESC]);
        }
        // Adding a new schedule
        else{
            return view('home/scheduledoctors/form');
        }
    }
    
    //==== Save schedule
    public function save(Request $request){
        // Edit an EXISTING schedule 
        if($request->VSCHCODE != NULL){
            // update modified by & time
            $data = Mstscheduledoctors::where('VSCHCODE', $request->VSCHCODE)->first();
            $data->BACTIVE = $request->BACTIVE;
            $data->VMODI = Session::get('id');
            $data->DMODI = Carbon::now();
            $data->save();
                
            // Schedule header log
            $data_log = new \App\SchDocHdrLogs();
            $data_log->VSCHCODE = $request->VSCHCODE;
            $data_log->VCLINICCODE = $request->VCLINICCODE;
            $data_log->VUSRID = $request->VDOCTORID;
            $data_log->VSPCCODE = $request->VSPCCODE;
            $data_log->BACTIVE = $request->BACTIVE;
            $data_log->VUSER = Session::get('id');
            //$data_log->DDATE = Carbon::now();
            $data_log->save();

            // check if there is a row in schedule details table
            if (isset($request->ILINENO))   
            {
                for ($i = 0; $i < count($request->ILINENO); $i++)
                {
                    // Updating an EXISTING row of schedule details (if there is one)
                    if(strlen($request->ILINENO[$i]) != 13){
                        $condition = ['VSCHCODE' => $request->VSCHCODE, 'ILINENO' => $request->ILINENO[$i]];
                        $member = Mstscheduledoctordtls::where($condition)->first();
                        $member->DMODI = Carbon::now();
                    }
                    // Adding a NEW schedule detail (if there is one)
                    else{
                        $member = new Mstscheduledoctordtls();
                        $member->VCREA = Session::get('id');
                        $member->ILINENO = $request->ILINENO[$i];
                        $member->VSCHCODE = $request->VSCHCODE;
                    }
                    
                    // Schedule detail
                    $member->VSCHDAY = $request->VSCHDAY[$i];
                    $member->TSCHSTART = $request->TSCHSTART[$i];
                    $member->TSCHEND = $request->TSCHEND[$i];
                    $member->BACTIVE = (in_array('DTLBACTIVE' . $request->ILINENO[$i], $request->DTLBACTIVE)) ? true : false;
                    $member->VMODI = Session::get('id');
                    $member->save();
                    
                    // Schedule detail log
                    $member_log = new \App\SchDocDtlLogs();
                    $member_log->ILINENO = $request->ILINENO[$i];
                    $member_log->VSCHCODE = $request->VSCHCODE;
                    $member_log->VSCHDAY = $request->VSCHDAY[$i];
                    $member_log->TSCHSTART = $request->TSCHSTART[$i];
                    $member_log->TSCHEND = $request->TSCHEND[$i];
                    $member_log->BACTIVE = (in_array('DTLBACTIVE' . $request->ILINENO[$i], $request->DTLBACTIVE)) ? true : false;
                    $member_log->VUSER = Session::get('id');
                    //$member_log->DDATE = Carbon::now();
                    $member_log->save();
                }
            }
        }
        // Add a NEW schedule
        else{
            if (Mstscheduledoctors::where('VCLINICCODE', $request->VCLINICCODE)->where('VUSRID', $request->VDOCTORID)->where('BACTIVE', '1')->exists()) {
                return response()->json(['Failed: Data exist'], 400);
             }

            // Validation
            $validator = Validator::make($request->all(), [
                'VCLINICCODE' => 'required|max:20',
                'VDOCTORID' => 'required|max:50',
                'ILINENO' => 'required'
            ]);
            if ($validator->fails()) {   
                $response['error'] = "Please fill all required field(s)";
                return response()->json($response, 400);
            }

            // Schedule Code
            $sch_count = Mstscheduledoctors::all()->count();
            $new_sch_num = $sch_count + 1;
            $schcode = 'S' . $new_sch_num;
    
            // Schedule header
            $data =  new Mstscheduledoctors();
            $data->VSCHCODE = $schcode;
            $data->VCLINICCODE = $request->VCLINICCODE;
            $data->VUSRID = $request->VDOCTORID;
            $data->VSPCCODE = $request->VSPCCODE; 
            $data->VCREA = Session::get('id');
            $data->VMODI = Session::get('id');
            //$data->DMODI = Carbon::now();
            $data->save();
    
            // Schedule header log
            $data_log = new \App\SchDocHdrLogs();
            $data_log->VSCHCODE = $schcode;
            $data_log->VCLINICCODE = $request->VCLINICCODE;
            $data_log->VUSRID = $request->VDOCTORID;
            $data_log->VSPCCODE = $request->VSPCCODE;
            $data_log->VUSER = Session::get('id');
            //$data_log->DDATE = Carbon::now();
            $data_log->save();

            // Schedule details
            if (isset($request->ILINENO))
            {
                for ($i = 0; $i < count($request->ILINENO); $i++)
                {
                    // Schedule detail
                    $member = new Mstscheduledoctordtls();
                    $member->ILINENO = $request->ILINENO[$i];
                    $member->VSCHCODE = $schcode;
                    $member->VSCHDAY = $request->VSCHDAY[$i];
                    $member->TSCHSTART = $request->TSCHSTART[$i];
                    $member->TSCHEND = $request->TSCHEND[$i];
                    $member->BACTIVE = (in_array('DTLBACTIVE' . $request->ILINENO[$i], $request->DTLBACTIVE)) ? true : false;
                    $member->VCREA = Session::get('id');
                    $member->VMODI = Session::get('id');
                    //$member->DMODI = Carbon::now();
                    $member->save();

                    // Schedule detail log
                    $member_log = new \App\SchDocDtlLogs();
                    $member_log->ILINENO = $request->ILINENO[$i];
                    $member_log->VSCHCODE = $schcode;
                    $member_log->VSCHDAY = $request->VSCHDAY[$i];
                    $member_log->TSCHSTART = $request->TSCHSTART[$i];
                    $member_log->TSCHEND = $request->TSCHEND[$i];
                    $member_log->BACTIVE = (in_array('DTLBACTIVE' . $request->ILINENO[$i], $request->DTLBACTIVE)) ? true : false;
                    $member_log->VUSER = Session::get('id');
                    //$member_log->DDATE = Carbon::now();
                    $member_log->save();
                }
            }
        }

        return response()->json(['success'], 200);
    }

    //==== Export index table to excel file
	public function export_excel(Request $request){

        $user_clinic_name = Session::get('clinicname');
        if($user_clinic_name == '') $user_clinic_name = 'HO';    
        
        $clinic_filter = "";    // For all clinic (without clinic name filter)
        if($user_clinic_name != 'HO') $clinic_filter = " WHERE CLINICNAME = '$user_clinic_name'";   // Use clinic filter (current user clinic)

        if(!$request){
            $tmp = "";
            return Excel::download(new ScheduleDoctorsExport($tmp),'ScheduleDoctors.xls');
        }
        else{
            $no = $request->no;
            $schcode = $request->schcode;
            $clinicname = $request->clinicname;
            $docname = $request->docname;
            $spc = $request->spc;
            $status = $request->status;
            $lmname = $request->lmname;
            if(!$request->lmdate){
                $lmdate = '';
            }
            else{
                $lmdate = Carbon::parse($request->lmdate)->format('d-M-Y');
            }
            $search = $request->search;

            return Excel::download(new ScheduleDoctorsExport($no,$schcode,$clinicname,$docname,$spc,$status,$lmname,$lmdate,$search,$clinic_filter),'ScheduleDoctors.xls');
        }
    }

    //==== Get data for Clinic lookup table
    public function getcliniclookup(){
        $views = \DB::select("SELECT CLINICCODE, CLINICNAME FROM vw_mstclinic");

        return response()->json(['data' => $views]);
    }

    //==== Get data for Doctor lookup table
    public function getdoctorlookup(Request $request){
        $clinic_code = $request->input('clinic_code'); 
        $sp = \DB::select("EXEC sp_clinicdoctor ?", [$clinic_code]);

		return response()->json(['data' => $sp]);
    }
}
