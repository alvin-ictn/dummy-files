<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Resultmcuanalysis extends Model
{
	protected $table = 'MEDSYS_RESULTMCUANALYSIS';
	
	public $timestamps = false;
	
	protected $primaryKey = 'VREGNO';
    
    public $incrementing = false;
}
