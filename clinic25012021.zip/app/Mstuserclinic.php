<?php

namespace App;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class Mstuserclinic extends Model
{
    protected $table = 'MEDSYS_MSTUSERCLINICS';

    protected $primaryKey = ['VUSRID', 'VCLINICCODE'];
    protected $fillable = ['VUSRID'];

    public $timestamps = false;
    public $incrementing = false;
	
    protected function setKeysForSaveQuery(Builder $query)
	{
		foreach($this->primaryKey as $pk)
		{
			$query = $query->where($pk, $this->attributes[$pk]);
		}
		return $query;
	}
}
