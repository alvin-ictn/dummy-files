<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstpersonelareas extends Model
{
	protected $table = 'MEDSYS_MSTPERSONELAREAS';
	
	public $timestamps = false;

}
