<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Resultmcuaudios extends Model
{
	protected $table = 'MEDSYS_RESULTMCUAUDIOS';
	
	public $timestamps = false;
	
	protected $primaryKey = 'VREGNO';
    
    public $incrementing = false;
}
