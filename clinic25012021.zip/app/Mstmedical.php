<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstmedical extends Model
{
    protected $table = 'MEDSYS_MSTMDCLINSTRS';


    public $timestamps = false;
}
