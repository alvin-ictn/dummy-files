<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstpacklogs extends Model
{
    protected $table = 'MEDSYS_MSTPACKAGELOGS';


    public $timestamps = false;
}
