<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchDocDtlLogs extends Model
{
    protected $table = 'MEDSYS_SCHDCTRDTLLOGS';

    public $timestamps = false;
}
