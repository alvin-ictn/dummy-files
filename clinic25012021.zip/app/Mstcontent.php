<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstcontent extends Model
{
    protected $table = 'MEDSYS_MSTCONTENTS';
	protected $primaryKey = 'VCONTENTCODE';


    public $timestamps = false;
}
