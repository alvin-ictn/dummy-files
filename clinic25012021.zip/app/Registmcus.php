<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Registmcus extends Model
{
	protected $table = 'MEDSYS_REGISTMCUS';
	
	public $timestamps = false;
	
	protected $primaryKey = 'VREGNO';
    
    public $incrementing = false;
	
	protected $dates = ['DSUBMIT', 'DRESERVED'];
}
