<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstsubpersonelareas extends Model
{
	protected $table = 'MEDSYS_MSTSUBPERSONELAREAS';
}
