<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invrequests extends Model
{
	protected $table = 'MEDSYS_INVREQUESTS';
	
	public $timestamps = false;
	
	protected $primaryKey = 'VREQNO';
    
    public $incrementing = false;
	
	protected $dates = ['DREQ'];
}
