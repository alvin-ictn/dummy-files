<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstgnrl extends Model
{
    protected $table = 'MEDSYS_MSTGENERALS';


    public $timestamps = false;
}
