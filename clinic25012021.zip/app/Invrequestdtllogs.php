<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invrequestdtllogs extends Model
{
	protected $table = 'MEDSYS_INVREQUESTDTLLOGS';
	
	public $timestamps = false;
}
