<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MEDSYS_ICDDIAGNOSIS extends Model
{
    //
      //
      protected $table = 'MEDSYS_ICDDIAGNOSIS';


      public $timestamps = false;
}
