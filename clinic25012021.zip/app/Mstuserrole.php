<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstuserrole extends Model
{
    protected $table = 'MEDSYS_MSTUSERROLES';

    public $timestamps = false;
}
