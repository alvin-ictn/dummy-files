<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Resultmcuattch extends Model
{
	protected $table = 'MEDSYS_RESULTMCUATTCH';
	
	public $timestamps = false;
	
	protected $primaryKey = ['VREGNO', 'ILINENO'];
    
    public $incrementing = false;
}
