<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invmovehdrs extends Model
{
	protected $table = 'MEDSYS_INVMOVEHDRS';
	
	public $timestamps = false;
	
	protected $primaryKey = 'VTRXNO';
    
    public $incrementing = false;
	
	protected $dates = ['DTRX'];
}
