<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;

class Mstusers extends Model implements AuthenticatableContract
{
	use Authenticatable;
	
    //
    protected $table = 'MEDSYS_MSTUSERS';
    
    protected $guarded = [];
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'VUSRCODE','VUSRNAME','VUSRFLAG', 'VUSRPASS','VUSREMAIL','VTYPEUSR','BUSRLOCK'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'VUSRPASS','VTYPEUSR','BUSRLOCK'
    ];
    public $timestamps = false;
	
	protected $primaryKey = 'VUSRID';
    
    public $incrementing = false;

	public function getAuthPassword()
	{
		return $this->VUSRPASS;
	}
}
