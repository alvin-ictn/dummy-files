<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstsettings extends Model
{
    protected $table = 'MEDSYS_MSTSETTINGS';

    protected $primaryKey = ['VSETID', 'VSETCODE']; 


    public $timestamps = false;
    public $incrementing = false;

}
