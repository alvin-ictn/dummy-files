<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstuseracc extends Model
{

    protected $table = 'MEDSYS_MSTUSERACCESS';


    public $timestamps = false;
}
