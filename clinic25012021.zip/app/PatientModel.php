<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PatientModel extends Model
{
    protected $table = 'MEDSYS_PATIENTS';


    public $timestamps = false;
}
