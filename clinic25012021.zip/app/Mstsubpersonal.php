<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstsubpersonal extends Model
{
    protected $table = 'MEDSYS_MSTSUBPERSONELAREAS';


    public $timestamps = false;

}
