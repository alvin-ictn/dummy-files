<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstemployees extends Model
{
    //
    protected $table = 'MEDSYS_MSTEMPLOYEES';
    
    protected $guarded = [];
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'VMAIL', 'VDEPTHEADMAIL', 'VADDRESS', 'VPHONENO'
    ];

    public $timestamps = false;
	
	protected $dates = ['DBIRTH', 'DMARITAL', 'DHIRE', 'DENDCNTRCT'];
	
	protected $primaryKey = 'VUSRID';
    
    public $incrementing = false;
}
