<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Resultmcuchecks extends Model
{
	protected $table = 'MEDSYS_RESULTMCUCHECKS';
	
	public $timestamps = false;
	
	protected $primaryKey = 'VREGNO';
    
    public $incrementing = false;
}
