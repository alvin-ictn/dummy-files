<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Treatment extends Model
{
    //
    protected $table = 'MEDSYS_TREATMENTS';

    protected $primaryKey = ['VBOOKINGNO','ILINENO'];


    public $timestamps = false;
}
