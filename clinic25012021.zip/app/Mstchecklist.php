<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstchecklist extends Model
{
    protected $table = 'MEDSYS_MSTCHCKLISTMCU';


    public $timestamps = false;
}
