<?php

namespace App;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class BillModel extends Model
{
    protected $table = 'MEDSYS_BILLS';

    public $timestamps = false;
    
    protected $primaryKey = ['ILINENO', 'VBOOKINGNO'];
    
    public $incrementing = false;
	
    protected function setKeysForSaveQuery(Builder $query)
	{
		foreach($this->primaryKey as $pk)
		{
			$query = $query->where($pk, $this->attributes[$pk]);
		}
		return $query;
	}
}
