<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstdrugs extends Model
{
    protected $table = 'MEDSYS_MSTDRUGS';


    public $timestamps = false;
}
