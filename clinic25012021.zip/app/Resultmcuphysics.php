<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Resultmcuphysics extends Model
{
	protected $table = 'MEDSYS_RESULTMCUPHYSICS';
	
	public $timestamps = false;
	
	protected $primaryKey = 'VREGNO';
    
    public $incrementing = false;
}
