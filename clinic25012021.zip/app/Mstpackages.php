<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstpackages extends Model
{
    protected $table = 'MEDSYS_MSTPACKAGES';


    public $timestamps = false;
}
