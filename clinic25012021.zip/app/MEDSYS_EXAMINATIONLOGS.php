<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MEDSYS_EXAMINATIONLOGS extends Model
{
    //
    protected $table = 'MEDSYS_EXAMINATIONLOGS';

	protected $primaryKey = 'VBOOKINGNO';

    public $timestamps = false;
}
