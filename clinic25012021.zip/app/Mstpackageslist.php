<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstpackageslist extends Model
{
    protected $table = 'MEDSYS_MSTPACKAGELISTS';


    public $timestamps = false;
}
