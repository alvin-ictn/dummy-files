<?php

namespace App\Exports;

use Carbon\Carbon;
use DataTables;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Session;

class InventoryMovementExport implements FromView, ShouldAutoSize, WithEvents
{
    use Exportable;
	
    function __construct($no, $date, $transaction_no, $request_no, $search)
	{
        $this->no = $no;
        $this->date = $date;
        $this->transaction_no = $transaction_no;
        $this->request_no = $request_no;
        $this->search = $search;
    }

    public function view(): view
    {
		$movementsel = DB::select("SELECT ROW_NUMBER() OVER(ORDER BY DCREA DESC) AS No, FORMAT(DTRX,'dd-MMM-yyyy') AS DTRX, VTRXNO, VREQNO FROM MEDSYS_INVMOVEHDRS");
		$no = $this->no;
        $date = $this->date;
        $transaction_no = $this->transaction_no;
        $request_no = $this->request_no;
        $search = $this->search;
		$exports = DataTables::of($movementsel)
                ->addIndexColumn()
				->filter(function ($instance) use ($no, $date, $transaction_no, $request_no, $search) {
					if (!empty($no))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($no)
						{
							return Str::contains(Str::lower($row['No']), Str::lower($no));
						});
					}
					if (!empty($date))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($date)
						{
							$dot = Carbon::parse($date)->format('d-M-Y');
							return Str::contains($row['DTRX'], $dot) ? true : false;
						});
					}
					if (!empty($transaction_no))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($transaction_no)
						{
							return Str::contains(Str::lower($row['VTRXNO']), Str::lower($transaction_no));
						});
					}
					if (!empty($request_no))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request_no)
						{
							return Str::contains(Str::lower($row['VREQNO']), Str::lower($request_no));
						});
					}
					if (!empty($search))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($search)
						{
							if (Str::contains(Str::lower($row['VREQNO']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DTRX']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VTRXNO']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['No']), Str::lower($search)))
							{
								return true;
							}
							return false;
						});
					}
				})
                ->make(true);
		return view('excel.inventorymovementexport', [
            'exports' => $exports->getData()->data
        ]);
    }

    public function registerEvents(): array
    {
        //border style
		$styleArray = [
            'borders' => [
                'outline' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                //'color' => ['argb' => 'FFFF0000'],
                    ],
                ],
            ];
            
		//font style	
		$styleArray1 = [
            'font' => [
                'bold' => true,
                ]
            ];
        
		//column  text alignment
		$styleArray2 = array(
			'alignment' => array(
				'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
				 )
		);				
		
		//$styleArray3 used for vertical alignment 
		$styleArray3 = array(
			'alignment' => array(
				'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
				 )
		);
		

		$styleArray4 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_GRADIENT_LINEAR,
        'startColor' => [
        'argb' => 'FFA0A0A0',
        ],
        'endColor' => [
            'argb' => 'FFFFFFFF',
        ]]
					);
		
		$styleArray5 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
        
        'startColor' => [
            'rgb' => '00BFFF',
        ]]);
		
        return [
            AfterSheet::class => function(AfterSheet $event) use ($styleArray, $styleArray1,$styleArray2, $styleArray3, $styleArray4, $styleArray5)
            {$cellRange = 'A1:D1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(13);
                $event->sheet->getStyle($cellRange)->ApplyFromArray($styleArray);
                $event->sheet->getStyle('A1:D1')->ApplyFromArray($styleArray);
            
            
        //Heading formatting...
        $event->getSheet()->setAutoFilter('A1:D1');
        $event->getSheet()->getDelegate()->getStyle('A1:D1')->applyFromArray($styleArray);						
        $event->getSheet()->getDelegate()->getStyle('A1:D1')->applyFromArray($styleArray1);
            
        //used for making bold
        $event->getSheet()->getDelegate()->getStyle('A1:D1')->applyFromArray($styleArray1);
                       
        //column width set							
        $event ->sheet-> getDelegate()->getColumnDimension('A')->setWidth(65);
        $event ->sheet-> getDelegate()->getColumnDimension('B')->setWidth(64);
        $event ->sheet-> getDelegate()->getColumnDimension('C')->setWidth(13);
                    
                    
        //D column width set to 17
        $columns = ['D'];
            foreach ($columns as $column) {
                $event ->sheet-> getDelegate()->getColumnDimension($column)->setWidth(17);	
                    }
                    
        //D1 text wrapping...
        $event ->sheet->getStyle('D1')->getAlignment()->setWrapText(true);
                    
        //text center columns...
        $event ->sheet->getStyle('A1:A10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('B1:B10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('C1:C10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('D1:D10000')->applyFromArray($styleArray2);
                    
        //headings vertical alignment 
        $event ->sheet->getStyle('A1:D1')->applyFromArray($styleArray3); 
        //sums color formatting..
        $event ->sheet->getStyle('A1:D1')->applyFromArray($styleArray5);
            },
        ];

    }
}
