<?php

namespace App\Exports;

use Carbon\Carbon;
use DataTables;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Session;

class BalanceExport implements FromView, ShouldAutoSize, WithEvents
{
    use Exportable;
	
    function __construct($clinic_code, $date, $no, $itemcode, $contain, $brand, $uom, $stock, $request, $balance, $search)
	{
        $this->clinic_code = $clinic_code;
        $this->date = $date;
        $this->no = $no;
        $this->itemcode = $itemcode;
		$this->contain = $contain;
        $this->brand = $brand;
        $this->uom = $uom;
		$this->stock = $stock;
		$this->request = $request;
		$this->balance = $balance;
        $this->search = $search;
    }

    public function view(): view
    {
		$sp = \DB::select("EXEC sp_ItemBalance ?,?", array($this->clinic_code, $this->date));
		
		$no = $this->no;
		$itemcode = $this->itemcode;
        $contain = $this->contain;
        $brand = $this->brand;
        $uom = $this->uom;
		$stock = $this->stock;
		$request = $this->request;
		$balance = $this->balance;
		$search = $this->search;
		
		$exports = DataTables::of($sp)
				->addIndexColumn()
                ->addColumn('BALANCE', function($row){
                    return $row->STOCK + $row->REQUEST;
                })
				->filter(function ($instance) use ($no, $itemcode, $contain, $brand, $uom, $stock, $request, $balance, $search) {
					if (!empty($no))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($no)
						{
							return Str::contains(Str::lower($row['No']), Str::lower($no));
						});
					}
					if (!empty($itemcode))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($itemcode)
						{
							return Str::contains(Str::lower($row['VDRUGSCODE']), Str::lower($itemcode));
						});
					}
					if (!empty($contain))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($contain)
						{
							return Str::contains(Str::lower($row['VCONTAIN']), Str::lower($contain));
						});
					}
					if (!empty($brand))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($brand)
						{
							return Str::contains(Str::lower($row['VBRAND']), Str::lower($brand));
						});
					}
					if (!empty($uom))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($uom)
						{
							return Str::contains(Str::lower($row['VUOM']), Str::lower($uom));
						});
					}
					if (!empty($stock))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($stock)
						{
							return Str::contains(Str::lower($row['STOCK']), Str::lower($stock));
						});
					}
					if (!empty($request))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($request)
						{
							return Str::contains(Str::lower($row['REQUEST']), Str::lower($request));
						});
					}
					if (!empty($balance))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($balance)
						{
							return Str::contains(Str::lower($row['BALANCE']), Str::lower($balance));
						});
					}
					if (!empty($search))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($search)
						{
							if (Str::contains(Str::lower($row['No']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VDRUGSCODE']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VCONTAIN']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VBRAND']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VUOM']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['STOCK']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['REQUEST']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['BALANCE']), Str::lower($search)))
							{
								return true;
							}
							return false;
						});
					}
				})
                ->make(true);
		return view('excel.balanceexport', [
            'exports' => $exports->getData()->data
        ]);
    }

    public function registerEvents(): array
    {
        //border style
		$styleArray = [
            'borders' => [
                'outline' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                //'color' => ['argb' => 'FFFF0000'],
                    ],
                ],
            ];
            
		//font style	
		$styleArray1 = [
            'font' => [
                'bold' => true,
                ]
            ];
        
		//column  text alignment
		$styleArray2 = array(
			'alignment' => array(
				'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
				 )
		);				
		
		//$styleArray3 used for vertical alignment 
		$styleArray3 = array(
			'alignment' => array(
				'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
				 )
		);
		

		$styleArray4 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_GRADIENT_LINEAR,
        'startColor' => [
        'argb' => 'FFA0A0A0',
        ],
        'endColor' => [
            'argb' => 'FFFFFFFF',
        ]]
					);
		
		$styleArray5 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
        
        'startColor' => [
            'rgb' => '00BFFF',
        ]]);
		
        return [
            AfterSheet::class => function(AfterSheet $event) use ($styleArray, $styleArray1,$styleArray2, $styleArray3, $styleArray4, $styleArray5)
            {$cellRange = 'A1:H1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(13);
                $event->sheet->getStyle($cellRange)->ApplyFromArray($styleArray);
                $event->sheet->getStyle('A1:H1')->ApplyFromArray($styleArray);
            
            
        //Heading formatting...
        $event->getSheet()->setAutoFilter('A1:H1');
        $event->getSheet()->getDelegate()->getStyle('A1:H1')->applyFromArray($styleArray);						
        $event->getSheet()->getDelegate()->getStyle('A1:H1')->applyFromArray($styleArray1);
            
        //used for making bold
        $event->getSheet()->getDelegate()->getStyle('A1:H1')->applyFromArray($styleArray1);
                       
        //column width set							
        $event ->sheet-> getDelegate()->getColumnDimension('A')->setWidth(65);
        $event ->sheet-> getDelegate()->getColumnDimension('B')->setWidth(64);
        $event ->sheet-> getDelegate()->getColumnDimension('C')->setWidth(13);
                    
                    
        //D - H column width set to 17
        $columns = ['D', 'E', 'F', 'G', 'H'];
            foreach ($columns as $column) {
                $event ->sheet-> getDelegate()->getColumnDimension($column)->setWidth(17);	
                    }
                    
        //D1 - H1 text wrapping...
        $event ->sheet->getStyle('D1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('E1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('F1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('G1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('H1')->getAlignment()->setWrapText(true);
                    
        //text center columns...
        $event ->sheet->getStyle('A1:A10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('B1:B10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('C1:C10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('D1:D10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('E1:E10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('F1:F10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('G1:G10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('H1:H10000')->applyFromArray($styleArray2);
                    
        //headings vertical alignment 
        $event ->sheet->getStyle('A1:H1')->applyFromArray($styleArray3); 
        //sums color formatting..
        $event ->sheet->getStyle('A1:H1')->applyFromArray($styleArray5);
            },
        ];

    }
}
