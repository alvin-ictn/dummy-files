<?php

namespace App\Exports;

use Carbon\Carbon;
use DataTables;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Session;

class MovementInquiryExport implements FromView, ShouldAutoSize, WithEvents
{
    use Exportable;
	
    function __construct($clinic_code, $drugs_code, $from_date, $to_date, $no, $date, $transno, $type, $uom, $qty, $search)
	{
        $this->clinic_code = $clinic_code;
        $this->drugs_code = $drugs_code;
        $this->from_date = $from_date;
        $this->to_date = $to_date;
        $this->no = $no;
        $this->date = $date;
		$this->transno = $transno;
        $this->type = $type;
        $this->uom = $uom;
		$this->qty = $qty;
        $this->search = $search;
    }

    public function view(): view
    {
		
        $VCLINICCODE = $this->clinic_code;
        $VDRUGSCODE = $this->drugs_code;
        $SDATE = Carbon::parse($this->from_date)->format('Y-m-d');
		$EDATE = Carbon::parse($this->to_date)->format('Y-m-d');  
		
        $sp = \DB::select("EXEC sp_ItemMovementHistory ?,?,?,?", array($VCLINICCODE, $VDRUGSCODE, $SDATE, $EDATE));

		$no = $this->no;
		$date = $this->date;
        $transno = $this->transno;
        $type = $this->type;
        $uom = $this->uom;
		$qty = $this->qty;
		$search = $this->search;
		
		$exports = DataTables::of($sp)
                ->addIndexColumn()
				->filter(function ($instance) use ($no, $date, $transno, $type, $uom, $qty, $search) {
					if (!empty($no))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($no)
						{
							return Str::contains(Str::lower($row['No']), Str::lower($no));
						});
					}
					if (!empty($date))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($date)
						{
							$dot = Carbon::parse($date)->format('d-M-Y');
							return Str::contains($row['DCREA'], $dot) ? true : false;
						});
					}
					if (!empty($transno))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($transno)
						{
							return Str::contains(Str::lower($row['VTRXNO']), Str::lower($transno));
						});
					}
					if (!empty($type))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($type)
						{
							return Str::contains(Str::lower($row['VTYPE']), Str::lower($type));
						});
					}
					if (!empty($uom))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($uom)
						{
							return Str::contains(Str::lower($row['VUOM']), Str::lower($uom));
						});
					}
					if (!empty($qty))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($qty)
						{
							return Str::contains(Str::lower($row['IQTY']), Str::lower($qty));
						});
					}
					if (!empty($search))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($search)
						{
							if (Str::contains(Str::lower($row['No']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DCREA']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VTRXNO']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VTYPE']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VUOM']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['IQTY']), Str::lower($search)))
							{
								return true;
							}
							return false;
						});
					}
				})
                ->make(true);
		return view('excel.movementinquiryexport', [
            'exports' => $exports->getData()->data
        ]);
    }

    public function registerEvents(): array
    {
        //border style
		$styleArray = [
            'borders' => [
                'outline' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                //'color' => ['argb' => 'FFFF0000'],
                    ],
                ],
            ];
            
		//font style	
		$styleArray1 = [
            'font' => [
                'bold' => true,
                ]
            ];
        
		//column  text alignment
		$styleArray2 = array(
			'alignment' => array(
				'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
				 )
		);				
		
		//$styleArray3 used for vertical alignment 
		$styleArray3 = array(
			'alignment' => array(
				'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
				 )
		);
		

		$styleArray4 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_GRADIENT_LINEAR,
        'startColor' => [
        'argb' => 'FFA0A0A0',
        ],
        'endColor' => [
            'argb' => 'FFFFFFFF',
        ]]
					);
		
		$styleArray5 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
        
        'startColor' => [
            'rgb' => '00BFFF',
        ]]);
		
        return [
            AfterSheet::class => function(AfterSheet $event) use ($styleArray, $styleArray1,$styleArray2, $styleArray3, $styleArray4, $styleArray5)
            {$cellRange = 'A1:F1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(13);
                $event->sheet->getStyle($cellRange)->ApplyFromArray($styleArray);
                $event->sheet->getStyle('A1:F1')->ApplyFromArray($styleArray);
            
            
        //Heading formatting...
        $event->getSheet()->setAutoFilter('A1:F1');
        $event->getSheet()->getDelegate()->getStyle('A1:F1')->applyFromArray($styleArray);						
        $event->getSheet()->getDelegate()->getStyle('A1:F1')->applyFromArray($styleArray1);
            
        //used for making bold
        $event->getSheet()->getDelegate()->getStyle('A1:F1')->applyFromArray($styleArray1);
                       
        //column width set							
        $event ->sheet-> getDelegate()->getColumnDimension('A')->setWidth(65);
        $event ->sheet-> getDelegate()->getColumnDimension('B')->setWidth(64);
        $event ->sheet-> getDelegate()->getColumnDimension('C')->setWidth(13);
                    
                    
        //D - F column width set to 17
        $columns = ['D', 'E', 'F'];
            foreach ($columns as $column) {
                $event ->sheet-> getDelegate()->getColumnDimension($column)->setWidth(17);	
                    }
                    
        //D1 - F1 text wrapping...
        $event ->sheet->getStyle('D1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('E1')->getAlignment()->setWrapText(false);
        $event ->sheet->getStyle('F1')->getAlignment()->setWrapText(true);
                    
        //text center columns...
        $event ->sheet->getStyle('A1:A10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('B1:B10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('C1:C10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('D1:D10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('E1:E10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('F1:F10000')->applyFromArray($styleArray2);
                    
        //headings vertical alignment 
        $event ->sheet->getStyle('A1:F1')->applyFromArray($styleArray3); 
        //sums color formatting..
        $event ->sheet->getStyle('A1:F1')->applyFromArray($styleArray5);
            },
        ];

    }
}
