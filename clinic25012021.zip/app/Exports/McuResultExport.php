<?php

namespace App\Exports;

use App\Mstusers;
use Carbon\Carbon;
use DataTables;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Session;

class McuResultExport implements FromView, ShouldAutoSize, WithEvents
{
    use Exportable;
	
    function __construct($no, $registration_no, $sap_id, $employee_name, $department, $verified_date, $completed_date, $result_date, $search)
	{
        $this->no = $no;
        $this->registration_no = $registration_no;
		$this->sap_id = $sap_id;
        $this->employee_name = $employee_name;
        $this->department = $department;
		$this->verified_date = $verified_date;
		$this->completed_date = $completed_date;
		$this->result_date = $result_date;
        $this->search = $search;
    }

    public function view(): view
    {
		$SDATE = '2000-01-01';
		$EDATE = '2100-01-01';

		if (in_array("ADM", Session::get('groupuser')) || in_array("ANALYST", Session::get('groupuser')) || in_array("PRMDC", Session::get('groupuser')) || in_array("DCTR", Session::get('groupuser')) || in_array("HRADM", Session::get('groupuser')))
		{
			$resultmcusel = DB::select("EXEC sp_ResultMCU 'ALL', 'ALL', '" . $SDATE . "', '" . $EDATE . "'");
		}
		else if (in_array("HRRCT", Session::get('groupuser')) !== false)
		{
			$resultmcusel = DB::select("EXEC sp_ResultMCU 'ALL', '" . Session::get('id') . "', '" . $SDATE . "', '" . $EDATE . "'");
		}
		else
		{
			$vidno = Mstusers::where('MEDSYS_MSTUSERS.VUSRID', Session::get('id'))
						->leftjoin('MEDSYS_MSTEMPLOYEES', function ($join) { $join->on('MEDSYS_MSTEMPLOYEES.VUSRID', '=', 'MEDSYS_MSTUSERS.VUSRID')->where('MEDSYS_MSTEMPLOYEES.BACTIVE', '1'); })
						->leftjoin('MEDSYS_MSTCLINICSTAFFS', 'MEDSYS_MSTCLINICSTAFFS.VUSRID', '=', 'MEDSYS_MSTUSERS.VUSRID')
						->select(DB::raw('COALESCE(MEDSYS_MSTEMPLOYEES.VEMPSAPID, MEDSYS_MSTCLINICSTAFFS.VUSRID) AS VIDNO'))
						->first()->VIDNO;
			$resultmcusel = DB::select("EXEC sp_ResultMCU '" . $vidno . "', 'ALL', '" . $SDATE . "', '" . $EDATE . "'");
		}

		$no = $this->no;
		$registration_no = $this->registration_no;
        $sap_id = $this->sap_id;
        $employee_name = $this->employee_name;
        $department = $this->department;
		$verified_date = $this->verified_date;
		$completed_date = $this->completed_date;
		$result_date = $this->result_date;
		$search = $this->search;
		
		$exports = DataTables::of($resultmcusel)
                ->addIndexColumn()
				->filter(function ($instance) use ($no, $registration_no, $sap_id, $employee_name, $department, $verified_date, $completed_date, $result_date, $search) {
					if (!empty($no))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($no)
						{
							return Str::contains(Str::lower($row['No']), Str::lower($no));
						});
					}
					if (!empty($registration_no))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($registration_no)
						{
							return Str::contains(Str::lower($row['VREGNO']), Str::lower($registration_no));
						});
					}
					if (!empty($sap_id))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($sap_id)
						{
							return Str::contains(Str::lower($row['VIDNO']), Str::lower($sap_id));
						});
					}
					if (!empty($employee_name))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($employee_name)
						{
							return Str::contains(Str::lower($row['EMPNAME']), Str::lower($employee_name));
						});
					}
					if (!empty($department))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($department)
						{
							return Str::contains(Str::lower($row['DEPARTMENT']), Str::lower($department));
						});
					}
					if (!empty($verified_date))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($verified_date)
						{
							$dot = Carbon::parse($verified_date)->format('d-M-Y');
							return Str::contains($row['DVERIFIED'], $dot) ? true : false;
						});
					}
					if (!empty($completed_date))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($completed_date)
						{
							$dot = Carbon::parse($completed_date)->format('d-M-Y');
							return Str::contains($row['DCOMPLETED'], $dot) ? true : false;
						});
					}
					if (!empty($result_date))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($result_date)
						{
							$dot = Carbon::parse($result_date)->format('d-M-Y');
							return Str::contains($row['DRESULT'], $dot) ? true : false;
						});
					}
					if (!empty($search))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($search)
						{
							if (Str::contains(Str::lower($row['No']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VREGNO']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VIDNO']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['EMPNAME']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DEPARTMENT']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DVERIFIED']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DCOMPLETED']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DRESULT']), Str::lower($search)))
							{
								return true;
							}
							return false;
						});
					}
				})
                ->make(true);
		return view('excel.mcuresultexport', [
            'exports' => $exports->getData()->data
        ]);
    }

    public function registerEvents(): array
    {
        //border style
		$styleArray = [
            'borders' => [
                'outline' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                //'color' => ['argb' => 'FFFF0000'],
                    ],
                ],
            ];
            
		//font style	
		$styleArray1 = [
            'font' => [
                'bold' => true,
                ]
            ];
        
		//column  text alignment
		$styleArray2 = array(
			'alignment' => array(
				'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
				 )
		);				
		
		//$styleArray3 used for vertical alignment 
		$styleArray3 = array(
			'alignment' => array(
				'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
				 )
		);
		

		$styleArray4 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_GRADIENT_LINEAR,
        'startColor' => [
        'argb' => 'FFA0A0A0',
        ],
        'endColor' => [
            'argb' => 'FFFFFFFF',
        ]]
					);
		
		$styleArray5 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
        
        'startColor' => [
            'rgb' => '00BFFF',
        ]]);
		
        return [
            AfterSheet::class => function(AfterSheet $event) use ($styleArray, $styleArray1,$styleArray2, $styleArray3, $styleArray4, $styleArray5)
            {$cellRange = 'A1:H1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(13);
                $event->sheet->getStyle($cellRange)->ApplyFromArray($styleArray);
                $event->sheet->getStyle('A1:H1')->ApplyFromArray($styleArray);
            
            
        //Heading formatting...
        $event->getSheet()->setAutoFilter('A1:H1');
        $event->getSheet()->getDelegate()->getStyle('A1:H1')->applyFromArray($styleArray);						
        $event->getSheet()->getDelegate()->getStyle('A1:H1')->applyFromArray($styleArray1);
            
        //used for making bold
        $event->getSheet()->getDelegate()->getStyle('A1:H1')->applyFromArray($styleArray1);
                       
        //column width set							
        $event ->sheet-> getDelegate()->getColumnDimension('A')->setWidth(65);
        $event ->sheet-> getDelegate()->getColumnDimension('B')->setWidth(64);
        $event ->sheet-> getDelegate()->getColumnDimension('C')->setWidth(13);
                    
                    
        //D - H column width set to 17
        $columns = ['D', 'E', 'F', 'G', 'H'];
            foreach ($columns as $column) {
                $event ->sheet-> getDelegate()->getColumnDimension($column)->setWidth(17);	
                    }
                    
        //D1 - H1 text wrapping...
        $event ->sheet->getStyle('D1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('E1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('F1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('G1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('H1')->getAlignment()->setWrapText(true);
                    
        //text center columns...
        $event ->sheet->getStyle('A1:A10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('B1:B10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('C1:C10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('D1:D10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('E1:E10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('F1:F10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('G1:G10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('H1:H10000')->applyFromArray($styleArray2);
                    
        //headings vertical alignment 
        $event ->sheet->getStyle('A1:H1')->applyFromArray($styleArray3); 
        //sums color formatting..
        $event ->sheet->getStyle('A1:H1')->applyFromArray($styleArray5);
            },
        ];

    }
}
