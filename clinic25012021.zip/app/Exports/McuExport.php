<?php

namespace App\Exports;

use App\Mstemployees;
use Carbon\Carbon;
use DataTables;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Session;

class McuExport implements FromView, ShouldAutoSize, WithEvents
{
    use Exportable;
	
    function __construct($from_date, $to_date, $registration_no, $sap_id, $employee_name, $personnel_area, $sub_personnel_area, $cost_center, $package, $gender, $reserved_date, $time, $document_status, $verified_date, $completed_date, $created_name, $created_date, $last_modified_name, $modified_date, $search)
	{
        $this->from_date = $from_date;
        $this->to_date = $to_date;
        $this->registration_no = $registration_no;
        $this->sap_id = $sap_id;
        $this->employee_name = $employee_name;
        $this->personnel_area = $personnel_area;
        $this->sub_personnel_area = $sub_personnel_area;
        $this->cost_center = $cost_center;
        $this->package = $package;
        $this->gender = $gender;
        $this->reserved_date = $reserved_date;
		$this->time = $time;
		$this->document_status = $document_status;
		$this->verified_date = $verified_date;
		$this->completed_date = $completed_date;
		$this->created_name = $created_name;
		$this->created_date = $created_date;
		$this->last_modified_name = $last_modified_name;
		$this->modified_date = $modified_date;
        $this->search = $search;
    }

    public function view(): view
    {
		$SDATE = $this->from_date;
		$EDATE = $this->to_date;
		if (in_array("HRADM", Session::get('groupuser')) !== false || (in_array("ADM", Session::get('groupuser')) !== false && Session::get('namaclinic') == 'TS1'))
		{
			$VIDNO = 'ALL';
			$VCREA = 'ALL';
		}
		else if (RoleAccessController::FunctionAccessCheck('C', 'F33'))
		{
			$VIDNO = 'ALL';
			$VCREA = Session::get('id');
		}
		else
		{
			$VIDNO = Mstemployees::where('VUSRID', Session::get('id'))->first()->VEMPSAPID;
			$VCREA = 'ALL';
		}
		$mcusel = DB::select("EXEC sp_RegisterMCU ?, ?, ?, ?", [$VIDNO, $VCREA, $SDATE, $EDATE]);
		$registration_no = $this->registration_no;
        $sap_id = $this->sap_id;
        $employee_name = $this->employee_name;
		$personnel_area = $this->personnel_area;
        $sub_personnel_area = $this->sub_personnel_area;
        $cost_center = $this->cost_center;
        $package = $this->package;
		$gender = $this->gender;
        $reserved_date = $this->reserved_date;
		$time = $this->time;
		$document_status = $this->document_status;
		$verified_date = $this->verified_date;
		$completed_date = $this->completed_date;
		$created_name = $this->created_name;
		$created_date = $this->created_date;
		$last_modified_name = $this->last_modified_name;
		$modified_date = $this->modified_date;
        $search = $this->search;
		$exports = DataTables::of($mcusel)
                ->addIndexColumn()
				->filter(function ($instance) use ($registration_no, $sap_id, $employee_name, $personnel_area, $sub_personnel_area, $cost_center, $package, $gender, $reserved_date, $time, $document_status, $verified_date, $completed_date, $created_name, $created_date, $last_modified_name, $modified_date, $search) {
					if (!empty($registration_no))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($registration_no)
						{
							return Str::contains(Str::lower($row['VREGNO']), Str::lower($registration_no));
						});
					}
					if (!empty($sap_id))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($sap_id)
						{
							return Str::contains(Str::lower($row['VIDNO']), Str::lower($sap_id));
						});
					}
					if (!empty($employee_name))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($employee_name)
						{
							return Str::contains(Str::lower($row['EMPNAME']), Str::lower($employee_name));
						});
					}
					if (!empty($personnel_area))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($personnel_area)
						{
							return Str::contains(Str::lower($row['PERSONALAREA']), Str::lower($personnel_area));
						});
					}
					if (!empty($sub_personnel_area))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($sub_personnel_area)
						{
							return Str::contains(Str::lower($row['SUBPERSONALAREA']), Str::lower($sub_personnel_area));
						});
					}
					if (!empty($cost_center))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($cost_center)
						{
							return Str::contains(Str::lower($row['COSTCENTER']), Str::lower($cost_center));
						});
					}
					if (!empty($package))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($package)
						{
							return Str::contains(Str::lower($row['PACKAGE']), Str::lower($package));
						});
					}
					if (!empty($gender))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($gender)
						{
							return Str::contains(Str::lower($row['GENDER']), Str::lower($gender));
						});
					}
					if (!empty($reserved_date))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($reserved_date)
						{
							$dot = Carbon::parse($reserved_date)->format('d-M-Y');
							return Str::contains($row['DRESERVED'], $dot) ? true : false;
						});
					}
					if (!empty($time))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($time)
						{
							return Str::contains(Str::lower($row['TSESSIONTIME']), Str::lower($time));
						});
					}
					if (!empty($document_status))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($document_status)
						{
							return Str::contains(Str::lower($row['VDOCSTATUS']), Str::lower($document_status));
						});
					}
					if (!empty($verified_date))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($verified_date)
						{
							$dot = Carbon::parse($verified_date)->format('d-M-Y');
							return Str::contains($row['DVERIFIED'], $dot) ? true : false;
						});
					}
					if (!empty($completed_date))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($completed_date)
						{
							$dot = Carbon::parse($completed_date)->format('d-M-Y');
							return Str::contains($row['DCOMPLETED'], $dot) ? true : false;
						});
					}
					if (!empty($created_name))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($created_name)
						{
							return Str::contains(Str::lower($row['VCREA']), Str::lower($created_name));
						});
					}
					if (!empty($created_date))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($created_date)
						{
							$dot = Carbon::parse($created_date)->format('d-M-Y');
							return Str::contains($row['DCREA'], $dot) ? true : false;
						});
					}
					if (!empty($last_modified_name))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($last_modified_name)
						{
							return Str::contains(Str::lower($row['VMODI']), Str::lower($last_modified_name));
						});
					}
					if (!empty($modified_date))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($modified_date)
						{
							$dot = Carbon::parse($modified_date)->format('d-M-Y');
							return Str::contains($row['DMODI'], $dot) ? true : false;
						});
					}
					if (!empty($search))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($search)
						{
							if (Str::contains(Str::lower($row['VREGNO']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VIDNO']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['EMPNAME']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['PERSONALAREA']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['SUBPERSONALAREA']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['COSTCENTER']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['PACKAGE']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['GENDER']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DRESERVED']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['TSESSIONTIME']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VDOCSTATUS']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DVERIFIED']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DCOMPLETED']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VCREA']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DCREA']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VMODI']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DMODI']), Str::lower($search)))
							{
								return true;
							}
							return false;
						});
					}
				})
                ->make(true);
		return view('excel.mcuexport', [
            'exports' => $exports->getData()->data
        ]);
    }

    public function registerEvents(): array
    {
        //border style
		$styleArray = [
            'borders' => [
                'outline' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                //'color' => ['argb' => 'FFFF0000'],
                    ],
                ],
            ];
            
		//font style	
		$styleArray1 = [
            'font' => [
                'bold' => true,
                ]
            ];
        
		//column  text alignment
		$styleArray2 = array(
			'alignment' => array(
				'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
				 )
		);				
		
		//$styleArray3 used for vertical alignment 
		$styleArray3 = array(
			'alignment' => array(
				'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
				 )
		);
		

		$styleArray4 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_GRADIENT_LINEAR,
        'startColor' => [
        'argb' => 'FFA0A0A0',
        ],
        'endColor' => [
            'argb' => 'FFFFFFFF',
        ]]
					);
		
		$styleArray5 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
        
        'startColor' => [
            'rgb' => '00BFFF',
        ]]);
		
        return [
            AfterSheet::class => function(AfterSheet $event) use ($styleArray, $styleArray1,$styleArray2, $styleArray3, $styleArray4, $styleArray5)
            {$cellRange = 'A1:Q1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(13);
                $event->sheet->getStyle($cellRange)->ApplyFromArray($styleArray);
                $event->sheet->getStyle('A1:Q1')->ApplyFromArray($styleArray);
            
            
        //Heading formatting...
        $event->getSheet()->setAutoFilter('A1:Q1');
        $event->getSheet()->getDelegate()->getStyle('A1:Q1')->applyFromArray($styleArray);						
        $event->getSheet()->getDelegate()->getStyle('A1:Q1')->applyFromArray($styleArray1);
            
        //used for making bold
        $event->getSheet()->getDelegate()->getStyle('A1:Q1')->applyFromArray($styleArray1);
                       
        //column width set							
        $event ->sheet-> getDelegate()->getColumnDimension('A')->setWidth(65);
        $event ->sheet-> getDelegate()->getColumnDimension('B')->setWidth(64);
        $event ->sheet-> getDelegate()->getColumnDimension('C')->setWidth(13);
                    
                    
        //D - Q column width set to 17
        $columns = ['D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q'];
            foreach ($columns as $column) {
                $event ->sheet-> getDelegate()->getColumnDimension($column)->setWidth(17);	
                    }
                    
        //D1 - Q1 text wrapping...
        $event ->sheet->getStyle('D1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('E1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('F1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('G1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('H1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('I1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('J1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('K1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('L1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('M1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('N1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('O1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('P1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('Q1')->getAlignment()->setWrapText(true);
                    
        //text center columns...
        $event ->sheet->getStyle('A1:A10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('B1:B10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('C1:C10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('D1:D10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('E1:E10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('F1:F10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('G1:G10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('H1:H10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('I1:I10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('J1:J10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('K1:K10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('L1:L10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('M1:M10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('N1:N10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('O1:O10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('P1:P10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('Q1:Q10000')->applyFromArray($styleArray2);
                    
        //headings vertical alignment 
        $event ->sheet->getStyle('A1:Q1')->applyFromArray($styleArray3); 
        //sums color formatting..
        $event ->sheet->getStyle('A1:Q1')->applyFromArray($styleArray5);
            },
        ];

    }
}
