<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\WithHeadings; 
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Events\AfterSheet;
use Maatwebsite\Excel\Concerns\WithEvents;

use Maatwebsite\Excel\Concerns\WithCustomStartCell;

class RpengunjungExport implements WithHeadings 
    

{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function headings(): array

    {

        return[
            [
              'Program Name',
              'Project Lead',
              'DS&E Contact',
              'Name of external service provider',
              'Prepared By',
              'External Service Provider Contact Information',
              'Time Period Covered',
              'Program ID',
              'Date of Report',
              'Data Type',
              'Signature'
            ],
            [
                'Id',
                'Date of report',
                'Date',
                'URL',
                'Username',
                'Reporter Type',
                'Product Name',
                'Verbatim',
                'Priority',            
                'AE Raised',
                'User',
                'Date From',
                'Date Till',
                'Record Created At',
                'Record Updated At'
            ]                   
        ];

    }
    // public function view(): view
    // {
    //     return view('excel.reportkunjunganexport');
    // }
}
