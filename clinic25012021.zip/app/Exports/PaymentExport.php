<?php

namespace App\Exports;

use Carbon\Carbon;
use DataTables;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use Session;

class PaymentExport implements FromView, ShouldAutoSize, WithEvents
{
    use Exportable;
	
    function __construct($clinic_code, $start_date, $end_date, $type, $no, $mr_no, $booking_no, $doctor, $patient_name, $patient_type, $date_of_birth, $gender, $last_visit_date, $phone_no, $status, $total, $last_modified_name, $last_modified_date, $search)
	{
        $this->clinic_code = $clinic_code;
        $this->start_date = $start_date;
        $this->end_date = $end_date;
        $this->type = $type;
        $this->no = $no;
        $this->mr_no = $mr_no;
        $this->booking_no = $booking_no;
		$this->doctor = $doctor;
		$this->patient_name = $patient_name;
        $this->patient_type = $patient_type;
        $this->date_of_birth = $date_of_birth;
		$this->gender = $gender;
		$this->last_visit_date = $last_visit_date;
		$this->phone_no = $phone_no;
		$this->status = $status;
		$this->total = $total;
		$this->last_modified_name = $last_modified_name;
		$this->last_modified_date = $last_modified_date;
        $this->search = $search;
    }

    public function view(): view
    {
		$sp = \DB::select("EXEC sp_PaymentList ?,?,?,?", array($this->clinic_code,$this->start_date,$this->end_date,$this->type));
		
		$no = $this->no;
		$mr_no = $this->mr_no;
		$booking_no = $this->booking_no;
		$doctor = $this->doctor;
        $patient_name = $this->patient_name;
        $patient_type = $this->patient_type;
        $date_of_birth = $this->date_of_birth;
		$gender = $this->gender;
		$last_visit_date = $this->last_visit_date;
		$phone_no = $this->phone_no;
		$status = $this->status;
		$total = $this->total;
		$last_modified_name = $this->last_modified_name;
		$last_modified_date = $this->last_modified_date;
		$search = $this->search;
		
		$exports = DataTables::of($sp)
                ->addIndexColumn()
				->filter(function ($instance) use ($no, $mr_no, $booking_no, $doctor, $patient_name, $patient_type, $date_of_birth, $gender, $last_visit_date, $phone_no, $status, $total, $last_modified_name, $last_modified_date, $search) {
					if (!empty($no))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($no)
						{
							return Str::contains(Str::lower($row['No']), Str::lower($no));
						});
					}
					if (!empty($mr_no))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($mr_no)
						{
							return Str::contains(Str::lower($row['VMRNO']), Str::lower($mr_no));
						});
					}
					if (!empty($booking_no))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($booking_no)
						{
							return Str::contains(Str::lower($row['VBOOKINGNO']), Str::lower($booking_no));
						});
					}
					if (!empty($doctor))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($doctor)
						{
							return Str::contains(Str::lower($row['DOCTOR']), Str::lower($doctor));
						});
					}
					if (!empty($patient_name))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($patient_name)
						{
							return Str::contains(Str::lower($row['VNAME']), Str::lower($patient_name));
						});
					}
					if (!empty($patient_type))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($patient_type)
						{
							return Str::contains(Str::lower($row['VTYPEPATIENT']), Str::lower($patient_type));
						});
					}
					if (!empty($date_of_birth))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($date_of_birth)
						{
							$dot = Carbon::parse($date_of_birth)->format('d-M-Y');
							return Str::contains(Carbon::parse($row['DBIRTH'])->format('d-M-Y'), $dot) ? true : false;
						});
					}
					if (!empty($gender))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($gender)
						{
							return Str::contains($row['GENDER'], $dot) ? true : false;
						});
					}
					if (!empty($last_visit_date))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($last_visit_date)
						{
							$dot = Carbon::parse($last_visit_date)->format('d-M-Y');
							return Str::contains(Carbon::parse($row['LASTVISITDATE'])->format('d-M-Y'), $dot) ? true : false;
						});
					}
					if (!empty($phone_no))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($phone_no)
						{
							return Str::contains(Str::lower($row['VPHONENO']), Str::lower($phone_no));
						});
					}
					if (!empty($status))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($status)
						{
							return Str::contains(Str::lower($row['STATUS']), Str::lower($status));
						});
					}
					if (!empty($total))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($total)
						{
							return Str::contains(Str::lower($row['TOTAL']), Str::lower($total));
						});
					}
					if (!empty($last_modified_name))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($last_modified_name)
						{
							return Str::contains(Str::lower($row['VMODI']), Str::lower($last_modified_name));
						});
					}
					if (!empty($last_modified_date))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($last_modified_date)
						{
							return Str::contains(Str::lower($row['DMODI']), Str::lower($last_modified_date));
						});
					}
					if (!empty($search))
					{
						$instance->collection = $instance->collection->filter(function ($row) use ($search)
						{
							if (Str::contains(Str::lower($row['No']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VMRNO']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VBOOKINGNO']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DOCTOR']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VNAME']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VTYPEPATIENT']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DBIRTH']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['GENDER']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['LASTVISITDATE']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VPHONENO']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['STATUS']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['TOTAL']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['VMODI']), Str::lower($search)))
							{
								return true;
							}
							else if (Str::contains(Str::lower($row['DMODI']), Str::lower($search)))
							{
								return true;
							}
							return false;
						});
					}
				})
                ->make(true);
		return view('excel.paymentexport', [
            'exports' => $exports->getData()->data
        ]);
    }

    public function registerEvents(): array
    {
        //border style
		$styleArray = [
            'borders' => [
                'outline' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                //'color' => ['argb' => 'FFFF0000'],
                    ],
                ],
            ];
            
		//font style	
		$styleArray1 = [
            'font' => [
                'bold' => true,
                ]
            ];
        
		//column  text alignment
		$styleArray2 = array(
			'alignment' => array(
				'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
				 )
		);				
		
		//$styleArray3 used for vertical alignment 
		$styleArray3 = array(
			'alignment' => array(
				'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
				 )
		);
		

		$styleArray4 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_GRADIENT_LINEAR,
        'startColor' => [
        'argb' => 'FFA0A0A0',
        ],
        'endColor' => [
            'argb' => 'FFFFFFFF',
        ]]
					);
		
		$styleArray5 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
        
        'startColor' => [
            'rgb' => '00BFFF',
        ]]);
		
        return [
            AfterSheet::class => function(AfterSheet $event) use ($styleArray, $styleArray1,$styleArray2, $styleArray3, $styleArray4, $styleArray5)
            {$cellRange = 'A1:N1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(13);
                $event->sheet->getStyle($cellRange)->ApplyFromArray($styleArray);
                $event->sheet->getStyle('A1:N1')->ApplyFromArray($styleArray);
            
            
        //Heading formatting...
        $event->getSheet()->setAutoFilter('A1:N1');
        $event->getSheet()->getDelegate()->getStyle('A1:N1')->applyFromArray($styleArray);						
        $event->getSheet()->getDelegate()->getStyle('A1:N1')->applyFromArray($styleArray1);
            
        //used for making bold
        $event->getSheet()->getDelegate()->getStyle('A1:N1')->applyFromArray($styleArray1);
                       
        //column width set							
        $event ->sheet-> getDelegate()->getColumnDimension('A')->setWidth(65);
        $event ->sheet-> getDelegate()->getColumnDimension('B')->setWidth(64);
        $event ->sheet-> getDelegate()->getColumnDimension('C')->setWidth(13);
                    
                    
        //D - I column width set to 17
        $columns = ['D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N'];
            foreach ($columns as $column) {
                $event ->sheet-> getDelegate()->getColumnDimension($column)->setWidth(17);	
                    }
                    
        //D1 - K1 text wrapping...
        $event ->sheet->getStyle('D1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('E1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('F1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('G1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('H1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('I1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('J1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('K1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('L1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('M1')->getAlignment()->setWrapText(true);
        $event ->sheet->getStyle('N1')->getAlignment()->setWrapText(true);
                    
        //text center columns...
        $event ->sheet->getStyle('A1:A10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('B1:B10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('C1:C10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('D1:D10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('E1:E10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('F1:F10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('G1:G10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('H1:H10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('I1:I10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('J1:J10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('K1:K10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('L1:L10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('M1:M10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('N1:N10000')->applyFromArray($styleArray2);
                    
        // Set Column Phone No. format to Number
		$event->sheet->getStyle('J2:J10000')->getNumberFormat()->setFormatCode('0');
		
        //headings vertical alignment 
        $event ->sheet->getStyle('A1:N1')->applyFromArray($styleArray3); 
        //sums color formatting..
        $event ->sheet->getStyle('A1:N1')->applyFromArray($styleArray5);
            },
        ];

    }
}
