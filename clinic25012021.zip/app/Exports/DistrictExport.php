<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\WithHeadings; 
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Events\AfterSheet;
use Maatwebsite\Excel\Concerns\WithEvents;

class DistrictExport implements FromView ,WithHeadings , ShouldAutoSize, WithEvents
{
    use Exportable;

    function __construct($no,$code,$name,$provname,$lastmo,$status,$modifiedn,$search) {
        $this->no = $no;
        $this->code = $code;
        $this->name = $name;
        $this->provname = $provname;
        $this->lastmo = $lastmo;
        $this->status = $status;
        $this->lmname = $modifiedn;
        $this->search = $search;

    }
    public function headings(): array
    {
        return 
        [
            'head1',
            'head2',
            'head3',
            'head4',
            'head5',
        'head6',
        'head7',
        ];
    }

    public function view(): view
    {

        return view('excel.districtexport', [
            'district' => \DB::select("  WITH setting AS (
                SELECT ROW_NUMBER() OVER(ORDER BY (MODIFY_DATE) ASC,YEAR(MODIFY_DATE) ASC,MODIFY_DATE ASC) row_num, DISTRICTCODE, DISTRICTNAME, PROV_NAME, STATUS, MODIFY_DATE, MODIFY_NAME 
                FROM vw_mstdistrict
            ) SELECT row_num, DISTRICTCODE, DISTRICTNAME, PROV_NAME, STATUS, MODIFY_DATE, MODIFY_NAME 
            FROM setting
            WHERE row_num LIKE '%$this->no%'
            AND ISNULL(DISTRICTCODE,'') LIKE '%$this->code%'
            AND ISNULL(DISTRICTNAME,'')  LIKE '%$this->name%'
            AND ISNULL(PROV_NAME,'')  LIKE '%$this->provname%'
            AND ISNULL(STATUS,'')  LIKE '%$this->status%'
            AND ISNULL(MODIFY_NAME,'')  LIKE '%$this->lmname%'
            AND CONVERT(varchar,MODIFY_DATE,103) LIKE '%$this->lastmo%' 
            
            AND (row_num LIKE '%$this->search%'
            OR ISNULL(DISTRICTCODE,'') LIKE '%$this->search%'
            OR ISNULL(DISTRICTNAME,'')  LIKE '%$this->search%'
            OR ISNULL(PROV_NAME,'')  LIKE '%$this->search%'
            OR ISNULL(STATUS,'')  LIKE '%$this->search%'
            OR ISNULL(MODIFY_NAME,'')  LIKE '%$this->search%'
            OR CONVERT(varchar,MODIFY_DATE,103) LIKE '%$this->search%')
            ")
        ]);
    }

    public function registerEvents(): array
    {
        //border style
		$styleArray = [
            'borders' => [
                'outline' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                //'color' => ['argb' => 'FFFF0000'],
                    ],
                ],
            ];
            
		//font style	
		$styleArray1 = [
            'font' => [
                'bold' => true,
                ]
            ];
        
		//column  text alignment
		$styleArray2 = array(
			'alignment' => array(
				'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
				 )
		);				
		
		//$styleArray3 used for vertical alignment 
		$styleArray3 = array(
			'alignment' => array(
				'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
				 )
		);
		

		$styleArray4 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_GRADIENT_LINEAR,
        'startColor' => [
        'argb' => 'FFA0A0A0',
        ],
        'endColor' => [
            'argb' => 'FFFFFFFF',
        ]]
					);
		
		$styleArray5 = array(
						'fill' => [
        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
        
        'startColor' => [
            'rgb' => '00BFFF',
        ]]);
		
        return [
            AfterSheet::class => function(AfterSheet $event) use ($styleArray, $styleArray1,$styleArray2, $styleArray3, $styleArray4, $styleArray5)
            {$cellRange = 'A1:G1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(13);
                $event->sheet->getStyle($cellRange)->ApplyFromArray($styleArray);
                $event->sheet->getStyle('A1:G1')->ApplyFromArray($styleArray);
            
        //Heading formatting...
        $event->getSheet()->setAutoFilter('A1:G1');

        $event->getSheet()->getDelegate()->getStyle('A1:G1')->applyFromArray($styleArray);						
        $event->getSheet()->getDelegate()->getStyle('A1:G1')->applyFromArray($styleArray1);
            
        //used for making bold
        $event->getSheet()->getDelegate()->getStyle('A1:G1')->applyFromArray($styleArray1);
                       
        //column width set							
        $event ->sheet-> getDelegate()->getColumnDimension('A')->setWidth(65);
        $event ->sheet-> getDelegate()->getColumnDimension('B')->setWidth(64);
        $event ->sheet-> getDelegate()->getColumnDimension('C')->setWidth(13);
        $event ->sheet-> getDelegate()->getColumnDimension('F')->setWidth(12);
        $event ->sheet-> getDelegate()->getColumnDimension('G')->setWidth(12);
                    
                    
        //D & E column width set to 17
        $columns = ['D', 'E'];
            foreach ($columns as $column) {
                $event ->sheet-> getDelegate()->getColumnDimension($column)->setWidth(17);	
                    }
                    
        //D1 & E1 text wrapping...
        $event ->sheet->getStyle('D1')->getAlignment()->setWrapText(true);	
        $event ->sheet->getStyle('E1')->getAlignment()->setWrapText(true);	
                    
        //text center columns...
        $event ->sheet->getStyle('A1:A10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('B1:B10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('C1:C10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('D1:D10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('E1:E10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('F1:F10000')->applyFromArray($styleArray2);
        $event ->sheet->getStyle('G1:G10000')->applyFromArray($styleArray2);
                    
        //headings vertical alignment 
        $event ->sheet->getStyle('A1:G1')->applyFromArray($styleArray3); 
        //sums color formatting...
        $event ->sheet->getStyle('A1:G1')->applyFromArray($styleArray5);
    
            },
        ];

    }
}
