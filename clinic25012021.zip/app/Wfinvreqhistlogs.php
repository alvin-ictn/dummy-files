<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Wfinvreqhistlogs extends Model
{
	protected $table = 'MEDSYS_WFINVREQHISTLOGS';
	
	public $timestamps = false;
}
