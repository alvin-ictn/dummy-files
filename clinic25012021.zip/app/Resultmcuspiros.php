<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Resultmcuspiros extends Model
{
	protected $table = 'MEDSYS_RESULTMCUSPIROS';
	
	public $timestamps = false;
	
	protected $primaryKey = 'VREGNO';
    
    public $incrementing = false;
}
