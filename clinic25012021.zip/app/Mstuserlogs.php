<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstuserlogs extends Model
{
    protected $table = 'MEDSYS_MSTUSERLOGS';

    protected $primaryKey = 'ILINE';
    
    public $incrementing    = false;


    public $timestamps = false;
}
