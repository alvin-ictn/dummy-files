<?php

namespace App;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class Invmovedtls extends Model
{
	protected $table = 'MEDSYS_INVMOVEDTLS';
	
	public $timestamps = false;
	
	protected $primaryKey = ['VTRXNO', 'ILINENO'];
    
    public $incrementing = false;
	
	protected $dates = ['DEXPIRED'];
	
    protected function setKeysForSaveQuery(Builder $query)
	{
		foreach($this->primaryKey as $pk)
		{
			$query = $query->where($pk, $this->attributes[$pk]);
		}
		return $query;
	}
}
