<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchDocHdrLogs extends Model
{
    protected $table = 'MEDSYS_SCHDCTRHDRLOGS';

    public $timestamps = false;
}
