<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstdistrict extends Model
{
    protected $table = 'MEDSYS_MSTDISTRICTS';


    public $timestamps = false;
}
