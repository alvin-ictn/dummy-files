<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstclinicstaffs extends Model
{
    //
    protected $table = 'MEDSYS_MSTCLINICSTAFFS';
    
    protected $guarded = [];
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'VMAIL', 'VADDRESS', 'VIDCARDNO', 'VPHONENO'
    ];

    public $timestamps = false;
	
	protected $dates = ['DBIRTH'];
	
	protected $primaryKey = 'VUSRID';
    
    public $incrementing = false;
}
