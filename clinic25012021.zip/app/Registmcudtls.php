<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Registmcudtls extends Model
{
	protected $table = 'MEDSYS_REGISTMCUDTLS';
	
	public $timestamps = false;
	
	protected $primaryKey = ['VREGNO', 'ILINENO'];
    
    public $incrementing = false;
}
