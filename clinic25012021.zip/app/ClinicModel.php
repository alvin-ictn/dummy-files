<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClinicModel extends Model
{
    protected $table = 'MEDSYS_MSTCLINICS';

    protected $primaryKey = 'VCLINICCODE'; 

    protected $fillable = [
        'VCLINICCODE', 'VAREACODE', 'VCLINICINIT','DLASTSYNC','VCLINICNAME','REGION'
    ];

    public $timestamps = false;
    public $incrementing = false;
}
