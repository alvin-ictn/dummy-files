<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstsubdistrict extends Model
{

    protected $table = 'MEDSYS_MSTSUBDISTRICTS';


    public $timestamps = false;

}
