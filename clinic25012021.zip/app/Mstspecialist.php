<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstspecialist extends Model
{
    protected $table = 'MEDSYS_MSTSPECIALISTS';


    public $timestamps = false;
}
