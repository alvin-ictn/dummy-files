<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invrequestlogs extends Model
{
	protected $table = 'MEDSYS_INVREQUESTLOGS';
	
	public $timestamps = false;
}
