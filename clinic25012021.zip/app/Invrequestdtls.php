<?php

namespace App;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class Invrequestdtls extends Model
{
	protected $table = 'MEDSYS_INVREQUESTDTLS';
	
	public $timestamps = false;
	
	protected $primaryKey = ['VREQNO', 'ILINENO'];
    
    public $incrementing = false;
	
	protected function setKeysForSaveQuery(Builder $query)
	{
		foreach($this->primaryKey as $pk)
		{
			$query = $query->where($pk, $this->attributes[$pk]);
		}
		return $query;
	}
}
