<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Doclists extends Model
{
    //
    protected $table = 'MEDSYS_DOCLISTS';
    
    protected $guarded = [];
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'VDOCID', 'VDOCTYPE', 'VDOCNO', 'VDOCFILENAME', 'DPERIODFR', 'DPERIODTO'
    ];
	
    public $timestamps = false;
	
	protected $dates = ['DPERIODFR', 'DPERIODTO'];
	
	protected $primaryKey = 'VID';
    
    public $incrementing = false;
	
	protected static function boot()
    {
        parent::boot();

        static::creating(function ($post) {
            $post->{$post->getKeyName()} = (string) Str::uuid();
        });
    }
}
