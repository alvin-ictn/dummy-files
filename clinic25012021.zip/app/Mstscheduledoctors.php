<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstscheduledoctors extends Model
{
    protected $table = 'MEDSYS_SCHDCTRHDRS';

    public $timestamps = false;
    
	protected $primaryKey = 'VSCHCODE';
}
