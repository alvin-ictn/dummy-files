<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Candidates extends Model
{
	protected $table = 'MEDSYS_CANDIDATES';
	
	public $timestamps = false;
	
	protected $primaryKey = 'VCANDIDATENO';
    
    public $incrementing = false;
	
	protected $dates = ['DBIRTH'];
}
