<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstempmembers extends Model
{
	protected $table = 'MEDSYS_MSTEMPMEMBERS';
	
    public $timestamps = false;
	
	protected $primaryKey = 'ILINE';
    
    public $incrementing = false;
}
