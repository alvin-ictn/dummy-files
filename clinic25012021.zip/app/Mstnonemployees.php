<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstnonemployees extends Model
{
    //
    protected $table = 'MEDSYS_MSTNONEMPLOYEES';
    
    protected $guarded = [];
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'VMAIL', 'VADDRESS', 'VIDCARDNO', 'VPHONENO'
    ];

    public $timestamps = false;
}
