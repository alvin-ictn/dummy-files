<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstmedicallogs extends Model
{
    protected $table = 'MEDSYS_MSTMDCLINSTRLOGS';


    public $timestamps = false;
}
