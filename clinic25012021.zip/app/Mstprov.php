<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstprov extends Model
{
    protected $table = 'MEDSYS_MSTPROVS';


    public $timestamps = false;
}
