<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MEDSYS_EXAMINATIONDTLLOGS extends Model
{
    //
    protected $table = 'MEDSYS_EXAMINATIONDTLLOGS';


    public $timestamps = false;
}
