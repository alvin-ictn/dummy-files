<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Registmcushists extends Model
{
	protected $table = 'MEDSYS_REGISTMCUSHISTS';
	
	public $timestamps = false;
	
	protected $primaryKey = ['VREGNO', 'ILINENO'];
    
    public $incrementing = false;
	
	protected $dates = ['DRESERVED', 'DDATE'];
}
