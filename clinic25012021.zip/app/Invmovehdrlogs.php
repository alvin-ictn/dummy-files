<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invmovehdrlogs extends Model
{
	protected $table = 'MEDSYS_INVMOVEHDRLOGS';


	public $timestamps = false;
}
