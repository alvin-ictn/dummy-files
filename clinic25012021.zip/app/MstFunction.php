<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MstFunction extends Model
{
    //
    protected $table = 'MEDSYS_MSTFUNCTIONS';


    public $timestamps = false;
}
