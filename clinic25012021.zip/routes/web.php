<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
    Route::group(['prefix'=>'account'], function() {


        Route::get('/home','HomeController@index');

        // bank
        Route::get('/bank','HomeController@bank');
        Route::get('/bank/add','BankController@insert');
        Route::get('/bank/edit/{id}','BankController@edit');
        Route::get('/bank/export_excel','BankController@export_excel');

        // user
        Route::get('/users', 'RegistrasiController@show');
        Route::get('/users/form/{id?}','RegistrasiController@form');
        Route::get('/users/deldoc/{id}','RegistrasiController@deldoc');
        Route::post('/users/export_excel','RegistrasiController@export_excel');

        // clinic
        Route::get('/clinic','HomeController@clinic');
        Route::get('/clinic/add','ClinicController@insert');
        Route::get('/clinic/edit/{id}','ClinicController@edit');
        Route::get('/clinic/edit/{id?}','ClinicController@form');
        Route::post('/clinic/export_excel','ClinicController@export_excel');

        // setting
        Route::get('/setting','HomeController@setting');
        Route::get('/setting/add','SettingController@insert');
        Route::get('/setting/edit/{id}', 'SettingController@edit');
        Route::post('/setting/export_excel','SettingController@export_excel');

        // medical
        Route::get('/medical', 'HomeController@medical');
        Route::get('/medical/add','MedicalController@insert');
        Route::get('/medical/edit/{id}', 'MedicalController@edit');
        Route::post('/medical/export_excel','MedicalController@export_excel');

        // content
        Route::get('/content', 'HomeController@content');
        Route::get('/content/add', 'ContentController@insert');
        Route::get('/content/edit/{id}','ContentController@edit');

        // district
        Route::get('/district','HomeController@district');
        Route::get('/district/add','DistrictController@insert');
        Route::get('/district/edit/{id}','DistrictController@edit');
        Route::post('/district/export_excel','DistrictController@export_excel');

        // subdistrict
        Route::get('/subdistrict','HomeController@subdistrict');
        Route::get('/subdistrict/add','SubDistrictController@insert');
        Route::get('/subdistrict/edit/{id}','SubDistrictController@edit');
        Route::post('/subdistrict/export_excel','SubDistrictController@export_excel');

        // drugs
        Route::get('/drugs','HomeController@drugs');
        Route::get('/drugs/add','DrugsController@insert');
        Route::get('/getdrugslookup','DrugsController@drug');

        
        Route::get('/drugs/edit/{id}','DrugsController@edit');
        Route::post('/drugs/export_excel','DrugsController@export_excel');

        // Specialist
        Route::get('/specialist','HomeController@specialist');
        Route::get('/specialist/add','SpecialistController@insert');
        Route::get('/specialist/edit/{id}','SpecialistController@edit');

        // Provinsi
        Route::get('/province','HomeController@prop');
        Route::get('/province/add','ProvinsiController@insert');
        Route::get('/province/edit/{id}','ProvinsiController@edit');
        Route::post('/province/export_excel','ProvinsiController@export_excel');

        // SubPersonals
        Route::get('/subpersonel','HomeController@subpersonal');
        Route::get('/subpersonel/add','SubPersonnelController@insert');
        Route::get('/subpersonel/edit/{id}','SubPersonnelController@edit');
        Route::post('/subpersonel/export_excel','SubPersonnelController@export_excel');

        // Personal
        Route::get('/personel','HomeController@personal');
        Route::get('/personel/add','PersonnelAreaController@insert');
        Route::get('/personel/edit/{id}','PersonnelAreaController@edit');
        Route::post('/personel/export_excel','PersonnelAreaController@export_excel');

        // UserAccess
        Route::get('/useracc','HomeController@useraccess');
        Route::get('/useracc/add','UserAccController@insert');
        Route::get('/useracc/edit/{id}','UserAccController@edit');

        // UserClinic
        Route::get('/userclinic','HomeController@userclin');
        Route::get('/userclinic/add','UserClinicController@insert');
        Route::get('/userclinic/edit/{id}','UserClinicController@edit');
        Route::post('/userclinic/export_excel','UserClinicController@export_excel');

        // Userlogs
        Route::get('/userlogs','HomeController@userlogs');
        Route::get('/userlogs/add','UserLogsController@insert');
        Route::get('/userlogs/edit/{id}','UserLogsController@edit');

        // UserRole
        Route::get('/userrole','HomeController@userrole');
        Route::get('/userrole/add','UserRoleController@insert');
        Route::get('/userrole/edit/{id}','UserRoleController@edit');
        Route::post('/userrole/export_excel','UserRoleController@export_excel');

        // ScheduleDoctors
        Route::get('/scheduledoctors','HomeController@scheduledoctors');
        Route::get('/scheduledoctors/form/{id?}','ScheduleDoctorsController@form');
        Route::get('/scheduledoctors/add','ScheduleDoctorsController@form'); 
        Route::post('/scheduledoctors/export_excel','ScheduleDoctorsController@export_excel');

        // Role Access
        Route::get('/roleaccess','HomeController@roleaccess');
        Route::get('/roleaccess/form/{id?}','RoleAccessController@form');
        Route::get('/roleaccess/add','RoleAccessController@form'); 

        // Movement Inquiry
        Route::get('/movementinquiry','HomeController@movementinquiry');

        // Balance
        Route::get('/balance','HomeController@balance');
        Route::post('/balance/export_excel','BalanceController@export_excel');

        // paramedic
        Route::get('/bookingsm','HomeController@paramedic');

        // Patient Information
        Route::get('/booking/patientinfo/{id}','HomeController@patientinfo');

        
        // Patient List
        Route::get('/booking/patientlist/','HomeController@patientlist');
        Route::get('/patientlist/form/{id?}','PatientListController@form');
        Route::post('/patientlist/export_excel','PatientListController@export_excel');
        Route::post('/patientlist/convert_to_pdf','PatientListController@DocToPDFConverter');

        // booking
        Route::get('/booking/add','BookingController@addbooking');
        Route::get('/booking/add/appointment/{id}','BookingController@appointment');

        // cost center
        Route::get('/costcenter','HomeController@costcenter');
        Route::get('/costcenter/add','CostCenterController@insert');
        Route::get('/costcenter/edit/{id}','CostCenterController@edit');
        Route::post('/costcenter/export_excel','CostCenterController@export_excel');

        // packages 
        Route::get('/packages','HomeController@packages');
        Route::get('/packages/add','PackagesController@insert');
        Route::get('/packages/edit/{id}','PackagesController@edit');
        Route::post('/packages/export_excel','PackagesController@export_excel');

        // cost center packages 
        Route::get('/costcenterpackages','HomeController@ccenterpackages');
        Route::get('/costcenterpackages/add','CostCenterpackgesController@insert');
        Route::get('/costcenterpackages/edit/{id}','CostCenterpackgesController@edit');
        Route::POST('/costcenterpackages/export_excel','CostCenterpackgesController@export_excel');

        // packages list
        Route::get('/packagelist','HomeController@packageslist');
        Route::get('/packagelist/add','PackageslistController@insert');
        Route::get('/packagelist/edit/{id}','PackageslistController@edit');

        // general
        Route::get('/general','HomeController@general');
        Route::get('/general/add','GeneralController@insert');
        Route::get('/general/edit/{id}','GeneralController@edit');
        Route::post('/general/export_excel','GeneralController@export_excel');

        // check list MCU
        Route::get('/checklist','HomeController@checklistmcu');

        // MyProfile
        Route::get('/myprofile','MyProfileController@index');
		Route::post('/changepassword','MyProfileController@changepassword');

        // PermissionSetting
        Route::get('/permissionsetting','PermissionSettingController@index');
		Route::get('/group/{id}','PermissionSettingController@group');

        // Inventory
        Route::get('/inventory','InventoryController@index');
		Route::get('/inventory/form/{id?}','InventoryController@form');
        Route::post('/inventory/export_excel','InventoryController@export_excel');

        // Synch
        Route::get('/synch','SynchController@index');
        Route::get('/synch/dosynch','SynchController@dosynch');

        // Movement
        Route::get('/movement','MovementController@index');
		Route::get('/movement/form/{id?}','MovementController@form');
		Route::get('/movement/getreqdetail/{id}/{type}', 'MovementController@getreqdetail');
        Route::post('/movement/export_excel','MovementController@export_excel');
		
        Route::get('/download/{id}','HomeController@download');
        Route::get('/download/examination/{id}','HomeController@download_examination');

        // payment
        Route::get('/payment','HomeController@payment');
		Route::get('/payment/form/{id?}','PaymentController@form');
		Route::post('/payment/export_excel','PaymentController@export_excel');

        // MCU
        Route::get('/mcu','McuController@index');
		Route::get('/mcu/form/{id?}/{page?}','McuController@form');
        Route::get('/mcu/proceed/{id}/{type}','McuController@proceed');
        Route::get('/mcu/reschedule/{id}/{date}/{time}','McuController@reschedule');
        Route::get('/mcu/schedule','HomeController@scheduleMCU');
        Route::get('/mcu/schedule/form/{id?}','McuController@scheduleForm');
        Route::post('/mcu/schedulemcu/export_excel','McuController@export_schedulemcu');
        Route::post('/mcu/export_excel','McuController@export_excel');

        // Result MCU
        Route::get('/resultmcu','ResultMcuController@index');
		Route::get('/resultmcu/form/{id}','ResultMcuController@form');
		Route::get('/resultmcu/download/{id}','ResultMcuController@download');
        Route::post('/resultmcu/export_excel','ResultMcuController@export_excel');

        
        //  Master ICD
        Route::GET('/icd','IcdController@index');

        // Report 
        Route::get('/reportkunjungan','ReportController@reportkunjungan');
        Route::get('/reportdrugs','ReportController@reportdrugs');
        Route::get('/reportMcus','ReportController@reportMcus');
		Route::get('/reportmcu','ReportController@reportmcu');
		Route::get('/reportvisit','ReportController@reportvisit');

    });

// ajax

Route::get('/ajaxicd','IcdController@ajax');
Route::get('/ajaxuserrole','UserRoleController@ajax');
Route::get('/ajaxscheduledoctors','ScheduleDoctorsController@ajax');
Route::get('/ajaxroleaccess','RoleAccessController@ajax');
Route::get('/ajaxmovementinquiry','MovementInquiryController@ajax');
Route::get('/ajaxpayment','PaymentController@ajax');
Route::post('payment/save','PaymentController@save');
Route::get('/ajaxbalance','BalanceController@ajax');
Route::get('/ajaxpatientlist','PatientListController@ajax');

Route::get('/ajaxsynch','SynchController@ajax');
Route::get('/ajaxregistrasi', 'RegistrasiController@ajax');
Route::get('/ajaxinventory', 'InventoryController@ajax');
Route::get('/ajaxmovement', 'MovementController@ajax');
Route::get('/ajaxmcu', 'McuController@ajax');
Route::get('/ajaxresultmcu', 'ResultMcuController@ajax');
Route::get('/ajaxsetting','SettingController@ajax')->name('ajaxsetting');
Route::get('/viewclinic/{id}', 'ClinicController@view')->name('viewclinic/{id}');
Route::get('/getajaxcliniccode/{id}','ClinicController@getajaxcliniccode');
Route::get('/getajaxprovince/{id}','ProvinsiController@getajaxprovince');
Route::get('/getajaxcostcenter/{id}','CostCenterController@getajaxcostcenter');
Route::get('/getajaxpackages/{id}','PackagesController@getajaxpackages');
Route::get('/getajaxcostcenterpackages/{id}','CostCenterpackgesController@getajaxcostcenterpackages');
Route::get('/getajaxcostcenterpackages2/{id}','CostCenterpackgesController@getajaxcostcenterpackages2');
Route::get('/getajaxdistrictcode/{id}','districtController@getajaxdistrictcode');
Route::get('/getajaxsubpersonnel/{id}','SubPersonnelController@getajaxsubpersonnel');
Route::get('/getajaxcostcenterpackageexists/{id}','CostCenterpackgesController@getajaxcostcenterpackageexists');
Route::get('/getajaxclinicinitialexists/{id}','ClinicController@getajaxclinicinitialexists');

// email
Route::post('sendemail/forgotpassword', 'EmailController@ForgotPasswordSendEmail');

// content
Route::get('/ajaxcontent', 'ContentController@ajax');
Route::get('/viewcontent/{id}', 'ContentController@view')->name('viewcontent/{id}');
Route::post('/addcontent/content', 'ContentController@add');
Route::post('/content/update', 'ContentController@update')->name('content/update');
Route::post('/content/export', 'ContentController@export');


// setting
Route::get('/viewsetting/{id}', 'SettingController@view')->name('viewsetting/{id}');
Route::post('addsetting/insert','SettingController@add');
Route::post('setting/update', 'SettingController@update');

// registrasi
Route::get('/login', 'LoginController@index')->name('login');
Route::get('/login/{id?}', 'LoginController@index');
Route::get('/insertajax', 'MedicalController@ajax');
Route::get('/viewins/{id}','MedicalController@view');
Route::post('/login', 'LoginController@login')->name('logins');

// bank
Route::get('/ajaxbank', 'BankController@ajax')->name('ajaxbank');
Route::post('/addbank/insert','BankController@add');
Route::post('/bank/edit','BankController@update');

// clinic
Route::get('/ajaxclinic', 'ClinicController@ajax')->name('ajaxclinic');
Route::post('addclinic/insert','ClinicController@add');
Route::post('clinic/update','ClinicController@update');
Route::get('/clinic/getsubdistlookup', 'ClinicController@getsubdistlookup');

// Medical
Route::get('/ajaxmedical', 'MedicalController@ajax');
Route::post('addmedical/insert','MedicalController@add');
Route::post('medical/update','MedicalController@update');

// users
Route::post('/users/update-lock', 'RegistrasiController@update_lock')->name('users/update-lock');
Route::post('/users/kick-user', 'RegistrasiController@kick_user')->name('users/kick-user');
Route::get('/getcoordinatorlookup', 'RegistrasiController@getcoordinatorlookup');
Route::post('/user/save', 'RegistrasiController@save');

// registrasi
Route::get('/logout','HomeController@logout');
Route::post('/registrasis', 'RegistrasiController@store')->name('registrasis');
route::post('login/updatetype','LoginController@updatetype');

//district
Route::get('/ajaxdistrict', 'DistrictController@ajax');
Route::get('/getajaxdistrict/{id}', 'DistrictController@getdistrict');

Route::post('adddistrict/insert','DistrictController@add');
Route::post('district/update','DistrictController@update');

//subdistrict
Route::get('/ajaxsubdistrict', 'SubDistrictController@ajax');
Route::post('addsubdistrict/insert','SubDistrictController@add');
Route::post('subdistrict/update','SubDistrictController@update');
Route::get('/getajaxsubdistrict/{id}', 'SubDistrictController@getajaxsubdistrict');
//login
Route::post('changepasword','LoginController@changepassword');
Route::post('changepasword/forgotpassword','LoginController@ChngPwdForgotPassword');
Route::post('logindoctor','LoginController@logindoctor');

// drugs
Route::get('/ajaxdrugs','DrugsController@ajax');
Route::post('adddrugs/insert','DrugsController@add');
Route::post('drugs/update','DrugsController@update');
Route::get('/getdrugslookup', 'DrugsController@getdrugslookup');
Route::get('/getdrugslookup1/{id?}', 'DrugsController@getdrugslookup1');
Route::get('/getdrugslookupexamination/{id?}','DrugsController@getdrugslookupexamination');

Route::get('/itemiuses/{id}', 'DrugsController@itemiuses');

// Specialist
Route::get('/ajaxspecialist', 'SpecialistController@ajax');
Route::post('addspecialist/insert','SpecialistController@add');
Route::post('specialist/update','SpecialistController@update');
Route::get('/choosespecialist/{id}', 'BookingController@choose');
Route::get('/choosedoctor/{id}', 'BookingController@choosedoctor');
Route::get('/ajaxdetaildoctor/{id}', 'BookingController@ajaxdetaildoctor');
Route::get('/ajaxtime/{id}', 'BookingController@ajaxtime');
Route::get('/ajaxfamily/{id}/{ids?}', 'BookingController@ajaxfamily');
Route::get('/ajaxcategory/{id}', 'BookingController@ajaxcategory');
Route::get('/ajaxdoctor/{id}', 'BookingController@ajaxdoctor');
Route::get('/ajaxmember/{id}', 'BookingController@ajaxmember');
Route::get('/ajaxbookings', 'BookingController@ajaxbooking');
Route::post('/updategeneral', 'BookingController@updategeneral');

///booking
Route::get('/booking/cancel/{id}', 'BookingController@cancelbooking');
Route::get('/getprovincelookup', 'BookingController@getprovincelookup');
Route::get('/getdistrictlookup/{id}', 'BookingController@getdistrictlookup');
Route::get('/alternativedoctor/{id}', 'BookingController@alternativedoctorlookup');
Route::get('/doctorlist/{id}', 'BookingController@doctorlistlookup');

Route::POST('/patientbooking', 'BookingController@patientbooking');
Route::POST('/booking/addpointment', 'BookingController@addpointment');

// Provinsi
Route::get('/ajaxprov','ProvinsiController@ajax')->name('ajaxprov');
Route::post('addprop/insert','ProvinsiController@add');
Route::post('prop/update','ProvinsiController@update');

// SubPersonal
Route::get('/ajaxsubpersonel','SubPersonnelController@ajax');
Route::get('/getcodelookup', 'SubPersonnelController@getcodelookup');
Route::post('addsubpersonel/insert','SubPersonnelController@add');
Route::post('subpersonel/update','SubPersonnelController@update');

// Personal
Route::get('/ajaxpersonel','PersonnelAreaController@ajax');
Route::post('addpersonel/insert','PersonnelAreaController@add');
Route::post('personel/update','PersonnelAreaController@update');

// UserAccess
Route::get('/ajaxuseracc','UserAccController@ajax');
Route::post('adduseracc/insert','UserAccController@add');
Route::post('useracc/update','UserAccController@update');

// User Clinic
Route::get('/ajaxuserclinic','UserClinicController@ajax');
Route::get('/getcliniclookup', 'UserClinicController@getcliniclookup');
Route::get('/getclinic2lookup', 'UserClinicController@getclinic2lookup');
Route::post('adduserclinic/insert','UserClinicController@add');
Route::post('userclinic/update','UserClinicController@update');

// User Logs
Route::get('/ajaxuserlog','UserLogsController@ajax');
Route::post('adduserlog/insert','UserLogsController@add');
Route::post('userlog/update','UserLogsController@update');

// User Role
Route::post('/adduserrole/insert','UserRoleController@add');
Route::get('/userrole/getusernamelookup', 'UserRoleController@getusernamelookup');
Route::get('/userrole/getrolenamelookup', 'UserRoleController@getrolenamelookup');
Route::post('userrole/update','UserRoleController@update');

// Schedule Doctors
Route::post('/scheduledoctors/form', 'ScheduleDoctorsController@save');
Route::get('/scheduledoctors/getcliniclookup', 'ScheduleDoctorsController@getcliniclookup');
Route::get('/scheduledoctors/getdoctorlookup', 'ScheduleDoctorsController@getdoctorlookup');

// Role Access
Route::post('/roleaccess/form', 'RoleAccessController@save');
Route::get('/roleaccess/getrolenamelookup', 'RoleAccessController@getrolenamelookup');

// Movement Inquiry
Route::get('/movementinquiry/getitemlookup', 'MovementInquiryController@getitemlookup');
Route::post('/movementinquiry/export_excel', 'MovementInquiryController@export_excel');

// MyProfile
Route::post('/updateprofile/update','MyProfileController@update');

// PermissionSetting
Route::post('/updatepermission/update','PermissionSettingController@update');

// Cost Center
Route::get('/ajaxcostcenter','CostCenterController@ajax');
Route::post('addcostcenter/insert','CostCenterController@add');
Route::post('costcenter/update','CostCenterController@update');

// Packages
Route::get('/ajaxpackages','PackagesController@ajax');
Route::post('addpackages/insert','PackagesController@add');
Route::post('packages/update','PackagesController@update');

// CostCenter Packages
Route::get('/ajaxccenterpackages','CostCenterpackgesController@ajax');
Route::get('/getcostcenterlookup', 'CostCenterpackgesController@getcostcenterlookup');
Route::get('/getpackageslookup', 'CostCenterpackgesController@getpackageslookup');
Route::post('addccpackages/insert','CostCenterpackgesController@add');
Route::post('costcenterpackages/update','CostCenterpackgesController@update');

// Packages List
Route::get('/ajaxpackageslist','PackageslistController@ajax');
Route::post('addpackageslist/insert','PackageslistController@add');
Route::post('packageslist/update','PackageslistController@update');

// Check List
Route::get('/ajaxchecklist','ChecklistController@ajax');
Route::post('addchecklist/insert','ChecklistController@add');
Route::post('checklist/update','ChecklistController@update');

// General
Route::get('/ajaxgeneral','GeneralController@ajax');
Route::get('/getgenerallookup', 'GeneralController@getgenerallookup');
Route::post('addgeneral/insert','GeneralController@add');
Route::post('general/update','GeneralController@update');

// Inventory
Route::post('/inventory/save', 'InventoryController@save');
Route::get('/getreqnolookup/{id}', 'MovementController@getreqnolookup');
Route::post('/movement/save', 'MovementController@save');
Route::post('/getdruglookup', 'MovementController@getdruglookup');
Route::get('/gettblreqdetail/{id?}', 'InventoryController@gettblreqdetail');

// MCU
Route::get('/getemployeelookup', 'McuController@getemployeelookup');
Route::get('/getdatelookup', 'McuController@getdatelookup');
Route::get('/getschdlist/{date}/{day}', 'McuController@getschdlist');
Route::post('/mcu/save', 'McuController@save');
Route::get('/getdepartmentlookup', 'McuController@getdepartmentlookup');
Route::get('/getbusinessunitlookup', 'McuController@getbusinessunitlookup');
Route::get('/mcu/print/{id}', 'McuController@print');
Route::post('/resultmcu/save', 'ResultMcuController@save');
Route::get('/ajaxmcuschedule', 'McuController@ajaxmcuschedule');
Route::post('/scheduleMCU/post', 'McuController@schedulemcuPost');


//Patient Information
Route::POST('/patientexamination','BookingController@postExamination');
Route::get('/geticddiagnosislookup', 'DrugsController@geticddiagnosislookup');
Route::POST('/addtreatment/insert','BookingController@postTreatment');
Route::get('/treatment/print_pdf/{id}', 'BookingController@print_treatment');
Route::get('/treatment/view_pdf/{id}', 'BookingController@view_print');
Route::get('/scanbarcode/{id}', 'BookingController@scanbarcode');
Route::POST('/examination/update','BookingController@UpdateExamination');
Route::get('/examination/delete/{id}','BookingController@DeleteExamination');
Route::post('/patientlist/uploaddocument','BookingController@UploadDocument');
Route::post('/uploadExamination','BookingController@UploadDocumentExamination');
Route::get('/downloadletter/{letter}/{id}','BookingController@downloadletter');
Route::POST('/treatment/update','BookingController@UpdateTreatment');
Route::GET('/treatment/delete/{id}','BookingController@DeleteTreatment');
Route::GET('/resultmr','BookingController@ResultMr');
Route::GET('/history/mr/{id}','BookingController@historyMr');

Route::GET('/resultmcu','BookingController@ResultMcu');

/// DASHBOARD HOME
Route::GET('/tools-calibrate/{id?}','HomeController@toolscalibration');
Route::GET('/legalcompliance/{id?}','HomeController@legalcompliance');
Route::GET('/drugsreceive/{id?}','HomeController@drugsreceive');
Route::GET('/routinedrugs/{id?}','HomeController@routinedrugs');


// UPLOAD IMAGES CKEDITOR
// Route::post('ckeditor/upload', 'HomeController@uploadckeditor')->name('ckeditor.upload');

// Master ICD
Route::post('icd/import_excel', 'ICDController@import_excel');
Route::post('/icd/export_excel','ICDController@export_excel');

// Payment List
Route::get('/payment/delete/{id?}','PaymentController@remove');
Route::get('/payment/print/{id?}','PaymentController@print');

/// Report
Route::get('/getajaxreq/{id}','ReportController@getajaxreq');
Route::get('/getajaxbisnisunit/{id}','ReportController@getajaxbisnisunit');

Route::get('/getajaxclinic/{id}','ReportController@getajaxclinic');
Route::post('/report/export/kunjungan','ReportController@download_report');

Route::get('/mcu','ReportController@mcu');
Route::get('/visit','ReportController@visit');

Route::get('/reportkunjungan','ReportController@reportkunjungan');

Route::get('/getreport','ReportController@viewreport');

Route::post('ckeditor/upload', 'HomeController@uploadckeditor')->name('ckeditor.upload');

