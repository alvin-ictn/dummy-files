<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'gender' => 'Jenis Kelamin',
    'employee_name' => 'Nama Karyawan',
    'address' => 'Alamat',
    'occupational_hazard_exposure' => 'Riwayat Bahaya Lingkungan Kerja',
    'noise' => 'Bising',
    'hour_s_per_day_length' => 'Jam/Hari, Selama',
    'year_s' => 'Tahun',
    'vibration' => 'Getaran',
    'smoke_gass' => 'Asap',
    'computer' => 'Monitor',
    'dust' => 'Debu',
    'movement' => 'Gerakan',
    'chemical' => 'Zat Kimia',
    'pushing' => 'Mendorong',
    'heat' => 'Panas',
    'lifting' => 'Mengangkat',
    'must_be_filled_at_least_one_checkbox' => 'Wajib Diisi Salah Satu',
    'accident_history' => 'Riwayat Kecelakaan Kerja',
    'year' => 'Tahun',
    'fall_from_high_places' => 'Jatuh Dari Ketinggian',
    'muscle_sprain' => 'Terpilin/Terguling',
    'lacerated_wound_punctured_wound' => 'Luka Robek/Tusuk',
    'contusion' => 'Terbentur',
    'parts_of_body' => 'Bagian',
    'electric_shock' => 'Tersengat Listrik',
    'hit_by_an_object' => 'Tertimpa',
    'burn_injury' => 'Luka Bakar',
    'sting' => 'Gigitan/Sengatan Hewan',
    'contact_with_other_heat_source' => 'Tersiram Air Panas/Uap Panas',
    'skin_rash' => 'Ruam Dikulit Akibat Bahan Kimia',
    'chemical_inhaled_ingested' => 'Terhirup/Tertelan Bahan Kimia',
    'foreign_body_entering' => 'Kemasukan Benda Asing',
    'habit_per_second_nature' => 'Kebiasaan',
    'physical_exercise' => 'Olahraga',
    'time_s_per_week' => 'Kali/Minggu',
    'alcohol' => 'Alkohol',
    'bottle_s_per_day' => 'Botol/Hari',
    'cigarettes_smoke' => 'Merokok',
    'pcs_per_day' => 'Batang/Hari',
    'coffee' => 'Minum Kopi',
    'glass_es_per_day' => 'Gelas/Hari',
    'history_of_family_disease' => 'Riwayat Penyakit Keluarga',
    'heart_disease' => 'Penyakit Jantung',
    'tumor_or_cancer' => 'Penyakit Kanker/Tumor',
    'hypertension' => 'Penyakit Darah Tinggi',
    'mental_disorder' => 'Penyakit Gangguan Jiwa',
    'diabetes_melitus' => 'Penyakit Kencing Manis/Diabetes Melitus',
    'kidney_disease' => 'Penyakit Ginjal',
    'stroke' => 'Penyakit Stroke',
    'disorder_of_digestive_system' => 'Penyakit Saluran Cerna',
    'lung_disease' => 'Penyakit Paru/Paru Menahun/Asma/TBC',
    'other' => 'Penyakit Lainnya',
    'from' => 'Dari',
    'to' => 'Sampai',
    'company' => 'Perusahaan',
    'job_classification' => 'Jenis Pekerjaan',
    'working_exposure' => 'Terpapar',
    'smoke' => 'Asap',
    'gass' => 'Gas',
    'length' => 'Lama',
    'hour_s_per_day' => '(Jam/Hari)',
    'remarks' => 'Keterangan',
    'phone_number' => 'Telp/HP',
    'date' => 'Tanggal',
    'time' => 'Jam',
    'package' => 'Paket',
    'age' => 'Umur',
    'years' => 'Tahun',
    'working_history' => 'Riwayat Pekerjaan',
    'blood' => 'DARAH',
    'physical' => 'FISIK'

];
