<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'gender' => 'Gender',
    'employee_name' => 'Employee Name',
    'address' => 'Address',
    'occupational_hazard_exposure' => 'Occupational Hazard Exposure',
    'noise' => 'Noise',
    'hour_s_per_day_length' => 'Hour(s)/day,Length',
    'year_s' => 'Year(s)',
    'vibration' => 'Vibration',
    'smoke_gass' => 'Smoke/Gass',
    'computer' => 'Computer',
    'dust' => 'Dust',
    'movement' => 'Movement',
    'chemical' => 'Chemical',
    'pushing' => 'Pushing',
    'heat' => 'Heat',
    'lifting' => 'Lifting',
    'must_be_filled_at_least_one_checkbox' => 'Must Be Filled At Least One Checkbox',
    'accident_history' => 'Accident History',
    'year' => 'Year',
    'fall_from_high_places' => 'Fall From High Places',
    'muscle_sprain' => 'Muscle Sprain',
    'lacerated_wound_punctured_wound' => 'Lacerated Wound / Punctured wound',
    'contusion' => 'Contusion',
    'parts_of_body' => 'Parts of Body',
    'electric_shock' => 'Electric Shock',
    'hit_by_an_object' => 'Hit By An Object',
    'burn_injury' => 'Burn Injury',
    'sting' => 'Sting',
    'contact_with_other_heat_source' => 'Contact With Other Heat Source',
    'skin_rash' => 'Skin Rash',
    'chemical_inhaled_ingested' => 'Chemical Inhaled / Ingested',
    'foreign_body_entering' => 'Foreign Body Entering',
    'habit_per_second_nature' => 'Habit/Second Nature',
    'physical_exercise' => 'Physical Exercise',
    'time_s_per_week' => 'Time(s)/week',
    'alcohol' => 'Alcohol',
    'bottle_s_per_day' => 'Bottle(s)/day',
    'cigarettes_smoke' => 'Cigarettes Smoke',
    'pcs_per_day' => 'Pcs/day',
    'coffee' => 'Coffee',
    'glass_es_per_day' => 'Glass(es)/day',
    'history_of_family_disease' => 'History Of Family Disease',
    'heart_disease' => 'Heart Disease',
    'tumor_or_cancer' => 'Tumor or Cancer',
    'hypertension' => 'Hypertension',
    'mental_disorder' => 'Mental Disorder',
    'diabetes_melitus' => 'Diabetes Melitus',
    'kidney_disease' => 'Kidney Disease',
    'stroke' => 'Stroke',
    'disorder_of_digestive_system' => 'Disorder of Digestive System',
    'lung_disease' => 'Lung Disease',
    'other' => 'Other',
    'from' => 'From',
    'to' => 'To',
    'company' => 'Company',
    'job_classification' => 'Job Classification',
    'working_exposure' => 'Working Exposure',
    'smoke' => 'Smoke',
    'gass' => 'Gass',
    'length' => 'Length',
    'hour_s_per_day' => 'Hour(s)/day',
    'remarks' => 'Remarks',
    'phone_number' => 'Phone Number',
    'date' => 'Date',
    'time' => 'Time',
    'package' => 'Package',
    'age' => 'Age',
    'years' => 'Years',
    'working_history' => 'Working History',
    'blood' => 'BLOOD',
    'physical' => 'PHYSICAL'

];
