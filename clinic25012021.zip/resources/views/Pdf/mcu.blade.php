<html>
   <head>
      <title>MCU</title>
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
   </head>
   <body>
      <style type="text/css">
         table tr td {
         font-size: 9pt;
         }
         .invoice header td {
         text-align: center;
         font-size: 15pt;
         }
         label {
         margin-bottom: 0rem;
         }
		 @page { margin: 0px; }
		 body {
			 margin: 10px;
			 font-size: 0.75rem;
		 }
		 body:before {
			 content: "";
			 position: absolute;
			 z-index: 9999;
			 top: 0;
			 bottom: 0;
			 left: 0;
			 right: 0;
			 background: 
			   url('data:image/svg+xml;utf8,<svg style="transform:rotate(-45deg)" xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 50 60"><text x="0" y="25" fill="%23000">Lorem </text></svg>') 
			   0 0/100% 100vh;
		 }
      </style>
	  <div id="invoice">
         <div class="invoice overflow-auto">
            <header>
			   <table width="100%">
					<tr>
						<td width="20%"></td>
						<td width="60%"><u>MCU PARTICIPANT FORM AND TICKET</u></td>
						<td width="20%" style="font-size: 12pt;">Registration No# {{ $mcu->VREGNO }}</td>
					</tr>
				</table>
            </header>
			<br>
            <main>
				<table width="100%">
					<tr>
						<td width="50%">
							<table width="100%">
								<tr>
									<td><b>SAP ID</b></td>
									<td>:</td>
									<td>{{ $mcu->VIDNO }}</td>
								</tr>
								<tr>
									<td><b>{{ __('mcu.employee_name') }}</b></td>
									<td>:</td>
									<td>{{ $mcu->VNAME }}</td>
								</tr>
								<tr>
									<td><b>PA-Dept</b></td>
									<td>:</td>
									<td>{{ $mcu->VPRSNL }}</td>
								</tr>
								<tr>
									<td><b>{{ __('mcu.gender') }}</b></td>
									<td>:</td>
									<td>{{ $mcu->VSETDESC }}</td>
								</tr>
								<tr>
									<td><b>{{ __('mcu.phone_number') }}</b></td>
									<td>:</td>
									<td>{{ $mcu->VPHONENO }}</td>
								</tr>
								<tr>
									<td><b>{{ __('mcu.address') }}</b></td>
									<td>:</td>
									<td>{{ $mcu->VADDRESS }}</td>
								</tr>
							</table>
						</td>
						<td width="50%">
							<table width="100%" style="border:1px solid;">
								<tr>
									<td style="padding-left:5px;"> Document Status</td>
									<td>:</td>
									<td>{{ $mcu->VDOCSTATUS }}</td>
								</tr>
								<tr>
									<td style="padding-left:5px;"> {{ __('mcu.date') }}</td>
									<td>:</td>
									<td>{{ $mcu->DRESERVED->format('d-M-Y') }}</td>
								</tr>
								<tr>
									<td style="padding-left:5px;"> {{ __('mcu.time') }}</td>
									<td>:</td>
									<td>{{ $mcu->TSESSIONTIME }}</td>
								</tr>
								<tr>
									<td style="padding-left:5px;">{{ __('mcu.package') }}</td>
									<td>:</td>
									<td>{{ $mcu->VPCKGNAME }}</td>
								</tr>
								<tr>
									<td style="padding-left:5px;">{{ __('mcu.age') }}</td>
									<td>:</td>
									<td>{{ $mcu->AGE }} {{ __('mcu.years') }}</td>
								</tr>
								<tr>
									<td>&nbsp;</td>
									<td>&nbsp;</td>
									<td>&nbsp;</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
            </main>
            <main style="font-size: 12pt;">
				<label><b>{{ __('mcu.occupational_hazard_exposure') }}</b></label>
            </main>
            <main>
				<table width="100%">
					<tr>
						<td width="50%">
							<table width="100%">
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRBLK_BISING == '1' ? 'checked' : '' }}>
									</td>
									<td></td>
									<td width="25%">{{ __('mcu.noise') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_HOURS_BISING }}</td>
									<td width="30%" style="padding-left:5px;">{{ __('mcu.hour_s_per_day_length') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_YEARS_BISING }}</td>
									<td width="20%" style="padding-left:5px;">{{ __('mcu.year_s') }}</td>
								</tr>
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRBLK_GETARAN == '1' ? 'checked' : '' }}>
									</td>
									<td></td>
									<td width="25%">{{ __('mcu.vibration') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_HOURS_GETARAN }}</td>
									<td width="30%" style="padding-left:5px;">{{ __('mcu.hour_s_per_day_length') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_YEARS_GETARAN }}</td>
									<td width="20%" style="padding-left:5px;">{{ __('mcu.year_s') }}</td>
								</tr>
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRBLK_DEBU == '1' ? 'checked' : '' }}>
									</td>
									<td></td>
									<td width="25%">{{ __('mcu.dust') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_HOURS_DEBU }}</td>
									<td width="30%" style="padding-left:5px;">{{ __('mcu.hour_s_per_day_length') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_YEARS_DEBU }}</td>
									<td width="20%" style="padding-left:5px;">{{ __('mcu.year_s') }}</td>
								</tr>
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRBLK_ZATKIMIA == '1' ? 'checked' : '' }}>
									</td>
									<td></td>
									<td width="25%">{{ __('mcu.chemical') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_HOURS_ZATKIMIA }}</td>
									<td width="30%" style="padding-left:5px;">{{ __('mcu.hour_s_per_day_length') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_YEARS_ZATKIMIA }}</td>
									<td width="20%" style="padding-left:5px;">{{ __('mcu.year_s') }}</td>
								</tr>
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRBLK_PANAS == '1' ? 'checked' : '' }}>
									</td>
									<td></td>
									<td width="25%">{{ __('mcu.heat') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_HOURS_PANAS }}</td>
									<td width="30%" style="padding-left:5px;">{{ __('mcu.hour_s_per_day_length') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_YEARS_PANAS }}</td>
									<td width="20%" style="padding-left:5px;">{{ __('mcu.year_s') }}</td>
								</tr>
							</table>
						</td>
						<td width="50%">
							<table width="100%">
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRBLK_ASAP == '1' ? 'checked' : '' }}>
									</td>
									<td></td>
									<td width="25%">{{ __('mcu.smoke_gass') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_HOURS_ASAP }}</td>
									<td width="30%" style="padding-left:5px;">{{ __('mcu.hour_s_per_day_length') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_YEARS_ASAP }}</td>
									<td width="20%" style="padding-left:5px;">{{ __('mcu.year_s') }}</td>
								</tr>
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRBLK_MONITOR == '1' ? 'checked' : '' }}>
									</td>
									<td></td>
									<td width="25%">{{ __('mcu.computer') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_HOURS_MONITOR }}</td>
									<td width="30%" style="padding-left:5px;">{{ __('mcu.hour_s_per_day_length') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_YEARS_MONITOR }}</td>
									<td width="20%" style="padding-left:5px;">{{ __('mcu.year_s') }}</td>
								</tr>
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRBLK_GERAKAN == '1' ? 'checked' : '' }}>
									</td>
									<td></td>
									<td width="25%">{{ __('mcu.movement') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_HOURS_GERAKAN }}</td>
									<td width="30%" style="padding-left:5px;">{{ __('mcu.hour_s_per_day_length') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_YEARS_GERAKAN }}</td>
									<td width="20%" style="padding-left:5px;">{{ __('mcu.year_s') }}</td>
								</tr>
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRBLK_MENDORONG == '1' ? 'checked' : '' }}>
									</td>
									<td></td>
									<td width="25%">{{ __('mcu.pushing') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_HOURS_MENDORONG }}</td>
									<td width="30%" style="padding-left:5px;">{{ __('mcu.hour_s_per_day_length') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_YEARS_MENDORONG }}</td>
									<td width="20%" style="padding-left:5px;">{{ __('mcu.year_s') }}</td>
								</tr>
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRBLK_MENGANGKAT == '1' ? 'checked' : '' }}>
									</td>
									<td></td>
									<td width="25%">{{ __('mcu.lifting') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_HOURS_MENGANGKAT }}</td>
									<td width="30%" style="padding-left:5px;">{{ __('mcu.hour_s_per_day_length') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRBLK_YEARS_MENGANGKAT }}</td>
									<td width="20%" style="padding-left:5px;">{{ __('mcu.year_s') }}</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
            </main>
			<main style="font-size: 12pt;">
				<label><b>{{ __('mcu.accident_history') }}</b></label>
            </main>
            <main>
				<table width="100%">
					<tr>
						<td width="50%">
							<table width="100%">
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRKK_JATUH == '1' ? 'checked' : '' }}>
									</td>
									<td width="55%">{{ __('mcu.fall_from_high_places') }}</td>
									<td width="10%" style="padding-left:5px;">{{ __('mcu.year') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRKK_YEARS_JATUH }}</td>
									<td width="20%"></td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRKK_LUKAROBEK == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.lacerated_wound_punctured_wound') }}</td>
									<td style="padding-left:5px;">{{ __('mcu.year') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRKK_YEARS_LUKAROBEK }}</td>
									&nbsp;
									<td width="20%" style="border:1px solid; text-align: center;">{{ $mcu->VRKK_LUKAROBEK }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRKK_TERSENGAT == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.electric_shock') }}</td>
									<td style="padding-left:5px;">{{ __('mcu.year') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRKK_YEARS_TERSENGAT }}</td>
									<td></td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRKK_LUKABAKAR == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.burn_injury') }}</td>
									<td style="padding-left:5px;">{{ __('mcu.year') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRKK_YEARS_LUKABAKAR }}</td>
									<td width="20%" style="border:1px solid; text-align: center;">{{ $mcu->VRKK_LUKABAKAR }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRKK_LUKATERSIRAM == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.contact_with_other_heat_source') }}</td>
									<td style="padding-left:5px;">{{ __('mcu.year') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRKK_YEARS_LUKATERSIRAM }}</td>
									<td width="20%" style="border:1px solid; text-align: center;">{{ $mcu->VRKK_LUKATERSIRAM }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRKK_TERHIRUP == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.chemical_inhaled_ingested') }}</td>
									<td style="padding-left:5px;">{{ __('mcu.year') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRKK_YEARS_TERHIRUP }}</td>
									<td></td>
								</tr>
							</table>
						</td>
						<td width="50%">
							<table width="100%">
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRKK_TERGULING == '1' ? 'checked' : '' }}>
									</td>
									<td width="60%">{{ __('mcu.muscle_sprain') }}</td>
									<td width="10%" style="padding-left:5px;">{{ __('mcu.year') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRKK_YEARS_TERGULING }}</td>
									<td width="20%"></td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRKK_TERBENTUR == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.contusion') }}</td>
									<td style="padding-left:5px;">{{ __('mcu.year') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRKK_YEARS_TERBENTUR }}</td>
									<td width="20%" style="border:1px solid; text-align: center;">{{ $mcu->VRKK_TERBENTUR }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRKK_TERTIMPA == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.hit_by_an_object') }}</td>
									<td style="padding-left:5px;">{{ __('mcu.year') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRKK_YEARS_TERTIMPA }}</td>
									<td></td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRKK_TERGIGIT == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.sting') }}</td>
									<td style="padding-left:5px;">{{ __('mcu.year') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRKK_YEARS_TERGIGIT }}</td>
									<td width="20%" style="border:1px solid; text-align: center;">{{ $mcu->VRKK_TERGIGIT }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRKK_RUAM == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.skin_rash') }}</td>
									<td style="padding-left:5px;">{{ __('mcu.year') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRKK_YEARS_RUAM }}</td>
									<td width="20%" style="border:1px solid; text-align: center;">{{ $mcu->VRKK_RUAM }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRKK_KEMASUKAN == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.foreign_body_entering') }}</td>
									<td style="padding-left:5px;">{{ __('mcu.year') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IRKK_YEARS_KEMASUKAN }}</td>
									<td></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
            </main>
			<main style="font-size: 12pt;">
				<label><b>{{ __('mcu.habit_per_second_nature') }}</b></label>
            </main>
            <main>
				<table width="100%">
					<tr>
						<td width="50%">
							<table width="100%">
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BKBS_OLAHRAGA == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.physical_exercise') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IKBS_TIMES_OLAHRAGA }}</td>
									<td style="padding-left:5px;">{{ __('mcu.time_s_per_week') }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BKBS_MEROKOK == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.cigarettes_smoke') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IKBS_TIMES_MEROKOK }}</td>
									<td style="padding-left:5px;">{{ __('mcu.pcs_per_day') }}</td>
								</tr>
							</table>
						</td>
						<td width="50%">
							<table width="100%">
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BKBS_ALKOHOL == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.alcohol') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IKBS_TIMES_ALKOHOL }}</td>
									<td style="padding-left:5px;">{{ __('mcu.bottle_s_per_day') }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BKBS_MINUMKOPI == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.coffee') }}</td>
									<td width="10%" style="border:1px solid; text-align: center;">{{ $mcu->IKBS_TIMES_MINUMKOPI }}</td>
									<td style="padding-left:5px;">{{ __('mcu.glass_es_per_day') }}</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
            </main>
			<main style="font-size: 12pt;">
				<label><b>{{ __('mcu.history_of_family_disease') }}</b></label>
            </main>
            <main>
				<table width="100%">
					<tr>
						<td width="50%">
							<table width="100%">
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRPK_JANTUNG == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.heart_disease') }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRPK_DARAHTINGGI == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.hypertension') }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRPK_DIABETES == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.diabetes_melitus') }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRPK_STROKE == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.stroke') }}</td>
								</tr>
							</table>
						</td>
						<td width="50%">
							<table width="100%">
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRPK_KANKER == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.tumor_or_cancer') }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRPK_GANGGUANJIWA == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.mental_disorder') }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRPK_GINJAL == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.kidney_disease') }}</td>
								</tr>
								<tr>
									<td>
										<input type="checkbox" {{ $mcu->BRPK_SALURAN == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.disorder_of_digestive_system') }}</td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td width="50%">
							<table width="100%">
								<tr>
									<td width="5%">
										<input type="checkbox" {{ $mcu->BRPK_PARU == '1' ? 'checked' : '' }}>
									</td>
									<td>{{ __('mcu.lung_disease') }}</td>
								</tr>
							</table>
						</td>
						<td width="50%">
							<table width="100%">
								<tr>
									<td>{{ $mcu->VRPK_OTHER }}</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
            </main>
			<main style="font-size: 12pt;">
				<label><b>{{ __('mcu.working_history') }}</b></label>
            </main>
			<main>
				<table width="100%" border="1">
					<thead>
						<tr>
							<td colspan="2" class="text-center">{{ __('mcu.year_s') }}</td>
							<td rowspan="2" class="text-center">{{ __('mcu.company') }}</td>
							<td rowspan="2" class="text-center">{{ __('mcu.job_classification') }}</td>
							<td colspan="4" class="text-center">{{ __('mcu.working_exposure') }}</td>
							<td rowspan="2" class="text-center">{{ __('mcu.length') }}<br>{{ __('mcu.hour_s_per_day') }}</td>
							<td rowspan="2" class="text-center">{{ __('mcu.remarks') }}</td>
						</tr>
						<tr>
							<td class="text-center" width="5%">{{ __('mcu.from') }}</td>
							<td class="text-center" width="5%">{{ __('mcu.to') }}</td>
							<td class="text-center" width="5%">{{ __('mcu.dust') }}</td>
							<td class="text-center" width="5%">{{ __('mcu.smoke') }}</td>
							<td class="text-center" width="5%">{{ __('mcu.gass') }}</td>
							<td class="text-center" width="5%">{{ __('mcu.noise') }}</td>
						</tr>
					</thead>
					<tbody>
						@foreach ($dtls as $dtl)
							<tr>
								<td>{{ $dtl->IRWP_FROM }}</td>
								<td>{{ $dtl->IRWP_TO }}</td>
								<td>{{ $dtl->VRWP_CO }}</td>
								<td>{{ $dtl->VRWP_JOBTYPE }}</td>
								<td>
									<input type="checkbox" {{ $dtl->BRWP_DEBU == '1' ? 'checked' : '' }}>
								</td>
								<td>
									<input type="checkbox" {{ $dtl->BRWP_ASAP == '1' ? 'checked' : '' }}>
								</td>
								<td>
									<input type="checkbox" {{ $dtl->BRWP_GAS == '1' ? 'checked' : '' }}>
								</td>
								<td>
									<input type="checkbox" {{ $dtl->BRWP_BISING == '1' ? 'checked' : '' }}>
								</td>
								<td>{{ $dtl->IRWP_TIME }}</td>
								<td>{{ $dtl->VRWP_REMARK }}</td>
							</tr>
						@endforeach
					</tbody>
				</table>
            </main>
			<main>
				<table width="100%">
					<tr>
						<td width="70%">
							<table width="100%">
								<tr>
									<td>@if ($mcu->BBAHASA == '1')<img src="{{ url('/img/id-graph.png') }}">@else<img src="{{ url('/img/en-graph.png') }}">@endif</td>
								</tr>
								<tr>
									<td>@if ($mcu->BBAHASA == '1')<img src="{{ url('/img/id-notes.png') }}">@else<img src="{{ url('/img/en-notes.png') }}">@endif</td>
								</tr>
							</table>
						</td>
						<td width="30%">
							<br>
							<br>
							<br>
							<br>
							<table width="100%" border="1">
								<tr>
									<td class="text-center">ACTIVITIES NAME</td>
									<td class="text-center">SIGN</td>
								</tr>
								<tr>
									<td>REGISTRATION</td>
									<td></td>
								</tr>
								<tr>
									<td>VITAL SIGN <input class="float-right" type="checkbox" {{ $mcu->BVITALSIGN == '1' ? 'checked' : '' }}></td>
									<td></td>
								</tr>
								<tr>
									<td>URINE <input class="float-right" type="checkbox" {{ $mcu->BURINE == '1' ? 'checked' : '' }}></td>
									<td></td>
								</tr>
								<tr>
									<td>RONTGEN <input class="float-right" type="checkbox" {{ $mcu->BRONTGEN == '1' ? 'checked' : '' }}></td>
									<td></td>
								</tr>
								<tr>
									<td>{{ __('mcu.blood') }} NON CHOL <input class="float-right" type="checkbox" {{ $mcu->BDARAHNONCHOL == '1' ? 'checked' : '' }}></td>
									<td></td>
								</tr>
								<tr>
									<td>{{ __('mcu.blood') }} CHOLESTEROL <input class="float-right" type="checkbox" {{ $mcu->BDARAHCHOL == '1' ? 'checked' : '' }}></td>
									<td></td>
								</tr>
								<tr>
									<td>{{ __('mcu.physical') }} <input class="float-right" type="checkbox" {{ $mcu->BFISIK == '1' ? 'checked' : '' }}></td>
									<td></td>
								</tr>
								<tr>
									<td>EKG <input class="float-right" type="checkbox" {{ $mcu->BEKG == '1' ? 'checked' : '' }}></td>
									<td></td>
								</tr>
								<tr>
									<td>SPIROMETRI <input class="float-right" type="checkbox" {{ $mcu->BSPIRO == '1' ? 'checked' : '' }}></td>
									<td></td>
								</tr>
								<tr>
									<td>AUDIOMETRI <input class="float-right" type="checkbox" {{ $mcu->BAUDIO == '1' ? 'checked' : '' }}></td>
									<td></td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
            </main>
			<br>
			<footer>
				<table width="100%">
					<tr>
						<td width="65%"></td>
						<td width="35%">printed by : {{ Session::get('nameuser') }}, {{ Carbon\carbon::now()->format('d-M-Y H:i:s') }}</td>
					</tr>
				</table>
			</footer>
         </div>
      </div>
   </body>
</html>