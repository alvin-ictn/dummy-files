<html>
   <head>
      <title>Treatment</title>
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
   </head>
   <body>
      <style type="text/css">
         table tr td,
         table tr th {
         font-size: 9pt;
         }
         body {
         border-style: solid;
         }
         .invoice header {
         text-align: center;
         padding: 10px 0;
         margin-bottom: 20px;
         border-bottom: 1px solid #000000;
         }
         .invoice .head {
         padding: 10px 0;
         margin-bottom: 20px;
         border-bottom: 1px solid #000000;
         }
         .invoice .contacts {
         margin-bottom: 20px;
         }
         .invoice main {
         padding-bottom: 10px;
         border-bottom: 1px solid #000000;
         }
         .invoice .invoice-to {
         text-align: left;
         }
         .invoice .treatment {
         }
         .resep{

         padding-bottom: 400px;
         border-bottom: 1px solid #000000;
         }
         .pro{
            margin: auto;
         padding: 100px;
         padding-bottom: 400px;
         border-bottom: 1px solid #000000;
         }
      </style>
      <div id="invoice">
         <div class="invoice overflow-auto">
            <header>
               <h5>Klinik RAPP CMS</h5>
               <h4>Jl. .....................</h4>
            </header>
            <header>
               <h5>KHUSUS AKSES RAWAT JALAN / INAP</h5>
            </header>
            <main>
               <div class="row contacts">
                  <div class="col invoice-to">
                     <table>
                        <tr>
                           <td>
                              <h6 class="to">Tgl</h6>
                           </td>
                           <td>
                              <h6 class="to">:</h6>
                           </td>
                           <td>
                              <h6 class="to">{{ \Carbon\Carbon::parse($drugs->DVISIT)->format('Y/m/d') }}</h6>
                           </td>
                        </tr>
                        <tr>
                           <td>
                              <h6 class="to">Dr</h6>
                           </td>
                           <td>
                              <h6 class="to">:</h6>
                           </td>
                           <td>
                              <h6 class="to">{{$drugs->VNAME}}</h6>
                           </td>
                        </tr>
                     </table>
                  </div>
               </div>
            </main>
            <div class="treatment">
               <h3>R/</h3>
               <div class="resep">
                  <table>
                     @foreach($treatment as $tr)
                     <tr>
                        <td width="50%">
                           <h5>
                           {{$tr->VCONTAIN}}
                           <h5>
                        </td>
                     </tr>
                     @endforeach
                  </table>
               </div>
            </div>
                    <table>
                        <tr>
                            <td><h5>Pro</h5></td>
                            <td><h5>:</h5></td>
                            <td><h5>{{$patient->VNAME}}</h5></td>
                        </tr>
                        <tr>
                            <td><h5>Umur</h5></td>
                            <td><h5>:</h5></td>
                            <td><h5>{{ $age }}</h5></td>
                        </tr>
                        <tr>
                            <td><h5>Alamat</h5></td>
                            <td><h5>:</h5></td>
                            <td><h5>{{$patient->VADDRESS}}</h5></td>
                        </tr>
                        <tr>
                            <td><h5>No. RM</h5></td>
                            <td><h5>:</h5></td>
                            <td><h5>{{$patient->VMRNO}}</h5></td>
                        </tr>
                    </table>
            
         </div>
      </div>
   </body>
</html>