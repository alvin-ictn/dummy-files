<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title><?php echo Request::ip(); ?></title>
      <link href="{{ asset('css/custom.css') }}" rel="stylesheet">
      <link rel="stylesheet" href="{{ asset('css/all.min.css') }}">
      <link href="{{ asset('css/app.css') }}" rel="stylesheet">
      <link href="{{ asset('css/adminlte.css') }}" rel="stylesheet">
      <link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
      <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
      <link rel="stylesheet" href="{{ asset('plugins/datatables-bs4/css/dataTables.bootstrap4.min.css') }}">
      <link rel="stylesheet" href="{{ asset('plugins/datatables-responsive/css/responsive.bootstrap4.min.css') }}">
      <script src="{{ asset('js/jquery.js') }}"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.2/rollups/aes.js" integrity="sha256-/H4YS+7aYb9kJ5OKhFYPUjSJdrtV6AeyJOtTkw6X72o=" crossorigin="anonymous"></script>
      <!-- Styles -->
      <style>
         body {
         background-color: #DDEBF7;
         }
         .rounded1 {
          border-radius: 10px;
   
         }
      </style>
   </head>
   <body>
      <nav class=" navbar navbar-expand navbar-dark navbar-primary">
         <!-- Right navbar links -->
         <ul class="navbar-nav ml-auto">
            <li class="nav-item"> <a class="nav-link" href="{{ url('/login') }}">SIGN IN</a>
            </li>
         </ul>
      </nav>
      <!-- <div class="flex-center position-ref full-height">
         @if (Route::has('login'))
             <div class="top-right links">
                 @auth
                     <a href="{{ url('/home') }}">Home</a>
                 @else
                     <a href="{{ route('login') }}">Login</a>
         
                     @if (Route::has('register'))
                         <a href="{{ route('register') }}">Register</a>
                     @endif
                 @endauth
             </div>
         @endif -->
      <main class="body-login">
         <div class="container-fluid">
            <div class="row">
               <div class="col-12">
                  <div class="card rounded1 ">
                     <h5 class="card-header">Information / Announcement</h5>
                     <div class="card-body berita">
                        
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </main>
   </body>
   <script src="{{ asset('js/adminlte.js') }}" defer></script>
   <script src="{{ asset('js/demo.js') }}" defer></script>
   <script src="{{ asset('js/jquery-ui.js') }}" defer></script>
   <script src="{{ asset('plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
   <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
   <script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
   <script src="{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
   <script src="{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
   <script src="{{ asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>
   <script src="{{ asset('js/custom-clinic.js') }}" ></script>
   <script>
      $(document).ready(function() {

         $.ajax({
           dataType: 'json',
           type: 'GET',
           url: '/api/content/',
           success: function(result) {

            var data = '';
            var i;
                   
                   for (i = 0; i < result.length; i++) {
                   data += '<div class="card">';
                   data += '<h5 class="card-header">'+result[i].VCONTENTNAME+'</h5>';
                   data += '<div class="card-body">';
                   data += '<div class="card-text">'+result[i].VCONTENT+'</div>';
                   data += '</div>';
                   data += '</div>';
            
                   }

            $('.berita').html(data);
               
           }
       });
      })

   </script>
</html>