
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Sub District Code</th>
            <th>Sub District Name</th>
            <th>District Name</th>
            <th>Status</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($subdistrict as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->SUBDISTRICTCODE }}</td>
            <td>{{ $export->SUBDISTRICTNAME }}</td>
            <td>{{ $export->DISTRICT_NAME }}</td>
            <td>{{ $export->STATUS }}</td>
            <td>{{ $export->MODIFY_NAME }}</td>
            <td>{{ $export->MODIFY_DATE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>