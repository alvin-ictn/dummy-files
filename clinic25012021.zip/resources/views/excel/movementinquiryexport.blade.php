<table>
    <thead>
        <tr>
            <th>No.</th>
            <th>Date</th>
            <th>Transaction No.</th>
            <th>Type</th>
            <th>UoM</th>
            <th>Quantity</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($exports as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->DCREA }}</td>
            <td>{{ $export->VTRXNO }}</td>
            <td>{{ $export->VTYPE }}</td>
            <td>{{ $export->VUOM }}</td>
            <td>{{ $export->IQTY }}</td>
        </tr>
    @endforeach
    </tbody>
</table>