
                     
<table>
    <thead>
        <tr>
                              <th>No</th>
                              <th>Content Code</th>
                              <th>Content Name</th>
                              <th style="width: 5%">Content</th>
                              <th>Publish</th>
                              <th>Last Modified Name</th>
                              <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($content as $export)
        <tr>
                                <th>{{ $no++ }}</th>
                              <th>{{ $export->VCONTENTCODE }}</th>
                              <th>{{ $export->VCONTENTNAME }}</th>
                              <th style="width: 5%">{{ $export->VCONTENT }}</th>
                              <th>{{ $export->DPUBLISH }}</th>
                              <th>{{ $export->MODIFY_NAMES }}</th>
                              <th>{{ $export->DMODI }}</th>
 
        </tr>
    @endforeach
    </tbody>
</table>