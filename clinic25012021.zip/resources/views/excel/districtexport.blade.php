
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>District Code</th>
            <th>District Name</th>
            <th>Province Name</th>
            <th>Status</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($district as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->DISTRICTCODE }}</td>
            <td>{{ $export->DISTRICTNAME }}</td>
            <td>{{ $export->PROV_NAME }}</td>
            <td>{{ $export->STATUS }}</td>
            <td>{{ $export->MODIFY_NAME }}</td>
            <td>{{ $export->MODIFY_DATE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>