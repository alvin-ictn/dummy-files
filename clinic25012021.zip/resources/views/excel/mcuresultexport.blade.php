<table>
    <thead>
        <tr>
            <th>No.</th>
            <th>Registration No.</th>
            <th>SAP ID</th>
            <th>Employee Name</th>
			<th>Department</th>
			<th>Verified Date</th>
			<th>Completed Date</th>
			<th>Result Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($exports as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->VREGNO }}</td>
            <td>{{ $export->VIDNO }}</td>
            <td>{{ $export->EMPNAME }}</td>
            <td>{{ $export->DEPARTMENT }}</td>
            <td>{{ $export->DVERIFIED }}</td>
            <td>{{ $export->DCOMPLETED }}</td>
            <td>{{ $export->DRESULT }}</td>
        </tr>
    @endforeach
    </tbody>
</table>