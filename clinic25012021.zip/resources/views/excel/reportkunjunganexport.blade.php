            <table >
                     <tbody>
                        <tr>
                           <td> R </td>
                           <td>A </td>
                           <td>C </td>
                           <td>D </td>
                           <td>S</td>
                           <td> V</td>
                           <td> S</td>
                           <td>V </td>
                           <td>S </td>
                           <td>V </td>
                           <td>F </td>
                           <td>C </td>
                           <td>A </td>
                           <td>F </td>

                        </tr>
                     </tbody>
                  </table>