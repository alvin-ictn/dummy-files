
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Clinic Code</th>
            <th>Clinic Initial</th>
            <th>Clinic Name</th>
            <th>Clinic Status</th>
            <th>Sub District Name</th>
            <th>District Name</th>
            <th>Status</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($clinic as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->CLINICCODE }}</td>
            <td>{{ $export->CLINICINIT }}</td>
            <td>{{ $export->CLINICNAME }}</td>
            <td>{{ $export->CLINIC_STATUS }}</td>
            <td>{{ $export->SUBDISTRICTNAME }}</td>
            <td>{{ $export->DISTRICTNAME }}</td>
            <td>{{ $export->STATUS }}</td>
            <td>{{ $export->MODIFY_NAME }}</td>
            <td>{{ $export->MODIFY_DATE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>