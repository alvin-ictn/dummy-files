
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Regist Number</th>
            <th>Material Code</th>
            <th>Assets No</th>
            <th>Medical Kits Name</th>
            <th>Medical Kits Code</th>
            <th>Purchase Date</th>
            <th>Submit Date</th>
            <th>Location Name</th>
            <th>Business Unit</th>
            <th>Calibrate Date</th>
            <th>Status</th>
            <th>Criteria</th>
            <th>Quantity</th>
            <th>Remarks</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($medical as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->REG_NO }}</td>
            <td>{{ $export->MTRL_CODE }}</td>
            <td>{{ $export->ASSET_NO }}</td>
            <td>{{ $export->INSTR_NAME }}</td>
            <td>{{ $export->INSTR_BRAND }}</td>
            <td>{{ $export->PURCHASE_DATE }}</td>
            <td>{{ $export->SUBMIT_DATE }}</td>
            <td>{{ $export->LOCATION_NAME }}</td>
            <td>{{ $export->BUSINESS_UNIT }}</td>
            <td>{{ $export->CALIBRATE_DATE }}</td>
            <td>{{ $export->Status }}</td>
            <td>{{ $export->CRITERIA }}</td>
            <td>{{ $export->QTY }}</td>
            <td>{{ $export->REMARKS }}</td>
            <td>{{ $export->MODIFY_NAME }}</td>
            <td>{{ $export->MODIFY_DATE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>