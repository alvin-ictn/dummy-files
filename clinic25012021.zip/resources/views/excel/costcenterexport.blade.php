
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Cost Center Code</th>
            <th>Cost Center Name</th>
            <th>Status</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($costcenter as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->CC_CODE }}</td>
            <td>{{ $export->CC_NAME }}</td>
            <td>{{ $export->STATUS }}</td>
            <td>{{ $export->MODIFY_NAME }}</td>
            <td>{{ $export->MODIFY_DATE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>