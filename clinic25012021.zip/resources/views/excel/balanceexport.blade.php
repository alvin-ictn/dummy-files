<table>
    <thead>
        <tr>
            <th>No.</th>
            <th>Item Code</th>
            <th>Contain</th>
            <th>Brand</th>
            <th>UoM</th>
            <th>Stock</th>
            <th>Request</th>
            <th>Balance</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($exports as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->VDRUGSCODE }}</td>
            <td>{{ $export->VCONTAIN }}</td>
            <td>{{ $export->VBRAND }}</td>
            <td>{{ $export->VUOM }}</td>
            <td>{{ $export->STOCK }}</td>
            <td>{{ $export->REQUEST }}</td>
            <td>{{ $export->BALANCE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>