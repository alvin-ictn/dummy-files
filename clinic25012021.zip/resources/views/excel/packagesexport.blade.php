
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Packages Code</th>
            <th>Packages Name</th>
            <th>Status</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($packages as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->PCKG_CODE }}</td>
            <td>{{ $export->PCKG_NAME }}</td>
            <td>{{ $export->STATUS }}</td>
            <td>{{ $export->MODIFY_NAME }}</td>
            <td>{{ $export->MODIFY_DATE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>