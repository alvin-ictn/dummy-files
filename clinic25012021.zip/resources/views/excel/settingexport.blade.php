
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Parameter ID</th>
            <th>Parameter Code</th>
            <th>Description</th>
            <th>Additional Description</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($setting as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->SETID }}</td>
            <td>{{ $export->SETCODE }}</td>
            <td>{{ $export->SETDESC }}</td>
            <td>{{ $export->SETADDDESC }}</td>
            <td>{{ $export->MODIFY_NAME }}</td>
            <td>{{ $export->MODIFY_DATE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>