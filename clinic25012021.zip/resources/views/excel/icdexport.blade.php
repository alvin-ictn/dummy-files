
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Diagnosis Code</th>
            <th>Diagnosis Name</th>
            <th>Diagnosis Remarks</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($icd as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->VDXCODE }}</td>
            <td>{{ $export->VDXNAME }}</td>
            <td>{{ $export->VREMARKS }}</td>
            <td>{{ $export->DMODI }}</td>
        </tr>
    @endforeach
    </tbody>
</table>