
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>MR No</th>
            <th>Patient Name</th>
            <th>Date of Birth</th>
            <th>Gender</th>
            <th>Last Visit Date</th>
            <th>Phone No</th>
            <th>Doctor</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($exports as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->VMRNO }}</td>
            <td>{{ $export->VNAME }}</td>
            <td>{{ $export->DBIRTH }}</td>
            <td>{{ $export->GENDER }}</td>
            <td>{{ $export->LASTVISITDATE }}</td>
            <td>{{ $export->VPHONENO }}</td>
            <td>{{ $export->DOCTOR }}</td>
        </tr>
    @endforeach
    </tbody>
</table>