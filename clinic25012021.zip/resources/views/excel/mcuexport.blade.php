<table>
    <thead>
        <tr>
            <th>Registration No.</th>
            <th>SAP ID</th>
            <th>Employee Name</th>
			<th>Personnel Area</th>
            <th>Sub Personnel Area</th>
            <th>Cost Center</th>
			<th>Package</th>
			<th>Gender</th>
			<th>Reserved Date</th>
			<th>Time</th>
			<th>Document Status</th>
			<th>Verified Date</th>
			<th>Completed Date</th>
			<th>Created Name</th>
			<th>Created Date</th>
			<th>Last Modified Name</th>
			<th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @foreach($exports as $export)
        <tr>
            <td>{{ $export->VREGNO }}</td>
            <td>{{ $export->VIDNO }}</td>
            <td>{{ $export->EMPNAME }}</td>
			<td>{{ $export->PERSONALAREA }}</td>
            <td>{{ $export->SUBPERSONALAREA }}</td>
            <td>{{ $export->COSTCENTER }}</td>
            <td>{{ $export->PACKAGE }}</td>
            <td>{{ $export->GENDER }}</td>
            <td>{{ $export->DRESERVED }}</td>
            <td>{{ $export->TSESSIONTIME }}</td>
            <td>{{ $export->VDOCSTATUS }}</td>
            <td>{{ $export->DVERIFIED }}</td>
            <td>{{ $export->DCOMPLETED }}</td>
            <td>{{ $export->VCREA }}</td>
            <td>{{ $export->DCREA }}</td>
            <td>{{ $export->VMODI }}</td>
            <td>{{ $export->DMODI }}</td>
        </tr>
    @endforeach
    </tbody>
</table>