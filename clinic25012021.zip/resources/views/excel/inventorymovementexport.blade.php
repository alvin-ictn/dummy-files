<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Date</th>
            <th>Transaction No.</th>
            <th>Request No.</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($exports as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->DTRX }}</td>
            <td>{{ $export->VTRXNO }}</td>
            <td>{{ $export->VREQNO }}</td>
        </tr>
    @endforeach
    </tbody>
</table>