
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>General Type</th>
            <th>General Code</th>
            <th>General Description</th>
            <th>General Remarks</th>
            <th>Status</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($general as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->GNRLTYPE }}</td>
            <td>{{ $export->GNRLCODE }}</td>
            <td>{{ $export->GNRLDESC }}</td>
            <td>{{ $export->GNRLREMARKS }}</td>
            <td>{{ $export->STATUS }}</td>
            <td>{{ $export->MODIFY_NAME }}</td>
            <td>{{ $export->MODIFY_DATE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>