
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>User ID</th>
            <th>User Role</th>
            <th>User Name</th>
            <th>User Email</th>
            <th>Position</th>
            <th>Doctor Type</th>
            <th>Specialist</th>
            <th>User Type</th>
            <th>Last Login</th>
            <th>Status</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($users as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->USERID }}</td>
            <td>{{ $export->USERGROUP }}</td>
            <td>{{ $export->USERNAME }}</td>
            <td>{{ $export->USERMAIL }}</td>
            <td>{{ $export->POSNAME }}</td>
            <td>{{ $export->DRTYPE }}</td>
            <td>{{ $export->SPCNAME }}</td>
            <td>{{ $export->USERTYPE }}</td>
            <td>{{ $export->LOGINDATE }}</td>
            <td>{{ $export->STATUS }}</td>
            <td>{{ $export->MODIFY_NAME }}</td>
            <td>{{ $export->MODIFY_DATE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>