
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Sub Personnel Code</th>
            <th>Sub Personnel Name</th>
            <th>Personnel Area Name</th>
            <th>Status</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($subpersonnel as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->SUBPERSONELCODE }}</td>
            <td>{{ $export->SUBPERSONELNAME }}</td>
            <td>{{ $export->PERSONELNAME }}</td>
            <td>{{ $export->STATUS }}</td>
            <td>{{ $export->MODIFY_NAME }}</td>
            <td>{{ $export->MODIFY_DATE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>