
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Schedule Code</th>
            <th>Clinic Name</th>
            <th>Doctor Name</th>
            <th>Specialist</th>
            <th>Status</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($scheduledoctors as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->SCHEDULECODE }}</td>
            <td>{{ $export->CLINICNAME }}</td>
            <td>{{ $export->DOCTORNAME }}</td>
            <td>{{ $export->SPECIALIST }}</td>
            <td>{{ $export->STATUS }}</td>
            <td>{{ $export->MODIFY_NAME }}</td>
            <td>{{ $export->MODIFY_DATE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>