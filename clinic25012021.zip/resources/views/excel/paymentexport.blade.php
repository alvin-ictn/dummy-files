<table>
    <thead>
        <tr>
            <th>No</th>
            <th>MR No.</th>
            <th>Booking No.</th>
            <th>Doctor</th>
            <th>Patient Name</th>
            <th>Patient Type</th>
            <th>Date of Birth</th>
            <th>Gender</th>
            <th>Last Visit Date</th>
            <th>Phone No</th>
            <th>Status</th>
            <th>Total</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($exports as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->VMRNO }}</td>
            <td>{{ $export->VBOOKINGNO }}</td>
            <td>{{ $export->DOCTOR }}</td>
            <td>{{ $export->VNAME }}</td>
            <td>{{ $export->VTYPEPATIENT }}</td>
            <td>{{ $export->DBIRTH }}</td>
            <td>{{ $export->GENDER }}</td>
            <td>{{ $export->LASTVISITDATE }}</td>
            <td>{{ $export->VPHONENO }}</td>
            <td>{{ $export->STATUS }}</td>
            <td>{{ $export->TOTAL }}</td>
            <td>{{ $export->VMODI }}</td>
            <td>{{ $export->DMODI }}</td>
        </tr>
    @endforeach
    </tbody>
</table>