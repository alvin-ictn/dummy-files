
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>User Name</th>
            <th>Role Name</th>
            <th>Status</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($userrole as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->USERNAME }}</td>
            <td>{{ $export->ROLENAME }}</td>
            <td>{{ $export->STATUS }}</td>
            <td>{{ $export->MODIFY_NAME }}</td>
            <td>{{ $export->MODIFY_DATE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>