<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Request No.</th>
            <th>Request Date</th>
            <th>Request by</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($exports as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->VREQNO }}</td>
            <td>{{ $export->DREQ }}</td>
            <td>{{ $export->VCLINICNAME }}</td>
            <td>{{ $export->BSTATUS }}</td>
        </tr>
    @endforeach
    </tbody>
</table>