
<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Drugs Code</th>
            <th>Drugs Type</th>
            <th>Contain</th>
            <th>Brand</th>
            <th>Vendor</th>
            <th>UOM</th>
            <th>Price</th>
            <th>PBF</th>
            <th>Status</th>
            <th>Last Modified Name</th>
            <th>Last Modified Date</th>
        </tr>
    </thead>
    <tbody>
    @php $no = 1 @endphp
    @foreach($drugs as $export)
        <tr>
            <td>{{ $no++ }}</td>
            <td>{{ $export->DRUGS_CODE }}</td>
            <td>{{ $export->DRUGS_TYPE }}</td>
            <td>{{ $export->DRUGS_CONTAIN }}</td>
            <td>{{ $export->DRUGS_BRAND }}</td>
            <td>{{ $export->DRUGS_VENDOR }}</td>
            <td>{{ $export->DRUGS_UOM }}</td>
            <td>{{ $export->DRUGS_PRICE }}</td>
            <td>{{ $export->PBF_TYPE }}</td>
            <td>{{ $export->STATUS }}</td>
            <td>{{ $export->MODIFY_NAME }}</td>
            <td>{{ $export->MODIFY_DATE }}</td>
        </tr>
    @endforeach
    </tbody>
</table>