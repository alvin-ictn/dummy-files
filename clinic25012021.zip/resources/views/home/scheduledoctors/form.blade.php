@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-12">
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header card-color">
                        <h3 class="card-title text-white">
                        Doctor Schedule Form
                    </h3>
                </div>
               <!-- /.card-header -->
                <div class="card-body">
                    <form id="form-confirm" data-url="/scheduledoctors/form" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input name="VSCHCODE" type="hidden" value="{{ $schedule->VSCHCODE ?? '' }}">
                        <div class="row">
                            <div class="col-lg-2 col-sm-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Clinic Name</label>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-12">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <div class="input-group">
                                            <input name="VCLINICNAME" class="form-control" type="text" value="{{ $schedule->VCLINICCODE ?? '' }}{{ isset($mstclinic->CLINICNAME) && $mstclinic->CLINICNAME != '' ? ' - '.$mstclinic->CLINICNAME : '' }}" readonly>
                                            <input name="VCLINICCODE"class="form-control" type="hidden" value="{{ $schedule->VCLINICCODE ?? '' }}" readonly>
                                            @if(!isset($schedule))
                                                <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myModalClinic" pointer-events="none">
                                                    <div class="input-group-text"><i class="fa fa-search"></i></div>
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>

                            @if(isset($schedule))
                            <div class="col-lg-2 col-sm-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Status</label>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-12">
                                <div class="form-group">
                                    <div class="col-sm-12">
								        <div class="form-check form-check-inline">
								            <input class="form-check-input" name="BACTIVE" type="radio" value="1" {{ ($schedule->VCLINICCODE != '' && $schedule->BACTIVE == '1') ? 'checked' : '' }} required>
								            <label class="form-check-label">Active</label>
								        </div>
								        <div class="form-check form-check-inline">
								            <input class="form-check-input" name="BACTIVE" type="radio" value="0" {{ ($schedule->VCLINICCODE != '' && $schedule->BACTIVE == '0') ? 'checked' : '' }} required>
								            <label class="form-check-label">Inactive</label>
								        </div>
                                    </div>
                                </div>
                            </div> 
                            @endif 
                        </div>

                        <div class="row">
                            <div class="col-lg-2 col-sm-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Doctor Name</label>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-12">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <div class="input-group">
                                            <input name="VDOCTORNAME" class="form-control" type="text" value="{{ $schedule->VUSRID ?? '' }}{{ isset($mstclinicstaff->VNAME) ? ' - '.$mstclinicstaff->VNAME : '' }}" readonly>
                                            <input name="VDOCTORID"class="form-control" type="hidden" value="{{ $schedule->VUSRID ?? '' }}" readonly>
                                            @if(!isset($schedule))
                                                <div class="input-group-append" style="cursor: pointer;" onclick="return getDoctorList();" data-toggle="modal" data-target="#myModalDoctor">
                                                    <div class="input-group-text"><i class="fa fa-search"></i></div>
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-12">
                                <div class="form-group">
                                    <label class="control-label col-md-12">Specialist</label>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-12">
                                <div class="form-group">
                                    <div class="col-md-12">
                                    <input name="VSPCNAME" class="form-control" value="{{ $VGNRLDESC ?? '' }}" type="text" readonly>
                                    <input name="VSPCCODE" class="form-control" value="{{ $schedule->VSPCCODE ?? '' }}" type="hidden" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>
                        <div class="row">
                            <div class="col-lg-12 col-sm-12 form-group">
                                <button type="button" class="btn-cstm btn-primary btn-sz" onclick="return toForm(this);">Add New</button>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 col-sm-12 form-group">
                                <table id="tblmember" border="1" width="100%">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Action</th>
                                            <th class="text-center">Day</th>
                                            <th class="text-center">Start</th>
                                            <th class="text-center">End</th>
                                            <th class="text-center">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if(isset($schedule))
                                            @foreach ($members as $member)
                                                <tr>
                                                    <!-- inserted "member" to prevent editing the wrong row -->
                                                    <td data-value="ILINENO" style="display: none;"> {{ $member->ILINENO."member" }}    
                                                        <input name="ILINENO[]" type="hidden" value='{{ $member->ILINENO }}'>
                                                    </td>
                                                    <td style="text-align:center; width:10%;"><button type="button" title="Edit" class="btn btn-link btn-sm" onclick="toForm(this, '{{ $member->ILINENO }}')"> <i class="fas fa-edit"></i></button></td>
                                                    <td data-value="VSCHDAY"> {{$member->VSCHDAY }}  <input name="VSCHDAY[]" type="hidden" value='{{$member->VSCHDAY }}'></td>
                                                    <td data-value="TSCHSTART"> {{ date_format(date_create($member->TSCHSTART),"H:i") }} <input name="TSCHSTART[]" type="hidden" value=' {{ date_format(date_create($member->TSCHSTART),"H:i") }}'></td>
                                                    <td data-value="TSCHEND"> {{ date_format(date_create($member->TSCHEND),"H:i") }} <input name="TSCHEND[]" type="hidden" value='{{ date_format(date_create($member->TSCHEND),"H:i") }}'></td>
                                                    <td data-value="DTLBACTIVE" style="text-align:center; width:5%;"> 
                                                        @if($member->BACTIVE == '1')
                                                            <input name="DTLBACTIVE[]" type="checkbox" value='DTLBACTIVE{{ $member->ILINENO }}' checked>
                                                        @else
                                                            <input name="DTLBACTIVE[]" type="checkbox" value='DTLBACTIVE{{ $member->ILINENO }}'>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endforeach
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <br/>
                        <div class="form-group row">
                            <div class="col-md-12">
                                <div class="float-right">
                                    <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz" onclick="return CheckTimeOverlap();">Save</button>
                                    <a href="/account/scheduledoctors" class="btn btn-cstm btn-light btn-sz">Close</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
   

    <!-- Clinic List -->
    <div class="modal fade in" id="myModalClinic" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-content">
         <div class="card mb-4">
            <div class="card-header bg-info">
               <h5 class="card-title text-white" align="center">Clinic</h5>
               <button type="button" class="close text-white" data-dismiss="modal">×</button>
            </div>
            <div class="card-body p-3">
               <div id="dvData" class="table-responsive">
                  <table id="tblclinic" class="display" style="width:100%">
                     <thead>
                        <tr>
                           <th>
                              Clinic Code
                           </th>
                           <th>
                              Clinic Name
                           </th>
                        </tr>
                     </thead>
                  </table>
               </div>
            </div>
         </div>
      </div>
    </div>
    <!-- Doctor List -->
    <div class="modal fade in" id="myModalDoctor" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-content">
         <div class="card mb-4">
            <div class="card-header bg-info">
               <h5 class="card-title text-white" align="center">Doctor</h5>
               <button type="button" class="close text-white" data-dismiss="modal">×</button>
            </div>
            <div class="card-body p-3">
               <div id="dvData" class="table-responsive">
                  <table id="tbldoctor" class="display" style="width:100%">
                     <thead>
                        <tr>
                           <th >
                              Docter User ID
                           </th>
                           <th>
                              Doctor Name
                           </th>
                           <th>
                              Doctor
                           </th>
                           <th>
                              Specialist
                           </th>
                        </tr>
                     </thead>
                  </table>
               </div>
            </div>
         </div>
      </div>
    </div>

    <!-- Schedule Detail form -->
    <div class="modal fade" id="modaladdnew" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-body">
                    <form id="form-addnew">
						<div class="container">
							<div class="row">
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
                                        <div class="col-sm-12">
                                            <input id="ILINENO" type="text" style="display: none;">
										    <select class="form-control" id="VSCHDAY" placeholder="Type Document">
											   <option value="">-- Select Day --</option>
                                                <option value="Monday">Monday</option>                             
                                                <option value="Tuesday">Tuesday</option>                             
                                                <option value="Wednesday">Wednesday</option>                             
                                                <option value="Thursday">Thursday</option>                             
                                                <option value="Friday">Friday</option>                             
                                                <option value="Saturday">Saturday</option>                             
                                                <option value="Sunday">Sunday</option>                             
										    </select>
									    </div>
								    </div>
								</div>
                            </div>
							<div class="row">
								<div class="col-lg-6 col-sm-12">
								    <div class="form-group">
									    <div class="col-sm-12">
										    <div class="input-group date" id="SCHSTART" data-target-input="nearest">
											    <input type="text" class="form-control datetimepicker-input" id="TSCHSTART" data-target="#SCHSTART" placeholder="Start time" autocomplete="off" >
											    <div class="input-group-append" data-target="#SCHSTART" data-toggle="datetimepicker">
											       <div class="input-group-text"><i class="fa fa-calendar"></i></div>
											    </div>
									 	    </div>
									    </div>
								    </div>
								</div>
								<div class="col-lg-6 col-sm-12">
								    <div class="form-group">
									    <div class="col-sm-12">
										    <div class="input-group date" id="SCHEND" data-target-input="nearest">
											    <input type="text" class="form-control datetimepicker-input" id="TSCHEND" data-target="#SCHEND" placeholder="End time" autocomplete="off" >
											    <div class="input-group-append" data-target="#SCHEND" data-toggle="datetimepicker">
											        <div class="input-group-text"><i class="fa fa-calendar"></i></div>
											    </div>
										    </div>
									    </div>
								    </div>
								</div>
							</div>

							<br/>
							<div style="text-align:center;">
								<button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
								<a onclick="$('#modaladdnew').modal('hide');" class="btn-cstm btn-light btn-sz">Close</a>
							</div>
                        </div>
                    </form>
                </div>
             </div>
        </div>
    </div>
</section>

<script>
    var session_groupuser = '{{ Session::get('groupuser')[0] }}';   
    var session_cliniccode = '{{ Session::get('cliniccode') }}';   
    var session_clinicname = '{{ Session::get('clinicname') }}';   

	$(document).ready(function() {
        //==== When user is Admin Clinic
        if(session_groupuser === 'ADM' && window.location.href.indexOf("add") > -1)
        {
            $('input[name="VCLINICNAME"]').val(session_cliniccode + ' - ' + session_clinicname); 
            $('input[name="VCLINICCODE"]').val(session_cliniccode);  
            $('div[data-target="#myModalClinic"]').hide()
        }

        //==== Clinic List table
		var table_clinic = $("#tblclinic").DataTable({ 
         ajax: { url: '/scheduledoctors/getcliniclookup', type: "GET" }, 
         columns: [ 
            { data: "CLINICCODE" }, 
            { data: "CLINICNAME" } 
         ] 
        });
        $('#tblclinic tbody').on('dblclick', 'tr', function () {  // Select with double click
			var data = table_clinic.row(this).data();
			$('input[name="VCLINICNAME"]').val(data['CLINICCODE'] + ' - ' + data['CLINICNAME']);     // fill field with "clinic code - clinic name"
			$('input[name="VCLINICCODE"]').val(data['CLINICCODE']);                                  // save "clinic code" in hidden input
            $(this).closest('.card').find('button').trigger('click');
            
            // Reset Doctor Name and Specialist field
            $('input[name="VDOCTORNAME"]').val(''); 
            $('input[name="VDOCTORID"]').val('');                            
            $('input[name="VSPCNAME"]').val('');                         
            $('input[name="VSPCCODE"]').val('');                     
        });

        //==== Doctor List table
        getDoctorList();

        //==== Time picker
		$('#SCHSTART, #SCHEND').datetimepicker({
            format: 'HH:mm'
        });

        // DEBUG
        // $('#startDiv').on('click', function()
        // {
        //     alert("VSCHCODE val : " + $('input[name="VSCHCODE"]').val());
        // });
    });
    
    //==== Doctor list lookup
    function getDoctorList()
    {
        // Clear & destroy existing table_doctor (if there is one), for reinitialize
        if($('#tbldoctor') != null){
            $('#tbldoctor').DataTable().clear();
            $('#tbldoctor').DataTable().destroy();
        }

        // Doctor List table
        table_doctor = $("#tbldoctor").DataTable({ 
           ajax: { url: '/scheduledoctors/getdoctorlookup', type: "GET", data: { 'clinic_code' : $('input[name="VCLINICCODE"').val() } }, 
           columns: [ 
              { data: "DRCODE",
                bVisible:false,
                 }, 
              { data: "DRNAME" },
              { data: "DRTYPE",
                render:function(data, type, row){
                    switch(data)
                    {
                        case 'UMUM': return "General Practitioner";
                        case "SPCL": return "Specialist";
                        case "GIGI": return "Dentist";
                        default: return "";
                    }
                },
             },
              { data: "SPECIALIST" }
           ] 
        });
        $('#tbldoctor tbody').on('dblclick', 'tr', function () {  // Select with double click
	    		var data = table_doctor.row(this).data();
	    		$('input[name="VDOCTORNAME"]').val(data['DRCODE'] + ' - ' + data['DRNAME']); // fill field with "id - name" of doctor
                $('input[name="VDOCTORID"]').val(data['DRCODE']);                            // save "doctor id" in hidden input 
                $('input[name="VSPCNAME"]').val(data['SPECIALIST']);                         // set field specialist
                $('input[name="VSPCCODE"]').val(data['SPECIALISTCODE']);                     // save "specialist code" in hidden input
	    		$(this).closest('.card').find('button').trigger('click');
        });
    }

    //==== Add new row to table & edit existing row
    function toForm(th, id) {
		$('#form-addnew').trigger("reset");
        if (id !== undefined) {     // edit row, when id(ILINENO) is not empty
			$.each($(th).closest('tr').find('td'), function( index, value ) {
				var input = $('#form-addnew #' + $(value).attr('data-value') + '');
                // Day
                if ($(value).attr('data-value') == "VSCHDAY") { 
					if ($(value).text() != '') $('#VSCHDAY').prop('selectedIndex', $("#VSCHDAY option:contains(" + $(value).text().trim() + ")")[0].index);
				}
                // LineNo, Time start and end
                else {
                    input.val($(value).text());
                }
			});
		}
        $('#modaladdnew').modal('show');
    }
    
    //==== Remove existing row in table
	function remove(th) {
		swal.fire({
			text: "Do you want to delete the data?",
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Yes",
			cancelButtonText: "No"
		}).then(function (result) {
			if (result.value) {
				$(th).closest('tr').remove();
                $.each($('#tblfile tbody tr'), function( index, value ) {
                    $('#tblfile tbody tr:eq(' + index + ') td:eq(1)').text(index + 1);
                });
			}
		});
	}

    //==== Add new row & edit row save button
    // for ILINENO, row number
	$(document).on("submit", "[id^=form-addnew]", function (e) {
        e.preventDefault();

        // Validations
        if($('#TSCHSTART,#TSCHEND').val() == ''){
            Swal.fire('Error', 'Please fill all fields.', 'error');
            return false;
        }
        if($('#VSCHDAY option:selected').val() == ''){
            Swal.fire('Error', 'Please select a day.', 'error');
            return false;
        }
        if(parseInt($('#TSCHSTART').val().replace(':', '')) >= parseInt($('#TSCHEND').val().replace(':', ''))){
            Swal.fire('Error', 'Time is invalid.', 'error');
            return false;
        }
        
        // Validation for time overlapping
        // var all_lineno = $('input[name="ILINENO[]"]').map(function(){return $(this).val();}).get();
        // var all_day = $('input[name="VSCHDAY[]"]').map(function(){return $(this).val();}).get();
        // var all_start_time = $('input[name="TSCHSTART[]"]').map(function(){return $(this).val().trim();}).get();
        // var all_end_time = $('input[name="TSCHEND[]"]').map(function(){return $(this).val().trim();}).get();
        // for(var i = 0; i < $('input[name="ILINENO[]"]').length; i++)
        // {
        //     if(all_lineno[i] == $('#ILINENO').val().replace(/[a-z]*/gi, '').trim() || all_day[i] != $('#VSCHDAY').val()) continue;

        //     var this_start = parseInt($('#TSCHSTART').val().replace(':', ''));      // newly added start time
        //     var this_end = parseInt($('#TSCHEND').val().replace(':', ''));          // newly added end time
        //     var that_start = parseInt(all_start_time[i].replace(':', ''));          // existing(by index) start time
        //     var that_end = parseInt(all_end_time[i].replace(':', ''));              // existing(by index) end time

        //     if(that_start <= this_start && this_start <= that_end)
        //     {
        //         Swal.fire('Error', 'Start time (' + $('#TSCHSTART').val() + ') is overlapping with ' + all_day[i] + '\'s schedule (' + all_start_time[i] + ' - ' + all_end_time[i] + ').', 'error');
        //         return false;
        //     }
        //     if(that_start <= this_end && this_end <= that_end)
        //     {
        //         Swal.fire('Error', 'End time (' + $('#TSCHEND').val() + ') is overlapping with ' + all_day[i] + '\'s schedule (' + all_start_time[i] + ' - ' + all_end_time[i] + ').', 'error');
        //         return false;
        //     }
        // }
        
        serial = $('td[data-value="ILINENO"]').length + 1;
		if ($('#form-addnew #ILINENO').val() != '') {
            // Edit existing row
			$.each($('#tblmember td:contains(' + $('#form-addnew #ILINENO').val().trim() + ')').closest('tr').find('td[data-value]'), function( index, value ) {
                //alert($('#form-addnew #ILINENO').val().trim());
                // Day
                if ($(value).attr('data-value') == "VSCHDAY") {
                    if ($('#VSCHDAY option:selected').val() != '') {
                        $(value).html($('#VSCHDAY option:selected').text() + '<input name="' + $(value).attr('data-value') + '[]" type="hidden" value="' + $('#VSCHDAY option:selected').val() + '">');
                    }
                } 
                // Time start and end (except ILINENO & DTLBACTIVE)
                else if ($(value).attr('data-value') != "ILINENO" && $(value).attr('data-value') != "DTLBACTIVE"){
                    $(value).html($('#form-addnew input[id="' + $(value).attr('data-value') + '"]').val() + '<input name="' + $(value).attr('data-value') + '[]" type="hidden" value="' + $('#form-addnew input[id="' + $(value).attr('data-value') + '"]').val() + '">');
                }
			});
        } 
        else {    
            // Add new row
			var td = '';
            // Row number (insert "new" to prevent editing the wrong row)
            td += '<td data-value="ILINENO" style="display: none;">' + serial.toString().padStart(13, '0') + 'new' + '<input name="ILINENO[]" type="hidden" value="' + serial.toString().padStart(13, '0') + '"></td>';
            // Edit button
            td += '<td style="text-align:center; width:10%;"><button onclick="toForm(this, \'' + serial.toString().padStart(13, '0') + '\')" type="button" title="Edit" class="btn btn btn-link btn-sm"><i class="fas fa-edit"></i></button>&nbsp;';    
            // Delete button
            td += '<button onclick="remove(this)" data-id="' + $('#ILINENO').val() + '" type="button" title="Delete" class="btn btn btn-link btn-sm"><i class="fas fa-times"></i></button></td>';
            // the rest of the cell
            $.each($('#form-addnew input[type="text"]'), function( index, value ) {
                // Day
                if (index == 0) td += '<td data-value="VSCHDAY">' + $('#VSCHDAY option:selected').text() + '<input name="VSCHDAY[]" type="hidden" value="' + $('#VSCHDAY option:selected').val() + '"></td>';
				// Time start and end
                else td += '<td data-value="' + $(value).attr('id') + '">' + $(value).val() + '<input name="' + $(value).attr('id') + '[]" type="hidden" value="' + $(value).val() + '"></td>';
            });
            // Status
            td += '<td data-value="DTLBACTIVE" style="text-align:center; width:5%;"> <input name="DTLBACTIVE[]" type="checkbox" value="DTLBACTIVE' + serial.toString().padStart(13, '0') + '" checked></td>';
			$('#tblmember tbody').append('<tr>' + td + '</tr>');    // Add to table
            serial++;   // for next row's row number
		}
		$('#modaladdnew').modal('hide');    // close
	});
   
    //===== When click save, check if there is a checked schedule detail time that overlapping with others
    function CheckTimeOverlap()
    {
        var all_dtlbactive = $('input[name="DTLBACTIVE[]"]').map(function(){return $(this).prop("checked");}).get();
        var all_lineno = $('input[name="ILINENO[]"]').map(function(){return $(this).val();}).get();
        var all_day = $('input[name="VSCHDAY[]"]').map(function(){return $(this).val();}).get();
        var all_start_time = $('input[name="TSCHSTART[]"]').map(function(){return $(this).val().trim();}).get();
        var all_end_time = $('input[name="TSCHEND[]"]').map(function(){return $(this).val().trim();}).get();
        for(var i = 0; i < $('input[name="ILINENO[]"]').length; i++)
        {
            if(all_dtlbactive[i] == false) continue;
            for(var j = 0; j < $('input[name="ILINENO[]"]').length; j++)
            {
                if(all_dtlbactive[j] == false) continue;
                if(all_lineno[i] == all_lineno[j] || all_day[i] != all_day[j]) continue;

                var this_start = parseInt(all_start_time[i].replace(':', ''));          // existing(by index i) start time
                var this_end = parseInt(all_end_time[i].replace(':', ''));              // existing(by index i) end time
                var that_start = parseInt(all_start_time[j].replace(':', ''));          // existing(by index j) start time
                var that_end = parseInt(all_end_time[j].replace(':', ''));              // existing(by index j) end time

                if(that_start <= this_start && this_start <= that_end || that_start <= this_end && this_end <= that_end)
                {
                    Swal.fire('Error', all_day[j] + '\'s schedule time is overlapping :<br/>(' + all_start_time[i] + ' - ' + all_end_time[i] + ') and (' + all_start_time[j] + ' - ' + all_end_time[j] + ').', 'error');
                    return false;
                }
            }
        }
    }

</script>
@endsection