@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-12">
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12"> 
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Movement Inquiry
                  </h3>
               </div>
               <!-- <div class="card-header">
                  <h3 class="row card-title">
                     <a class="btn btn-sz btn-primary" href="userrole/add" role="button">Add New</a>
                  </h3>
               </div> -->
               <div class="card-header">
                  <h3 class="row card-title">
                     <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('E', 'F35')) { ?>
                        <form action="/movementinquiry/export_excel" method="POST">
                              @csrf
                              <input type="hidden" name="cliniccode">
                              <input type="hidden" name="drugscode">
                              <input type="hidden" name="from_date">
                              <input type="hidden" name="to_date">
                              <input type="hidden" name="no" id="no">
							         <input type="hidden" name="date" id="date">
                              <input type="hidden" name="transno" id="transno">
                              <input type="hidden" name="type" id="type">
                              <input type="hidden" name="uom" id="uom">
                              <input type="hidden" name="qty" id="qty">
                              <input id="search" type="hidden" name="search">
                        
                              <button class="btn btn-sz btn-primary" type="submit">Export to Excel</button>
                        </form>
                     <?php } ?>
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <div class="form-group">
                     <div class="form-group row">
                        <label class="col-form-label control-label col-sm-1">Date from</label>
                        <div class="col-sm-4">
                           <div class="input-group date" id="DFROM" data-target-input="nearest">
                              <input type="text" class="form-control datetimepicker-input" name="DFROM" data-target="#DFROM" placeholder="DD-MMM-YYYY" required>
                              <div class="input-group-append" data-target="#DFROM" data-toggle="datetimepicker">
                                 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                              </div>
                           </div>
                        </div>
                        <label class="col-form-label control-label col-sm-1">to</label>
                        <div class="form-group col-sm-4">
                           <div class="input-group date" id="DTO" data-target-input="nearest">
                              <input type="text" class="form-control datetimepicker-input" name="DTO" data-target="#DTO" placeholder="DD-MMM-YYYY" required>
                              <div class="input-group-append" data-target="#DTO" data-toggle="datetimepicker">
                                 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="form-group row">
                        <label class="col-form-label control-label col-sm-1">Item Code</label>
                        <div class="col-sm-4">
                           <div class="input-group">
                              <input name="VITEMNAME" class="form-control" type="text" readonly>
                              <input name="VITEMCODE"class="form-control" type="hidden" readonly>
                              <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myModalItem">
                                 <div class="input-group-text"><i class="fa fa-search"></i></div>
                              </div>
                           </div>
                        </div>
                        <label class="col-form-label control-label col-sm-1">Location</label>
                        <div class="col-sm-4">
                              @if(session('groupuser')[0] == 'HRADM')
                                 <input name="VCLINICCODE"class="form-control" type="hidden" readonly>
                                 <input name="clinic_code"class="form-control" type="hidden" value="{{ session('cliniccode') }}" readonly>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="VLOC" type="radio" value="H" onchange="SetClinicCode()" required>
                                    <label class="form-check-label">HO</label>
                                 </div>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="VLOC" type="radio" value="C" onchange="SetClinicCode()" required>
                                    <label class="form-check-label">Clinic</label>
                                 </div>
                              @else
                                 <input name="VCLINICCODE"class="form-control" type="hidden" value="{{ session('cliniccode') }}" readonly>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="VLOC" type="radio" value="H" disabled required>
                                    <label class="form-check-label">HO</label>
                                 </div>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="VLOC" type="radio" value="C" checked disabled required>
                                    <label class="form-check-label">Clinic</label>
                                 </div>
                              @endif
                              <button class="btn btn-sz btn-primary" onclick="return LoadTable();" role="button" style="color:white;">Search</button>
                        </div>
                     </div>
                  </div>
                  <br/>
                  @if ($errors->any())
                     <div class="alert alert-danger">
                        <ul>
                           @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                           @endforeach
                        </ul>
                     </div>
                  @endif
                  <div class="table-responsive">
                     <table id="cmmovementinquiry" class="table table-bordered table-striped display compact nowrap" style="width:100%">
                        <thead>
                           <tr>
                              <th>No.</th>
                              <th>Date</th>
                              <th>Transaction No.</th>
                              <th>Type</th>
                              <!-- <th>Item Code</th>
                              <th>Item Name</th> -->
                              <th>UoM</th>
                              <th>Quantity</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>

   <!-- User List -->
   <div class="modal fade in" id="myModalItem" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-content">
         <div class="card mb-4">
            <div class="card-header bg-info">
               <h5 class="card-title text-white" align="center">Item List</h5>
               <button type="button" class="close text-white" data-dismiss="modal">×</button>
            </div>
            <div class="card-body p-3">
               <div id="dvData" class="table-responsive">
                  <table id="tblitem" class="display" style="width:100%">
                     <thead>
                        <tr>
                           <th>
                              Item Code
                           </th>
                           <th>
                              Contain
                           </th>
                           <th>
                              Brand
                           </th>
                        </tr>
                     </thead>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<style>
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::after{display: none}
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::before{display: none}
</style>

<script>
	$(document).ready(function() {

      $('#DFROM, #DTO').datetimepicker({
         format: 'DD-MMM-YYYY',
      });

   });
   
	$(document).ready(function() {
      //====Main table
      SetClinicCode();
      LoadTable();    
      $('#cmmovementinquiry thead tr').clone(true).appendTo( '#cmmovementinquiry thead' );
      $('#cmmovementinquiry thead tr:eq(1) th').each( function (i) {
         var title = $(this).text();

         if (title === "No."){
            $(this).html( '<input type="text" class="input-sm no" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Date"){
            $(this).html( '<input type="date" class="input-sm date" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Transaction No."){
            $(this).html( '<input type="text" class="input-sm transno" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Type"){
            $(this).html( '<input type="text" class="input-sm type" placeholder="Search ' + title + '" />' );
         }
         // else if (title === "Item Code"){
         //    $(this).html( '<input type="text" class="input-sm itemcode" placeholder="Search ' + title + '" />' );
         // }
         // else if (title === "Item Name"){
         //    $(this).html( '<input type="text" class="input-sm itemname" placeholder="Search ' + title + '" />' );
         // }
         else if (title === "UoM"){
            $(this).html( '<input type="text" class="input-sm uom" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Quantity"){
            $(this).html( '<input type="text" class="input-sm qty" placeholder="Search ' + title + '" />' );
         }
        
         $( 'input', this ).on( 'keyup change', function () {
            if ( tablemovementinquiry.column(i).search() !== this.value ) {
               tablemovementinquiry
                  .column(i)
                  .search( this.value )
                  .draw();
                  
                  var no = $('.no').val();
                  var date = $('input.date').val();
                  var transno = $('.transno').val();
                  var type = $('.type').val();
                  // var itemcode = $('.itemcode').val();
                  // var itemname = $('.itemname').val();
                  var uom = $('.uom').val();
                  var qty = $('.qty').val();
                  
                  $('#no').val(no);
                  $('#date').val(date);
                  $('#transno').val(transno);
                  $('#type').val(type);
                  // $('#itemcode').val(itemcode);
                  // $('#itemname').val(itemname);
                  $('#uom').val(uom);
                  $('#qty').val(qty);
            }
         });
      });

      tablemovementinquiry.columns().every(function (index) {
        $('#cmmovementinquiry thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
            tablemovementinquiry.column($(this).parent().index() + ':visible')
                .search(this.value)
                .draw();
        });
      });

      //====User List table
		var table_user_name = $("#tblitem").DataTable({ 
         ajax: { url: '/movementinquiry/getitemlookup', type: "GET", }, 
         columns: [ 
            { data: "DRUGS_CODE" }, 
            { data: "DRUGS_CONTAIN" },
            { data: "DRUGS_BRAND" } 
         ] 
      });
      
      $('#tblitem tbody').on('dblclick', 'tr', function () {  // Select with double click
			var data = table_user_name.row(this).data();
			$('input[name="VITEMNAME"]').val(data['DRUGS_CODE'] + ' - ' + data['DRUGS_CONTAIN']);   // fill field with "id - name" of user
			$('input[name="VITEMCODE"]').val(data['DRUGS_CODE']);                             // save "user id" in hidden input 
			$(this).closest('.card').find('button').trigger('click');
      });
   });

   //==== Load the main table
   function LoadTable()
   {
      tablemovementinquiry = $("#cmmovementinquiry").DataTable({
         destroy: true,
         processing: true,
         serverSide: true,
         dom: '<lf<t><r>ip>',
         columns: [
            { data: "IQTY", className: "text-right" }
         ],
         columnDefs: [
            { "width": "5%", "targets": 0 },
         ],
         ajax: {
            url: '/ajaxmovementinquiry',
            type: "GET",
            data: function (d) {
               d.date = $('input.date').val(),
               d.search = $('input[type="search"]').val(),
               d.VCLINICCODE = $('input[name="VCLINICCODE"]').val(),
               d.VITEMCODE = $('input[name="VITEMCODE"]').val(),
               d.DFROM = $('input[name="DFROM"]').val(), 
               d.DTO = $('input[name="DTO"]').val()
            }
         },
         columns: [
            {
               data: "no",
               name: "no",
            },
            {
               data: "DCREA",
               name: "DCREA",
               searchable: false,
            },
            {
               data: "VTRXNO",
               name: "VTRXNO",
            },
            {
               data: "VTYPE",
               name: "VTYPE",
            },
            // {
            //    data: "ItemCode",
            //    name: "ItemCode",
            // },
            // {
            //    data: "ItemName",
            //    name: "ItemName",
            // },
            {
               data: "VUOM",
               name: "VUOM",
            },
            {
               data: "IQTY",
               name: "IQTY",
            },
         ],
      })
      
		$('input[name="cliniccode"]').val($('input[name="VCLINICCODE"]').val());
      $('input[name="drugscode"]').val($('input[name="VITEMCODE"]').val());
		$('input[name="from_date"]').val($('input[name="DFROM"]').val());
      $('input[name="to_date"]').val($('input[name="DTO"]').val());
   }

   function SetClinicCode()
   {
      if($("input[name='VLOC']:checked").val() == 'H') $("input[name='VCLINICCODE']").val('ALL');
      else  $("input[name='VCLINICCODE']").val($("input[name='clinic_code']").val());
   }
   
</script>

@endsection