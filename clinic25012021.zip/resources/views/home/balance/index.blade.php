@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-12">
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12"> 
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Inventory Balance
                  </h3>
               </div>
               <div class="card-header">
                  <h3 class="row card-title">
                     <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('E', 'F36')) { ?>
                        <form action="balance/export_excel" method="POST">
                              @csrf
                              <input type="hidden" value="" name="no" id="no">
                              <input type="hidden" value="" name="itemcode" id="itemcode">
                              <input type="hidden" value="" name="contain" id="contain">
                              <input type="hidden" value="" name="brand" id="brand">
                              <input type="hidden" value="" name="uom" id="uom">
                              <input type="hidden" value="" name="stock" id="stock">
                              <input type="hidden" value="" name="_request" id="_request">
                              <input type="hidden" value="" name="balance" id="balance">
                              <input id="search" type="hidden" name="search">
                        
                              <button class="btn btn-sz btn-primary" type="submit">Export to Excel</button>
                        </form>
                     <?php } ?>
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  @if ($errors->any())
                     <div class="alert alert-danger">
                        <ul>
                           @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                           @endforeach
                        </ul>
                     </div>
                  @endif
                  <div class="table-responsive">
                     <table id="cmbalance" class="table table-bordered table-striped display compact nowrap" style="width:100%">
                        <thead>
                           <tr>
                              <th>No</th>
                              <th>Item Code</th>
                              <th>Contain</th>
                              <th>Brand</th>
                              <th>UoM</th>
                              <th>Stock</th>
                              <th>Request</th>
                              <th>Balance</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>

</section>
<style>
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::after{display: none}
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::before{display: none}
</style>

<script>
	$(document).ready(function() {
      //====Main table
      LoadTable();    
      $('#cmbalance thead tr').clone(true).appendTo( '#cmbalance thead' );
      $('#cmbalance thead tr:eq(1) th').each( function (i) {
         var title = $(this).text();

         if (title === "No"){
            $(this).html( '<input type="text" class="input-sm no" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Item Code"){
            $(this).html( '<input type="text" class="input-sm itemcode" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Contain"){
            $(this).html( '<input type="text" class="input-sm contain" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Brand"){
            $(this).html( '<input type="text" class="input-sm brand" placeholder="Search ' + title + '" />' );
         }
         else if (title === "UoM"){
            $(this).html( '<input type="text" class="input-sm uom" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Stock"){
            $(this).html( '<input type="text" class="input-sm stock" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Request"){
            $(this).html( '<input type="text" class="input-sm request" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Balance"){
            $(this).html( '<input type="text" class="input-sm balance" placeholder="Search ' + title + '" />' );
         }
        
         $( 'input', this ).on( 'keyup change', function () {
            if ( tablebalance.column(i).search() !== this.value ) {
                tablebalance
                  .column(i)
                  .search( this.value )
                  .draw();
                  
                  var no = $('.no').val();
                  var itemcode = $('.itemcode').val();
                  var contain = $('.contain').val();
                  var brand = $('.brand').val();
                  var uom = $('.uom').val();
                  var stock = $('.stock').val();
                  var _request = $('.request').val();
                  var balance = $('.balance').val();
                  
                  $('#no').val(no);
                  $('#itemcode').val(itemcode);
                  $('#contain').val(contain);
                  $('#brand').val(brand);
                  $('#uom').val(uom);
                  $('#stock').val(stock);
                  $('#_request').val(_request);
                  $('#balance').val(balance);
            }
         });
    });
    tablebalance.columns().every(function (index) {
        $('#cmbalance thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
            tablebalance.column($(this).parent().index() + ':visible')
                .search(this.value)
                .draw();
        });
    });
   });

   //==== Load the main table
   function LoadTable()
   {
      tablebalance = $("#cmbalance").DataTable({
         destroy: true,
         processing: true,
         serverSide: true,
         dom: '<lf<t><r>ip>',
         columns: [
            { data: "STOCK", className: "text-right" },
            { data: "REQUEST", className: "text-right" },
            { data: "BALANCE", className: "text-right" }
         ],
         columnDefs: [
            { "width": "5%", "targets": 0 },
         ],
         ajax: {
            url: '/ajaxbalance',
            type: "GET",
         },
         columns: [
            {
               data: "no",
               name: "no",
            },
            {
               data: "VDRUGSCODE",
               name: "VDRUGSCODE",
            },
            {
               data: "VCONTAIN",
               name: "VCONTAIN",
            },
            {
               data: "VBRAND",
               name: "VBRAND",
            },
            {
               data: "VUOM",
               name: "VUOM",
            },
            {
               data: "STOCK",
               name: "STOCK",
            },
            {
               data: "REQUEST",
               name: "REQUEST",
            },
            {
               data: "BALANCE",
               name: "BALANCE",
            }
         ],
      })
   }
   
</script>

@endsection