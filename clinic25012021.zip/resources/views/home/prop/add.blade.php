@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Add Province</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                  Add New Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/addprop/insert" id="form-confirm">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Province Code</label>
                                 <div class="col-sm-4">
                                    <input id="provincecode" name="provcode" placeholder="Province Code" class="form-control" type="text" maxlength="5" required>
                                    <span class="help-block"></span>
                                    <div class="invalid-feedback" id="already">
                                    </div>
                                 </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Province Name</label>
                              <div class="col-sm-4">
                                 <input name="provname" placeholder="Province Name" class="form-control" type="text" maxlength="50" required>
                              </div>
                           </div>
                           <div class="form-group row">
                              <div class="col-md-12">
                                 <div class="float-right">
                                    <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                    <a href="/account/province" class="btn btn-cstm btn-light btn-sz">Close</a>
                                 </div>
                              </div>
                           </div>
                        </div>
						   </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<script>
   $(document).ready(function() {
      $("#provincecode").keyup(function() {
         var id = $(this).val();
         var base = btoa(id);
         $.ajax({
            dataType: "json",
            type: "GET",
            url: "/getajaxprovince/" + base,
            success: function(result) {
               if(result.data === 'already'){
                  $('#already').html('Province Code already in use!');
                  $('input#provincecode').addClass('is-invalid');
               }else{
                  $('#already').html('');
                  $('input#provincecode').removeClass('is-invalid');

               }
             
            }
         });
      });
   });
</script>
@endsection