@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Edit Clinic</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Edit Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/clinic/update" id="form-edit" enctype="multipart/form-data">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Clinic Code</label>
                              <div class="col-sm-4">
                                 <input name="cliniccode" placeholder="Clinic Code" value="{{$clinic->VCLINICCODE}}" class="form-control" type="text" readonly>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Clinic Name</label>
                              <div class="col-sm-4">
                                 <input name="clinicname" placeholder="Clinic Name" value="{{$clinic->VCLINICNAME}}" class="form-control" type="text" maxlength="50">
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Clinic Initial</label>
                              <div class="col-sm-4">
                                 <input name="clinicinit" placeholder="Clinic Initial" value="{{$clinic->VCLINICINIT}}" class="form-control" type="text"  maxlength="2" readonly>
                                 <span class="help-block"></span>
                                 <div class="invalid-feedback" id="exists"></div>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Region</label>

                                 <div class="col-sm-4">
                                    <select class="form-control" name="region" required>
                                          <option value="">-- Select Region --</option>
                                          @foreach($regiontype as $a)
                                             <option value="{{$a->VGNRLCODE}}"  {{ $clinic->VREGION == $a->VGNRLCODE ? 'selected="selected"' : '' }}>{{$a->VGNRLDESC}}</option>
                                          @endforeach
                                    </select>
                                 </div>
                             
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Clinic Status</label>
                              <div class="col-sm-4">
                                 <select class="form-control" name="clinicstatus" id="clinicstatus" required>
                                    <option value="">-- Select Clinic Status --</option>
                                    @foreach($setting1 AS $a)
                                    <option value="{{$a->VSETCODE}}" {{ $setting->VSETCODE == $a->VSETCODE ? 'selected="selected"' : '' }}>{{$a->VSETDESC}}</option>
                                    @endforeach                                 
                                 </select>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Business Unit</label>
                              <div class="col-sm-4">
                                 <select class="form-control" name="business" required>
                                    <option value="">-- Select Business Unit --</option>
                                    <option value="IF" {{ $clinic->VBU == "IF" ? 'selected' : '' }}>Indra Fiber</option>
                                    <option value="KF" {{ $clinic->VBU == "KF" ? 'selected' : '' }}>Kampar Fiber</option>
                                    <option value="RF" {{ $clinic->VBU == "RF" ? 'selected' : '' }}>Riau Fiber</option>
                                    <option value="DF" {{ $clinic->VBU == "DF" ? 'selected' : '' }}>Dumai Fiber</option>
                                    <option value="RPL" {{ $clinic->VBU == "RPL" ? 'selected' : '' }}>Riau Pulp</option>
                                 </select>
                              </div>

                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Status</label>
                              <div class="col-sm-4">
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a1" value="1" {{ ($clinic->BACTIVE==="1")? "checked" : "" }}>
                                    <label class="form-check-label" for="a1">Active</label>
                                 </div>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a2" value="0" {{ ($clinic->BACTIVE==="0")? "checked" : "" }}>
                                    <label class="form-check-label" for="a2">InActive</label>
                                 </div>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Sub District</label>
                              <div class="col-sm-4">
							            <div class="form-group">
							         		<div class="input-group">
							         		   <input name="subdistname" value="{{$clinic->VSUBDISTRICTCODE ?? ''}}{{ isset($Mstsubdistrict->VSUBDISTRICTNAME) && $Mstsubdistrict->VSUBDISTRICTNAME != '' ? ' - '.$Mstsubdistrict->VSUBDISTRICTNAME : ''}}" class="form-control" type="text" readonly>
                                         <input name="SUBDISTRICTCODE" value="{{$clinic->VSUBDISTRICTCODE}}" class="form-control" type="hidden" readonly>
							         		   <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myModalSubDist">
							         		      <div class="input-group-text"><i class="fa fa-search"></i></div>
							         		   </div>
							         		</div>
							            </div>
							         </div>
                           </div>
                           <div class="form-group row">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Last Synchronize</label>
                              <div class="col-sm-4">
                                 <input name="lastd" placeholder="Last Synchronize" value="{{$clinic->DLASTSYNC}}" class="form-control" type="text"  disabled>
                                 <span class="help-block"></span>
                                 <div class="invalid-feedback" id="exists"></div>
                              </div>

                           </div>
                           <hr>
                           <div class="row">
                              <div class="col-lg-12 col-sm-12 form-group">
                                 <button type="button" class="btn-cstm btn-primary btn-sz" onclick="return toFormDoc(this);">Add New</button>
                              </div>
                           </div>
                           <div class="row table-responsive">
                              <div class="col-sm-12 col-sm-12 form-group">
                                 <table id="tblfile" border="1" width="100%">
                                    <thead>
                                       <tr>
                                          <th class="text-center" style="width:10%">Action</th>
                                          <th class="text-center">No</th>
                                          <th class="text-center">Document Type</th>
                                          <th class="text-center">Document No</th>
                                          <th class="text-center">Valid From</th>
                                          <th class="text-center">Valid To</th>
                                          <th class="text-center">File Name</th>
                                       </tr>
                                    </thead>
                                    <tbody>
									            <?php $inc = 1;?>
									            @if (isset($docs))
									            	@foreach ($docs as $doc)
											               <tr id="{{ $inc }}">
											               	<td data-value="VID" style="display: none;">{{ $doc->VID }}</td>
											               	<td data-value="VDOCFILENAME" style="display: none;">{{ $doc->VDOCFILENAME }}</td>
											               	<td style="text-align: center;"><button onClick="toFormDoc(this, '{{ $doc->VID }}')" type="button" class="btn btn btn-link btn-sm"><i title="Edit" class="fas fa-edit"></i></button>&nbsp;<button onClick="remove(this)" data-id="{{ $doc->VID }}" type="button" class="btn btn btn-link btn-sm"><i title="Delete" class="fas fa-times"></i></button></td>
											               	<td>{{ $inc }}</td>
											               	<td data-value="VDOCTYPE">{{ $doc->VGNRLDESC }}</td>
											               	<td data-value="VDOCNO">{{ $doc->VDOCNO }}</td>
											               	<td data-value="DPERIODFR">{{ isset($doc->DPERIODFR) ? $doc->DPERIODFR->format('d-m-Y') : '' }}</td>
											               	<td data-value="DPERIODTO">{{ isset($doc->DPERIODTO) ? $doc->DPERIODTO->format('d-m-Y') : '' }}</td>
											               	<td><a href="/account/download/{{ strtolower($doc->VID . substr($doc->VDOCFILENAME, strrpos($doc->VDOCFILENAME, '.'))) }}">{{ $doc->VDOCFILENAME }}</a></td>
											               </tr>
									            		  <?php $inc++; ?>
									            	@endforeach
									            @endif
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                           <div class="form-group row">
                              <div class="col-sm-12">
                                 <div class="float-right">
                                    <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                    <a  href="/account/clinic" class="btn btn-cstm btn-light btn-sz">Close</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade" id="modaldoc" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-md modal-dialog-centered">
            <div class="modal-content">
               <div class="modal-body">
                  <form id="form-doc">
                     <input id="VID" name="VID" type="text" style="display: none;">
                     <div class="container">
                        <div class="row">
                           <div class="col-lg-6 col-sm-12">
                              <div class="form-group">
                                 <div class="col-sm-12">
                                    <select class="form-control" id="VDOCTYPE" placeholder="Document Type">
                                       <option value="">-- Select Type Document --</option>
											         @foreach($clinicdoc AS $VDOCTYPE)
											         	<option value="{{$VDOCTYPE['VGNRLCODE']}}">{{$VDOCTYPE['VGNRLDESC']}}</option>
											         @endforeach                
                                    </select>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-6 col-sm-12">
                              <div class="form-group">
                                 <div class="col-sm-12">
                                    <input id="VDOCNO" class="form-control" type="text" placeholder="Document No" maxlength="30">
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-lg-6 col-sm-12">
                              <div class="form-group">
                                 <div class="col-sm-12">
                                    <div class="input-group date" id="PERIODFR" data-target-input="nearest">
                                       <input type="text" class="form-control datetimepicker-input" id="DPERIODFR" data-target="#PERIODFR" placeholder="Valid From">
                                       <div class="input-group-append" data-target="#PERIODFR" data-toggle="datetimepicker">
                                          <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-6 col-sm-12">
                              <div class="form-group">
                                 <div class="col-sm-12">
                                    <div class="input-group date" id="PERIODTO" data-target-input="nearest">
                                       <input type="text" class="form-control datetimepicker-input" id="DPERIODTO" data-target="#PERIODTO" placeholder="to">
                                       <div class="input-group-append" data-target="#PERIODTO" data-toggle="datetimepicker">
                                          <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-lg-12 col-sm-12">
                              <div class="form-group">
                                 <div id="divFile" class="col-sm-12">
                                    <input id="file" type="file" required>
                                 </div>
                                 <div id="divFileEdit" class="col-sm-12" style="display: none;">
                                    <button type="button">Choose File</button>&nbsp;<label></label>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <br/>
                        <div style="text-align:center;">
                           <button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                           <a onclick="$('#modaldoc').modal('hide');" class="btn btn-cstm btn-light btn-sz">Close</a>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- Sub District List -->
   <div class="modal fade in" id="myModalSubDist" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-content">
         <div class="card mb-4">
            <div class="card-header bg-info">
               <h5 class="card-title text-white" align="center">Sub District List</h5>
               <button type="button" class="close text-white" data-dismiss="modal">×</button>
            </div>
            <div class="card-body p-3">
               <div id="dvData" class="table-responsive">
                  <table id="tblsubdist" class="display" style="width:100%">
                     <thead>
                        <tr>
                           <th>
                              Sub District Code
                           </th>
                           <th>
                              Sub District Name
                           </th>
                           <th>
                              District Name
                           </th>
                        </tr>
                     </thead>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<script>
	$(document).ready(function() {
      
      $('#PERIODFR, #PERIODTO').datetimepicker({
         format: 'DD-MMM-YYYY',
      });

      //====Sub District table
      var table_sub_dist = $("#tblsubdist").DataTable({ 
         pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
         ajax: { url: '/clinic/getsubdistlookup', type: "GET", }, 
         columns: [ 
            { data: "SUBDISTRICTCODE" }, 
            { data: "SUBDISTRICTNAME" }, 
            { data: "DISTRICT_NAME" } 
         ] 
      });
      $('#tblsubdist tbody').on('dblclick', 'tr', function () {  // Select with double click
         var data = table_sub_dist.row(this).data();
         $('input[name="subdistname"]').val(data['SUBDISTRICTCODE'] + ' - ' + data['SUBDISTRICTNAME']);     // fill field with "id - name" of user
         $('input[name="SUBDISTRICTCODE"]').val(data['SUBDISTRICTCODE']);                                   // save "user id" in hidden input 
         $(this).closest('.card').find('button').trigger('click');
      });

      $('#divFile').on('change', 'input', function(){
         $('#divFile').css('display', 'block');
         $('#divFileEdit').css('display', 'none');
      });
		$('#divFile').on('change', 'input', function(){
			$('#divFile').css('display', 'block');
			$('#divFileEdit').css('display', 'none');
		});
   });

   var files = 0;
   
	function remove(th) {
		swal.fire({
			text: "Do you want to delete the data?",
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Yes",
			cancelButtonText: "No"
		}).then(function (result) {
			if (result.value) {
				if ($(th).attr('data-id').length == 36) {
					$.ajax({
						url: "/account/users/deldoc/" + $(th).attr('data-id'),
						type: "GET",
						headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
						success: function () {
							location.reload();
						}
					});
				} else {
					$(th).closest('tr').remove();
					$.each($('#tblfile tbody tr'), function( index, value ) {
                  $('#tblfile tbody tr:eq(' + index + ') td:eq(4)').text(index + 1);
                  $('#tblfile tbody tr:eq(' + index + ')').attr("id", index + 1);
					});
				}
			}
		});
	}
	function toFormDoc(th, id) {
		$('#form-doc').trigger("reset");
		if (id !== undefined) {
			$.each($(th).closest('tr').find('td[data-value]'), function( index, value ) {
				var input = $('#form-doc #' + $(value).attr('data-value') + '');
				if ($(value).attr('data-value') == "VDOCTYPE") {
					if ($(value).text() != '') {
						$('#VDOCTYPE').prop('selectedIndex', $("#VDOCTYPE option:contains(" + $(value).text() + ")")[0].index);
					}
				} else if ($(value).attr('data-value') == "VDOCFILENAME") {
					$('#divFileEdit label').text($(value).text());
				} else {
					input.val($(value).text());
				}
			});
			$('#divFile').css('display', 'none');
			$('#divFileEdit').css('display', 'block');
			$('#file').removeAttr('required');
		} else {
			$('#divFile').css('display', 'block');
			$('#divFileEdit').css('display', 'none');
		}
		$('#modaldoc').modal('show');
	}
   
   function toForm(th, id) {
      $('#form-addnew').trigger("reset");
      if (id !== undefined) {
         $.each($(th).closest('tr').find('td'), function(index, value) {
            var input = $('#form-addnew input[name="' + $(value).attr('data-value') + '"]');
            if (input.attr('type') == 'radio') {
               if ($(value).text() != '') {
                  input.filter('[value=' + $(value).text().substring(0, 1) + ']').prop('checked', true);
               }
            } else {
               input.val($(value).text());
            }
         });
      }
      $('#modaladdnew').modal('show');
   }
   
   var serial = 1;

   $(document).on("submit", "[id^=form-addnew]", function(e) {
      e.preventDefault();
      if ($('#form-addnew input[name="ILINE"]').val() != '') {
         $.each($('#tblmember td:contains(' + $('#form-addnew input[name="ILINE"]').val() + ')').closest('tr').find('td'), function(index, value) {
            if (index == 3) {
               $(value).html($('#form-addnew input[name="VRELGENDER"]:checked').siblings('label').text() + '<input name="VRELGENDER[]" type="hidden" value="' + $('#form-addnew input[name="VRELGENDER"]').val() + '">');
            } else if (index == 1) {
               $(value).html('<a class="btn btn-link btn-sm" href="#" onclick="return toForm(this, \'' + $('#form-addnew input[name="ILINE"]').val() + '\');">' + $('#form-addnew input[name="' + $(value).attr('data-value') + '"]').val() + '</a><input name="' + $(value).attr('data-value') + '[]" type="hidden" value="' + $('#form-addnew input[name="' + $(value).attr('data-value') + '"]').val() + '">');
            } else {
               $(value).html($('#form-addnew input[name="' + $(value).attr('data-value') + '"]').val() + '<input name="' + $(value).attr('data-value') + '[]" type="hidden" value="' + $('#form-addnew input[name="' + $(value).attr('data-value') + '"]').val() + '">');
            }
         });
      } else {
         var td = '';
         $.each($('#form-addnew input[type="text"]'), function(index, value) {
            if (index == 3) {
               td += '<td data-value="VRELGENDER">' + $('#form-addnew input[name="VRELGENDER"]:checked').siblings('label').text() + '<input name="VRELGENDER[]" type="hidden" value="' + $('#form-addnew input[name="VRELGENDER"]').val() + '"></td>';
            }
            if (index == 0) {
               td += '<td data-value="' + $(value).attr('name') + '" style="display: none;">' + serial.toString().padStart(13, '0') + '<input name="' + $(value).attr('name') + '[]" type="hidden" value="' + serial.toString().padStart(13, '0') + '"></td>';
            } else if (index == 1) {
               td += '<td data-value="' + $(value).attr('name') + '"><a class="btn btn-link btn-sm" href="#" onclick="return toForm(this, \'' + serial.toString().padStart(13, '0') + '\');">' + $(value).val() + '</a><input name="' + $(value).attr('name') + '[]" type="hidden" value="' + $(value).val() + '"></td>';
               serial++;
            } else {
               td += '<td data-value="' + $(value).attr('name') + '">' + $(value).val() + '<input name="' + $(value).attr('name') + '[]" type="hidden" value="' + $(value).val() + '"></td>';
            }
         });
         $('#tblmember tbody').append('<tr>' + td + '</tr>');
      }
      $('#modaladdnew').modal('hide');
   });
   
	$(document).on("submit", "[id^=form-doc]", function (e) {
		e.preventDefault();

      var periodfrParts = $('#DPERIODFR').val().split("-");
      var periodfr = new Date(+periodfrParts[2], periodfrParts[1] - 1, +periodfrParts[0]);
      var periodtoParts = $('#DPERIODTO').val().split("-");
      var periodto = new Date(+periodtoParts[2], periodtoParts[1] - 1, +periodtoParts[0]);
      if(periodfr >= periodto){
         Swal.fire('Error', 'Time is invalid.', 'error');
         return false;
      }

		var th = $('#file')[0];
		if ($('#form-doc input[name="VID"]').val() != '') {
			$.each($('#tblfile td:contains(' + $('#form-doc input[name="VID"]').val() + ')').closest('tr').find('td[data-value]'), function( index, value ) {
				if ($(value).attr('data-value') == "VDOCFILENAME") {
					var tdTag = $(value).closest('tr').children('td').last();
					if (th.files[0]) {
						$(value).html(th.files[0].name);
						if ($(value).closest('tr').find('[name="files[]"]').length > 0) {
							$(value).closest('tr').find('[name="files[]"]').closest('td').remove();
						}
						$(value).closest('tr').prepend('<td id="fileInput" style="display: none;"></td>');
						reloadFile();
						tdTag.html(th.files[0].name + '<input name="VDOCFILENAME[]" type="hidden" value="' + th.files[0].name + '">');
					} else {
						var aTag = tdTag.find('a');
						if (aTag.length > 0) {
							aTag.html($('#divFileEdit label').text() + '<input name="VDOCFILENAME[]" type="hidden" value="">');
							$(value).closest('tr').prepend('<td style="display: none;"><input name="files[]"></td>');
						}
					}
				} else if ($(value).attr('data-value') == "VDOCTYPE") {
					if ($('#VDOCTYPE option:selected').val() != '') {
						$(value).html($('#VDOCTYPE option:selected').text() + '<input name="' + $(value).attr('data-value') + '[]" type="hidden" value="' + $('#VDOCTYPE option:selected').val() + '">');
					}
				} else {
					$(value).html($('#form-doc input[id="' + $(value).attr('data-value') + '"]').val() + '<input name="' + $(value).attr('data-value') + '[]" type="hidden" value="' + $('#form-doc input[id="' + $(value).attr('data-value') + '"]').val() + '">');
				}
			});
		} else {
         var row_len = $('#tblfile tbody tr').length;
			$('#tblfile tbody').append('<tr id="' + (row_len + 1) + '"><td id="fileInput" style="display: none;"></td><td data-value="VID" style="display: none;">' + files.toString().padStart(13, '0') + '<input name="VID[]" type="hidden" value="' + files.toString().padStart(13, '0') + '"></td><td data-value="VDOCFILENAME" style="display: none;">' + th.files[0].name + '</td><td class="text-center"><button onClick="toFormDoc(this, \'' + files.toString().padStart(13, '0') + '\')" type="button" class="btn btn btn-link btn-sm"><i title="Edit" class="fas fa-edit"></i></button>&nbsp;<button onClick="remove(this)" data-id="' + files.toString().padStart(13, '0') + '" type="button" class="btn btn btn-link btn-sm"><i title="Delete" class="fas fa-times"></i></button></td><td>' + ($('#tblfile tbody tr').length + 1) + '</td><td data-value="VDOCTYPE">' + ($('#VDOCTYPE').val() != '' ? $('#VDOCTYPE option:selected').text() : '') + '<input name="VDOCTYPE[]" type="hidden" value="' + $('#VDOCTYPE').val() + '"></td><td data-value="VDOCNO">' + $('#VDOCNO').val() + '<input name="VDOCNO[]" type="hidden" value="' + $('#VDOCNO').val() + '"></td><td data-value="DPERIODFR">' + $('#DPERIODFR').val() + '<input name="DPERIODFR[]" type="hidden" value="' + $('#DPERIODFR').val() + '"></td><td data-value="DPERIODTO">' + $('#DPERIODTO').val() + '<input name="DPERIODTO[]" type="hidden" value="' + $('#DPERIODTO').val() + '"></td><td>' + th.files[0].name + '<input name="VDOCFILENAME[]" type="hidden" value="' + th.files[0].name + '"></td></tr>');
			reloadFile();
			files++;
		}
		$('#modaldoc').modal('hide');
   });
   
	function reloadFile () {
		$("#fileInput").append($('#file')).removeAttr("id");
		$("#file").attr('name', 'files[]').removeAttr("id").removeAttr("required");
		$('#divFile').append('<input id="file" type="file" required>');
	}
	$('#divFileEdit').on('click', 'button', function () {
		$('#file').trigger('click');
	});

   //==== Check Clinic Initial every key up
   $('input[name="cliniccode"], input[name="clinicinit"]').keyup(function() {
      CheckClinicInitialExists();
   });
   
   //==== Check if current Clinic Initial is already exists
   function CheckClinicInitialExists()
   {
      if($('input[name="cliniccode"]').val() == '' || $('input[name="clinicinit"]').val() == '') return;
      var clinic_code = $('input[name="cliniccode"]').val();
      var clinic_initial = $('input[name="clinicinit"]').val();
      var base = btoa(clinic_code + "," + clinic_initial);
      $.ajax({
         dataType: "json",
         type: "GET",
         url: "/getajaxclinicinitialexists/" + base,
         success: function(result) {
            if(result.data === 'exists'){
               $('#exists').html('This Clinic Initial is already exists!');
               $('input[name="clinicinit"]').addClass("is-invalid");
            }else{
               $('#exists').html('');
               $('input[name="clinicinit"]').removeClass("is-invalid");
            }
         }
      });
   }
</script>
@endsection