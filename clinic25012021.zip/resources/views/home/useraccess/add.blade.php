@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-12">
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Add New Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/adduseracc/insert" id="form-confirm">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">User ID</label>
                              <div class="col-sm-4">
                                 <input name="id" placeholder="User ID" class="form-control" type="text">
                                 <span class="help-block"></span>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Menu Code</label>
                              <div class="col-sm-4">
                                 <input name="code" placeholder="Menu Code" class="form-control" type="text">
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Status</label>
                              <div class="col-sm-4">
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="contactive" type="radio" id="a1" value="1" required checked>
                                    <label class="form-check-label" for="a1">Active</label>
                                 </div>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="contactive" type="radio" id="a2" value="0" required>
                                    <label class="form-check-label" for="a2">InActive</label>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="form-group row">
                           <div class="col-md-12">
                              <div class="float-right">
                                 <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                 <a  onclick="history.back()" class="btn btn-cstm btn-light btn-sz">Close</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
@endsection