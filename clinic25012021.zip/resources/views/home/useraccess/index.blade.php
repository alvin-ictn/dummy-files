@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-12">
               <h5>Master User Access</h5>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header">
                  <h3 class="card-title">
                     <a class="btn btn-sz btn-primary" href="useracc/add" role="button">Add New</a>
                     <a class="btn btn-sz btn-primary" href="useracc/export" role="button">Export to Excel</a>
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
               @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div>
               @endif
                  <div class="table-responsive">
                     <table id="cmuseracc" class="table table-bordered table-striped display compact nowrap" style="width:100%">
                        <thead>
                           <tr>
                              <th>No</th>
                              <th>User ID</th>
                              <th>Menu Code</th>
                              <th>User Add</th>
                              <th>User Edit</th>
                              <th>User Delete</th>
                              <th>User Print</th>
                              <th>User Post</th>
                              <th>Last Modified Date</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<style>
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::after{display: none}
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::before{display: none}
</style>
@endsection