@extends('layout.app')
@section('content')
<style>
iframe {
   overflow: hidden;
   width:100%;
   height:calc(100vh - 4px);
}
</style>
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Mcu Report</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
   <div class="row">
      <div class="col-12">
         <div class="card">
            <div class="card-header card-color">
               <h3 class="card-title text-white">
                    Mcu Report
               </h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
            <form  method="POST" id="form-visit">
                  @csrf

                  <div class="row">
                     <div class="col-4">
                        <div class="form-group">
                              <label for="example-text-input" class="req col-form-label col-sm-3">MCU Type</label>
                                 <select class="form-control select22 region" name="VTYPE" id="VTYPE">
                                       <option value="ALL">ALL</option>
                                       <option value="3">Pre employement</option>
                                       <option value="1">Annual</option>

                                 </select>
                    
                        </div>
                     </div>
                     <div class="form-group col-sm-4">
                        <label class="col-form-label control-label col-sm-8">Personnel Area</label>

                        <select class="form-control" name="personalarea" id="personalarea">
                              <option value="ALL">ALL</option>

                              @foreach($personalarea as $a)
                                 <option value="{{$a->PERSONELCODE}}">{{$a->PERSONELCODE}} - {{$a->PERSONELNAME}}</option>
                              @endforeach
                        </select>
                     </div>
                  </div>
                  <div class="form-group">
                  <div class="row">
                  <div class="col-4">
                           <label class="control-label col-sm-12">WD ID /SAP ID</label>

                           <select class="form-control VSAPID" name="VSAPID" id="VSAPID">
                              <option value="ALL">ALL</option>

                              @foreach($employee as $a)
                                 <option value="{{$a->VEMPSAPID}}">{{$a->VEMPSAPID}} - {{$a->VNAME}}</option>
                              @endforeach
                           </select>
                     </div>
                     <div class="form-group col-sm-4">
                        <label class="control-label col-sm-12">Cost Center</label>

                        <select class="form-control" name="VCOSTCNTRCODE" id="VCOSTCNTRCODE">
                                    <option value="ALL">ALL</option>
                              @foreach($costcenter as $a)
                                 <option value="{{$a->CC_CODE}}">{{$a->CC_CODE}} - {{$a->CC_NAME}}</option>
                              @endforeach
                        </select>
                     </div>

                  </div>
                  

                  <div class="form-group row">
                  <div class="col-sm-4">
                     <label class="col-form-label control-label col-sm-3">Date from</label>

                     <div class="input-group date" id="DFROM" data-target-input="nearest">
                        <input value="{{Carbon\Carbon::now()->format('d-M-Y')}}" id="DFROM1" type="text" class="form-control datetimepicker-input" name="DFROM" data-target="#DFROM" placeholder="DD-MMM-YYYY" required>
                        <div class="input-group-append" data-target="#DFROM" data-toggle="datetimepicker">
                           <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                     </div>
                  </div>
                  <div class="form-group col-sm-4">
                     <label class="col-form-label control-label col-sm-3">to</label>

                     <div class="input-group date" id="DTO" data-target-input="nearest">
                        <input value="{{Carbon\Carbon::now()->format('d-M-Y')}}" type="text" id="EFROM1" class="form-control datetimepicker-input" name="DTO" data-target="#DTO" placeholder="DD-MMM-YYYY" required>
                        <div class="input-group-append" data-target="#DTO" data-toggle="datetimepicker">
                           <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                     </div>
                  </div>
                  
               </div>
               <div class="col-lg-4 col-sm-12">
                     
                     <button class="btn btn-primary btn-block" type="submit" role="button" style="color:white;">Search</button>
               </div>
            <br />
            </form>
               <div class="table-responsive visit">
                    
                     <iframe is="x-frame-bypass" src="http://{{ env('APP_REPORT') }}/Reports/Pages/ReportViewer.aspx?%2fRAPP%2fReportMcu&rs:Command=Render&rs:Embed=true&rs:Format=HTML4.0&rc:Parameters=false&VEMPSAPID=ALL&VCOSTCNTRCODE=ALL&VPRSNLAREACODE=ALL&VTYPE=ALL&SDATE=2020-02-01&EDATE=2020-02-01"  frameborder="0" sandbox="allow-same-origin allow-scripts allow-forms" scroll="no" style="overflow: hidden"  allowfullscreen></iframe>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<script>
$(document).on("submit", "[id^=form-visit]", function(e) {
    e.preventDefault();
    var VPRSNLAREACODE = document.getElementById("personalarea").value;
    var VEMPSAPID = document.getElementById("VSAPID").value;
    var VCOSTCNTRCODE = document.getElementById("VCOSTCNTRCODE").value;
    var VTYPE = document.getElementById("VTYPE").value;

    // start Date
    var sdate = document.getElementById("DFROM1").value;
    var startdate = new Date(sdate);
    var sdates = moment(startdate).format('Y-M-D');
    // End Date
    var edate = document.getElementById("EFROM1").value;
    var enddate = new Date(edate);
    var edates = moment(enddate).format('Y-M-D');
    
    // console.log(region);
    $('.visit').html('<iframe is="x-frame-bypass" src="http://{{ env('APP_REPORT') }}/Reports/Pages/ReportViewer.aspx?%2fRAPP%2fReportMcu&rs:Command=Render&rs:Embed=true&rs:Format=HTML4.0&rc:Parameters=false&VEMPSAPID='+VEMPSAPID+'&VCOSTCNTRCODE='+VCOSTCNTRCODE+'&VPRSNLAREACODE='+VPRSNLAREACODE+'&VTYPE='+VTYPE+'&SDATE='+sdates+'&EDATE='+edates+'" frameborder="0" scroll="no" style="overflow: hidden" allowfullscreen></iframe>');
});
$(document).ready(function() {
    $('#DFROM, #DTO').datetimepicker({
        format: 'DD-MMM-YYYY',
    });
    $('.region').select2({
        theme: 'bootstrap4',
        width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
        allowClear: Boolean($(this).data('allow-clear')),
    });
    $('.bisnisunit').select2({
        theme: 'bootstrap4',
        width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
        allowClear: Boolean($(this).data('allow-clear')),
    });
    $('.clinic').select2({
        theme: 'bootstrap4',
        width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
        allowClear: Boolean($(this).data('allow-clear')),
    });
    $('.request').select2({
        theme: 'bootstrap4',
        width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
        allowClear: Boolean($(this).data('allow-clear')),
    });
    $(document).on("change", '.region', function(e) {
        var id = $(this).val();
        $.ajax({
            dataType: 'json',
            type: 'GET',
            url: '/getajaxbisnisunit/' + id,
            success: function(result) {

                $('.bisnisunit').html(result);
                getclinic();
            }
        });
    });


    function getclinic() {
        var bisnisunit = $(".bisnisunit").val();
        $.ajax({
            dataType: 'json',
            type: 'GET',
            url: '/getajaxclinic/' + bisnisunit,
            success: function(result) {

                $('.clinic').html(result);
                var region = $(".region option:selected").val();
                var bisnisunit = $(".bisnisunit option:selected").val();
                var clinic = $(".clinic option:selected").val();
                $('#regions').val($(".region option:selected").val());
                $('#bisnit').val($(".bisnisunit option:selected").val());
                $('#clinics').val($(".clinic option:selected").val());
                getreq();
            }
        });

    }

    function getreq() {
         var clinic = $(".clinic").val();
        $.ajax({
            dataType: 'json',
            type: 'GET',
            url: '/getajaxreq/' + btoa(clinic),
            success: function(result) {
                $('.request').html(result);

               //  var region = $(".region option:selected").val();
               //  var bisnisunit = $(".bisnisunit option:selected").val();
               //  var clinic = $(".clinic option:selected").val();
               //  $('#regions').val($(".region option:selected").val());
               //  $('#bisnit').val($(".bisnisunit option:selected").val());
               //  $('#clinics').val($(".clinic option:selected").val());
               //  getreq();
            }
        });


    }

    $(".bisnisunit").change(getclinic); // 
    $(".clinic").change(getreq); // 

    $('#tblreport').DataTable({

        footer: true,
        scrollCollapse: false,
        scroller: false,
        paging: false,
        bInfo: false,
        visible: false,
        searching: false,
        ordering: false
    });
});

</script>
@endsection