@extends('layout.app')
@section('content')
<section class="content">
<div class="container-fluid">
  <div class="row">
	<label class="col-form-label control-label col-sm-2">Region</label>
	<div class="col-sm-2">
		<select class="form-control" name="R" required>
			<option value="ALL">-- ALL --</option>
			@foreach($RS AS $R)
				<option value="{{$R['VGNRLCODE']}}">{{$R['VGNRLCODE']}} - {{$R['VGNRLDESC']}}</option>
			@endforeach
		</select>
	</div>
	<label class="col-form-label control-label col-sm-1">Business Unit</label>
	<div class="col-sm-2">
		<select class="form-control" name="BU" required>
			<option value="ALL">-- ALL --</option>
			@foreach($BUS AS $BU)
				<option value="{{$BU['VGNRLCODE']}}">{{$BU['VGNRLCODE']}} - {{$BU['VGNRLDESC']}}</option>
			@endforeach
		</select>
	</div>
  </div>
  <div class="row">
	<label class="col-form-label control-label col-sm-2">Personnel Area</label>
	<div class="col-sm-2">
		<select class="form-control" name="PA" required>
			<option value="ALL">-- ALL --</option>
			@foreach($PAS AS $PA)
				<option value="{{$PA['VPRSNLAREACODE']}}">{{$PA['VPRSNLAREACODE']}} - {{$PA['VPRSNLNAME']}}</option>
			@endforeach
		</select>
	</div>
	<label class="col-form-label control-label col-sm-1">Cost Center</label>
	<div class="col-sm-2">
		<select class="form-control" name="CC" required>
			<option value="ALL">-- ALL --</option>
			@foreach($CCS AS $CC)
				<option value="{{$CC['VCOSTCNTRCODE']}}">{{$CC['VCOSTCNTRCODE']}} - {{$CC['VCOSTCNTRNAME']}}</option>
			@endforeach
		</select>
	</div>
  </div>
  <div class="row">
	<label class="col-form-label control-label col-sm-2">Date From</label>
	<div class="col-sm-2">
	   <div class="input-group date" id="DFROM" data-target-input="nearest">
		  <input type="text" class="form-control datetimepicker-input" name="DFROM" data-target="#DFROM" placeholder="DD-MMM-YYYY" required>
		  <div class="input-group-append" data-target="#DFROM" data-toggle="datetimepicker">
			 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
		  </div>
	   </div>
	</div>
	<label class="col-form-label control-label col-sm-1">to</label>
	<div class="form-group col-sm-2">
	   <div class="input-group date" id="DTO" data-target-input="nearest">
		  <input type="text" class="form-control datetimepicker-input" name="DTO" data-target="#DTO" placeholder="DD-MMM-YYYY" required>
		  <div class="input-group-append" data-target="#DTO" data-toggle="datetimepicker">
			 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
		  </div>
	   </div>
	</div>
	<div class="col-lg-1 col-sm-12">
	   <div class="form-group">
		  <button class="btn btn-sz btn-primary" onclick="return LoadVisit();" role="button" style="color:white;">Search</button>
	   </div>
	</div>
  </div>
  <div class="row">
	<div class="col-sm-3">
		<canvas id="employee"></canvas>
	</div>
	<div class="col-sm-3">
		<canvas id="employeeFam"></canvas>
	</div>
	<div class="col-sm-3">
		<canvas id="gender"></canvas>
	</div>
	<div class="col-sm-3">
		<canvas id="referal"></canvas>
	</div>
  </div>
  <div class="row">
	<div class="col-sm-3">
		<canvas id="accident"></canvas>
	</div>
	<div class="col-sm-3">
		<canvas id="days"></canvas>
	</div>
	<div class="col-sm-3">
		<canvas id="letter"></canvas>
	</div>
	<div class="col-sm-3">
		<canvas id="age"></canvas>
	</div>
  </div>
  <div class="row">
	<div class="col-sm-6">
		<canvas id="rujukan"></canvas>
	</div>
	<div class="col-sm-6">
		<canvas id="disease"></canvas>
	</div>
  </div>
</div>
</section>
<script src="{{ asset('plugins/chart.js/Chart.js') }}"></script>
<script>
var employee, employeeFam, gender, referal, accident, days, letter, age, rujukan, disease;

$(document).ready(function() {
	$('#DFROM, #DTO').datetimepicker({
		format: 'DD-MMM-YYYY'
	});
	
	var date = new Date();
	$('input[name="DFROM"]').val(moment(new Date(date.getFullYear(), date.getMonth(), 1)).format('DD-MMM-YYYY'));
	$('input[name="DTO"]').val(moment(new Date(date.getFullYear(), date.getMonth() + 1, 0)).format('DD-MMM-YYYY'));
	
	LoadVisit();
});

function LoadVisit()
{
	$.ajax({
		url: "/visit",
		type: "GET",
		data: { DFROM: $('input[name="DFROM"]').val(), DTO: $('input[name="DTO"]').val(), PA: $('select[name="PA"]').val(), CC: $('select[name="CC"]').val(), R: $('select[name="R"]').val(), BU: $('select[name="BU"]').val() },
		success: function(data) {
			if (employee == undefined) {
				employee = new Chart(document.getElementById('employee'), {
					type: 'pie',
					data: {
						labels: data.employee.labels,
						datasets: [{
							data: data.employee.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)',
								'rgba(255, 206, 86, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)',
								'rgba(255, 206, 86, 1)'
							]
						}]
					},
					options: {
						legend: { position: 'bottom' },
						title: {
							display: true,
							text: 'Employee'
						}
					}
				});
				
				employeeFam = new Chart(document.getElementById('employeeFam'), {
					type: 'pie',
					data: {
						labels: data.employeeFam.labels,
						datasets: [{
							data: data.employeeFam.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)',
								'rgba(255, 206, 86, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)',
								'rgba(255, 206, 86, 1)'
							]
						}]
					},
					options: {
						legend: { position: 'bottom' },
						title: {
							display: true,
							text: 'Employee fam'
						}
					}
				});
				
				gender = new Chart(document.getElementById('gender'), {
					type: 'pie',
					data: {
						labels: data.gender.labels,
						datasets: [{
							data: data.gender.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)'
							]
						}]
					},
					options: {
						legend: { position: 'bottom' },
						title: {
							display: true,
							text: 'Gender'
						}
					}
				});
				
				referal = new Chart(document.getElementById('referal'), {
					type: 'pie',
					data: {
						labels: data.referal.labels,
						datasets: [{
							data: data.referal.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)'
							]
						}]
					},
					options: {
						legend: { position: 'bottom' },
						title: {
							display: true,
							text: 'Referal'
						}
					}
				});
				
				accident = new Chart(document.getElementById('accident'), {
					type: 'pie',
					data: {
						labels: data.accident.labels,
						datasets: [{
							data: data.accident.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)'
							]
						}]
					},
					options: {
						legend: { position: 'bottom' },
						title: {
							display: true,
							text: 'Accident Status'
						}
					}
				});
				
				days = new Chart(document.getElementById('days'), {
					type: 'pie',
					data: {
						labels: data.days.labels,
						datasets: [{
							data: data.days.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)',
								'rgba(255, 206, 86, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)',
								'rgba(255, 206, 86, 1)'
							]
						}]
					},
					options: {
						legend: { position: 'bottom' },
						title: {
							display: true,
							text: 'no of days (Sickness Letter)'
						}
					}
				});
				
				letter = new Chart(document.getElementById('letter'), {
					type: 'pie',
					data: {
						labels: data.letter.labels,
						datasets: [{
							data: data.letter.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)'
							]
						}]
					},
					options: {
						legend: { position: 'bottom' },
						title: {
							display: true,
							text: 'no of Sickness Letter'
						}
					}
				});
				
				age = new Chart(document.getElementById('age'), {
					type: 'pie',
					data: {
						labels: data.age.labels,
						datasets: [{
							data: data.age.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)',
								'rgba(255, 206, 86, 0.2)',
								'rgba(75, 192, 192, 0.2)',
								'rgba(153, 102, 255, 0.2)',
								'rgba(255, 159, 64, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)',
								'rgba(255, 206, 86, 1)',
								'rgba(75, 192, 192, 1)',
								'rgba(153, 102, 255, 1)',
								'rgba(255, 159, 64, 1)'
							]
						}]
					},
					options: {
						legend: { position: 'bottom' },
						title: {
							display: true,
							text: 'Age'
						}
					}
				});
				
				rujukan = new Chart(document.getElementById('rujukan'), {
					type: 'horizontalBar',
					data: {
						labels: data.rujukan.labels,
						datasets: data.rujukan.data
					},
					options: {
						legend: { position: 'bottom' },
						title: {
							display: true,
							text: 'Data Rujukan Klinik'
						},
						scales: { xAxes: [ { ticks: { stepSize: 1 } } ] }
					}
				});
				
				disease = new Chart(document.getElementById('disease'), {
					type: 'bar',
					data: {
						labels: data.disease.labels,
						datasets: [{
							data: data.disease.data,
							backgroundColor: 'rgba(54, 162, 235, 0.2)'
						}]
					},
					options: {
						legend: { display: false },
						title: {
							display: true,
							text: 'Top 10 Disease'
						},
						scales: { yAxes: [{ ticks: { suggestedMin: 0, stepSize: 1 } }] }
					}
				});
			} else {
				employee.data = {
					labels: data.employee.labels,
					datasets: [{
						data: data.employee.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)',
							'rgba(255, 206, 86, 0.2)',
							'rgba(75, 192, 192, 0.2)',
							'rgba(153, 102, 255, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)',
							'rgba(255, 206, 86, 1)',
							'rgba(75, 192, 192, 1)',
							'rgba(153, 102, 255, 1)'
						]
					}]
				};
				employee.update();
				employeeFam.data = {
					labels: data.employeeFam.labels,
					datasets: [{
						data: data.employeeFam.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)',
							'rgba(255, 206, 86, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)',
							'rgba(255, 206, 86, 1)'
						]
					}]
				};
				employeeFam.update();
				gender.data = {
					labels: data.gender.labels,
					datasets: [{
						data: data.gender.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)'
						]
					}]
				};
				gender.update();
				referal.data = {
					labels: data.referal.labels,
					datasets: [{
						data: data.referal.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)'
						]
					}]
				};
				referal.update();
				accident.data = {
					labels: data.accident.labels,
					datasets: [{
						data: data.accident.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)'
						]
					}]
				};
				accident.update();
				days.data = {
					labels: data.days.labels,
					datasets: [{
						data: data.days.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)',
							'rgba(255, 206, 86, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)',
							'rgba(255, 206, 86, 1)'
						]
					}]
				};
				days.update();
				letter.data = {
					labels: data.letter.labels,
					datasets: [{
						data: data.letter.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)'
						]
					}]
				};
				letter.update();
				age.data = {
					labels: data.age.labels,
					datasets: [{
						data: data.age.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)',
							'rgba(255, 206, 86, 0.2)',
							'rgba(75, 192, 192, 0.2)',
							'rgba(153, 102, 255, 0.2)',
							'rgba(255, 159, 64, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)',
							'rgba(255, 206, 86, 1)',
							'rgba(75, 192, 192, 1)',
							'rgba(153, 102, 255, 1)',
							'rgba(255, 159, 64, 1)'
						]
					}]
				};
				age.update();
				rujukan.data = {
					labels: data.rujukan.labels,
					datasets: data.rujukan.data
				};
				rujukan.update();
				disease.data = {
					labels: data.disease.labels,
					datasets: [{
						data: data.disease.data,
						backgroundColor: 'rgba(54, 162, 235, 0.2)'
					}]
				};
				disease.update();
			}
		}
	});
}
</script>
@endsection