@extends('layout.app')
@section('content')
<section class="content">
<div class="container-fluid">
  <div class="row">
	<label class="col-form-label control-label col-sm-2">Personnel Area</label>
	<div class="col-sm-2">
		<select class="form-control" name="PA" required>
			<option value="ALL">-- ALL --</option>
			@foreach($PAS AS $PA)
				<option value="{{$PA['VPRSNLAREACODE']}}">{{$PA['VPRSNLAREACODE']}} - {{$PA['VPRSNLNAME']}}</option>
			@endforeach
		</select>
	</div>
	<label class="col-form-label control-label col-sm-1">Cost Center</label>
	<div class="col-sm-2">
		<select class="form-control" name="CC" required>
			<option value="ALL">-- ALL --</option>
			@foreach($CCS AS $CC)
				<option value="{{$CC['VCOSTCNTRCODE']}}">{{$CC['VCOSTCNTRCODE']}} - {{$CC['VCOSTCNTRNAME']}}</option>
			@endforeach
		</select>
	</div>
  </div>
  <div class="row">
	<label class="col-form-label control-label col-sm-2">Year From</label>
	<div class="col-sm-2">
	   <div class="input-group date" id="YFROM" data-target-input="nearest">
		  <input type="text" class="form-control datetimepicker-input" name="YFROM" data-target="#YFROM" placeholder="YYYY" required>
		  <div class="input-group-append" data-target="#YFROM" data-toggle="datetimepicker">
			 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
		  </div>
	   </div>
	</div>
	<label class="col-form-label control-label col-sm-1">to</label>
	<div class="form-group col-sm-2">
	   <div class="input-group date" id="YTO" data-target-input="nearest">
		  <input type="text" class="form-control datetimepicker-input" name="YTO" data-target="#YTO" placeholder="YYYY" required>
		  <div class="input-group-append" data-target="#YTO" data-toggle="datetimepicker">
			 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
		  </div>
	   </div>
	</div>
	<div class="col-lg-1 col-sm-12">
	   <div class="form-group">
		  <button class="btn btn-sz btn-primary" onclick="return LoadMcu();" role="button" style="color:white;">Search</button>
	   </div>
	</div>
  </div>
  <div class="row">
	<div class="col-sm-4">
		<canvas id="age"></canvas>
	</div>
	<div class="col-sm-4">
		<canvas id="bmi"></canvas>
	</div>
	<div class="col-sm-4">
		<canvas id="color"></canvas>
	</div>
  </div>
  <div class="row">
	<div class="col-sm-4">
		<canvas id="right"></canvas>
	</div>
	<div class="col-sm-4">
		<canvas id="left"></canvas>
	</div>
	<div class="col-sm-4">
		<canvas id="spiro"></canvas>
	</div>
  </div>
</div>
</section>
<script src="{{ asset('plugins/chart.js/Chart.js') }}"></script>
<script>
var age, bmi, color, right, left, spiro;

$(document).ready(function() {
	$('#YFROM, #YTO').datetimepicker({
		format: 'YYYY'
	});
	
	var date = new Date();
	$('input[name="YFROM"]').val(moment(new Date(date.getFullYear() - 1, date.getMonth(), 1)).format('YYYY'));
	$('input[name="YTO"]').val(moment(new Date(date.getFullYear(), date.getMonth() + 1, 0)).format('YYYY'));
	
	LoadMcu();
});

function LoadMcu()
{
	$.ajax({
		url: "/mcu",
		type: "GET",
		data: { YFROM: $('input[name="YFROM"]').val(), YTO: $('input[name="YTO"]').val(), PA: $('select[name="PA"]').val(), CC: $('select[name="CC"]').val() },
		success: function(data) {
			if (age == undefined) {
				age = new Chart(document.getElementById('age'), {
					type: 'pie',
					data: {
						labels: data.age.labels,
						datasets: [{
							data: data.age.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)',
								'rgba(255, 206, 86, 0.2)',
								'rgba(75, 192, 192, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)',
								'rgba(255, 206, 86, 1)',
								'rgba(75, 192, 192, 1)'
							]
						}]
					},
					options: {
						legend: {
							position: 'bottom'
						},
						title: {
							display: true,
							text: 'Age'
						}
					}
				});
				
				bmi = new Chart(document.getElementById('bmi'), {
					type: 'pie',
					data: {
						labels: data.bmi.labels,
						datasets: [{
							data: data.bmi.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)',
								'rgba(255, 206, 86, 0.2)',
								'rgba(75, 192, 192, 0.2)',
								'rgba(153, 102, 255, 0.2)',
								'rgba(255, 159, 64, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)',
								'rgba(255, 206, 86, 1)',
								'rgba(75, 192, 192, 1)',
								'rgba(153, 102, 255, 1)',
								'rgba(255, 159, 64, 1)'
							]
						}]
					},
					options: {
						legend: {
							position: 'bottom'
						},
						title: {
							display: true,
							text: 'BMI Status (WHO)'
						}
					}
				});
				
				color = new Chart(document.getElementById('color'), {
					type: 'pie',
					data: {
						labels: data.color.labels,
						datasets: [{
							data: data.color.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)',
								'rgba(255, 206, 86, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)',
								'rgba(255, 206, 86, 1)'
							]
						}]
					},
					options: {
						legend: {
							position: 'bottom'
						},
						title: {
							display: true,
							text: 'Buta Warna'
						}
					}
				});
				
				right = new Chart(document.getElementById('right'), {
					type: 'pie',
					data: {
						labels: data.right.labels,
						datasets: [{
							data: data.right.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)',
								'rgba(255, 206, 86, 0.2)',
								'rgba(75, 192, 192, 0.2)',
								'rgba(153, 102, 255, 0.2)',
								'rgba(255, 159, 64, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)',
								'rgba(255, 206, 86, 1)',
								'rgba(75, 192, 192, 1)',
								'rgba(153, 102, 255, 1)',
								'rgba(255, 159, 64, 1)'
							]
						}]
					},
					options: {
						legend: {
							position: 'bottom'
						},
						title: {
							display: true,
							text: 'Audiometri Kanan'
						}
					}
				});
				
				left = new Chart(document.getElementById('left'), {
					type: 'pie',
					data: {
						labels: data.left.labels,
						datasets: [{
							data: data.left.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)',
								'rgba(255, 206, 86, 0.2)',
								'rgba(75, 192, 192, 0.2)',
								'rgba(153, 102, 255, 0.2)',
								'rgba(255, 159, 64, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)',
								'rgba(255, 206, 86, 1)',
								'rgba(75, 192, 192, 1)',
								'rgba(153, 102, 255, 1)',
								'rgba(255, 159, 64, 1)'
							]
						}]
					},
					options: {
						legend: {
							position: 'bottom'
						},
						title: {
							display: true,
							text: 'Audiometri Kiri'
						}
					}
				});
				
				spiro = new Chart(document.getElementById('spiro'), {
					type: 'pie',
					data: {
						labels: data.spiro.labels,
						datasets: [{
							data: data.spiro.data,
							backgroundColor: [
								'rgba(255, 99, 132, 0.2)',
								'rgba(54, 162, 235, 0.2)',
								'rgba(255, 206, 86, 0.2)',
								'rgba(75, 192, 192, 0.2)',
								'rgba(153, 102, 255, 0.2)',
								'rgba(255, 159, 64, 0.2)'
							],
							borderColor: [
								'rgba(255, 99, 132, 1)',
								'rgba(54, 162, 235, 1)',
								'rgba(255, 206, 86, 1)',
								'rgba(75, 192, 192, 1)',
								'rgba(153, 102, 255, 1)',
								'rgba(255, 159, 64, 1)'
							]
						}]
					},
					options: {
						legend: {
							position: 'bottom'
						},
						title: {
							display: true,
							text: 'Spirometri'
						}
					}
				});
			} else {
				age.data = {
					labels: data.age.labels,
					datasets: [{
						data: data.age.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)',
							'rgba(255, 206, 86, 0.2)',
							'rgba(75, 192, 192, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)',
							'rgba(255, 206, 86, 1)',
							'rgba(75, 192, 192, 1)'
						]
					}]
				};
				age.update();
				bmi.data = {
					labels: data.bmi.labels,
					datasets: [{
						data: data.bmi.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)',
							'rgba(255, 206, 86, 0.2)',
							'rgba(75, 192, 192, 0.2)',
							'rgba(153, 102, 255, 0.2)',
							'rgba(255, 159, 64, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)',
							'rgba(255, 206, 86, 1)',
							'rgba(75, 192, 192, 1)',
							'rgba(153, 102, 255, 1)',
							'rgba(255, 159, 64, 1)'
						]
					}]
				};
				bmi.update();
				color.data = {
					labels: data.color.labels,
					datasets: [{
						data: data.color.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)',
							'rgba(255, 206, 86, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)',
							'rgba(255, 206, 86, 1)'
						]
					}]
				};
				color.update();
				right.data = {
					labels: data.right.labels,
					datasets: [{
						data: data.right.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)',
							'rgba(255, 206, 86, 0.2)',
							'rgba(75, 192, 192, 0.2)',
							'rgba(153, 102, 255, 0.2)',
							'rgba(255, 159, 64, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)',
							'rgba(255, 206, 86, 1)',
							'rgba(75, 192, 192, 1)',
							'rgba(153, 102, 255, 1)',
							'rgba(255, 159, 64, 1)'
						]
					}]
				};
				right.update();
				left.data = {
					labels: data.left.labels,
					datasets: [{
						data: data.left.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)',
							'rgba(255, 206, 86, 0.2)',
							'rgba(75, 192, 192, 0.2)',
							'rgba(153, 102, 255, 0.2)',
							'rgba(255, 159, 64, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)',
							'rgba(255, 206, 86, 1)',
							'rgba(75, 192, 192, 1)',
							'rgba(153, 102, 255, 1)',
							'rgba(255, 159, 64, 1)'
						]
					}]
				};
				left.update();
				spiro.data = {
					labels: data.spiro.labels,
					datasets: [{
						data: data.spiro.data,
						backgroundColor: [
							'rgba(255, 99, 132, 0.2)',
							'rgba(54, 162, 235, 0.2)',
							'rgba(255, 206, 86, 0.2)',
							'rgba(75, 192, 192, 0.2)',
							'rgba(153, 102, 255, 0.2)',
							'rgba(255, 159, 64, 0.2)'
						],
						borderColor: [
							'rgba(255, 99, 132, 1)',
							'rgba(54, 162, 235, 1)',
							'rgba(255, 206, 86, 1)',
							'rgba(75, 192, 192, 1)',
							'rgba(153, 102, 255, 1)',
							'rgba(255, 159, 64, 1)'
						]
					}]
				};
				spiro.update();
			}
		}
	});
}
</script>
@endsection