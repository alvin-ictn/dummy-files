@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Add Cost Center Packages</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
            <div class="card-header card-color">
                  <h3 class="card-title text-white">
                    Add New Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/addccpackages/insert" id="form-confirm">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Cost Center Name</label>
                              <div class="col-sm-4">
									      <div class="input-group">
									      	<input name="ccenter" id="ccenter" placeholder="Cost Center Name" class="form-control" type="text" readonly>
                                    <input name="ccentercode"class="form-control" type="hidden" readonly>
									      	<div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myCostcentername">
									      	   <div class="input-group-text"><i class="fa fa-search"></i></div>
									      	</div>
                                    <div class="invalid-feedback" id="exists"></div>
									      </div>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Packages Code</label>
                              <div class="col-sm-4">
									      <div class="input-group">
									      	<input name="package" placeholder="Packages Code" class="form-control" type="text" readonly>
									      	<input name="packcode" class="form-control" type="hidden" readonly>
									      	<div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myCPackagescode">
									      	   <div class="input-group-text"><i class="fa fa-search"></i></div>
									      	</div>
									      </div>
                              </div>
                           </div>
                        </div>
                        <div class="form-group row">
                           <div class="col-md-12">
                              <div class="float-right">
                                 <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                 <a  href="/account/costcenterpackages" class="btn btn-cstm btn-light btn-sz">Close</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
		<div class="modal fade in" id="myCostcentername" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg modal-content">
				<div class="card mb-4">
					<div class="card-header bg-info">
						<h5 class="card-title text-white" align="center">Cost Center</h5>
						<button type="button" class="close text-white" data-dismiss="modal">×</button>
					</div>
					<div class="card-body p-3">
						<div id="dvData" class="table-responsive">
							<table id="tblcostcenter" class="display" style="width:100%">
								<thead>
									<tr>
										<th>
											Cost Center Code
										</th>
										<th>
                                 Cost Center Name
										</th>
									</tr>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade in" id="myCPackagescode" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg modal-content">
				<div class="card mb-4">
					<div class="card-header bg-info">
						<h5 class="card-title text-white" align="center">Packages</h5>
						<button type="button" class="close text-white" data-dismiss="modal">×</button>
					</div>
					<div class="card-body p-3">
						<div id="dvData" class="table-responsive">
							<table id="tblpack" class="display" style="width:100%">
								<thead>
									<tr>
										<th>
											Packages Code
										</th>
										<th>
                                 Packages Name
										</th>
									</tr>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
   </div>
</section>
<script>

   $(document).ready(function() {
      $("#costcode").keyup(function() {
         var id = $(this).val();
         var base = btoa(id);
         $.ajax({
            dataType: "json",
            type: "GET",
            url: "/getajaxcostcenterpackages/" + base,
            success: function(result) {
               if(result.data === 'already'){
                  $('#already').html('Cost Center Code already in use!');
                  $('input#costcode').addClass('is-invalid');
               }else{
                  $('#already').html('');
                  $('input#costcode').removeClass('is-invalid');
               }
            
            }
         });
      });
   });

   $(document).ready(function() {
      $("#code").keyup(function() {
         var id = $(this).val();
         var base = btoa(id);
         $.ajax({
            dataType: "json",
            type: "GET",
            url: "/getajaxcostcenterpackages2/" + base,
            success: function(result) {
               if(result.data === 'already2'){
                  $('#already2').html('Packages Center Code already in use!');
                  $('input#code').addClass('is-invalid');
               }else{
                  $('#already2').html('');
                  $('input#code').removeClass('is-invalid');
               }
            
            }
         });
      });
   });

   $(document).ready(function() {
   	var table = $("#tblcostcenter").DataTable({ pagingType: $(window).width() < 768 ? "simple" : "simple_numbers", ajax: { url: '/getcostcenterlookup', type: "GET", }, columns: [ { data: "VCOSTCNTRCODE", name: "VCOSTCNTRCODE" }, { data: "VCOSTCNTRNAME", name: "VCOSTCNTRNAME" } ] });
   	$('#tblcostcenter tbody').on('dblclick', 'tr', function () {
   		var data = table.row(this).data();
   		$('input[name="ccenter"]').val(data['VCOSTCNTRCODE'] + ' - ' + data['VCOSTCNTRNAME']);
   		$('input[name="ccentercode"]').val(data['VCOSTCNTRCODE']);
         $(this).closest('.card').find('button').trigger('click');
         CheckCostCenterPackageExists(); // Cost Center Package Check
   	});
   });

   $(document).ready(function() {
   	var table = $("#tblpack").DataTable({ pagingType: $(window).width() < 768 ? "simple" : "simple_numbers", ajax: { url: '/getpackageslookup', type: "GET", }, columns: [ { data: "VPCKGCODE", name: "VPCKGCODE" }, { data: "VPCKGNAME", name: "VPCKGNAME" } ] });
   	$('#tblpack tbody').on('dblclick', 'tr', function () {
   		var data = table.row(this).data();
   		$('input[name="package"]').val(data['VPCKGCODE'] + ' - ' + data['VPCKGNAME']);
   		$('input[name="packcode"]').val(data['VPCKGCODE']);
   		$(this).closest('.card').find('button').trigger('click');
   	});
   });

   //==== Check if current inputted Cost Center has an active package. Return: Cost Center Package data with an active status
   function CheckCostCenterPackageExists()
   {
      if($('#ccenter').val() == '') return;
      var costcode = $('input[name="ccentercode"]').val();
      var base = btoa(costcode);
      $.ajax({
         dataType: "json",
         type: "GET",
         url: "/getajaxcostcenterpackageexists/" + base,
         success: function(result) {
            if(result.data === ''){
               $('#exists').html('');
               $('#ccenter').removeClass("is-invalid");
            }else{
               $('#exists').html(result.data);
               $('#ccenter').addClass("is-invalid");
            }
         }
      });
   }
	
</script>
@endsection