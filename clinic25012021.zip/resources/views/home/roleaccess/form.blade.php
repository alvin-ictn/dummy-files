@extends('layout.app')
@section('content')
<section class="content">
    <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Add Role Access</li>
               </ol>
            </div>
         </div>
      </div>
       <!-- /.container-fluid -->
    </section>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header card-color">
                        <h3 class="card-title text-white">
                        Role Access Form
                    </h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <form id="form-confirm" data-url="/roleaccess/form" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-lg-2 col-sm-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Role Name</label>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-12">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <div class="input-group">
                                            <input name="VROLENAME" class="form-control" type="text" value="{{ $role->ROLEID ?? '' }}{{ isset($role->ROLEDESC) && $role->ROLEDESC != '' ? ' - '.$role->ROLEDESC : '' }}" readonly>
                                            <input name="VROLEID"class="form-control" type="hidden" value="{{ $role->ROLEID ?? '' }}" readonly>
                                            @if(!isset($role))
                                                <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myModalRole">
                                                    <div class="input-group-text"><i class="fa fa-search"></i></div>
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        @foreach($mstmenus as $menu)
                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingOne">
                                    <div class="panel-title" data-toggle="collapse">
                                        <a class="roleacc collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse{{ $menu->No }}" aria-expanded="false" aria-controls="collapseOne">{{ $menu->VMENUNAME }}</a>
                                    </div>
                                </div>
                                <div id="collapse{{ $menu->No }}" class="table-responsive panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                    <div class="col-12">
                                        <input type="checkbox" id="all{{ $menu->No }}" name="checkall" value="{{ $menu->No }}">
                                        <label for="all{{ $menu->No }}"> Check All</label><br>
                                    </div>
                                    <table style="padding:5px; width: 50%;">
                                        <tr>
                                          <th style="padding: 5px; width: 5%; text-align:center;"> </th>
                                          <!-- Column: name of options -->
                                          @foreach($array_options as $key=>$value)
                                              <th style="padding: 5px; width: 5%; text-align:center;">{{$key}}</th> 
                                          @endforeach
                                        </tr>
                                        @foreach($mstfunctions as $function)
                                            @if($function->VMENUCODE == $menu->VMENUCODE)
                                                <tr>
                                                    <td style="width: 10%;">{{ $function->VFUNCNAME }}</td>
                                                    <!-- Checkbox of options for each function -->
                                                    @foreach($array_options as $key=>$value)
                                                        <td style="width: 5%; text-align:center;">
                                                            @if(isset($array_mstroleaccess["$function->VFUNCCODE"]["$value"]) && $array_mstroleaccess["$function->VFUNCCODE"]["$value"])
                                                                <input 
                                                                    type="checkbox" 
                                                                    id="{{ $key }}{{ $menu->No }}{{ $function->No }}" 
                                                                    name="checkbox[]" 
                                                                    value="{{ $function->VFUNCCODE }}-{{ $key }}" 
                                                                    section="checkbox{{ $menu->No }}" 
                                                                    checked 
                                                                    <?php $flag = App\Http\Controllers\RoleAccessController::CheckDisabled($function->VDISABLED, $key);
                                                                    if($flag == 'TRUE'){ ?>
                                                                            disabled="disabled" style="display:inline-block;" 
                                                                    <?php } else if($flag == 'ERROR') { ?>
                                                                            disabled="disabled" style="display:inline-block; opacity:0;" 
                                                                    <?php } ?>
                                                                >
                                                            @else
                                                                <!-- <input type="checkbox" id="{{ $key }}{{ $menu->No }}{{ $function->No }}" name="checkbox[]" value="{{ $function->VFUNCCODE }}-{{ $key }}" @if($function->VMENUCODE === 'M6' || $function->VMENUCODE === 'M5' )@if($key === 'Print' || $key === 'Export' || $key === 'Cancel' || $key === 'Edit' || $key === 'Add') disabled="disabled" style="display:inline-block;background: red;" @endif @endif @if($function->VMENUCODE === 'M1')@if($key === 'Print') disabled="disabled" style="display:inline-block;background: red;" @endif @endif  @if($function->VMENUCODE === 'M7') @if($key === 'Cancel' || $key === 'Edit' || $key === 'Add') disabled="disabled" style="display:inline-block;background: red;" @endif @endif @if($function->VMENUCODE === 'M1')@if($key === 'Print') disabled="disabled" style="display:inline-block;background: red;" @endif @endif  @if($function->VFUNCCODE === 'F34') @if($key === 'Cancel') disabled="disabled" style="display:inline-block;background: red;" @endif @endif  @if($function->VFUNCCODE === 'F38') @if($key === 'Cancel' || $key === 'Edit') disabled="disabled" style="display:inline-block;background: red;" @endif @endif @if($function->VFUNCCODE === 'F35') @if($key === 'Print' || $key === 'Add' ||  $key === 'Cancel' || $key === 'Edit') disabled="disabled" style="display:inline-block;background: red;" @endif @endif @if($function->VFUNCCODE === 'F36') @if($key === 'Print' || $key === 'Add' ||  $key === 'Cancel' || $key === 'Edit') disabled="disabled" style="display:inline-block;background: red;" @endif @endif section="checkbox{{ $menu->No }}"> -->
                                                                <!-- <input type="checkbox" id="{{ $key }}{{ $menu->No }}{{ $function->No }}" name="checkbox[]" value="{{ $function->VFUNCCODE }}-{{ $key }}"  @if($function->VMENUCODE === 'M6' || $function->VMENUCODE === 'M5' )@if($key === 'Print' || $key === 'Export' || $key === 'Cancel' || $key === 'Edit' || $key === 'Add') disabled="disabled" style="display:inline-block;background: red;" @endif @endif @if($function->VMENUCODE === 'M1')@if($key === 'Print') disabled="disabled" style="display:inline-block;background: red;" @endif @endif  @if($function->VMENUCODE === 'M7') @if($key === 'Cancel' || $key === 'Edit' || $key === 'Add') disabled="disabled" style="display:inline-block;background: red;" @endif @endif @if($function->VMENUCODE === 'M1')@if($key === 'Print') disabled="disabled" style="display:inline-block;background: red;" @endif @endif  @if($function->VFUNCCODE === 'F34') @if($key === 'Cancel') disabled="disabled" style="display:inline-block;background: red;" @endif @endif  @if($function->VFUNCCODE === 'F38') @if($key === 'Cancel' || $key === 'Edit') disabled="disabled" style="display:inline-block;background: red;" @endif @endif @if($function->VFUNCCODE === 'F35') @if($key === 'Print' || $key === 'Add' || $key === 'Cancel' || $key === 'Edit') disabled="disabled" style="display:inline-block;background: red;" @endif @endif @if($function->VFUNCCODE === 'F36') @if($key === 'Print' || $key === 'Add' ||  $key === 'Cancel' || $key === 'Edit') disabled="disabled" style="display:inline-block;background: red;" @endif @endif @if($function->VMENUCODE === 'M1')@if($key === 'Print') disabled="disabled" style="display:inline-block;background: red;" @endif @endif  @if($function->VMENUCODE === 'M7') @if($key === 'Cancel' || $key === 'Edit' || $key === 'Add') disabled="disabled" style="display:inline-block;background: red;" @endif @endif @if($function->VMENUCODE === 'M1')@if($key === 'Print') disabled="disabled" style="display:inline-block;background: red;" @endif @endif  @if($function->VFUNCCODE === 'F34') @if($key === 'Cancel') disabled="disabled" style="display:inline-block;background: red;" @endif @endif  @if($function->VFUNCCODE === 'F38') @if($key === 'Cancel' || $key === 'Edit') disabled="disabled" style="display:inline-block;background: red;" @endif @endif @if($function->VFUNCCODE === 'F35') @if($key === 'Print' || $key === 'Add' || $key === 'Cancel' || $key === 'Edit') disabled="disabled" style="display:inline-block;background: red;" @endif @endif @if($function->VFUNCCODE === 'F37') @if( $key === 'Cancel' || $key === 'Edit' || $key === 'Print') disabled="disabled" style="display:inline-block;background: red;" @endif @endif section="checkbox{{ $menu->No }}"> -->
                                                                <input 
                                                                    type="checkbox" 
                                                                    id="{{ $key }}{{ $menu->No }}{{ $function->No }}" 
                                                                    name="checkbox[]" 
                                                                    value="{{ $function->VFUNCCODE }}-{{ $key }}"  
                                                                    section="checkbox{{ $menu->No }}"
                                                                    <?php $flag = App\Http\Controllers\RoleAccessController::CheckDisabled($function->VDISABLED, $key);
                                                                    if($flag == 'TRUE'){ ?>
                                                                            disabled="disabled" style="display:inline-block;" 
                                                                    <?php } else if($flag == 'ERROR') { ?>
                                                                            disabled="disabled" style="display:inline-block; opacity:0;" 
                                                                    <?php } ?>
                                                                >
                                                            @endif
                                                        </td>
                                                    @endforeach
                                                </tr>
                                            @endif
                                        @endforeach
                                    </table>
                                </div>
                            </div>
                        </div>
                        <br>
                        @endforeach
                        <br/>
                        <div class="form-group row">
                            <div class="col-md-12">
                                <div class="float-right">
                                    <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                    <a href="/account/roleaccess" class="btn btn-cstm btn-light btn-sz">Close</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Role List -->
    <div class="modal fade in" id="myModalRole" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-content">
            <div class="card mb-4">
                <div class="card-header bg-info">
                    <h5 class="card-title text-white" align="center">Role List</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">×</button>
                </div>
                <div class="card-body p-3">
                    <div id="dvData" class="table-responsive">
                        <table id="tblrole" class="display" style="width:100%">
                            <thead>
                                <tr>
                                   <th>
                                      Role ID
                                   </th>
                                   <th>
                                      Role Name
                                   </th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
	$(document).ready(function() {
        //==== Role List table
		var table_role = $("#tblrole").DataTable({ 
         pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
         ajax: { url: '/roleaccess/getrolenamelookup', type: "GET" }, 
         columns: [ 
            { data: "ROLEID" }, 
            { data: "ROLEDESC" } 
         ] 
        });
        $('#tblrole tbody').on('dblclick', 'tr', function () {  // Select with double click
			var data = table_role.row(this).data();
			$('input[name="VROLENAME"]').val(data['ROLEID'] + ' - ' + data['ROLEDESC']);   // fill field with "role id - role name"
			$('input[name="VROLEID"]').val(data['ROLEID']);                                // save "role id" in hidden input
			$(this).closest('.card').find('button').trigger('click');
        });

        //==== 'Check All' checkboxes
        $('input[name="checkall"]').click(function()
        {
            $('input[section="checkbox' + this.value + '"]').not("[disabled]").prop("checked", this.checked);
        });

        //==== 'View' checkboxes auto checked
        $('input[id*="View"], input[id*="Add"], input[id*="Edit"], input[id*="Cancel"], input[id*="Print"], input[id*="Export"]').click(function()
        {
            var id_num = this.id.replace(/[a-z]*/gi, '').trim();
            if ($('input[id="Add' + id_num + '"]').is(':checked') || 
                $('input[id="Edit' + id_num + '"]').is(':checked') || 
                $('input[id="Cancel' + id_num + '"]').is(':checked') || 
                $('input[id="Print' + id_num + '"]').is(':checked') || 
                $('input[id="Export' + id_num + '"]').is(':checked')) 
                {
                    $('input[id*="View' + id_num + '"]').prop("checked", true);
                }
            else if (this.id != "View" + id_num)
                $('input[id="View' + id_num + '"]').prop("checked", false);
        });

        // DEBUG
        // $('#startDiv').on('click', function()
        // {
        //     alert("VSCHCODE val : " + $('input[name="VSCHCODE"]').val());
        // });
    });
   
</script>
@endsection