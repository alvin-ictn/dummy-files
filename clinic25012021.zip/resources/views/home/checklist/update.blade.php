@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-12">
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Edit Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/checklist/update" id="form-edit">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="col-form-label col-sm-2">Check Code</label>
                              <div class="col-sm-4">
                                 <input name="chckcode" placeholder="Check Code" value="{{$checklisits->VPACKAGECODE}}" class="form-control" type="text" required readonly>
                                 <span class="help-block"></span>
                              </div>
                              <label for="example-text-input" class="col-form-label col-md-2">Check Name</label>
                              <div class="col-sm-4">
                                 <input name="chckname" placeholder="Check Name" value="{{$checklisits->VPACKAGENAME}}" class="form-control" type="text" required>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="col-form-label col-sm-2">Status</label>
                              <div class="col-sm-4">
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a1" value="1" {{ ($checklisits->BACTIVE==="1")? "checked" : "" }}>
                                    <label class="form-check-label" for="a1">Active</label>
                                 </div>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a2" value="0" {{ ($checklisits->BACTIVE==="0")? "checked" : "" }}>
                                    <label class="form-check-label" for="a2">InActive</label>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="form-group row">
                           <div class="col-md-12">
                              <div class="float-right">
                                 <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                 <a  onclick="history.back()" class="btn-cstm btn-light btn-sz">Close</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
@endsection