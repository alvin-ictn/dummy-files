@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-12">
               <h5>Master Check List MCU</h5>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header">
                  <h3 class="card-title">
                     <a class="btn btn-sz btn-primary" href="checklist/add" role="button">Add New</a>
                     <a class="btn btn-sz btn-primary" href="checklist/export" role="button">Export to Excel</a>
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
               @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div>
               @endif
                  <div class="table-responsive">
                     <table id="cmchcklist" class="table table-bordered table-striped display compact nowrap"  style="width:100%">
                        <thead>
                           <tr>
                              <th>No</th>
                              <th>Check Code</th>
                              <th>Check Name</th>
                              <th>Last Modified Date</th>
                              <th>Status</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
@endsection