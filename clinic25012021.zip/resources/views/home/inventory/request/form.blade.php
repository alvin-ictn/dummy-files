@extends('layout.app') 
@section('content')
<style>
	.table-line-height input { line-height: 15px; }
	table.dataTable thead th { padding: 0px 0px; }
	#tblreqdetail_wrapper .dataTables_filter { display: none; }
	table.dataTable thead th { border-bottom: 0px; }
</style>
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
					<li class="breadcrumb-item"><a href="/account/home">Home</a></li>
					<li class="breadcrumb-item active">Request List</li>
				</ol>
			</div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Request Order
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form id="form-confirm" data-url="/inventory/save" method="post">
                     <input name="VREQNO" type="hidden" value="{{ $inventory->VREQNO ?? '' }}">
					 <input name="VSIGN" type="hidden" value="{{ $VSIGN }}">
					 <input name="VCLINICCODE" type="hidden" value="{{ $VCLINICCODE }}">
					 <div class="row">
                        <div class="col-sm-2">
                           <div>
                              <label class="control-label col-sm-12">Request No :</label>
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div>
                              <div class="col-sm-12">
                                 <label>{{ $inventory->VREQNO ?? '' }}</label>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-2">
                           <div>
                              <label class="control-label col-sm-12">Request Date :</label>
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div>
                              <div class="col-sm-12">
                                 <label>{{ isset($inventory) ? $inventory->DREQ->format('d F Y') : \Carbon\Carbon::now()->format('d F Y') }}</label>
                              </div>
                           </div>
                        </div>
                     </div>
					 <div class="row">
                        <div class="col-sm-2">
                           <div>
                              <label class="control-label col-sm-12">Request by :</label>
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div>
                              <div class="col-sm-12">
								<label>{{ $inventory->VCLINICNAME ?? $VCLINICNAME }}</label>
                              </div>
                           </div>
                        </div>
                        <div class="col-sm-2">
                           <div class="{{ !isset($inventory) || (Session::get('namaclinic') == $inventory->VCLINICCODE && $canedit) || $canconfirm ? 'required' : '' }}">
                              <label class="control-label col-sm-12">Buy from :</label>
                           </div>
                        </div>
                        <div class="col-sm-4">
                           <div class="div-vbuy">
                              <div class="col-sm-12">
								@if (!isset($inventory) || ((Session::get('namaclinic') ?? 'HO') == $inventory->VCLINICCODE && $canedit) || $canconfirm)
									<div class="form-check form-check-inline col-sm-12">
									   <input class="form-check-input" name="VBUYFROM" type="radio" value="HO" {{ isset($inventory) && $inventory->VBUY == 'HO' ? 'checked' : '' }} required>
									   <label class="form-check-label">HO</label>
									</div>
									<div class="form-check form-check-inline">
									   <input class="form-check-input" name="VBUYFROM" type="radio" value="OP" {{ isset($inventory) && $inventory->VBUY != 'HO' ? 'checked' : '' }} required>
									   <label class="form-check-label">Other pharmacy</label>
									</div>
									<div class="form-check form-check-inline col-sm-6">
										<input name="VBUY" class="form-control" type="text" value="{{ isset($inventory) && $inventory->VBUY != 'HO' ? $inventory->VBUY : '' }}" {{ isset($inventory) && $inventory->VBUY == 'HO' ? 'readonly' : '' }}>
									</div>
								@else
									<label>{{ $inventory->VBUY }}<input name="VBUY" type="hidden" value="{{ isset($inventory) && $inventory->VBUY != 'HO' ? $inventory->VBUY : '' }}"></label>
								@endif
                              </div>
                           </div>
                        </div>
                     </div>
					 <br/>
					 @if (isset($inventory) && ($inventory->BSTATUS == 'C' || $inventory->BSTATUS == 'J' || $inventory->BSTATUS == 'A') && App\Http\Controllers\RoleAccessController::FunctionAccessCheck('P', 'F26'))
						<div id="hbutton" class="row">
							<div class="col-sm-2">
							   <div>
								  <label class="control-label col-sm-12">PBF/ Non PBF :</label>
							   </div>
							</div>
							<div class="col-sm-2">
							   <div class="form-group">
								  <div class="col-sm-12">
									<select class="form-control pbf-type">
										<option value="All">All</option>
										<option value="PBF">PBF</option>
										<option value="Non PBF">Non PBF</option>
									</select>
								  </div>
							   </div>
							</div>
						</div>
					 @endif
					 <div class="row">
						<div class="table-responsive col-lg-12 col-sm-12">
						  <table id="tblreqdetail" border="1" width="100%" class="table-line-height">
							<thead>
							  <tr>
								@if (!isset($inventory) || ((Session::get('namaclinic') ?? 'HO') == $inventory->VCLINICCODE && $canedit && ($inventory->BSTATUS == 'R' || $inventory->BSTATUS == 'S')))
									<th rowspan="2" class="text-center" width="3%">Action</th>
								@endif
								<th rowspan="2" class="text-center" width="3%">No</th>
								<th rowspan="2" class="text-center">Drug</th>
								<th rowspan="2" class="text-center" width="3%">UoM</th>
								<th colspan="2" class="text-center">Stock</th>
								<th rowspan="2" class="text-center" width="7%">PBF</th>
								<th rowspan="2" class="text-center" width="10%">Vendor Pharmacy</th>
								<th colspan="3" class="text-center">Qty</th>
								@if (App\Http\Controllers\Controller::check_role("HRADM") && isset($inventory) && $inventory->BSTATUS != 'S')
									<th rowspan="2" class="text-center" width="13%">Transfer From</th>
								@endif
								<th colspan="2" class="text-center">Price</th>
							  </tr>
							  <tr>
								<th class="text-center" width="3%">Request</th>
								<th class="text-center" width="3%">Remaining</th>
								<th class="text-center" width="3%">In</th>
								<th class="text-center" width="3%">Out</th>
								<th class="text-center" width="3%">Verify</th>
								<th class="text-center" width="3%">Unit</th>
								<th class="text-center" width="3%">Total</th>
							  </tr>
							</thead>
							<tbody></tbody>
							<tfoot>
							  <tr>
								<td colspan="{{ (!isset($inventory) || ((Session::get('namaclinic') ?? 'HO') == $inventory->VCLINICCODE && $canedit && ($inventory->BSTATUS == 'R' || $inventory->BSTATUS == 'S'))) || (App\Http\Controllers\Controller::check_role("HRADM") && isset($inventory) && $inventory->BSTATUS != 'S') ? 12 : 11 }}" class="text-center"><b>Total</b></td>
								<td class="text-right total-total"></td>
							  </tr>
							</tfoot>
						  </table>
						</div>
					 </div>
					 <br/>
					 @if (!isset($inventory) || ((Session::get('namaclinic') ?? 'HO') == $inventory->VCLINICCODE && $canedit && ($inventory->BSTATUS == 'R' || $inventory->BSTATUS == 'S')))
						<div class="row">
							<div class="col-lg-12 col-sm-12">
								<button type="button" class="btn-cstm btn-primary btn-sz" onclick="return toForm(this);">Add Row</button>
							</div>
						</div>
						 <br/>
					@endif
					 @if (!isset($inventory) || $canconfirm || (($inventory->BSTATUS == 'R' || ($inventory->BSTATUS == 'S' && (App\Http\Controllers\Controller::check_role("HRADM") && App\Mstsettings::where('VSETID', 'INVREQUEST')->where('VSETDESC', Session::get('id'))->where('BACTIVE', '1')->exists() || App\Http\Controllers\Controller::check_role("PMCY")))) && (Session::get('namaclinic') ?? 'HO') == $inventory->VCLINICCODE) || $canapprove)
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div>
								  <label class="control-label col-sm-12">Remarks</label>
							   </div>
							</div>
							<div class="col-lg-6 col-sm-12">
							   <div>
								  <div class="col-sm-12">
									 <textarea class="form-control" name="VREMARKS" rows="3"></textarea>
								  </div>
							   </div>
							</div>
						 </div>
					 @endif
					 <div class="row">
						<div class="col-lg-12 col-sm-12">
						  <label class="control-label col-sm-12"><b>Approval History</b></label>
						</div>
					 </div>
					 <div class="row">
						<div class="table-responsive  col-lg-12 col-sm-12">
						  <table border="1" width="100%">
							<thead>
							  <tr>
								<th class="text-center">No</th>
								<th class="text-center">Name</th>
								<th class="text-center">Action</th>
								<th class="text-center">Remarks</th>
								<th class="text-center">Last Modified</th>
							  </tr>
							</thead>
							<tbody>
								<?php $incwf = 1;?>
								@foreach ($workflows as $workflow)
									<tr>
										<td>{{ $incwf }}</td>
										<td>{{ $workflow->VRESPOND }}</td>
										<td>{{ $workflow->VSIGN }}</td>
										<td>{{ $workflow->VREMARKS }}</td>
										<td>{{ $workflow->DRESPOND }}</td>
									  </tr>
									  <?php $incwf++; ?>
								@endforeach
							</tbody>
						  </table>
						</div>
					 </div>
					<br/>
					<div class="float-right">
						<div id="hbutton" class="col-sm-12">
						  @if (isset($inventory) && ($inventory->BSTATUS == 'C' || $inventory->BSTATUS == 'J' || $inventory->BSTATUS == 'A') && App\Http\Controllers\RoleAccessController::FunctionAccessCheck('P', 'F26'))
							  <button type="button" class="btn-cstm btn-primary btn-sz" onclick="return print()">Print</button>
						  @endif
						  @if (!isset($inventory) || $canconfirm || ($inventory->BSTATUS == 'R' && Session::get('namaclinic') == $inventory->VCLINICCODE) || (($inventory->BSTATUS == 'S' && (App\Http\Controllers\Controller::check_role("HRADM") && App\Mstsettings::where('VSETID', 'INVREQUEST')->where('VSETDESC', Session::get('id'))->where('BACTIVE', '1')->exists() || App\Http\Controllers\Controller::check_role("PMCY"))) && (Session::get('namaclinic') ?? 'HO') == $inventory->VCLINICCODE))
							  @if (!isset($inventory) || $inventory->BSTATUS == 'S')
								  <button type="submit" class="btn-cstm btn-primary btn-sz" onclick="return sbmt('save');">Save as Draft</button>
							  @endif
							  <button type="submit" class="btn-cstm btn-primary btn-sz" onclick="return sbmt();">Submit</button>
							  @if (App\Http\Controllers\Controller::check_role("HRADM") && isset($inventory) && $inventory->BSTATUS != 'S')
								  <button type="button" class="btn-cstm btn-primary btn-sz" onclick="return reject('revised');">Revise</button>
							  @endif
						  @endif
						  @if (isset($inventory) && $canapprove)
							  <button type="submit" class="btn-cstm btn-primary btn-sz">Approve</button>
							  <button type="button" class="btn-cstm btn-primary btn-sz" onclick="return reject('rejected');">Reject</button>
						  @endif
						  <a onclick="history.length > 1 ? history.back() : location.href = document.referrer" class="btn btn-cstm btn-light btn-sz">Close</a>
						</div>
					</div>
                  </form>
               </div>
            </div>
         </div>
      </div>
	  <div class="modal fade" id="modaladdnew" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-hidden="true">
		 <div class="modal-dialog modal-md modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body">
				  <form id="form-addnew">
					 <input name="NPRICE" type="hidden">
					 <div class="container">
						<div class="row">
							<div class="col-lg-12 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									<div class="input-group">
										<input name="VDRUGSCODE" class="form-control readonly" style="background-color: #e9ecef;" type="text" placeholder="Drug" autocomplete="off" data-required="true" required>
										<div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myDrugsModal">
										   <div class="input-group-text"><i class="fa fa-search"></i></div>
										</div>
									</div>
								  </div>
							   </div>
							</div>
						 </div>
						<div class="row">
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="VUOM" class="form-control" type="text" placeholder="UoM" readonly>
								  </div>
							   </div>
							</div>
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 @if (App\Http\Controllers\Controller::check_role("HRADM"))
										<input name="IQTYREQ" class="form-control readonly" style="background-color: #e9ecef;" type="text" placeholder="Stock Request" autocomplete="off" data-required="true">
									@else
										<input name="IQTYREQ" class="form-control" type="number" placeholder="Stock Request" min="1" data-required="true" required>
									@endif 
								  </div>
							   </div>
							</div>
						 </div>
						<div class="row">
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="ISTOCK" class="form-control readonly" style="background-color: #e9ecef;" type="text" placeholder="Stock Remaining" autocomplete="off" data-required="true">
								  </div>
							   </div>
							</div>
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="PBF" class="form-control" type="text" placeholder="PBF" readonly>
								  </div>
							   </div>
							</div>
						 </div>
						<div class="row">
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="VPHARMACY" class="form-control" type="text" placeholder="Vendor Pharmacy" readonly>
								  </div>
							   </div>
							</div>
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="IQTYIN" class="form-control readonly" style="background-color: #e9ecef;" type="text" placeholder="Qty In" autocomplete="off" data-required="true">
								  </div>
							   </div>
							</div>
						 </div>
						 <div class="row">
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="IQTYOUT" class="form-control readonly" style="background-color: #e9ecef;" type="text" placeholder="Qty Out" autocomplete="off" data-required="true">
								  </div>
							   </div>
							</div>
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 @if (App\Http\Controllers\Controller::check_role("HRADM"))
										<input name="IQTYVERIFY" class="form-control" type="number" placeholder="Qty Verify" min="1" data-required="true" required>
									 @else
										<input name="IQTYVERIFY" class="form-control" type="text" placeholder="Qty Verify" readonly>
									 @endif
								  </div>
							   </div>
							</div>
						 </div>
						 <br/>
						 <div style="text-align:center;">
							<button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
							<a onclick="$('#modaladdnew').modal('hide');" class="btn-cstm btn-light btn-sz">Close</a>
						</div>
					 </div>
				  </form>
			   </div>
			</div>
		 </div>
	  </div>
	  <div class="modal fade in" id="myDrugsModal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-xl modal-content">
			<div class="card mb-4">
				<div class="card-header bg-info">
					<h5 class="card-title text-white" align="center">Drug List</h5>
					<button type="button" class="close text-white" data-dismiss="modal">×</button>
				</div>
				<div class="card-body p-3">
					<div class="table-responsive">
						<table id="tbldrug" class="display" style="width:100%">
							<thead>
								<tr>
									<th>Code</th>
									<th>Contain</th>
									<th>Brand</th>
									<th>UoM</th>
									<th>PBF</th>
									<th>Vendor Pharmacy</th>
									<th>Unit Price</th>
								</tr>
							</thead>
						</table>
					</div>
				</div>
			</div>
		</div>
	  </div>
   	</div>
</section>
<script>
	$(".readonly").on('keydown paste', function(e) {
        e.preventDefault();
    });
	
	var temp = [], previous, tbldrug, except = [], tblreqdetail, datatblreqdetail = [], dataclinic = [], datasp = [];
	
	$(document).ready(function() {
		$('input[type=radio][name=VBUYFROM]').change(function() {
			if (this.value == 'HO') {
				$(this).closest('.div-vbuy').find('input[name="VBUY"]').removeAttr('required').val('').prop('readonly', true);
				$('select[name="VTRF[]"]').val('HO');
			}
			else if (this.value == 'OP') {
				$(this).closest('.div-vbuy').find('input[name="VBUY"]').prop('required', true).removeAttr('readonly');
				$('select[name="VTRF[]"]').val('');
				$($('select[name="VTRF[]"]')).css('display', 'block').siblings().children().css('display', 'none');
			}
		});
		
		$('#tbldrug').on('dblclick', 'tbody tr', function () {
			var data = tbldrug.row(this).data();
			$('input[name="VDRUGSCODE"]').val(data['DRUGS_CODE'] + ' - ' + data['DRUGS_CONTAIN'] + ' - ' + data['DRUGS_BRAND']);
			$('input[name="VUOM"]').val(data['DRUGS_UOM']);
			$('input[name="PBF"]').val(data['PBF_TYPE']);
			$('input[name="VPHARMACY"]').val(data['DRUGS_VENDOR']);
			$('input[name="NPRICE"]').val(data['DRUGS_PRICE']);
			if (datasp.find(x => x.VDRUGSCODE === data['DRUGS_CODE']) !== undefined) {
				var fromsp = datasp.find(x => x.VDRUGSCODE === data['DRUGS_CODE']);
				$('input[name="ISTOCK"]').val(fromsp.ISTOCK);
				$('input[name="IQTYIN"]').val(fromsp.IQTYIN);
				$('input[name="IQTYOUT"]').val(fromsp.IQTYOUT);
			}
			$(this).closest('.card').find('button').trigger('click');
		});
		
		var trFilter = '';
		$('#tblreqdetail thead th:not([colspan])').each( function (i) {
			<?php
				if (!isset($inventory) || ((Session::get('namaclinic') ?? 'HO') == $inventory->VCLINICCODE && $canedit && ($inventory->BSTATUS == 'R' || $inventory->BSTATUS == 'S')))
				{
			?>
					if (i != 0) {
			<?php
				}
			?>
						trFilter += '<th id="hbutton"><input class="text-center" type="text" placeholder="Search" /></th>';
			<?php
				if (!isset($inventory) || ((Session::get('namaclinic') ?? 'HO') == $inventory->VCLINICCODE && $canedit && ($inventory->BSTATUS == 'R' || $inventory->BSTATUS == 'S')))
				{
			?>
					} else {
						trFilter += '<th></th>';
					}
			<?php
				}
			?>
		} );
		$('#tblreqdetail thead').append('<tr>' + trFilter + '</tr>');
		$('#tblreqdetail thead tr:eq(2) th').each( function (i) {
			<?php
				if (!isset($inventory) || ((Session::get('namaclinic') ?? 'HO') == $inventory->VCLINICCODE && $canedit && ($inventory->BSTATUS == 'R' || $inventory->BSTATUS == 'S')))
				{
			?>
					if (i != 0) {
			<?php
				}
			?>
						$( 'input', this ).on( 'keyup change', function () {
							if ( tblreqdetail.column(i).search() !== this.value ) {
								tblreqdetail
									.column(i)
									.search( this.value )
									.draw();
								reloadTotal();
							}
						} );
			<?php
				if (!isset($inventory) || ((Session::get('namaclinic') ?? 'HO') == $inventory->VCLINICCODE && $canedit && ($inventory->BSTATUS == 'R' || $inventory->BSTATUS == 'S')))
				{
			?>
					}
			<?php
				}
			?>
		} );
		tblreqdetail = $('#tblreqdetail').DataTable({
			sort: false,
			paging: false,
			info: false,
			data: datatblreqdetail,
			columns:
			[
				<?php
					if (!isset($inventory) || ((Session::get('namaclinic') ?? 'HO') == $inventory->VCLINICCODE && $canedit && ($inventory->BSTATUS == 'R' || $inventory->BSTATUS == 'S')))
					{
				?>
						{ data: "VDRUGSCODE", render: function (data) { return '<button onClick="remove(\'' + data + '\')" type="button" class="btn btn-link btn-sm"><i title="Delete" class="text-center fas fa-times"></i></button>' } },
				<?php
					}
				?>
				{ data: "ILINENO", render: function (data, type, full, meta) { return (meta.row + 1) + '<input name="ILINENO[]" type="hidden" value="' + (data ?? '') + '">' } },
				{ data: null, render: function (data, type, full) { return full.VDRUGSCODE + ' - ' + (full.VCONTAIN ?? '') + ' - ' + (full.VBRAND ?? '') + '<input name="VDRUGSCODE[]" type="hidden" value="' + full.VDRUGSCODE + '">' } },
				{ data: "VUOM" },
				{ data: "IQTYREQ", render: function (data) { return data + '<input name="IQTYREQ[]" type="hidden" value="' + data + '">' } },
				{ data: "ISTOCK", render: function (data) { return (data ?? '') + '<input name="ISTOCK[]" type="hidden" value="' + (data ?? '') + '">' } },
				{ data: "PBF" },
				{ data: "VPHARMACY" },
				{ data: "IQTYIN", render: function (data) { return (data ?? '') + '<input name="IQTYIN[]" type="hidden" value="' + (data ?? '') + '">' } },
				{ data: "IQTYOUT", render: function (data) { return (data ?? '') + '<input name="IQTYOUT[]" type="hidden" value="' + (data ?? '') + '">' } },
				{ data: null, render: function (data, type, full) {
					<?php
						if (isset($inventory) && $canconfirm)
						{
					?>
							return '<input name="IQTYVERIFY[]" type="number" value="' + (full.IQTYVERIFY ?? full.IQTYREQ) + '" min="0" required style="text-align: right;">'
					<?php
						}
						else
						{
							if (App\Http\Controllers\Controller::check_role("HRADM") && !isset($inventory))
							{
					?>
								return (full.IQTYVERIFY ?? full.IQTYREQ) + '<input name="IQTYVERIFY[]" type="hidden" value="' + full.IQTYREQ + '">'
					<?php
							}
							else
							{
					?>
								return full.IQTYVERIFY ?? full.IQTYREQ
					<?php
							}
						}
					?>
				}},
				<?php
					if (App\Http\Controllers\Controller::check_role("HRADM") && isset($inventory) && $inventory->BSTATUS != 'S')
					{
						if (!isset($inventory) || $canconfirm || ($inventory->BSTATUS == 'R' && Session::get('namaclinic') == $inventory->VCLINICCODE))
						{
				?>
							{ data: null, render: function (data, type, full) {
								var sel = '<select name="VTRF[]" required><option value="">-- Select Transfer From --</option>';
								$.each(dataclinic, function( index, value ) {
									sel += '<option ' + (value.code == full.VTRF || ('<?php echo $inventory->VBUY ?>' == 'HO' && value.code == 'HO') ? 'selected="selected" ' : '') + 'value="' + value.code + '">' + value.name + '</option>';
								});
								sel += '<option value="others">Others</option></select><div class="input-group"><div class="form-check-inline"><input name="VTRFOTH[]" type="text" value="' + (full.VTRFOTH ?? '') + '" style="height:25px; display: none;"><div class="input-group-append" style="height:25px; display: none;" onclick="hide(this)"><div class="input-group-text"><i class="fas fa-times"></i></div></div></div></div>';
								return sel
							}},
				<?php
						}
						else
						{
				?>
							{ data: null, render: function (data, type, full) { return full.VTRF != null && full.VTRF != 'others' ? dataclinic.filter(function(item) { return item.code == full.VTRF; })[0].name : full.VTRFOTH } },
				<?php
						}
					}
				?>
				{ data: "NPRICE", render: function (data) { return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'IDR' }).format(data ?? 1).replace('IDR ', '') } },
				{ data: "null", render: function (data, type, full) { return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'IDR' }).format((full.IQTYVERIFY ?? full.IQTYREQ) * (full.NPRICE ?? 1)).replace('IDR ', '') } }
			],
			columnDefs:
			[
				<?php
					if (!isset($inventory) || (Session::get('namaclinic') == $inventory->VCLINICCODE && $canedit && $inventory->BSTATUS == 'R'))
					{
				?>
						{ targets: 0, className: 'text-center' },
						{ targets: 4, className: 'text-right' },
						{ targets: 5, className: 'text-right' },
						{ targets: 6, className: 'pbf' },
						{ targets: 8, className: 'text-right' },
						{ targets: 9, className: 'text-right' },
						{ targets: 10, className: 'text-right' },
						{ targets: -2, className: 'text-right' },
						{ targets: -1, className: 'text-right subtotal' }
				<?php
					}
					else
					{
				?>
						{ targets: 3, className: 'text-right' },
						{ targets: 4, className: 'text-right' },
						{ targets: 5, className: 'pbf' },
						{ targets: 7, className: 'text-right' },
						{ targets: 8, className: 'text-right' },
						{ targets: 9, className: 'text-right' },
						{ targets: -2, className: 'text-right' },
						{ targets: -1, className: 'text-right subtotal' }
				<?php
					}
				?>
			]
		});
		$.ajax({
			url: "/gettblreqdetail<?php echo isset($inventory) ? '/' . $inventory->VREQNO : '' ?>",
			type: "GET",
			success: function (data) {
				datasp = data.data;
				datatblreqdetail = datasp.filter(function(item) { return item.IQTYREQ > 0; });
				tblreqdetail.rows.add(datasp.filter(function(item) { return item.IQTYREQ > 0; })).draw();
				$.each($('input[name="VDRUGSCODE[]"]'), function( index, value ) {
					except.push($(value).val());
				});
				reloadDrugs();
				$('select[name="VTRF[]"]').on('focus', function () {
					previous = this.value;
				}).change(function() {
					if (this.value == 'others') {
						$(this).css('display', 'none').siblings().children().children().css('display', 'block');
						if (temp.find(x => x.id === $(this).closest('tr').find('input[name="ILINENO[]"]').val()) !== undefined) {
							temp.splice(temp.map(function(item) { return item.id == $(this).closest('tr').find('input[name="ILINENO[]"]').val(); }).indexOf(), 1);
						}
						temp.push({ 'id': $(this).closest('tr').find('input[name="ILINENO[]"]').val(), 'val': previous });
					}
					previous = this.value;
				});
				<?php
					if (isset($inventory) && $canconfirm && $inventory->VBUY != 'HO')
					{
				?>
						previous = '';
						$('select[name="VTRF[]"]').val('others').change();
				<?php
					}
				?>
				reloadTotal();
			}
		});
		
		<?php
			if ($VCLINICCODE == 'HO' && $canedit)
			{
		?>
				$('input[type=radio][name=VBUYFROM]').filter('[value=OP]').prop('checked', true).change();
				$('input[type=radio][name=VBUYFROM]:not(:checked)').attr('disabled', true);
		<?php
			}
		?>
		
		<?php
			if (App\Http\Controllers\Controller::check_role("HRADM"))
			{
		?>
				$('input[name=IQTYVERIFY]').on('keyup change', function() {
					$('input[name="IQTYREQ"]').val(this.value);
				});
		<?php
			}
		?>
		
		<?php
			if (isset($clinics))
			{
				foreach ($clinics as $key => $val)
				{
		?>
					dataclinic.push({ code: '<?php echo $val['VCLINICCODE'] ?>', name: '<?php echo $val['VCLINICNAME'] ?>' });
		<?php
				}
			}
		?>
		
		<?php
			if (isset($inventory) && ($inventory->BSTATUS == 'C' || $inventory->BSTATUS == 'J' || $inventory->BSTATUS == 'A') && App\Http\Controllers\RoleAccessController::FunctionAccessCheck('P', 'F26'))
			{
		?>
				$('select.pbf-type').on('change', function () {
					if (this.value == "All") {
						tblreqdetail.clear().rows.add(datatblreqdetail).draw();
					} else {
						var valpbf = this.value;
						tblreqdetail.clear().rows.add($.grep(datatblreqdetail, function (e) { return e.PBF == valpbf; })).draw();
					}
					reloadTotal();
				});
		<?php
			}
		?>
	});
	
	function sbmt(act = null) {
		if (($('input[name="VBUYFROM"]:checked').val() == "HO" || ($('input[name="VBUYFROM"]:checked').val() == "OP" && $('input[name="VBUY"]').val() != "")) && datatblreqdetail.length == 0) {
			alert('Please add at least one item');
			return false;
		}
		if (act != null) {
			$('input[name="VSIGN"]').val(act);
		}
	}
	
	function reject(act) {
		$('input[name="VSIGN"]').val(act);
		$("form#form-confirm").submit();
	}
	
	function hide(th) {
		$(th).parent().parent().siblings().val(temp.find(x => x.id === $(th).closest('tr').find('input[name="ILINENO[]"]').val()).val).css('display', 'block').siblings().children().children().css('display', 'none');
	}
	
	function toForm(th) {
		$('#form-addnew').trigger("reset");
		<?php
			if (App\Http\Controllers\Controller::check_role("HRADM"))
			{
		?>
				$('input[name="IQTYREQ"]').removeAttr('required');
		<?php
			}
		?>
		$('#modaladdnew').modal('show');
	}
	
	function reloadDrugs() {
		tbldrug = $("#tbldrug").DataTable({ destroy: true, ajax: { url: "/getdruglookup", type: "POST", headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") }, data: { except: except.join() } }, columns: [ { data: "DRUGS_CODE", name: "DRUGS_CODE" }, { data: "DRUGS_CONTAIN", name: "DRUGS_CONTAIN" }, { data: "DRUGS_BRAND", name: "DRUGS_BRAND" }, { data: "DRUGS_UOM", name: "DRUGS_UOM" }, { data: "PBF_TYPE", name: "PBF_TYPE" }, { data: "DRUGS_VENDOR", name: "DRUGS_VENDOR" }, { data: "DRUGS_PRICE", name: "DRUGS_PRICE" } ] });
	}
	
	function reloadTotal() {
		var total = 0;
		$.each($('tbody td.subtotal'), function( index, value ) {
			total += parseInt($(value).html().replace(/,/g, '').replace('.00', ''));
		});
		$('.total-total').html(new Intl.NumberFormat('en-US', { style: 'currency', currency: 'IDR' }).format(total).replace('IDR ', ''));
	}
	
	function remove(id) {
		swal.fire({
			text: "Do you want to delete the data?",
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Yes",
			cancelButtonText: "No"
		}).then(function (result) {
			if (result.value) {
				except.splice(except.indexOf(id), 1);
				reloadDrugs();
				datatblreqdetail = $.grep(datatblreqdetail, function (e) { return e.VDRUGSCODE != id; });
				tblreqdetail.clear().rows.add(datatblreqdetail).draw();
				reloadTotal();
			}
		});
	}
	
	$(document).on("submit", "[id=form-addnew]", function (e) {
		e.preventDefault();
		var realVal = $('input[name="VDRUGSCODE"]').val().split(" - ")[0];
		except.push(realVal);
		reloadDrugs();
		$('input[name="IQTYREQ"]').prop('required', true);
		var obj = {};
		$.each($('#form-addnew input:not([type=hidden])'), function( index, value ) {
			if (index == 0) {
				obj[$(value).attr('name')] = realVal;
				obj['VCONTAIN'] = $('input[name="VDRUGSCODE"]').val().split(" - ")[1];
				obj['VBRAND'] = $('input[name="VDRUGSCODE"]').val().split(" - ")[2];
			}
			else {
				obj[$(value).attr('name')] = $(value).val();
			}
		});
		obj['NPRICE'] = $('input[name="NPRICE"]').val();
		if (obj.IQTYVERIFY == "") {
			delete obj.IQTYVERIFY;
		}
		datatblreqdetail.push(obj);
		tblreqdetail.row.add(obj).draw();
		reloadTotal();
		$('#modaladdnew').modal('hide');
	});
</script>
@endsection