@extends('layout.app') 
@section('content')
<section class="content">
   	<section class="content-header">
      	<div class="container-fluid">
         	<div class="row mb-2">
         	   	<div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
         	   	<div class="col-sm-6">
         	   		<ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
         	   			<li class="breadcrumb-item"><a href="/account/home">Home</a></li>
         	   			<li class="breadcrumb-item active">Movement</li>
         	   		</ol>
         	   	</div>
         	</div>
      	</div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Inventory Movement
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form id="form-confirm" data-url="/movement/save" method="post">
                     <div class="row">
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group">
                              <label class="control-label col-sm-12">Transaction No :</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
                                 <label>{{ $movement->VTRXNO ?? '' }}</label>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group">
                              <label class="control-label col-sm-12">Date :</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
                                 <label>{{ isset($movement) ? $movement->DTRX->format('d F Y') : \Carbon\Carbon::now()->format('d F Y') }}</label>
                              </div>
                           </div>
                        </div>
                     </div>
					 <div class="row">
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group {{ !isset($movement) ? 'required' : '' }}">
                              <label class="control-label col-sm-12">Type :</label>
                           </div>
                        </div>
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
								@if (!isset($movement))
									<select class="form-control" name="VTYPE" required>
										<option value="">-- Select Type --</option>
										@foreach($types AS $type)
											<option value="{{$type['VSETCODE']}}">{{$type['VSETDESC']}}</option>
										@endforeach
									</select>
								@else
									{{ $types[array_search($movement->VTYPE, array_column($types, "VSETCODE"))]['VSETDESC'] }}
								@endif
                              </div>
                           </div>
                        </div>
                     </div>
					 <div class="row row-req-no" style="visibility: hidden;">
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group {{ !isset($movement) ? 'required' : '' }}">
                              <label class="control-label col-sm-12">Request No :</label>
                           </div>
                        </div>
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
								@if (!isset($movement))
									<div class="input-group">
										<input name="VREQNO" class="form-control readonly" style="background-color: #e9ecef;" type="text" value="{{ $movement->VREQNO ?? '' }}" autocomplete="off">
										<div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myModal">
										   <div class="input-group-text"><i class="fa fa-search"></i></div>
										</div>
									</div>
								@else
									{{ $movement->VREQNO }}
								@endif
                              </div>
                           </div>
                        </div>
                     </div>
					 <div class="row">
						<div class="table-responsive col-lg-12 col-sm-12 form-group">
							<table id="tblreqdetail" border="1" class="display" style="width:100%">
								<thead>
									<tr>
										<th class="text-center" style="width:5%">No</th>
										<th class="text-center">Item Code</th>
										<th class="text-center">Item Name</th>
										<th class="text-center">Brand</th>
										<th class="text-center">UoM</th>
										<th class="text-center">PBF</th>
										<th class="text-center">Qty</th>
										<th class="text-center">Expired Date</th>
									</tr>
								</thead>
								@if (isset($movement))
									<tbody>
										<?php $inc = 1;?>
										@foreach ($drugs as $drug)
											<tr>
												<td>{{ $inc }}</td>
												<td>{{ $drug->VDRUGSCODE }}</td>
												<td>{{ $drug->VCONTAIN }}</td>
												<td>{{ $drug->VBRAND }}</td>
												<td>{{ $drug->VUOM }}</td>
												<td>{{ $drug->PBF }}</td>
												<td>{{ $movement->VTYPE == 'ISS' ? ($drug->IQTY * -1) : $drug->IQTY }}</td>
												<td>{{ isset($drug->DEXPIRED) ? $drug->DEXPIRED->format('d-M-Y') : '' }}</td>
											</tr>
										<?php $inc++; ?>
										@endforeach
									</tbody>
								@endif
							</table>
						</div>
					 </div>
					<div class="row row-add-row" style="visibility: hidden;">
						<div class="col-lg-12 col-sm-12 form-group">
							<button type="button" class="btn-cstm btn-primary btn-sz" onclick="return toForm(this);">Add Row</button>
						</div>
					</div>
					<div class="float-right">
						<div class="col-sm-12">
						  @if (!isset($movement))
							  <button type="submit" class="btn-cstm btn-primary btn-sz" onclick="return sbmt();">Submit</button>
						  @endif
							  <a onclick="history.length > 1 ? history.back() : location.href = document.referrer" class="btn btn-cstm btn-light btn-sz">Close</a>
						</div>
					</div>
                  </form>
               </div>
            </div>
         </div>
      </div>
	  <div class="modal fade in" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-lg modal-content">
			<div class="card mb-4">
				<div class="card-header bg-info">
					<h5 class="card-title text-white" align="center">Request No. List</h5>
					<button type="button" class="close text-white" data-dismiss="modal">×</button>
				</div>
				<div class="card-body p-3">
					<div class="table-responsive">
						<table id="tblreqno" class="display" style="width:100%">
							<thead>
								<tr>
									<th>Request No.</th>
									<th>Request Date</th>
									<th>Request by</th>
								</tr>
							</thead>
						</table>
					</div>
				</div>
			</div>
		</div>
	  </div>
	  <div class="modal fade" id="modaladdnew" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-hidden="true">
		 <div class="modal-dialog modal-md modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body">
				  <form id="form-addnew">
					 <input name="OLDVDRUGSCODE" type="hidden">
					 <div class="container">
						<div class="row">
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									<div class="input-group">
										<input name="VDRUGSCODE" class="form-control readonly" style="background-color: #e9ecef;" type="text" placeholder="Item Code" value="{{ $drug->VDRUGSCODE ?? '' }}" autocomplete="off" required>
										<div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myDrugsModal">
										   <div class="input-group-text"><i class="fa fa-search"></i></div>
										</div>
									</div>
								  </div>
							   </div>
							</div>
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="VCONTAIN" class="form-control" type="text" placeholder="Item Name" readonly>
									 <input name="VBRAND" type="text" style="display: none;">
								  </div>
							   </div>
							</div>
						 </div>
						<div class="row">
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="VUOM" class="form-control" type="text" placeholder="UoM" readonly>
								  </div>
							   </div>
							</div>
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="PBF" class="form-control" type="text" placeholder="PBF" readonly>
								  </div>
							   </div>
							</div>
						 </div>
						<div class="row">
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="IQTY" class="form-control" type="number" placeholder="Qty" required>
								  </div>
							   </div>
							</div>
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <div class="input-group date" id="DEXPIRED" data-target-input="nearest">
										<input type="text" class="form-control datetimepicker-input" name="DEXPIRED" data-target="#DEXPIRED" placeholder="Expired Date">
										<div class="input-group-append" data-target="#DEXPIRED" data-toggle="datetimepicker">
										   <div class="input-group-text"><i class="fa fa-calendar"></i></div>
										</div>
									 </div>
								  </div>
							   </div>
							</div>
						 </div>
						 <br/>
						 <div style="text-align:center;">
							<button type="submit" class="btn-cstm btn-primary btn-sz" onclick="return sbmtmodal();">Save</button>
							<a onclick="$('#modaladdnew').modal('hide');" class="btn-cstm btn-light btn-sz">Close</a>
						</div>
					 </div>
				  </form>
			   </div>
			</div>
		 </div>
	  </div>
	  <div class="modal fade in" id="myDrugsModal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-lg modal-content">
			<div class="card mb-4">
				<div class="card-header bg-info">
					<h5 class="card-title text-white" align="center">Drug List</h5>
					<button type="button" class="close text-white" data-dismiss="modal">×</button>
				</div>
				<div class="card-body p-3">
					<div class="table-responsive">
						<table id="tbldrug" class="display" style="width:100%">
							<thead>
								<tr>
									<th>Item Code</th>
									<th>Item Name</th>
									<th>Brand</th>
									<th>UoM</th>
									<th>PBF</th>
								</tr>
							</thead>
						</table>
					</div>
				</div>
			</div>
		</div>
	  </div>
   	</div>
</section>
<script>
	$(".readonly").on('keydown paste', function(e) {
        e.preventDefault();
    });
	
	var table, tblreqdetail, tbldrug, except = [];
	
	$(document).ready(function() {
		$('#DEXPIRED').datetimepicker({ format: 'DD-MMM-YYYY' });
		
		$('#tblreqno').on('dblclick', 'tbody tr', function () {
			var data = table.row(this).data();
			$('input[name="VREQNO"]').val(data['VREQNO']);
			tblreqdetail = $("#tblreqdetail").DataTable({ destroy: true, columnDefs: [ { orderable: false, className: 'select-checkbox', targets: 0 } ], select: { style: 'multi', selector: 'td:first-child' }, order: [[ 1, 'asc' ]], ajax: { url: "getreqdetail/" + data['VREQNO'] + "/" + $('select[name="VTYPE"]').val(), type: "GET" }, columns: [ { data: null, defaultContent: '' }, { data: "VDRUGSCODE", name: "VDRUGSCODE" }, { data: "VCONTAIN", name: "VCONTAIN" }, { data: "VBRAND", name: "VBRAND" }, { data: "VUOM", name: "VUOM" }, { data: "PBF", name: "PBF" }, { data: "IQTYVERIFY", name: "IQTYVERIFY" }, { data: "DEXPIRED", defaultContent: '' } ] });
			$(this).closest('.card').find('button').trigger('click');
		});
		
		$('#tbldrug').on('dblclick', 'tbody tr', function () {
			var data = tbldrug.row(this).data();
			$('input[name="VDRUGSCODE"]').val(data['DRUGS_CODE']);
			$('input[name="VCONTAIN"]').val(data['DRUGS_CONTAIN']);
			$('input[name="VUOM"]').val(data['DRUGS_UOM']);
			$('input[name="PBF"]').val(data['PBF_TYPE']);
			$('input[name="VBRAND"]').val(data['DRUGS_BRAND']);
			$(this).closest('.card').find('button').trigger('click');
		});
		
		$('select[name="VTYPE"]').change(function() {
			if (this.value != '' && this.value != 'ADJ') {
				$('.row-req-no').css('visibility', 'visible');
				table = $("#tblreqno").DataTable({ destroy: true, ajax: { url: '/getreqnolookup/' + $(this).val(), type: "GET" }, columns: [ { data: "VREQNO", name: "VREQNO" }, { data: "DREQ", name: "DREQ" }, { data: "VCLINICNAME", name: "VCLINICNAME" } ] });
			} else {
				$('.row-req-no').css('visibility', 'hidden');
			}
			if (this.value == 'ADJ') {
				reloadDrugs();
				$('.row-add-row').css('visibility', 'visible');
			} else {
				$('.row-add-row').css('visibility', 'hidden');
			}
			$('input[name="VREQNO"]').val('');
			if ($.fn.DataTable.isDataTable('#tblreqdetail')) {
				$('#tblreqdetail').empty();
				tblreqdetail.destroy();
			} else {
				$('#tblreqdetail tbody').empty();
			}
			$('input[name="VREQNO"]').prop('required', this.value != '' && this.value != 'ADJ');
		});
		
		$('#tblreqdetail').on('click', 'tbody td.select-checkbox', function () {
			if ($(this).closest('tr').hasClass("selected")) {
				$(this).find('input').remove();
				$($(this).siblings()[5]).html(tblreqdetail.row(this).data().IQTYVERIFY);
				$($(this).siblings()[6]).html(tblreqdetail.row(this).data().DEXPIRED ?? '');
			} else {
				$(this).append('<input name="VDRUGSCODE[]" type="hidden" value="' + tblreqdetail.row(this).data().VDRUGSCODE + '">');
				$($(this).siblings()[5]).append('<input name="IQTY[]" type="hidden" value="' + ($('select[name="VTYPE"]').val() == 'RCV' ? '' : '-') + tblreqdetail.row(this).data().IQTYVERIFY + '">');
				if ($('select[name="VTYPE"]').val() == 'ISS' || tblreqdetail.row(this).data().DEXPIRED != null) {
					$($(this).siblings()[6]).append('<input name="DEXPIRED[]" type="hidden" value="' + tblreqdetail.row(this).data().DEXPIRED + '">');
				}
				if ($('select[name="VTYPE"]').val() == 'RCV' && tblreqdetail.row(this).data().DEXPIRED == null) {
					var genid = makeid(8);
					$($(this).siblings()[6]).html('<div class="input-group date" id="' + genid + '" data-target-input="nearest"><div class="input-group-append" data-target="#' + genid + '" data-toggle="datetimepicker"></div></div><input type="date" class="form-control input-sm" name="DEXPIRED[]" data-target="#' + genid + '" placeholder="DD-MM-YYYY" required></div>');
					$('#' + genid).datetimepicker({ format: 'DD-MMM-YYYY' });
				}
			}
		});
		
		$('input[name="IQTY"]').change(function() {
			$('input[name="DEXPIRED"]').prop('required', parseInt($('input[name="IQTY"]').val()) > 0);
		});
		
		<?php
			if (isset($movement) && $movement->VTYPE != 'ADJ')
			{
		?>
				$('.row-req-no').css('visibility', 'visible');
		<?php
			}
		?>
	});
	
	function sbmt() {
		if ($('input[name="VREQNO"]').val() != "" && $('select[name="VTYPE"]').val() != "" && $('select[name="VTYPE"]').val() != "ADJ" && (!$.fn.DataTable.isDataTable('#tblreqdetail') || tblreqdetail.rows('.selected').data().length == 0)) {
			alert('Please select at least one item');
			return false;
		}
		if ($('select[name="VTYPE"]').val() == "ADJ" && $('#tblreqdetail tbody tr').length == 0) {
			alert('Please add at least one item');
			return false;
		}
	}
	
	function sbmtmodal() {
		if ($('input[name="VDRUGSCODE"]').val() != "" && $('input[name="IQTY"]').val() == "0") {
			alert('Qty cannot be 0');
			return false;
		}
	}
	
	function makeid(length) {
		var result           = '';
		var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
		var charactersLength = characters.length;
		for ( var i = 0; i < length; i++ ) {
			result += characters.charAt(Math.floor(Math.random() * charactersLength));
		}
		return result;
	}
	
	function toForm(th, id) {
		$('#form-addnew').trigger("reset");
		$('input[name="OLDVDRUGSCODE"]').val('');
		if (id !== undefined) {
			$.each($(th).closest('tr').find('td'), function( index, value ) {
				$('input[name="' + $(value).data('value') + '"]').val($(value).text());
			});
			$('input[name="OLDVDRUGSCODE"]').val(id);
		}
		$('#modaladdnew').modal('show');
	}
	
	function reloadDrugs() {
		tbldrug = $("#tbldrug").DataTable({ destroy: true, ajax: { url: "/getdruglookup", type: "POST", headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") }, data: { except: except.join() } }, columns: [ { data: "DRUGS_CODE", name: "DRUGS_CODE" }, { data: "DRUGS_CONTAIN", name: "DRUGS_CONTAIN" }, { data: "DRUGS_BRAND", name: "DRUGS_BRAND" }, { data: "DRUGS_UOM", name: "DRUGS_UOM" }, { data: "PBF_TYPE", name: "PBF_TYPE" } ] });
	}
	
	function remove(th, id) {
		swal.fire({
			text: "Do you want to delete the data?",
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Yes",
			cancelButtonText: "No"
		}).then(function (result) {
			if (result.value) {
				except.splice(except.indexOf(id), 1);
				reloadDrugs();
				$(th).closest('tr').remove();
			}
		});
	}
	
	$(document).on("submit", "[id=form-addnew]", function (e) {
		e.preventDefault();
		if ($('#tblreqdetail tr:has(td input[name="VDRUGSCODE[]"][value="' + $('input[name="OLDVDRUGSCODE"]').val() + '"])').length > 0) {
			except.splice(except.indexOf($('input[name="OLDVDRUGSCODE"]').val()), 1);
			$('#tblreqdetail tr:has(td input[value="' + $('input[name="OLDVDRUGSCODE"]').val() + '"])').remove();
		}
		except.push($('input[name="VDRUGSCODE"]').val());
		reloadDrugs();
		var td = '<td><button onClick="remove(this, \'' + $('input[name="VDRUGSCODE"]').val() + '\')" type="button" class="btn btn-link btn-sm"><i class="fas fa-times"></i></button></td>';
		$.each($('#form-addnew input:not([type=hidden])'), function( index, value ) {
			if (index == 0) {
				td += '<td data-value="' + $(value).attr('name') + '"><button type="button" class="btn btn-link btn-sm" onclick="return toForm(this, \'' + $(value).val() + '\');">' + $(value).val() + '</button><input name="' + $(value).attr('name') + '[]" type="hidden" value="' + $(value).val() + '"></td>';
			} else if ($(value).attr('name') == 'DEXPIRED') {
				td += '<td data-value="' + $(value).attr('name') + '">' + $(value).val() + '<input name="' + $(value).attr('name') + '[]" type="hidden" value="' + $(value).val() + '"></td>';
			}
			else {
				if ($(value).attr('required') == undefined) {
					td += '<td data-value="' + $(value).attr('name') + '">' + $(value).val() + '</td>';
				} else {
					td += '<td data-value="' + $(value).attr('name') + '">' + $(value).val() + '<input name="' + $(value).attr('name') + '[]" type="hidden" value="' + $(value).val() + '"></td>';
				}
			}
		});
		if ($('#tblreqdetail tbody').length == 0) {
			$('#tblreqdetail').append('<tbody><tr>' + td + '</tr></tbody>');
		} else {
			$('#tblreqdetail tbody').append('<tr>' + td + '</tr>');
		}
		$('#modaladdnew').modal('hide');
	});
</script>
@endsection