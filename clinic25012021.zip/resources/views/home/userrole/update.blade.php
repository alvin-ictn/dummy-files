@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Edit User Role</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Edit Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/userrole/update" id="form-edit">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">User Name</label>
                              <div class="col-sm-4">
							         	<input name="VUSRNAME" value="{{$userrole->VUSRID}}{{(isset($mstclinicstaffs->VNAME) && $mstclinicstaffs->VNAME != '') ? ' - '.$mstclinicstaffs->VNAME : ((isset($mstemployees->VNAME) && $mstemployees->VNAME != '') ? ' - '.$mstemployees->VNAME : '')}}" class="form-control" type="text" readonly>
                                 <input name="VUSRID" placeholder="User ID" value="{{$userrole->VUSRID}}" class="form-control" type="hidden" readonly>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Role Name</label>
                              <div class="col-sm-4">
							         	<input name="VROLENAME" value="{{$userrole->VROLEID}}{{isset($vw_getrole->ROLEDESC) && $vw_getrole->ROLEDESC != '' ?' - '.$vw_getrole->ROLEDESC:''}}" class="form-control" type="text" readonly>
                                 <input name="VROLEID" placeholder="Role ID" value="{{$userrole->VROLEID}}" class="form-control" type="hidden" readonly>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Status</label>
                              <div class="col-sm-4">
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a1" value="1" {{ ($userrole->BACTIVE==="1")? "checked" : "" }}>
                                    <label class="form-check-label" for="a1">Active</label>
                                 </div>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a2" value="0" {{ ($userrole->BACTIVE==="0")? "checked" : "" }}>
                                    <label class="form-check-label" for="a2">Inactive</label>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="form-group row">
                           <div class="col-md-12">
                              <div class="float-right">
                                 <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                 <a href="/account/userrole" class="btn btn-cstm btn-light btn-sz">Close</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
@endsection
