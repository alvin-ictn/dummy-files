@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Add User Role</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Add New Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/adduserrole/insert" id="form-confirm">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">User Name</label>
                              <div class="col-sm-4">
							            <div class="form-group">
							         	   <div class="col-sm-12">
							         		   <div class="input-group">
							   			         <input name="VUSRNAME" class="form-control" type="text" readonly>
                                          <input name="VUSRID"class="form-control" type="hidden" readonly>
							   			         <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myModalUser">
							   			            <div class="input-group-text"><i class="fa fa-search"></i></div>
							   			         </div>
							         		   </div>
							         	   </div>
							            </div>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-md-2">Role Name</label>
                              <div class="col-sm-4">
							            <div class="form-group">
							         	   <div class="col-sm-12">
							         		   <div class="input-group">
							   			         <input name="VROLENAME" class="form-control" type="text" readonly>
                                          <input name="VROLEID"class="form-control" type="hidden" readonly>
							   			         <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myModalRole">
							   			            <div class="input-group-text"><i class="fa fa-search"></i></div>
							   			         </div>
							         		   </div>
							         	   </div>
							            </div>
                              </div>
                           </div>
                           <div class="form-group row">
                              <div class="col-md-12">
                                 <div class="float-right">
                                    <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Add</button>
                                    <a href="/account/userrole" class="btn btn-cstm btn-light btn-sz">Close</a>
                                 </div>
                              </div>
                           </div>
                        </div>
						   </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- User List -->
   <div class="modal fade in" id="myModalUser" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-content">
         <div class="card mb-4">
            <div class="card-header bg-info">
               <h5 class="card-title text-white" align="center">User List</h5>
               <button type="button" class="close text-white" data-dismiss="modal">×</button>
            </div>
            <div class="card-body p-3">
               <div id="dvData" class="table-responsive">
                  <table id="tblusername" class="display" style="width:100%">
                     <thead>
                        <tr>
                           <th>
                              User ID
                           </th>
                           <th>
                              Name
                           </th>
                        </tr>
                     </thead>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- Role List -->
   <div class="modal fade in" id="myModalRole" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-content">
         <div class="card mb-4">
            <div class="card-header bg-info">
               <h5 class="card-title text-white" align="center">Role List</h5>
               <button type="button" class="close text-white" data-dismiss="modal">×</button>
            </div>
            <div class="card-body p-3">
               <div id="dvData" class="table-responsive">
                  <table id="tblrolename" class="display" style="width:100%">
                     <thead>
                        <tr>
                           <th>
                              Role ID
                           </th>
                           <th>
                              Role Name
                           </th>
                        </tr>
                     </thead>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>

<script>
	$(document).ready(function() {
      //====User List table
		var table_user_name = $("#tblusername").DataTable({ 
         pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
         ajax: { url: '/userrole/getusernamelookup', type: "GET", }, 
         columns: [ 
            { data: "VUSRID" }, 
            { data: "VNAME" } 
         ] 
      });
      $('#tblusername tbody').on('dblclick', 'tr', function () {  // Select with double click
			var data = table_user_name.row(this).data();
			$('input[name="VUSRNAME"]').val(data['VUSRID'] + ' - ' + data['VNAME']);   // fill field with "id - name" of user
			$('input[name="VUSRID"]').val(data['VUSRID']);                             // save "user id" in hidden input 
			$(this).closest('.card').find('button').trigger('click');
      });
      
      //====Role List table
      var table_role_name = $("#tblrolename").DataTable({ 
         pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
         ajax: { url: '/userrole/getrolenamelookup', type: "GET", }, 
         columns: [ 
            { data: "ROLEID" }, 
            { data: "ROLEDESC" } 
         ] 
      });
      $('#tblrolename tbody').on('dblclick', 'tr', function () {  // Select with double click
			var data = table_role_name.row(this).data();
			$('input[name="VROLENAME"]').val(data['ROLEID'] + ' - ' + data['ROLEDESC']);  // fill field with "id - name" of role
			$('input[name="VROLEID"]').val(data['ROLEID']);                               // save "role id" in hidden input 
			$(this).closest('.card').find('button').trigger('click');
		});
	});
   
</script>
@endsection
