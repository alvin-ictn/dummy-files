@extends('layout.app') @section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-12">
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Permission Setting
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form id="form-confirm" data-url="/updatepermission/update" class="needs-validation" method="post" novalidate>
					<div class="row">
						<div class="col-lg-1 col-md-12">
						   <div class="form-group">
							  <label class="control-label col-md-12">Group</label>
						   </div>
						</div>
						<div class="col-lg-3 col-md-12">
						   <div class="form-group">
							  <div class="col-md-12">
								<select class="form-control" name="group">
                                    <option value="-1">-- Select Group --</option>
                                    @foreach($groups AS $key => $value)
										<option value="{{$key}}">{{$value}}</option>
                                    @endforeach                                 
								</select>
							  </div>
						   </div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-12 col-md-12 form-group">
						  <table border="1" width="100%">
							<thead>
							  <tr>
								<th>Menu</th>
								<th>View</th>
								<th>Create</th>
								<th>Update</th>
								<th>Delete/Cancel</th>
								<th>Print</th>
							  </tr>
							</thead>
							<tbody>
								@foreach ($menus as $menu)
									<tr>
										<td>{{ $menu['value'] }}</td>
										<td>@if (in_array("V", $menu['access'])) <input type="checkbox" name="{{ $menu['key'] }}[]" value="V"> @endif</td>
										<td>@if (in_array("C", $menu['access'])) <input type="checkbox" name="{{ $menu['key'] }}[]" value="C"> @endif</td>
										<td>@if (in_array("U", $menu['access'])) <input type="checkbox" name="{{ $menu['key'] }}[]" value="U"> @endif</td>
										<td>@if (in_array("D/C", $menu['access'])) <input type="checkbox" name="{{ $menu['key'] }}[]" value="D/C"> @endif</td>
										<td>@if (in_array("P", $menu['access'])) <input type="checkbox" name="{{ $menu['key'] }}[]" value="P"> @endif</td>
									  </tr>
								@endforeach
							</tbody>
						  </table>
						</div>
					 </div>
                     <div>
                        <button type="submit" class="btn btn-primary btn-lg" disabled>Save</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<script>
  $(document).on("change", "[name^=group]", function (e, f) {
	  $.ajax({
		  url: "/account/group/" + $(this).val(),
		  type: "GET",
		  headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
		  success: function (data) {
			$('input[type="checkbox"]').prop('checked', false);
			$.each(data, function( i, v ) {
				$.each(v['access'], function( ind, val ) {
					$('input[name="' + v.key + '[]"][value="' + val + '"]').prop('checked', true);
				});
			});
			validate();
		  }
	  });
  });
  
  $(document).on("change", "[type^=checkbox]", function (e, f) {
	  validate();
  });
  
  function validate()
  {
	  if ($('select[name="group"]').val() != "-1" && $('input[type="checkbox"]:checked').length > 0)
	  {
		  $('button:contains("Save")').prop('disabled', false);
	  }
	  else
	  {
		  $('button:contains("Save")').prop('disabled', true);
	  }
  }
</script>
@endsection