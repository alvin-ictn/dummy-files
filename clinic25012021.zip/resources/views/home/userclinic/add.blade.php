@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Add User Clinic</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Add New Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/adduserclinic/insert" id="form-confirm">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">User Name</label>
                              <div class="col-sm-4">
                                 <div class="input-group">
                                    <input name="USER" placeholder="User Name" class="form-control" type="text" readonly>
                                    <input name="VUSRID" class="form-control" type="hidden" readonly>
                                    <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myUser">
                                       <div class="input-group-text"><i class="fa fa-search"></i></div>
                                    </div>
                                 </div>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Clinic Name</label>
                              <div class="col-sm-4">
                                 <div class="input-group">
                                    <input name="CLINIC" placeholder="Clinic Name" class="form-control" type="text" readonly>
                                    <input name="VCLINICCODE" class="form-control" type="hidden" readonly>
                                    <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myClinic">
                                       <div class="input-group-text"><i class="fa fa-search"></i></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="form-group row">
                              <div class="col-md-12">
                                 <div class="float-right">
                                    <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                    <a href="/account/userclinic" class="btn btn-cstm btn-light btn-sz">Close</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade in" id="myUser" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-lg modal-content">
            <div class="card mb-4">
               <div class="card-header bg-info">
                  <h5 class="card-title text-white" align="center">User Name</h5>
                  <button type="button" class="close text-white" data-dismiss="modal">×</button>
               </div>
               <div class="card-body p-3">
                  <div id="dvData" class="table-responsive">
                     <table id="tbluser" class="display" style="width:100%">
                        <thead>
                           <tr>
                              <th>
                                 User ID
                              </th>
                              <th>
                                 User Name
                              </th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade in" id="myClinic" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-lg modal-content">
            <div class="card mb-4">
               <div class="card-header bg-info">
                  <h5 class="card-title text-white" align="center">Clinic Name List</h5>
                  <button type="button" class="close text-white" data-dismiss="modal">×</button>
               </div>
               <div class="card-body p-3">
                  <div id="dvData" class="table-responsive">
                     <table id="tblclinic" class="display" style="width:100%">
                        <thead>
                           <tr>
                              <th>
                                 Clinic Code
                              </th>
                              <th>
                                 Clinic Name
                              </th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<script>
   $(document).ready(function() {
		var table = $("#tbluser").DataTable({ pagingType: $(window).width() < 768 ? "simple" : "simple_numbers", ajax: { url: '/getcliniclookup', type: "GET", }, columns: [ { data: "VUSRID", name: "VUSRID" }, { data: "VNAME", name: "VNAME" } ] });
   	$('#tbluser tbody').on('dblclick', 'tr', function () {
   		var data = table.row(this).data();
   		$('input[name="USER"]').val(data['VUSRID'] + ' - ' + data['VNAME']);
   		$('input[name="VUSRID"]').val(data['VUSRID']);
   		$(this).closest('.card').find('button').trigger('click');
   	});
	});
	
   $(document).ready(function() {
		var table = $("#tblclinic").DataTable({ pagingType: $(window).width() < 768 ? "simple" : "simple_numbers", ajax: { url: '/getclinic2lookup', type: "GET", }, columns: [ { data: "VCLINICCODE", name: "VCLINICCODE" }, { data: "VCLINICNAME", name: "VCLINICNAME" } ] });
   	$('#tblclinic tbody').on('dblclick', 'tr', function () {
   		var data = table.row(this).data();
   		$('input[name="CLINIC"]').val(data['VCLINICCODE'] + ' - ' + data['VCLINICNAME']);
   		$('input[name="VCLINICCODE"]').val(data['VCLINICCODE']);
   		$(this).closest('.card').find('button').trigger('click');
   	});
   });
</script>
@endsection