@extends('layout.app') @section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-12">
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     My Profile
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form id="form-confirm" data-url="/updateprofile/update" class="needs-validation" method="post" novalidate>
					@if (Session::get('typeuser') == "E")
						 <div class="row">
							<div class="col-lg-2 col-md-12">
							   <div class="form-group">
								  <label class="control-label col-md-12">Employee SAP ID</label>
							   </div>
							</div>
							<div class="col-lg-4 col-md-12">
							   <div class="form-group">
								  <div class="col-md-12">
									 <input class="form-control" type="text" value="{{ $user->VEMPSAPID }}" disabled>
								  </div>
							   </div>
							</div>
						 </div>
					@endif
                     <div class="row">
                        <div class="col-lg-2 col-md-12">
                           <div class="form-group">
                              <label class="control-label col-md-12">Name</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
                           <div class="form-group">
                              <div class="col-md-12">
                                 <input class="form-control" type="text" value="{{ $user->VNAME }}" disabled>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-2 col-md-12">
                           <div class="form-group">
                              <label class="control-label col-md-12">User ID</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
                           <div class="form-group">
                              <div class="col-md-12">
                                 <input name="VUSRID" class="form-control" type="text" value="{{ $user->VUSRID }}" required readonly>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-lg-2 col-md-12">
                           <div class="form-group">
                              <label class="control-label col-md-12">Authentication Type</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
                           <div class="form-group">
                              <div class="col-md-12">
								<div class="form-check form-check-inline">
								   <input class="form-check-input" name="VUSRFLAG" type="radio" value="AD" onchange="FieldAuthType()" {{ $user->VUSRFLAG == 'AD' ? 'checked' : '' }}>
								   <label class="form-check-label">AD</label>
								</div>
								<div class="form-check form-check-inline">
								   <input class="form-check-input" name="VUSRFLAG" type="radio" value="NAD" onchange="FieldAuthType()" {{ $user->VUSRFLAG == 'NAD' ? 'checked' : '' }}>
								   <label class="form-check-label">Non AD</label>
								</div>
                              </div>
                           </div>
                        </div>
						@if (Session::get('typeuser') == "E")
							<div class="col-lg-2 col-md-12">
							   <div class="form-group">
								  <label class="control-label col-md-12">User Type</label>
							   </div>
							</div>
							<div class="col-lg-4 col-md-12">
							   <div class="form-group">
								  <div class="col-md-12">
									 <input class="form-control" type="text" value="{{ $user->VTYPEUSR }}" disabled>
								  </div>
							   </div>
							</div>
						@elseif (Session::get('typeuser') == "NE")
							<div class="col-lg-2 col-md-12">
							   <div class="form-group">
								  <label class="control-label col-md-12">ID Card</label>
							   </div>
							</div>
							<div class="col-lg-4 col-md-12">
							   <div class="form-group">
								  <div class="col-md-12">
									 <input name="VIDCARDNO" class="form-control" type="text" value="{{ $user->VIDCARDNO }}">
								  </div>
							   </div>
							</div>
						@endif
                     </div>
                     <div class="row">
                        <div class="col-lg-2 col-md-12">
                           <div class="form-group">
                              <label class="control-label col-md-12">Email Address</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
                           <div class="form-group">
                              <div class="col-md-12">
                                 <input name="VMAIL" class="form-control" type="email" value="{{ $user->VMAIL }}">
                              </div>
                           </div>
                        </div>
						<div class="col-lg-2 col-md-12">
						   <div class="form-group">
							  <label class="control-label col-md-12">Phone No.</label>
						   </div>
						</div>
						<div class="col-lg-4 col-md-12">
						   <div class="form-group">
							  <div class="col-md-12">
								 <input name="VPHONENO" class="form-control" type="text" value="{{ $user->VPHONENO }}">
							  </div>
						   </div>
						</div>
                     </div>
                     <div class="row">
                        <div class="col-lg-2 col-md-12">
                           <div class="form-group">
                              <label class="control-label col-md-12">Gender</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
                           <div class="form-group">
                              <div class="col-md-12">
								<div class="form-check form-check-inline">
								   <input class="form-check-input" name="VGNDRCODE" type="radio" value="M" {{ $user->VGNDRCODE == 'M' ? 'checked' : '' }} disabled>
								   <label class="form-check-label">Male</label>
								</div>
								<div class="form-check form-check-inline">
								   <input class="form-check-input" name="VGNDRCODE" type="radio" value="F" {{ $user->VGNDRCODE == 'F' ? 'checked' : '' }} disabled>
								   <label class="form-check-label">Female</label>
								</div>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-2 col-md-12">
                           <div class="form-group">
                              <label class="control-label col-md-12">Date of birth</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
							<div class="form-group">
                              <div class="col-md-12">
                                 <div class="input-group date" id="datetimepicker4" data-target-input="nearest">
                                    <input type="text" value="{{ $user->DBIRTH }}" class="form-control datetimepicker-input" name="DBIRTH" data-target="#datetimepicker4" disabled>
                                    <div class="input-group-append" data-target="#datetimepicker4" data-toggle="datetimepicker">
                                       <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
						</div>
                     </div>
					@if (Session::get('typeuser') == "E")
						 <div class="row">
							<div class="col-lg-2 col-md-12">
							   <div class="form-group">
								  <label class="control-label col-md-12">Job Position</label>
							   </div>
							</div>
							<div class="col-lg-4 col-md-12">
							   <div class="form-group">
								  <div class="col-md-12">
									 <input class="form-control" type="text" value="{{ $user->VJOBPOSITION }}" disabled>
								  </div>
							   </div>
							</div>
							<div class="col-lg-2 col-md-12">
							   <div class="form-group">
								  <label class="control-label col-md-12">Job Area</label>
							   </div>
							</div>
							<div class="col-lg-4 col-md-12">
							   <div class="form-group">
								  <div class="col-md-12">
									 <input class="form-control" type="text" value="{{ $user->VJOBAREA }}" disabled>
								  </div>
							   </div>
							</div>
						 </div>
					@endif
                     <div class="row">
                        <div class="col-lg-2 col-md-12">
                           <div class="form-group">
                              <label class="control-label col-md-12">Address</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-md-12">
                           <div class="form-group">
                              <div class="col-md-12">
                                 <textarea class="form-control" name="VADDRESS" rows="5">{{ $user->VADDRESS }}</textarea>
                              </div>
                           </div>
                        </div>
						@if (Session::get('typeuser') == "E")
							<div class="col-lg-6 col-md-12">
							   <div class="row">
								  <div class="col-lg-4 col-md-12">
									<div class="form-group">
									  <label class="control-label col-md-12">Email Dept Head</label>
									</div>
								  </div>
								  <div class="col-lg-8 col-md-12">
									<div class="form-group">
									  <div class="col-md-12">
										<input name="VDEPTHEADMAIL" class="form-control" type="email" value="{{ $user->VDEPTHEADMAIL }}">
									  </div>
									</div>
								  </div>
							   </div>
							   <div class="row">
								  <div class="col-lg-4 col-md-12">
									<div class="form-group">
									  <label class="control-label col-md-12">Personnel Area</label>
									</div>
								  </div>
								  <div class="col-lg-8 col-md-12">
									<div class="form-group">
									  <div class="col-md-12">
										<input class="form-control" type="text" value="{{ $user->VPRSNL }}" disabled>
									  </div>
									</div>
								  </div>
							   </div>
							   <div class="row">
								  <div class="col-lg-4 col-md-12">
									<div class="form-group">
									  <label class="control-label col-md-12">Sub Personnel Area</label>
									</div>
								  </div>
								  <div class="col-lg-8 col-md-12">
									<div class="form-group">
									  <div class="col-md-12">
										<input class="form-control" type="text" value="{{ $user->VSUBPRSNL }}" disabled>
									  </div>
									</div>
								  </div>
							   </div>
							</div>
						@endif
                     </div>
					@if (Session::get('typeuser') == "E")
						 <div class="row">
							<div class="col-lg-2 col-md-12">
							   <div class="form-group">
								  <label class="control-label col-md-12">Cost Center</label>
							   </div>
							</div>
							<div class="col-lg-4 col-md-12">
							   <div class="form-group">
								  <div class="col-md-12">
									 <input class="form-control" type="text" value="{{ $user->VCOSTCNTR }}" disabled>
								  </div>
							   </div>
							</div>
							<div class="col-lg-2 col-md-12">
							   <div class="form-group">
								  <label class="control-label col-md-12">Package</label>
							   </div>
							</div>
							<div class="col-lg-4 col-md-12">
							   <div class="form-group">
								  <div class="col-md-12">
									 <input class="form-control" type="text" value="{{ $user->VPACKAGECODE }}{{ isset($user->VPCKGNAME) && $user->VPCKGNAME != '' ? ' - '.$user->VPCKGNAME : '' }}" disabled>
								  </div>
							   </div>
							</div>
						 </div>
						 <div class="row">
							<div class="col-lg-2 col-md-12">
							   <div class="form-group">
								  <label class="control-label col-md-12">Employment Start Date</label>
							   </div>
							</div>
							<div class="col-lg-4 col-md-12">
							   <div class="form-group">
								  <div class="col-md-12">
									 <input class="form-control" type="text" value="{{ \Carbon\Carbon::parse($user->DHIRE)->format('d-M-Y') }}" disabled>
								  </div>
							   </div>
							</div>
							<div class="col-lg-2 col-md-12">
							   <div class="form-group">
								  <label class="control-label col-md-12">Employment Status</label>
							   </div>
							</div>
							<div class="col-lg-4 col-md-12">
							   <div class="form-group">
								  <div class="col-md-12">
									 <input class="form-control" type="text" value="{{ $user->VEMPTYPE }}" disabled>
								  </div>
							   </div>
							</div>
						 </div>
					@endif
                     <div class="row">
                        <div class="col-lg-2 col-md-12">
                           <div class="form-group">
                              <label class="control-label col-md-12">Status</label>
                           </div>
                        </div>
                        <div class="col-lg-10 col-md-12">
                           <div class="form-group">
                              <div class="col-md-12">
								<div class="form-check form-check-inline">
								   <input class="form-check-input" name="STATUS" type="radio" value="1" {{ $user->STATUS == '1' ? 'checked' : '' }} disabled>
								   <label class="form-check-label">Is Lock</label>
								</div>
								<div class="form-check form-check-inline">
								   <input class="form-check-input" name="STATUS" type="radio" value="2" {{ $user->STATUS == '2' ? 'checked' : '' }} disabled>
								   <label class="form-check-label">Is Active</label>
								</div>
								@if (Session::get('typeuser') == "E")
									<div class="form-check form-check-inline">
									@if(isset($user) && $user->BOTHERS == true)
										<input type="checkbox" name="BOTHERS" checked disabled>
									@else
										<input type="checkbox" name="BOTHERS" disabled>
									@endif
										&nbsp;
									   <label class="form-check-label">Is Allow Create Others</label>
									</div>
								@endif
                              </div>
                           </div>
                        </div>
                     </div>
					@if (Session::get('typeuser') == "E")
						 <div class="row">
							<div class="col-lg-12 col-md-12 form-group">
							  <table border="1" width="100%">
								<thead>
								  <tr>
									<th class="text-center">Name</th>
									<th class="text-center">Family Relationship</th>
									<th class="text-center">Gender</th>
									<th class="text-center">Date of birth</th>
									<th class="text-center">Country of birth</th>
									<th class="text-center">City of birth</th>
									<th class="text-center">BPJS No.</th>
									<th class="text-center">JHT No.</th>

								  </tr>
								</thead>
								<tbody>
									@foreach ($members as $member)
										<tr>
											<td>{{ $member->VRELNAME }}</td>
											<td>{{ $member->VRELATION }}</td>
											<td>{{ $member->VRELGENDER }}</td>
											<td>{{ $member->DRELBIRTH }}</td>
											<td>{{ $member->VRELCTRYBIRTH }}</td>
											<td>{{ $member->VRELCITYBIRTH }}</td>
											<td>{{ $member->VBPJSNO }}</td>
											<td>{{ $member->VJHTNO }}</td>
											
										  </tr>
									@endforeach
								</tbody>
							  </table>
							</div>
						 </div>
					@endif
                     <div class="row">
                        <div class="col-lg-12 col-md-12 form-group">
						  <button type="button" class="btn-cstm btn-primary btn-sz float-right" id="btn-changepassword">Change Password</button>
                        </div>
                     </div>
                     <div>
                        <button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
	  
	  <div class="modal fade" id="modalchangepassword" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-md modal-dialog-centered">
            <div class="modal-content">
               <div class="modal-body">
                  <form id="form-changepassword" method="post" data-url='changepassword'>
                     <div class="container">
						<div class="row">
							<div class="input-group mb-3">
								<input name="old" class="form-control old" type="password" placeholder="old password" required>
								 <div class="input-group-append">
									<div class="input-group-text">
									   <i toggle=".old" class="fa fa-eye toggle-password"></i>
									</div>
									<div class="input-group-text">
									   <i class="fas fa-lock"></i>
									</div>
								 </div>
							</div>
						 </div>
						<div class="row">
							<div class="input-group">
								<input name="new" class="form-control new" type="password" placeholder="new password" required>
								 <div class="input-group-append">
									<div class="input-group-text">
									   <i toggle=".new" class="fa fa-eye toggle-password"></i>
									</div>
									<div class="input-group-text">
									   <i class="fas fa-lock"></i>
									</div>
								 </div>
							</div>
							<div class="row">
								<div class="col-12 ade-input-pw" style="font-size: 0.68rem; visibility: hidden; text-align: center;">
									Password must contain at least {{ $prmchar }} characters, including UPPER/lowercase, symbol, letter and number
								</div>
							</div>
						 </div>
						<div class="row">
							<div class="input-group">
								<input name="confirm" class="form-control confirm" type="password" placeholder="re-type new password" required>
								 <div class="input-group-append">
									<div class="input-group-text">
									   <i toggle=".confirm" class="fa fa-eye toggle-password"></i>
									</div>
									<div class="input-group-text">
									   <i class="fas fa-lock"></i>
									</div>
								 </div>
							</div>
							<div class="row">
								<div class="col-12 ade-input-confirm" style="font-size: 0.68rem; visibility: hidden; text-align: center;">
									The password must be the same!
								</div>
							</div>
						 </div>
						 <div class="row">
							<div class="col-12 ade-error-login" style="color: red; font-size: 0.98rem; visibility: hidden; text-align: center;">error-login</div>
						 </div>
						 <br/>
						 <div style="text-align:center;">
							<button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
							<a onclick="$('#modalchangepassword').modal('hide');" class="btn-cstm btn-light btn-sz">Close</a>
                        </div>
                     </div>
				  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<script>
$(document).ready(function() {
		$('#datetimepicker4').datetimepicker({
            format: 'DD-MMM-YYYY'
		});

		//---- Enable/Disable Fields
		FieldAuthType();
		if($('input[name="VUSRFLAG"]:checked').val() == "AD") $('input[name="VUSRFLAG"]').prop('disabled', true);	// Auth Type
	});

  $(document).on("click", "[id^=btn-changepassword]", function (e) {
	if ($('input[name="VUSRFLAG"]:checked').val() == "NAD")
	{
	   $('#form-changepassword').trigger("reset");
	   $('.old, .new, .confirm').css('border-color', '');
	   $('.ade-error-login, .ade-input-pw, .ade-input-confirm').css('visibility', 'hidden');
	   $.each($(".toggle-password"), function( index, value ) {
			if ($(this).hasClass("fa-eye-slash")) {
				$(this).toggleClass("fa-eye fa-eye-slash");
			}
			var input = $($(this).attr("toggle"));
			if (input.attr("type") == "text") {
				input.attr("type", "password");
			}
	   });
	   $('#modalchangepassword').modal('show');
	}
	else
	{
		Swal.fire({
			icon: "error",
			title: "Oops...",
			text: "You are not allow to change password"
		});
	}
  });
  
  $(document).on("submit", "[id^=form-changepassword]", function (e) {
		if ($('.ade-input-pw').css('visibility') == 'visible' || $('.ade-input-confirm').css('visibility') == 'visible')
		{
			return false;
		}
		e.preventDefault();
	  $.ajax({
		  url: $(this).data("url"),
		  type: "POST",
		  headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
		  dataType: "JSON",
		  data: $("#form-changepassword").serialize(),
		  success: function (data) {
			if(data === ""){
				Swal.fire({
					icon: 'success'
				});
				$("#modalchangepassword").modal("hide");
			}else{
				$('.ade-error-login').html(data);
				$('.ade-error-login').css('visibility', 'visible');
				if (data == 'Incorrect Old Password !')
				{
					$('.old').css('border-color', 'red');
				}
				else
				{
					$('.old').css('border-color', '');
				}
				if (data == 'cannot be use the same password in one year !')
				{
					$('.new').css('border-color', 'red');
					$('.confirm').css('border-color', 'red');
				}
				else
				{
					$('.new').css('border-color', '');
					$('.confirm').css('border-color', '');
				}
			}
		  }
	  });
  });
  
  $(document).on("keyup", "[name=new]", function (e) {
	  var t = $(this).val();
	  if (t.length == 0 || (t.length >= <?php echo $prmchar; ?> && t.match(new RegExp('[A-Z]')) && t.match(new RegExp('[a-z]')) && t.match(new RegExp('[0-9]')) && t.match(new RegExp('[!@#$%^&*()]'))))
	  {
		  $('.ade-input-pw').css('visibility', 'hidden');
	  }
	  else
	  {
		  $('.ade-input-pw').css('visibility', 'visible');
	  }
	  if ($('input[name="confirm"]').val().length != 0)
	  {
		  if (t == $('input[name="confirm"]').val())
		  {
			  $('.ade-input-confirm').css('visibility', 'hidden');
		  }
		  else
		  {
			  $('.ade-input-confirm').css('visibility', 'visible');
		  }
	  }
  });
  
  $(document).on("keyup", "[name=confirm]", function (e) {
	  var t = $(this).val();
	  if (t.length == 0 || $('input[name="new"]').val() == t)
	  {
		  $('.ade-input-confirm').css('visibility', 'hidden');
	  }
	  else
	  {
		  $('.ade-input-confirm').css('visibility', 'visible');
	  }
  });

//==== Enable/Disable Gender & User ID field
function FieldAuthType()
{
	if($('input[name="VUSRFLAG"]:checked').val() == "NAD") 
	{
		// User ID
		$('input[name="VUSRID"]').prop('readonly', true);			
		$('input[name="VUSRID"]').val('{{ $user->VUSRID }}');			
	}
	else{	// AD
		$('input[name="VUSRID"]').prop('readonly', false);	// User ID
	}
}


</script>
@endsection