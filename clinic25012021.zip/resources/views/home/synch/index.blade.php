@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Synchronize</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
	  <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Synchronize
                  </h3>
               </div>

			   
					<div class="card-body">
    	                    &nbsp;
        	                <form action="synch/dosynch">
								<div class="table-responsive">
									<table id="cmsynch" class="table table-bordered table-striped display compact nowrap" style="width:100%">
										<thead>
										<tr>
											<th>Clinic Name</th>
											<th style="text-align:center">Synchronize</th>
											<th>Last Synchronize</th>
										</tr>
										</thead>
									</table>
								</div>
                    	    </form>
			 		</div>
				
			</div>
		</div>
		</div>

   
</section>
<style>
    
</style>
@endsection

