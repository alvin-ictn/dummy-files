@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-12">
               <h1>Master Bank</h1>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header">
                  <h3 class="card-title">
                     <a class="btn btn-primary" href="/backend/addbank" role="button">Add bank</a>
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <table id="cmbank" class="table table-bordered table-striped table-responsive-lg">
                     <thead>
                        <tr>
                           <th>Action</th>
                           <th>Bank Code</th>
                           <th>NAMA BANK</th>
                           <th>ACTIVE</th>
                        </tr>
                     </thead>
                     <tbody>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   </div>
   </div>
</section>
<!-- untuk edit Bank  -->
<!-- Modal -->
<div class="modal fade" id="modalviewbank" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog modal-lg">
   <div class="modal-content">
      <div class="modal-header">
         <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
         <span aria-hidden="true">&times;</span>
         </button>
      </div>
      <div class="modal-body">
         <form  id="form"  method="post">
            <input type="hidden" value="" name="id" />
            <div class="form-body">
               <div class="form-group">
                  <label class="control-label col-md-12">Bank Name</label>
                  <div class="col-md-12">
                     <input name="namabank" placeholder="First Name" class="form-control" type="text">
                     <span class="help-block"></span>
                  </div>
               </div>
               <div class="form-group">
                  <label class="control-label col-md-12">Active Bank</label>
                  <div class="col-md-12">
                     <div class="form-check form-check-inline">
                        <input class="form-check-input" name="bankactive" type="radio" id="a1" value="1" required>
                        <label class="form-check-label" for="a1">Active</label>
                     </div>
                     <div class="form-check form-check-inline">
                        <input class="form-check-input" name="bankactive" type="radio" id="a2" value="0" required>
                        <label class="form-check-label" for="a2">No Active</label>
                     </div>
                  </div>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               <button type="submit" id="btn_update" class="btn btn-primary">Update changes</button>
         </form>
         </div>
      </div>
   </div>
</div>
<!-- untuk add  -->
<!-- Modal -->
<!-- Modal -->
<div class="modal show" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
         </div>
         <div class="modal-body">
            ...
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary">Save changes</button>
         </div>
      </div>
   </div>
</div>
@endsection