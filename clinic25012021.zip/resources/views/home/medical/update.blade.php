@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Edit Medical Kits</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Edit Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/medical/update" id="form-edit">
                     @csrf
                     <input name="regist" type="hidden" value="{{ $medical->VREGISTNO ?? '' }}">
                     <div class="form-body">
                        <div class="form-group">
  
                           <div class="row">
                              <div class="col-lg-6 col-sm-12">
                                 <div class="row">
                                    <div class="col-lg-4 col-sm-12">
                                       <div class="form-group required">
                                          <label for="example-text-input" class="req col-form-label col-sm-12">Material Code</label>
                                       </div>
                                    </div>
                                    <div class="col-lg-8 col-sm-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                                <input name="material" placeholder="Material Code" value="{{$medical->VMTRLCODE}}" class="form-control" type="text" maxlength="20" required>

                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-2 col-sm-12">
                                 <div class="form-group required">
                                    <label class="control-label col-sm-12">Assets No</label>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-sm-12">
                                 <div class="form-group">
                                    <div class="col-sm-12">
                                       <input name="asset" placeholder="Assets No" class="form-control" value="{{$medical->VASSETNO}}" type="text" maxlength="20" required>
                                       <span class="help-block"></span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-lg-6 col-sm-12">
                                 <div class="row">
                                    <div class="col-lg-4 col-sm-12">
                                       <div class="form-group required">
                                          <label for="example-text-input" class="req col-form-label col-sm-12">Medical Kits Name</label>
                                       </div>
                                    </div>
                                    <div class="col-lg-8 col-sm-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                                <input name="kitsname" placeholder="Medical Kits Name" value="{{$medical->VINSTRNAME}}"  class="form-control" type="text" maxlength="100" required>

                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-2 col-sm-12">
                                 <div class="form-group required">
                                    <label class="control-label col-sm-12">Medical Kits Brand</label>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-sm-12">
                                 <div class="form-group">
                                    <div class="col-sm-12">
                                          <input name="kitsbrand" placeholder="Medical Kits Brand" value="{{$medical->VINSTRBRAND}}" class="form-control" type="text" maxlength="100" required>

                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-lg-6 col-sm-12">
                                 <div class="row">
                                    <div class="col-lg-4 col-sm-12">
                                       <div class="form-group required">
                                          <label for="example-text-input" class="req col-form-label col-sm-12">Purchase Date</label>
                                       </div>
                                    </div>
                                    <div class="col-lg-8 col-sm-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <div class="input-group date" id="DPURCHASE" data-target-input="nearest">
                                                   <input type="text" value="{{ isset($medical) && isset($medical->DPURCHASE) ? $medical->DPURCHASE : '' }}" class="form-control datetimepicker-input" name="DPURCHASE" data-target="#DPURCHASE" placeholder="DD-MM-YYYY" required>
                                                <div class="input-group-append" data-target="#DPURCHASE" data-toggle="datetimepicker">
                                                      <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-2 col-sm-12">
                                 <div class="form-group required">
                                    <label class="control-label col-sm-12">Submission Date</label>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-sm-12">
                                 <div class="form-group">
                                    <div class="col-sm-12">
                                       <div class="input-group date" id="DSUBMIT" data-target-input="nearest">
                                             <input type="text" value="{{ isset($medical) && isset($medical->DSUBMIT) ? $medical->DSUBMIT : '' }}" class="form-control datetimepicker-input" name="DSUBMIT" data-target="#DSUBMIT" placeholder="DD-MM-YYYY" required>
                                          <div class="input-group-append" data-target="#DSUBMIT" data-toggle="datetimepicker">
                                             <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-lg-6 col-sm-12">
                                 <div class="row">
                                    <div class="col-lg-4 col-sm-12">
                                       <div class="form-group required">
                                          <label for="example-text-input" class="req col-form-label col-sm-12">Location</label>
                                       </div>
                                    </div>
                                    <div class="col-lg-8 col-sm-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <input name="loc" placeholder="Location" value="{{$medical->VLOCATION}}" class="form-control" type="text" maxlength="20" required>
                                             <span class="help-block"></span>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-2 col-sm-12">
                                 <div class="form-group required">
                                    <label class="control-label col-sm-12">Business Unit</label>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-sm-12">
                                 <div class="form-group">
                                    <div class="col-sm-12">
                                       <select class="form-control" name="business" required>
                                             <option value="">-- Select Business Unit --</option>
                                             <option value="IF" {{ $medical->VBU == "IF" ? 'selected' : '' }}>Indra Fiber</option>
                                             <option value="KF" {{ $medical->VBU == "KF" ? 'selected' : '' }}>Kampar Fiber</option>
                                             <option value="RF" {{ $medical->VBU == "RF" ? 'selected' : '' }}>Riau Fiber</option>
                                             <option value="DF" {{ $medical->VBU == "DF" ? 'selected' : '' }}>Dumai Fiber</option>
                                             <option value="RPL" {{ $medical->VBU == "RPL" ? 'selected' : '' }}>Riau Pulp</option>
                                       </select>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-lg-6 col-sm-12">
                                 <div class="row">
                                    <div class="col-lg-4 col-sm-12">
                                       <div class="form-group required">
                                          <label for="example-text-input" class="req col-form-label col-sm-12">Criteria</label>
                                       </div>
                                    </div>
                                    <div class="col-lg-8 col-sm-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <select class="form-control" name="cryteria" id="cry" required>
                                                <option value="">-- Select Criteria --</option>
                                                <option value="1" {{ $cryteria->CRITERIA == "Calibration Required" ? 'selected' : '' }}>Calibration Required</option>
                                                <option value="0" {{ $cryteria->CRITERIA == "Calibration Not Required" ? 'selected' : '' }}>Calibration Not Required</option>
                                             </select>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-2 col-sm-12">
                                 <div class="form-group required">
                                    <label class="control-label col-sm-12">Medical Kits Status</label>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-sm-12">
                                 <div class="form-group">
                                    <div class="col-sm-12">
                                       <select class="form-control" name="status" id="status" required>
                                          <option value="">-- Select Status --</option>
                                          <option value="1" {{ $status->Status == "Good" ? 'selected' : '' }}>Good</option>
                                          <option value="0" {{ $status->Status == "Damage" ? 'selected' : '' }}>Damage</option> 
                                       </select>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-lg-6 col-sm-12">
                                 <div class="row">
                                    <div class="col-lg-4 col-sm-12">
                                       <div class="form-group required">
                                          <label for="example-text-input" id="label_dcalibrate" class="req col-form-label col-sm-12">Calibrate Date</label>
                                       </div>
                                    </div>
                                    <div class="col-lg-8 col-sm-12">
                                       <div class="form-group">
                                          
                                          <div class="col-md-12">
                                             <div class="input-group date" id="DCALIBRATE" data-target-input="nearest">
                                                   <input type="text" value="{{ isset($medical) && isset($medical->DCALIBRATE) ? $medical->DCALIBRATE : '' }}" class="form-control datetimepicker-input" name="DCALIBRATE" data-target="#DCALIBRATE" placeholder="DD-MM-YYYY" required>
                                                <div class="input-group-append" data-target="#DCALIBRATE" data-toggle="datetimepicker">
                                                   <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group  required">
                                          <label class="control-label col-sm-12">Clinic Name</label>
                                       </div>
                                    </div>
                                    <div class="col-lg-8 col-sm-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                             <div class="input-group">
                                                   <input name="CLINIC" placeholder="Clinic Name" class="form-control" value="{{$medical->VCLINICCODE}}{{isset($medical->VCLINICNAME) && $medical->VCLINICNAME != '' ?' - '.$medical->VCLINICNAME:''}}" type="text" readonly> <span class="help-block" required></span>
                                                   <input name="VCLINICCODE" value="{{$medical->VCLINICCODE }}" class="form-control" type="hidden" readonly> <span class="help-block" required></span>
                                                <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myClinic">
                                                   <div class="input-group-text"><i class="fa fa-search"></i></div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-lg-2 col-sm-12">
                                 <div class="form-group required">
                                    <label class="control-label col-sm-12">Remarks</label>
                                 </div>
                              </div>
                              <div class="col-lg-4 col-sm-12">
                                 <div class="form-group">
                                    <div class="col-sm-12">
                                          <textarea name="remarks" placeholder="Remarks" class="form-control" cols="30" rows="5" type="text">{{$medical->VREMARKS}}</textarea>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="form-group row">
                           <div class="col-md-12">
                              <div class="float-right">
                                 <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                 <a href="/account/medical" class="btn btn-cstm btn-light btn-sz">Close</a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Material Code</label>
                              <div class="col-sm-4">
                                 <input name="material" placeholder="Material Code" value="{{$medical->VMTRLCODE}}" class="form-control" type="text" maxlength="20">
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Assets No</label>
                              <div class="col-sm-4">
                                 <input name="asset" placeholder="Assets No" value="{{$medical->VASSETNO}}" class="form-control" type="text" maxlength="20">
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Medical Kits Name</label>
                              <div class="col-sm-4">
                                 <input name="kitsname" placeholder="Medical Kits Name" value="{{$medical->VINSTRNAME}}" class="form-control" type="text" maxlength="100">
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Medical Kits Brand</label>
                              <div class="col-sm-4">
                                 <input name="kitsbrand" placeholder="Medical Kits Brand" value="{{$medical->VINSTRBRAND}}" class="form-control" type="text" maxlength="100">
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Purchase Date</label>
                              <div class="col-sm-4">
                                 <div class="input-group date" id="DPURCHASE" data-target-input="nearest">
                                    <input type="text" value="{{ isset($medical) && isset($medical->DPURCHASE) ? $medical->DPURCHASE : '' }}" class="form-control datetimepicker-input" name="DPURCHASE" data-target="#DPURCHASE" placeholder="DD-MM-YYYY" required>
                                    <div class="input-group-append" data-target="#DPURCHASE" data-toggle="datetimepicker">
                                       <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                    </div>
                                 </div>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Submission Date</label>
                              <div class="col-sm-4">
                                 <div class="input-group date" id="DSUBMIT" data-target-input="nearest">
                                    <input type="text" value="{{ isset($medical) && isset($medical->DSUBMIT) ? $medical->DSUBMIT : '' }}" class="form-control datetimepicker-input" name="DSUBMIT" data-target="#DSUBMIT" placeholder="DD-MM-YYYY" required>
                                    <div class="input-group-append" data-target="#DSUBMIT" data-toggle="datetimepicker">
                                       <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Location</label>
                              <div class="col-sm-4">
                                 <input name="loc" placeholder="Location" value="{{$medical->VLOCATION}}" class="form-control" type="text" maxlength="20">
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Business Unit</label>
                              <div class="col-sm-4">
                                 <select class="form-control" name="business" required>
                                    <option value="">-- Select Business Unit --</option>
                                    <option value="IF" {{ $medical->VBU == "IF" ? 'selected' : '' }}>Indra Fiber</option>
                                    <option value="KF" {{ $medical->VBU == "KF" ? 'selected' : '' }}>Kampar Fiber</option>
                                    <option value="RF" {{ $medical->VBU == "RF" ? 'selected' : '' }}>Riau Fiber</option>
                                    <option value="DF" {{ $medical->VBU == "DF" ? 'selected' : '' }}>Dumai Fiber</option>
                                    <option value="RPL" {{ $medical->VBU == "RPL" ? 'selected' : '' }}>Riau Pulp</option>
                                 </select>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" id="label_dcalibrate" class="req col-form-label col-sm-2">Calibrate Date</label>
                              <div class="col-sm-4">
                                 <div class="input-group date" id="DCALIBRATE" data-target-input="nearest">
                                    <input type="text" value="{{ isset($medical) && isset($medical->DCALIBRATE) ? $medical->DCALIBRATE : '' }}" class="form-control datetimepicker-input" name="DCALIBRATE" data-target="#DCALIBRATE" placeholder="DD-MM-YYYY" required>
                                    <div class="input-group-append" data-target="#DCALIBRATE" data-toggle="datetimepicker">
                                       <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                    </div>
                                 </div>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Medical Kits Status</label>
                              <div class="col-sm-4">
                                 <select class="form-control" name="status" id="status" required>
                                    <option value="">-- Select Status --</option>
                                    <option value="1" {{ $status->Status == "Good" ? 'selected' : '' }}>Good</option>
                                    <option value="0" {{ $status->Status == "Damage" ? 'selected' : '' }}>Damage</option>                    
                                 </select>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Quantity</label>
                              <div class="col-sm-4">
                                 <input name="quantity" placeholder="Quantity" value="{{$medical->NTOTAL}}"  class="form-control" type="text" onkeypress="return (event.charCode !=8 && event.charCode ==0 || ( event.charCode == 46 || (event.charCode >= 48 && event.charCode <= 57)))">
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Criteria</label>
                              <div class="col-sm-4">
                                 <select class="form-control" name="cry" id="cry" required>
                                    <option value="">-- Select Criteria --</option>
                                    <option value="1" {{ $cryteria->CRITERIA == "Calibration Required" ? 'selected' : '' }}>Calibration Required</option>
                                    <option value="0" {{ $cryteria->CRITERIA == "Calibration Not Required" ? 'selected' : '' }}>Calibration Not Required</option>              
                                 </select>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Clinic Name</label>
                              <div class="col-sm-4">
                                 <div class="input-group">
                                    <input name="CLINIC" placeholder="Clinic Name" class="form-control" value="{{$medical->VCLINICCODE}} - {{$medical->VCLINICNAME}}" type="text" readonly> <span class="help-block" required></span>
                                    <input name="VCLINICCODE" value="{{$medical->VCLINICCODE }}" class="form-control" type="hidden" readonly> <span class="help-block" required></span>
                                    <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myClinic">
                                       <div class="input-group-text"><i class="fa fa-search"></i></div>
                                    </div>
                                 </div>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Status</label>
                              <div class="col-sm-4">
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a1" value="1" {{ ($medical->BSTATUS==="1")? "checked" : "" }}>
                                    <label class="form-check-label" for="a1">Active</label>
                                 </div>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a2" value="0" {{ ($medical->BSTATUS==="0")? "checked" : "" }}>
                                    <label class="form-check-label" for="a2">InActive</label>
                                 </div>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="col-form-label col-sm-2">Remarks</label>
                              <div class="col-sm-4">
                                 <textarea name="remarks" placeholder="Remarks" class="form-control" cols="30" rows="5" type="text">{{$medical->VREMARKS}}</textarea>
                              </div>
                           </div>
                        </div>
                        <div class="form-group row">
                           <div class="col-md-12">
                              <div class="float-right">
                                 <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                 <a href="/account/medical" class="btn btn-cstm btn-light btn-sz">Close</a>
                              </div>
                           </div>
                        </div>
                     </div> -->
                  </form>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade in" id="myClinic" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-lg modal-content">
            <div class="card mb-4">
               <div class="card-header bg-info">
                  <h5 class="card-title text-white" align="center">Clinic Name List</h5>
                  <button type="button" class="close text-white" data-dismiss="modal">×</button>
               </div>
               <div class="card-body p-3">
                  <div id="dvData" class="table-responsive">
                     <table id="tblclinic" class="display" style="width:100%">
                        <thead>
                           <tr>
                              <th>
                                 Clinic Code
                              </th>
                              <th>
                                 Clinic Name
                              </th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<script>
	$(document).ready(function() {
		$('#DPURCHASE, #DSUBMIT, #DCALIBRATE').datetimepicker({
            format: 'DD-MMM-YYYY'
        });
      
      $('#cry').change(function () {
         FieldCalibrate(); // Calibrate & Calibrate Date
	   });
   });

   $(document).ready(function() {
		var table = $("#tblclinic").DataTable({ pagingType: $(window).width() < 768 ? "simple" : "simple_numbers", ajax: { url: '/getclinic2lookup', type: "GET", }, columns: [ { data: "VCLINICCODE", name: "VCLINICCODE" }, { data: "VCLINICNAME", name: "VCLINICNAME" } ] });
   	$('#tblclinic tbody').on('dblclick', 'tr', function () {
   		var data = table.row(this).data();
   		$('input[name="CLINIC"]').val(data['VCLINICCODE'] + ' - ' + data['VCLINICNAME']);
   		$('input[name="VCLINICCODE"]').val(data['VCLINICCODE']);
   		$(this).closest('.card').find('button').trigger('click');
   	});
      
      FieldCalibrate(); // Calibrate & Calibrate Date
   });

   //==== disable/enable Calibrate Date input field depending on Calibrate input field
   function FieldCalibrate()
   {
      if($('#cry').val() == '0') 
      {
         $('#label_dcalibrate').removeClass('req');
         $('input[name="DCALIBRATE"]').attr('disabled', 'disabled').removeAttr('required');
         $('input[name="DCALIBRATE"]').val('');
      }
      else 
      {
         $('#label_dcalibrate').addClass('req');
         $('input[name="DCALIBRATE"]').removeAttr('disabled').attr('required', 'required');
      }
   }

</script>
@endsection