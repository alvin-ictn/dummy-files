@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Master Medical Kits</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Master Medical Kits
                  </h3>
               </div>
               <div class="card-header">
                  <h3 class="row card-title">
                     <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('C', 'F15')) { ?>
                        <a class="btn btn-sz btn-primary" href="medical/add" role="button">Add New</a>
                     <?php } ?>
                     <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('E', 'F15')) { ?>
                        &nbsp;
                        <form action="medical/export_excel" method="POST">
                           @csrf
                           <input type="hidden" value="" name="rn" id="regist">
                           <input type="hidden" value="" name="mc" id="material">
                           <input type="hidden" value="" name="ass" id="assets">
                           <input type="hidden" value="" name="insn" id="instrname">
                           <input type="hidden" value="" name="insb" id="instrbrand">
                           <input type="hidden" value="" name="pd" id="purchdate">
                           <input type="hidden" value="" name="sd" id="submitdate">
                           <input type="hidden" value="" name="ln" id="locatname">
                           <input type="hidden" value="" name="bu" id="busunit">
                           <input type="hidden" value="" name="cd" id="caldate">
                           <input type="hidden" value="" name="sta" id="status">
                           <input type="hidden" value="" name="crit" id="criteria">
                           <input type="hidden" value="" name="ques" id="question">
                           <input type="hidden" value="" name="rmrks" id="remarks">
                           <input type="hidden" value="" name="lastmo" id="lm">
                           <input type="hidden" value="" name="modifiedn" id="modifiedn">
                           <input type="hidden" value="" name="no" id="no">
                           <input type="hidden" value="" name="search" id="search">
                           <button class="btn btn-sz btn-primary" type="submit">Export to Excel</button>
                        </form>   
                     <?php } ?>
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <div class="table-responsive">
                     <table id="cmmedical" class="table table-bordered table-striped display compact nowrap" style="width:100%">
                        <thead>
                           <tr>
                              <th>No</th>
                              <th>Regist Number</th>
                              <th>Material Code</th>
                              <th>Assets No</th>
                              <th>Medical Kits Name</th>
                              <th>Medical Kits Code</th>
                              <th>Purchase Date</th>
                              <th>Submit Date</th>
                              <th>Location Name</th>
                              <th>Business Unit</th>
                              <th>Calibrate Date</th>
                              <th>Status</th>
                              <th>Criteria</th>
                              <th>Quantity</th>
                              <th>Remarks</th>
                              <th>Last Modified Name</th>
                              <th>Last Modified Date</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<style>
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::after{display: none}
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::before{display: none}
</style>
@endsection