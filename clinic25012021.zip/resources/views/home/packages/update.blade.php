@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Edit Packages</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Edit Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/packages/update" id="form-edit">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Packages Code</label>
                              <div class="col-sm-4">
                                 <input name="packcode" placeholder="Packages Code" value="{{$packages->VPCKGCODE}}" class="form-control" type="text" readonly>
                                 <span class="help-block"></span>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Packages Name</label>
                              <div class="col-sm-4">
                                 <input name="packname" placeholder="Packages Name" value="{{$packages->VPCKGNAME}}" class="form-control" type="text" maxlength="50" required>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Status</label>
                              <div class="col-sm-4">
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a1" value="1" {{ ($packages->BACTIVE==="1")? "checked" : "" }}>
                                    <label class="form-check-label" for="a1">Active</label>
                                 </div>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a2" value="0" {{ ($packages->BACTIVE==="0")? "checked" : "" }}>
                                    <label class="form-check-label" for="a2">InActive</label>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-sm-12">
                                 <h5 class="head-h5">
                                    <span>&nbsp; List Items</span>
                                 </h5>
                              </div>
                           </div>
                           <br>
                           <div class="row">
                              <div class="col-sm-12">
                                 <div class="form-check form-check-inline col-sm-2">
                                 <input type="hidden" name="check1" value="0">

                                    <input type="checkbox" id="sign" value="1" name="check" {{ ($packages->BVITALSIGN==="1")? "checked" : "" }}>
                                    <label class="col-form-label col-sm-12">Vital Sign</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                 <input type="hidden" name="check2" value="0">

                                 <input type="checkbox" id="urine" value="2" name="check2" {{ ($packages->BURINE==="1")? "checked" : "" }}>
                                    <label class="col-form-label col-sm-12">Urine</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="hidden" name="check3" value="0">

                                    <input type="checkbox" id="rontgen" value="3" name="check3" {{ ($packages->BRONTGEN==="1")? "checked" : "" }}>
                                    <label class="col-form-label col-sm-12">Rontgen</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="hidden" name="check4" value="0">

                                    <input type="checkbox" id="spiro" value="4" name="check4" {{ ($packages->BSPIRO==="1")? "checked" : "" }}>
                                    <label class="col-form-label col-sm-12">Spiro</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="hidden" name="check5" value="0">

                                    <input type="checkbox" id="ekg" value="5" name="check5" {{ ($packages->BEKG==="1")? "checked" : "" }}>
                                    <label class="col-form-label col-sm-12">EKG</label>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-sm-12">
                                 <div class="form-check-inline col-sm-2">
                                    <input type="hidden" name="check6" value="0">

                                    <input type="checkbox" id="fisik" value="6" name="check6" {{ ($packages->BFISIK==="1")? "checked" : "" }}>
                                    <label class="col-form-label col-sm-12">Fisik</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="hidden" name="check7" value="0">
                                    <input type="checkbox" id="coles" value="7" name="check7" {{ ($packages->BDARAHCHOL==="1")? "checked" : "" }}>
                                    <label class="col-form-label col-sm-12">Darah Colesterol</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="hidden" name="check8" value="0">
                                    <input type="checkbox" id="ncoles" value="8" name="check8" {{ ($packages->BDARAHNONCHOL==="1")? "checked" : "" }}>
                                    <label class="col-form-label col-sm-12"> Darah Non Colesterol</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="hidden" name="check9" value="0">
                                    <input type="checkbox" id="aurdio" value="9" name="check9" {{ ($packages->BAUDIO==="1")? "checked" : "" }}>
                                    <label class="col-form-label col-sm-12">Audio</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="hidden" name="check10" value="0">
                                    <input type="checkbox" id="darah" value="10" name="check10" {{ ($packages->BDARAHHBSAG==="1")? "checked" : "" }}>
                                    <label class="col-form-label col-sm-12">Darah HBSAg</label>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="form-group row">
                           <div class="col-md-12">
                              <div class="float-right">
                                 <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                 <a href="/account/packages" class="btn btn-cstm btn-light btn-sz">Close</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
@endsection