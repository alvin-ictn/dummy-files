@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Add Packages</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Add New Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/addpackages/insert" id="form-confirm">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Packages Code</label>
                              <div class="col-sm-4">
                                 <input id="code" name="packcode" placeholder="Packages Code" class="form-control" type="text" maxlength="20" required>
                                 <span class="help-block"></span>
                                 <div class="invalid-feedback" id="already">
                                 </div>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Packages Name</label>
                              <div class="col-sm-4">
                                 <input name="packname" placeholder="Packages Name" class="form-control" type="text" maxlength="50" required>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-sm-12">
                                 <h5 class="head-h5">
                                    <span>&nbsp; List Items</span>
                                 </h5>
                              </div>
                           </div>
                           <br>
                           <div class="row">
                              <div class="col-sm-12">
                                 <div class="form-check form-check-inline col-sm-2">
                                    <input type="checkbox" id="sign" value="1" name="check">
                                    <label class="col-form-label col-sm-12">Vital Sign</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                 <input type="checkbox" id="urine" value="2" name="check2">
                                    <label class="col-form-label col-sm-12">Urine</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="checkbox" id="rontgen" value="3" name="check3">
                                    <label class="col-form-label col-sm-12">Rontgen</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="checkbox" id="spiro" value="4" name="check4">
                                    <label class="col-form-label col-sm-12">Spiro</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="checkbox" id="ekg" value="5" name="check5">
                                    <label class="col-form-label col-sm-12">EKG</label>
                                 </div>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-sm-12">
                                 <div class="form-check-inline col-sm-2">
                                    <input type="checkbox" id="fisik" value="6" name="check6">
                                    <label class="col-form-label col-sm-12">Fisik</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="checkbox" id="coles" value="7" name="check7">
                                    <label class="col-form-label col-sm-12">Darah Colesterol</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="checkbox" id="ncoles" value="8" name="check8">
                                    <label class="col-form-label col-sm-12"> Darah Non Colesterol</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="checkbox" id="aurdio" value="9" name="check9">
                                    <label class="col-form-label col-sm-12">Audio</label>
                                 </div>
                                 <div class="form-check-inline col-sm-2">
                                    <input type="checkbox" id="aurdio" value="10" name="check10">
                                    <label class="col-form-label col-sm-12">Darah HBSAg</label>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="form-group row">
                           <div class="col-md-12">
                              <div class="float-right">
                                 <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                 <a href="/account/packages" class="btn btn-cstm btn-light btn-sz">Close</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<script>
   $(document).ready(function() {
      $("#code").keyup(function() {
         var id = $(this).val();
         var base = btoa(id);
         $.ajax({
            dataType: "json",
            type: "GET",
            url: "/getajaxpackages/" + base,
            success: function(result) {
               if(result.data === 'already'){
                  $('#already').html('Packages Code already in use!');
                  $('input#code').addClass('is-invalid');
               }else{
   
                  $('#already').html('');
                  $('input#code').removeClass('is-invalid');
   
               }
             
            }
         });
      });
   });
</script>
@endsection