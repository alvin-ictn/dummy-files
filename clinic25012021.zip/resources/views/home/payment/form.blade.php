
@extends('layout.app') 
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Close Booking</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Payment
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form id="form-confirm" data-url="/payment/save" method="post">
                     <input type="hidden" class="form-control" name="VBOOKINGNO" value="{{ $booking_no ?? '' }}">
                     <input type="hidden" class="form-control" name="VMRNO" value="{{ $booking->VMRNO ?? '' }}">
                     <input type="hidden" class="form-control" name="VTYPE" value="{{ $type ?? '' }}"><div class="row">
                        <label for="example-text-input" class="col-form-label col-sm-2">Booking No :</label>
                        <div class="col-sm-4">
                           <div class="col-form-label">
                              <label>{{ $booking_no ?? '' }}</label>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <label for="example-text-input" class="col-form-label col-sm-2">MR No :</label>
                        <div class="col-sm-4">
                           <div class="col-form-label">
                              <label>{{ $booking->VMRNO ?? '' }}</label>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <label for="example-text-input" class="col-form-label col-sm-2">Patient Name :</label>
                        <div class="col-sm-10">
                           <div class="col-form-label">
                              <label>{{ $booking->VNAME ?? '' }}</label>
                           </div>
                        </div>
                     </div>
                     <div class="form-group row">
                        <label for="example-text-input" class="col-form-label col-sm-2">Total :</label>
                        <div class="col-sm-3">
                           <div class="total input-group">
                              <input name="total" placeholder="Total" id="rupiah" class="form-control" type="text" onchange='total()' readonly>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="table-responsive col-lg-12 col-sm-12 form-group">
                           <table id="tblbilling" border="1" class="display" style="width:100%">
                              <thead>
                                 <tr>
                                 <?php $inc = 1;?>
                                    <th class="text-center" style="width:7%">Action</th>
                                    <th class="text-center">No</th>
                                    <th class="text-center">Product/Service</th>
                                    <th class="text-center" style="width:15%">Qty</th>
                                    <th class="text-center">Unit Price</th>
                                    <th class="text-center">Amount</th>
                                    <th class="text-center" style="width:7%">Redeem</th>

                                 </tr>
                              </thead>
                              @if (isset($bills))
                              <tbody>
                                 @foreach ($bills as $bill)
                                 <tr id="{{ $inc }}">
                                    @if($bill->VREMARKS == "[EDIT]" && $booking->BSTATUS == "O")
                                       <input type='hidden' class='form-control' name='ILINENO[]' value="{{ $bill->ILINENO }}">
                                       <td data-id='remove' style='text-align: center;' width='5%' id='{{ $inc }}'>
                                          <button onClick='remove(this)' type='button' data-id='[EDIT]' class='btn btn btn-link btn-sm'>
                                             <i title='Delete' class='fas fa-times'></i>
                                          </button>
                                       </td>
                                       <td>{{ $inc }}</td>
                                       <td data-id='VITEMNAME' width='25%' id='{{ $inc }}'>
                                          <input type='text' class='product form-control' name='VITEMNAME[]' value='{{ $bill->VITEMNAME }}' required>
                                       </td>
                                       <td data-id='IQTY'  width='5  %' id='{{ $inc }}'>
                                          <input type='text' class='form-control' name='qty[]' value='{{ $bill->IQTY }}' onkeyup='calc("{{ $inc }}")' required>
                                       </td>
                                       <td data-id='PRICE' width='25%' id='{{ $inc }}'>
                                          <input type='text' class='form-control' name='price[]' value='{{ explode(".", $bill->NPRICE)[0] }}' onkeyup='calc("{{ $inc }}")' required>
                                       </td>
                                       <td data-id='TOTAL' width='15%' id='{{ $inc }}'>
                                          <input type='text' class='amount form-control' name='amount[]' value='{{ $bill->IQTY * $bill->NPRICE }}' onchange='Total();' readonly>
                                       </td>
                                    @else
                                       <td></td>
                                       <td>{{ $inc }}</td>
                                       <td data-value="VITEMNAME">{{ $bill->VITEMNAME }}</td>
                                       <td data-value="IQTY" class="text-center" >{{ $bill->IQTY }}</td>
                                       <td data-value="PRICE" class="uang text-right">{{ number_format($bill->NPRICE, 2, '.', ',') }}</td>
                                       <td data-value="TOTAL" class="uang text-right" name="total_td">{{ number_format($bill->IQTY * $bill->NPRICE, 2, '.', ',') }}</td>
                                       @if($bill->VREMARKS != "[]" && $bill->VREMARKS != "[EDIT]")
                                       <td data-value='Redeem' class="text-center">
                                          <div class="form-check form-check-inline">
                                             <input class="form-check-input" name="BREEDEEM[{{ $inc }}]" type="radio" onclick='Total();' value="1" {{ ($bill->BREEDEEM == "1") ? "checked" : "" }} <?php if($booking->BSTATUS == "D"){?> disabled <?php } ?>>
                                             <label class="form-check-label" for="s{{ $inc }}">Yes</label>
                                          </div>
                                          <div class="form-check form-check-inline">
                                             <input class="form-check-input" name="BREEDEEM[{{ $inc }}]" type="radio" onclick='Total();' value="0" {{ ($bill->BREEDEEM == "0") ? "checked" : "" }} <?php if($booking->BSTATUS == "D"){?> disabled <?php } ?>>
                                             <label class="form-check-label" for="s{{ $inc }}">No</label>
                                          </div>
                                       </td>
                                       @else
                                       <td></td>
                                       @endif
                                    @endif
                                 </tr>
                                 <?php $inc++; ?>
                                 @endforeach
                              </tbody>
                              @endif
                           </table>
                        </div>
                     </div>
                     <div class="row row-add-row">
                        <div class="col-lg-12 col-sm-12 form-group">
                           <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('C', 'F38')) { ?>
                              <button type="button" class="btn btn-cstm btn-primary btn-sz" id="addRow" <?php if($booking->BSTATUS != "O"){ ?>disabled<?php } ?>>Add Row</button>
                           <?php } ?>
                           <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('P', 'F38')) { ?>
                              @if (!isset($movement))
                                 <button onclick="(function(){ window.location.replace('/payment/print/{{ base64_encode($booking_no.','.$booking->VMRNO) ?? '' }}'); })()" type="button" class="btn btn-cstm btn-primary btn-sz" <?php if($booking->BSTATUS != "D"){ ?>disabled<?php } ?>>Print Cost</button>
                              @endif
                           <?php } ?>
                        </div>
                     </div>
                     <div class="float-right">
                        <div class="col-sm-12">
                           <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('C', 'F38')) { ?>
                              <button type="submit" id="hbutton" class="btn btn-cstm btn-primary btn-sz" <?php if($booking->BSTATUS != "O"){ ?>disabled<?php } ?>>Submit</button>
                           <?php } ?>
                           <a onclick="history.length > 1 ? history.back() : location.href = '/account/payment'" id="close" class="btn btn-cstm btn-light btn-sz">Close</a>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>


<script>
	$(document).ready(function() {
      Total();
   });

   var rupiah = document.getElementById('rupiah');
      rupiah.addEventListener("keyup", function(e) {
      rupiah.value = convertRupiah(this.value);
   });
   function convertRupiah(angka, prefix) {
      var number_string = angka.replace(/[^\d]/g, "").toString(),
      split  = number_string.split(","),
      sisa   = split[0].length % 3,
      rupiah = split[0].substr(0, sisa),
      ribuan = split[0].substr(sisa).match(/\d{3}/gi);

	   if (ribuan) {
		   separator = sisa ? "," : "";
		   rupiah += separator + ribuan.join(",");
	   }
      $('input[name="NPRICE"]').val(number_string)
	   rupiah = split[1] != undefined ? rupiah + "," + split[1] : rupiah;
	   return prefix == undefined ? rupiah : rupiah ? prefix + rupiah : "";
   }
   function Total(){
      var table = document.getElementById("rupiah");
      for(var i = 0; i < table.length; i++)
      {
         console.log(table.length);
      }

      // Total amount from Bill table
      var total_td = 0;
      $("#tblbilling").find('tbody tr').each(function(){
         var is_redeem = $(this).find('td:eq(6) input[type="radio"]:checked').val();
         if(is_redeem == undefined) is_redeem = 1;
         
         var data = $(this).find('td:eq(5)');   // Amount

         if(data.attr("data-value") == "TOTAL" && is_redeem == "1") total_td = total_td + parseInt(data.html().replace(/,/g, ''));
      })
      
      // Total amount of newly added row
      var total = $("#tblbilling").find('input[name="amount[]"]').map(function(){return $(this).val();}).get();   // newly added row total amount(per row)
      var plus_amount = 0;
      // By using for, add each value from total array and put it in plus_amount
      for(var i = 0; i < total.length; i++)
      {
         if(total[i] == 'NaN' || total[i] == '') continue;
         plus_amount = plus_amount + parseInt(total[i]);
      }
      
      plus_amount = plus_amount + total_td;  // add all total amount

      $('#rupiah').val(plus_amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + '.00');
   }
   let row_id_idx = $('#tblbilling tbody tr').length + 1;
   if(document.getElementById('addRow') != null){
   var addRow = document.getElementById('addRow');
      addRow.addEventListener('click', function() {
         var table = document.getElementById("tblbilling");
         $(table).find('tbody').append("<tr id='"+ row_id_idx +"'>"+
         "<input type='hidden' class='form-control' name='ILINENO[]' value=" + "[NEW]" + ">" +
         "<td data-id='remove' style='text-align: center;' width='5%' id='"+ row_id_idx +"'><button onClick='remove(this)' type='button' data-id='' class='btn btn btn-link btn-sm'><i title='Delete' class='fas fa-times'></i></button></td>"+
         "<td data-id='no' width='5%' id='"+ row_id_idx +"' class='no'>"+ ($('#tblbilling tbody tr').length + 1) +"</td>"+
         "<td data-id='VITEMNAME' width='25%' id='"+ row_id_idx +"'><input type='text' class='product form-control' name='VITEMNAME[]'  required></td>"+
         "<td data-id='IQTY'  width='5%' id='"+ row_id_idx +"'><input type='text' class='form-control' name='qty[]' onkeyup='calc("+ row_id_idx +")' required></td>"+
         "<td data-id='PRICE' width='25%' id='"+ row_id_idx +"'><input type='text' class='form-control' name='price[]' onkeyup='calc("+ row_id_idx +")' required></td>"+
         "<td data-id='TOTAL' width='25%' id='"+ row_id_idx +"'><input type='text' class='amount form-control' name='amount[]' onchange='Total();' readonly></td>"+
         "<td></td>"+
         "</tr>");      
         row_id_idx++;
      }, false);
   }
   function calc(id){
      var qty = parseInt($("#"+id).find('input[name="qty[]"]').val());
      if(isNaN(qty)) qty = 1;
      var price = parseInt($("#"+id).find('input[name="price[]"]').val());
      if(isNaN(price)) price = 1;
      var amount = (price * qty);
      
      $("#"+id).find('input[name="amount[]"]').val(amount);
      Total();
   }

   var vbooking = $('input[name="VBOOKINGNO"]').val();
   function remove(th) {
		swal.fire({
			text: "Do you want to delete the data?",
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Yes",
			cancelButtonText: "No"
		}).then(function (result) {
			if (result.value) {
				if ($(th).attr('data-id') === '[EDIT]') {
               var ext = btoa(vbooking +','+$(th).closest('tr').find('input[name="ILINENO[]"]').val());
            
					$.ajax({
						url: "/payment/delete/" + ext,
						type: "GET",
						headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
						success: function () {
							location.reload();
						}
					});
				} else {
					$(th).closest('tr').remove();
					$.each($('#tblbilling tbody tr'), function( index, value ) {
						$('#tblbilling tbody tr:eq(' + index + ') td:eq(1)').text(index + 1);
					});
				}
			}
		});
	}
</script>
@endsection