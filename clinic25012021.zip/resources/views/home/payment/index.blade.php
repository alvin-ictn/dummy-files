@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Close Booking</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12"> 
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Close Booking
                  </h3>
               </div>
               <div class="card-header">
                  <h3 class="row card-title">
                  <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('E', 'F38')) { ?>
                        <form action="payment/export_excel" method="POST">
                              @csrf
                              <input type="hidden" value="" name="start_date" id="start_date">
                              <input type="hidden" value="" name="end_date" id="end_date">
                              <input type="hidden" value="" name="type" id="type">
                              <input type="hidden" value="" name="no" id="no">
                              <input type="hidden" value="" name="mr_no" id="mr_no">
                              <input type="hidden" value="" name="booking_no" id="booking_no">
                              <input type="hidden" value="" name="doctor" id="doctor">
                              <input type="hidden" value="" name="patient_name" id="patient_name">
                              <input type="hidden" value="" name="patient_type" id="patient_type">
                              <input type="hidden" value="" name="date_of_birth" id="date_of_birth">
                              <input type="hidden" value="" name="gender" id="gender">
                              <input type="hidden" value="" name="last_visit_date" id="last_visit_date">
                              <input type="hidden" value="" name="phone_no" id="phone_no">
                              <input type="hidden" value="" name="status" id="status">
                              <input type="hidden" value="" name="status" id="status">
                              <input type="hidden" value="" name="total" id="total">
                              <input type="hidden" value="" name="last_modified_name" id="last_modified_name">
                              <input type="hidden" value="" name="last_modified_date" id="last_modified_date">
                              <input type="hidden" value="" name="search" id="search">
                        
                              <button class="btn btn-sz btn-primary" type="submit">Export to Excel</button>
                        </form>
                     <?php }  ; ?>
                  </h3>
               </div> 
               <!-- /.card-header -->
               <div class="card-body">
                  <div class="form-group">
                     <div class="form-group row">
                        <label class="col-form-label control-label col-sm-1">Date from</label>
                        <div class="col-sm-4">
                           <div class="input-group date" id="DFROM" data-target-input="nearest">
                              <input value="{{Carbon\Carbon::now()->format('d-M-Y')}}" type="text" class="form-control datetimepicker-input" name="DFROM" data-target="#DFROM" placeholder="DD-MMM-YYYY" required>
                              <div class="input-group-append" data-target="#DFROM" data-toggle="datetimepicker">
                                 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                              </div>
                           </div>
                        </div>
                        <label class="col-form-label control-label col-sm-1">to</label>
                        <div class="form-group col-sm-4">
                           <div class="input-group date" id="DTO" data-target-input="nearest">
                              <input value="{{Carbon\Carbon::now()->format('d-M-Y')}}" type="text" class="form-control datetimepicker-input" name="DTO" data-target="#DTO" placeholder="DD-MMM-YYYY" required>
                              <div class="input-group-append" data-target="#DTO" data-toggle="datetimepicker">
                                 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group">
                              <button class="btn btn-sz btn-primary" onclick="return LoadTable();" role="button" style="color:white;">Search</button>
                           </div>
                        </div>
                     </div>
                     <div class="form-group row">
                        <label for="example-text-input" class="req col-form-label col-sm-1">Patient Type</label>
                        <div class="col-sm-4">
                           <select class="form-control" name="pattype" id="pattype">
                              <option value="ALL">All Patient Type</option>
                                 @foreach($pts as $pt)
                                 <option value="{{$pt->VSETCODE}}">{{$pt->VSETDESC}}</option>
                                 @endforeach
                           </select>
                        </div>
                     </div>
                  </div>
                  <br/>
                  @if ($errors->any())
                     <div class="alert alert-danger">
                        <ul>
                           @foreach ($errors->all() as $error)
                              <li>{{ $error }}</li>
                           @endforeach
                        </ul>
                     </div>
                  @endif
                  <div class="table-responsive">
                     <table id="cmpayment" class="table table-bordered table-striped display compact nowrap" style="width:100%">
                        <thead>
                           <tr>
                              <th>No</th>
                              <th>MR No.</th>
                              <th>Booking No.</th>
                              <th>Doctor</th>
                              <th>Patient Name</th>
                              <th>Patient Type</th>
                              <th>Date of Birth</th>
                              <th>Gender</th>
                              <th>Last Visit Date</th>
                              <th>Phone No</th>
                              <th>Status</th>
                              <th>Total</th>
                              <th>Last Modified Name</th>
                              <th>Last Modified Date</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<style>
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::after{display: none}
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::before{display: none}
</style>

<script>

	$(document).ready(function() {

      $('#DFROM, #DTO').datetimepicker({
         format: 'DD-MMM-YYYY',
      });

   });
   
	$(document).ready(function() {
      LoadTable();
	   $('#cmpayment thead tr').clone(true).appendTo( '#cmpayment thead' );
	   $('#cmpayment thead tr:eq(1) th').each( function (i) {
         var title = $(this).text();
         if(title === "No"){
          $(this).html( '<input type="text" class="input-sm no" placeholder="Search '+title+'" />' );
         }
         else if(title === "MR No."){
            $(this).html('<input type="text" class="input-sm mr_no" placeholder="Search ' + title + '" />');
         }
         else if(title === "Booking No."){
            $(this).html('<input type="text" class="input-sm booking_no" placeholder="Search ' + title + '" />');
         }
         else if(title === "Doctor"){
            $(this).html('<input type="text" class="input-sm doctor" placeholder="Search ' + title + '" />');
         }
         else if(title === "Patient Name"){
            $(this).html('<input type="text" class="input-sm patient_name" placeholder="Search ' + title + '" />');
         }
         else if(title === "Patient Type"){
            $(this).html('<input type="text" class="input-sm patient_type" placeholder="Search ' + title + '" />');
         }
         else if (title === "Date of Birth") {
	   		$(this).html( '<input type="date" class="input-sm date_of_birth" placeholder="Search '+title+'" />' );
         }
         else if(title === "Gender"){
            $(this).html('<input type="text" class="input-sm gender" placeholder="Search ' + title + '" />');
         }
         else if(title === "Last Visit Date"){
            $(this).html('<input type="date" class="input-sm last_visit_date" placeholder="Search ' + title + '" />');
         }
         else if(title === "Phone No"){
            $(this).html('<input type="text" class="input-sm phone_no" placeholder="Search ' + title + '" />');
         }
         else if(title === "Status"){
            $(this).html('<input type="text" class="input-sm status" placeholder="Search ' + title + '" />');
         }
         else if(title === "Total"){
            $(this).html('<input type="text" class="input-sm total" placeholder="Search ' + title + '" />');
         }
         else if(title === "Last Modified Name"){
            $(this).html('<input type="text" class="input-sm last_modified_name" placeholder="Search ' + title + '" />');
         }
         else if(title === "Last Modified Date"){
            $(this).html('<input type="date" class="input-sm last_modified_date" placeholder="Search ' + title + '" />');
         }
	   	$( 'input', this ).on( 'keyup change', function () {
	   		if ( tablepayment.column(i).search() !== this.value ) {
	   			tablepayment
	   				.column(i)
	   				.search( this.value )
	   				.draw();
					$('input[name="' + $(this).attr('class').replace('input-sm ', '') + '"]').val($('.' + $(this).attr('class').replace('input-sm ', '')).val());
	   		}
	   	});
	   });

	   tablepayment.columns().every(function (index) {
	   	$('#cmpayment thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
	   		tablepayment.column($(this).parent().index() + ':visible')
	   			.search(this.value)
	   			.draw();
	   	});
      });
   });

   function LoadTable(){
         tablepayment = $("#cmpayment").DataTable({
         destroy: true,
         processing: true,
         serverSide: true,
         dom: '<lf<t><r>ip>',
         columnDefs: [
            { "width": "5%", "targets": 0 }
        ],
        ajax:{
               url: '/ajaxpayment',
               type: "GET",
			      data: function (d) {
					   d.date_of_birth = $('input[name="date_of_birth"]').val(),
					   d.last_visit_date = $('input[name="last_visit_date"]').val(),
					   d.last_modified_date = $('input[name="last_modified_date"]').val(),
					   d.search = $('input[type="search"]').val()
                  d.DFROM = $('input[name="DFROM"]').val(), 
                  d.DTO = $('input[name="DTO"]').val()
                  d.pattype = $('select[name="pattype"]').val()
				   },
            },
        columns: [
            {
               data: "no",
               name: "no",
            },
            {
               data: "action",
               name: "action",
				   render: function (data, type, row) {
                  return "<a href='payment/form/"+ btoa(row.VBOOKINGNO + "," + row.VMRNO) +"'>" + data + "</a>"
				   }
            },
            {
               data: "VBOOKINGNO",
               name: "VBOOKINGNO",
            },
            {
               data: "DOCTOR",
               name: "DOCTOR",
            },
            {
               data: "VNAME",
               name: "VNAME",
            },
            {
               data: "VTYPEPATIENT",
               name: "VTYPEPATIENT",
            },
            {
               data: "DBIRTH",
               name: "dbirth",
               searchable: false,
            },
            {
               data: "GENDER",
               name: "GENDER",
            },
            {
               data: "LASTVISITDATE",
               name: "lastvisitdate",
               searchable: false,
            },
            {
               data: "VPHONENO",
               name: "VPHONENO",
            },
            {
               data: "STATUS",
               name: "STATUS",
            },
            {
               data: "TOTAL",
               name: "TOTAL",
				   render: function (data, type, row) {
                  if(data == ".00") data = "0.00";
                  return "Rp. " + data.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
				   }
            },
            {
               data: "VMODI",
               name: "VMODI",
            },
            {
               data: "DMODI",
               name: "dmodi",
               searchable: false,
            },
           ]
      });
		$('input[name="start_date"]').val($('input[name="DFROM"]').val());
		$('input[name="end_date"]').val($('input[name="DTO"]').val());
		$('input[name="type"]').val($('select[name="pattype"]').val());
   }
</script>
@endsection