
@extends('layout.app') 
@section('content')
<section class="content">
   <section class="content-header">
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <!-- /.card-header -->
               <div class="card-body">
                  <h3 class="text-center">
                     Cost
                  </h3>
                  <hr style="border-width: 2px !important; background-color: black;">
                  <form>
                     <div class="row">
                        <label for="example-text-input" class="col-form-label col-sm-2">Booking No :</label>
                        <div class="col-sm-4">
                           <div class="col-form-label">
                              <label>{{ $booking_no ?? '' }}</label>
                           </div>
                        </div>
                        <label for="example-text-input" class="col-form-label col-sm-2">Date :</label>
                        <div class="col-sm-4">
                           <div class="col-form-label">
                              <label>{{ $booking->DVISIT ?? '' }}</label>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <label for="example-text-input" class="col-form-label col-sm-2">MR No :</label>
                        <div class="col-sm-4">
                           <div class="col-form-label">
                              <label>{{ $booking->VMRNO ?? '' }}</label>
                           </div>
                        </div>
                        <label for="example-text-input" class="col-form-label col-sm-2">Clinic :</label>
                        <div class="col-sm-4">
                           <div class="col-form-label">
                              <label>{{ $clinic ?? '' }}</label>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <label for="example-text-input" class="col-form-label col-sm-2">Patient Name :</label>
                        <div class="col-sm-4">
                           <div class="col-form-label">
                              <label>{{ $booking->VNAME ?? '' }}</label>
                           </div>
                        </div>
                        <label for="example-text-input" class="col-form-label col-sm-2">Doctor :</label>
                        <div class="col-sm-4">
                           <div class="col-form-label">
                              <label>{{ $doctor ?? '' }}</label>
                           </div>
                        </div>
                     </div>
                     <br>
                     <div class="row">
                        <div class="table-responsive col-lg-12 col-sm-12 form-group">
                           <table id="tblbilling" border="1" class="display" style="width:100%">
                              <thead>
                                 <tr>
                                    <th class="text-center">Product/Service</th>
                                    <th class="text-center" style="width:15%">Qty</th>
                                    <th class="text-center">Unit Price</th>
                                    <th class="text-center">Amount</th>
                                 </tr>
                              </thead>
                              @if (isset($bills))
                              <tbody>
                                 @foreach ($bills as $bill)
                                 @if ($bill->BREEDEEM == "1")
                                 <tr id="{{ $bill->ILINENO }}">
                                    <td data-value="VITEMNAME">{{ $bill->VITEMNAME }}</td>
                                    <td data-value="IQTY" class="text-center" >{{ $bill->IQTY }}</td>
                                    <td data-value="PRICE" class="uang text-right">{{ number_format($bill->NPRICE, 2, '.', ',') }}</td>
                                    <td data-value="TOTAL" class="uang text-right" name="total_td">{{ number_format($bill->IQTY * $bill->NPRICE, 2, '.', ',') }}</td>
                                 </tr>
                                 @endif
                                 @endforeach
                              </tbody>
                              @endif
                           </table>
                        </div>
                     </div>
                     <div class="form-group row">
                        <div class="col-sm-9">
                           <div class="input-group">
                           </div>
                        </div>
                        <label for="example-text-input" class="col-form-label col-sm-1">Total Payment :</label>
                        <div class="col-form-label col-sm-2">
                           <div class="total input-group">
                              <p name="total" placeholder="Total" id="rupiah" class=""></p>
                           </div>
                        </div>
                     </div>
                     <br>
                     <br>
                     <br>
                     <br>
                     <br>
                     <div class="row">
                        <div class="col-sm-10">
                           <button type="button" id="hbutton" class="btn-cstm btn-primary btn-sz" onclick="return print()">Print</button>
                           <a onclick="history.length > 1 ? history.back() : location.href = '/payment/print/{{ base64_encode($booking->VMRNO) ?? '' }}'" id="hbutton" class="btn-cstm btn-light btn-sz">Close</a>
                        </div>
                        <div class="col-sm-2">
                           <p>({{ Session::get("nameuser") }})</p>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>


<script>
	$(document).ready(function() {
      Total();
   });

   function Total(){
      var table = document.getElementById("rupiah");
      for(var i = 0; i < table.length; i++)
      {
         console.log(table.length);
      }

      // Total amount from Bill table
      var total_td = 0;
      $("#tblbilling").find('tbody tr').each(function(){
         var data = $(this).find('td:eq(3)');
         if(data.attr("data-value") == "TOTAL") total_td = total_td + parseInt(data.html().replace(/,/g, ''));
      })

      $('#rupiah').text(total_td.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + '.00');
   }

   function calc(id){
      var qty = parseInt($("#"+id).find('input[name="qty[]"]').val());
      if(isNaN(qty)) qty = 1;
      var price = parseInt($("#"+id).find('input[name="price[]"]').val());
      if(isNaN(price)) price = 1;
      var amount = (price * qty);
      $("#"+id).find('input[name="amount[]"]').val(amount);
      Total();
   }

</script>
@endsection