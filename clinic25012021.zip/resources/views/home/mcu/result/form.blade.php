@extends('layout.app') 
@section('content')
<style>
	.vl {
		border-left: 1px solid;
		height: 100%;
	}
	tr { border: solid thin; }
	td { padding: 0rem 0.5rem; }
	td input {
		height: 21px;
		width: 100%;
	}
	td label { margin-bottom: 0rem; }
	.form-ref.required .control-label::after {
		content: "*";
		color: red;
	}
	.table-all-border tr, .table-all-border th, .table-all-border td { border: solid thin; }
	.noBorder tr { border: 0; }

	@media print {
    .pagebreak {
        clear: both;
        page-break-after: always;
    }
}
</style>
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
					<li class="breadcrumb-item"><a href="/account/home">Home</a></li>
					<li class="breadcrumb-item active">Result MCU</li>
				</ol>
			</div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            @if ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4)
				<form id="form-confirm" data-url="/resultmcu/save" method="post">
			@endif
			<div class="card">
               <div class="card-body">
                  <div class="row">
					<div class="col-sm-12">
					   <div>
						  <label class="control-label col-sm-12"><b>@if ($resultmcu->VIDTYPE == '3'){{ 'PREEMPLOYMENT MEDICAL CHECK-UP REPORT' }}@else{{ 'ANNUAL MEDICAL CHECK-UP REPORT' }}@endif</b></label>
					   </div>
					</div>
				 </div>
                  <div class="row">
					<div class="col-sm-6" style="padding-right: 0px; padding-left: 0px;">
					   <table class="noBorder" style="border:1px solid;" width="100%">
						  <tbody>
							<tr>
								<td width="35%">Nama Karyawan</td>
								<td width="1%">:</td>
								<td width="64%">{{ $resultmcu->VNAME }}</td>
							</tr>
							<tr>
								<td>SAP ID</td>
								<td>:</td>
								<td>{{ $resultmcu->VIDNO }}</td>
							</tr>
							<tr>
								<td>Jabatan</td>
								<td>:</td>
								<td>{{ $resultmcu->VAPPLPOS }}</td>
							</tr>
							<tr>
								<td>Department</td>
								<td>:</td>
								<td>{{ $resultmcu->VCOSTCNTRNAME }}</td>
							</tr>
							<tr>
								<td>Business Unit</td>
								<td>:</td>
								<td>{{ $resultmcu->VPRSNLNAME }}</td>
							</tr>
							<tr>
								<td>Wilayah kerja</td>
								<td>:</td>
								<td></td>
							</tr>
						  </tbody>
					   </table>
					</div>
					<div class="col-sm-6" style="padding-right: 0px; padding-left: 0px;">
					   <table class="noBorder" style="border:1px solid;" width="100%">
						  <tbody>
							<tr>
								<td width="35%">MCU Reg. Number</td>
								<td width="1%">:</td>
								<td width="64%">{{ $resultmcu->VREGNO }}</td>
							</tr>
							<tr>
								<td>NIK</td>
								<td>:</td>
								<td></td>
							</tr>
							<tr>
								<td>Tanggal MCU</td>
								<td>:</td>
								<td>{{ $resultmcu->DRESERVED->format('d F Y') }}</td>
							</tr>
							<tr>
								<td>Tanggal Lahir</td>
								<td>:</td>
								<td>{{ $resultmcu->DBIRTH }}</td>
							</tr>
							<tr>
								<td>Umur</td>
								<td>:</td>
								<td>{{ $resultmcu->AGE }} tahun</td>
							</tr>
							<tr>
								<td>Jenis Kelamin</td>
								<td>:</td>
								<td>{{ $resultmcu->VSETDESC }}<label class="gender" style="display: none;">{{ $resultmcu->VGNDRCODE }}</label></td>
							</tr>
						  </tbody>
					   </table>
					</div>
				 </div>
				 @if ($section == 5)
					 <br/>
					 <div class="row sprint" style="display: none;">
						<div class="col-sm-12 text-center">
						   <div>
							  <label class="control-label col-sm-12"><b>RANGKUMAN PEMERIKSAAN</b></label>
						   </div>
						</div>
					 </div>
					 <div class="row sprint" style="display: none;">
						<div class="col-sm-12">
						   <table width="100%">
							<tbody>
								<tr>
									<td width="35%">Tinggi badan</td>
									<td width="1%">:</td>
									<td width="64%">
										<div class="row">
											<div class="col-sm-4">
												{{ $physics->IHEIGHT }} cm
											</div>
											<div class="col-sm-8">
												<div class="row">
													<div class="col-sm-4 vl">
														VOD
													</div>
													<div class="col-sm-1 text-center">
														:
													</div>
													<div class="col-sm-7">
														{{ $physics->VVOD }}
													</div>
												</div>
											</div>
										</div>
									</td>
								</tr>
								<tr>
									<td>Berat badan</td>
									<td>:</td>
									<td>
										<div class="row">
											<div class="col-sm-4">
												{{ $physics->IWEIGHT }} kg
											</div>
											<div class="col-sm-8">
												<div class="row">
													<div class="col-sm-4 vl">
														VOS
													</div>
													<div class="col-sm-1 text-center">
														:
													</div>
													<div class="col-sm-7">
														{{ $physics->VVOS }}
													</div>
												</div>
											</div>
										</div>
									</td>
								</tr>
								<tr>
									<td>Tekanan darah</td>
									<td>:</td>
									<td>
										<div class="row">
											<div class="col-sm-4">
												{{ $physics->IBLOODPRESSURE1 }} / {{ $physics->IBLOODPRESSURE2 }} mmHg
											</div>
											<div class="col-sm-8">
												<div class="row">
													<div class="col-sm-4 vl">
														Penglihatan warna
													</div>
													<div class="col-sm-1 text-center">
														:
													</div>
													<div class="col-sm-7">
														{{ $physics->VCOLORVISION }}
													</div>
												</div>
											</div>
										</div>
									</td>
								</tr>
								<tr>
									<td>BMI / Kategori</td>
									<td>:</td>
									<td>
										<div class="row">
											<div class="col-sm-4">
												{{ $physics->NBMI }} / {{ $physics->VBMI }}
											</div>
											<div class="col-sm-8">
												<div class="row">
													<div class="col-sm-4 vl">
														Status mental
													</div>
													<div class="col-sm-1 text-center">
														:
													</div>
													<div class="col-sm-7">
														
													</div>
												</div>
											</div>
										</div>
									</td>
								</tr>
							</tbody>
						  </table>
						</div>
					 </div>
					 <br/>
					 <div class="row sprint" style="display: none;">
						<div class="col-sm-12">
						   <table width="100%">
							<tbody>
								<tr>
									<td width="35%">Pemeriksaan fisik</td>
									<td width="1%">:</td>
									<td width="64%">
										<?php
											$vpf = '';
											if ($physics->VSKIN)
											{
												$vpf .= $physics->VSKIN . ', ';
											}
											if ($physics->VHEAD)
											{
												$vpf .= $physics->VHEAD . ', ';
											}
											if ($physics->VNECK)
											{
												$vpf .= $physics->VNECK . ', ';
											}
											if ($physics->VRESPIRATION)
											{
												$vpf .= $physics->VRESPIRATION . ', ';
											}
											if ($physics->VCARDIO)
											{
												$vpf .= $physics->VCARDIO . ', ';
											}
											if ($physics->VSTOMACH)
											{
												$vpf .= $physics->VSTOMACH . ', ';
											}
											if ($physics->VPELVIS)
											{
												$vpf .= $physics->VPELVIS . ', ';
											}
											if ($physics->VSPINE)
											{
												$vpf .= $physics->VSPINE . ', ';
											}
											if ($physics->VMOTION)
											{
												$vpf .= $physics->VMOTION . ', ';
											}
											if ($physics->VOTHER_PHYSIC)
											{
												$vpf .= $physics->VOTHER_PHYSIC . ', ';
											}
										?>
										{{ substr($vpf, 0, -2) }}
									</td>
								</tr>
								<tr>
									<td>Darah rutin</td>
									<td>:</td>
									<td class="darah-rutin"></td>
								</tr>
								<tr>
									<td>Kimia darah</td>
									<td>:</td>
									<td class="kimia-darah"></td>
								</tr>
								<tr>
									<td>Urinalisa</td>
									<td>:</td>
									<td class="urinalisa"></td>
								</tr>
								<tr>
									<td>Tekanan darah</td>
									<td>:</td>
									<td>{{ $analysis->VBLOODPRESSURE }}</td>
								</tr>
								<tr>
									<td>Total kolesterol</td>
									<td>:</td>
									<td>{{ $analysis->VTOTCHOLESTEROL }}</td>
								</tr>
								<tr>
									<td>EKG</td>
									<td>:</td>
									<td>{{ $analysis->VEKG }}</td>
								</tr>
								<tr>
									<td>Chest X-ray</td>
									<td>:</td>
									<td>{{ $analysis->VCHESTXRAY }}</td>
								</tr>
								<tr>
									<td>Audiometri</td>
									<td>:</td>
									<td>{{ $audios->VREMARKS }}</td>
								</tr>
								<tr>
									<td>Spirometri</td>
									<td>:</td>
									<td>{{ $spiros->VREMARKS }}</td>
								</tr>
								<tr>
									<td>Pemeriksaan lain</td>
									<td>:</td>
									<td>{{ $analysis->VOTHERS }}</td>
								</tr>
							</tbody>
						  </table>
						</div>
					 </div>
					 <br/>
					 <div class="row sprint" style="display: none;">
						<div class="col-sm-12">
						   <table width="100%">
							<tbody>
								<tr>
									<td width="35%">Kesimpulan okupasi</td>
									<td width="1%">:</td>
									<td width="64%">{{ $analysis->VOKUPASI }}</td>
								</tr>
								<tr>
									<td>Kategori resiko</td>
									<td>:</td>
									<td>{{ $analysis->VRISKS }}</td>
								</tr>
								<tr>
									<td>Saran</td>
									<td>:</td>
									<td style="white-space: pre-line">{{ $analysis->VADVICE }}</td>
								</tr>
							</tbody>
						  </table>
						</div>
					 </div>
					 <br/>
					 <div class="row sprint" style="display: none;">
						<div class="col-sm-12">
						   <div>
							  <label class="control-label col-sm-12"><b>Team Dokter-MCU  :</b></label>
						   </div>
						</div>
					 </div>
					 <div class="row sprint" style="display: none;">
						<div class="col-sm-12">
						   <table class="noBorder" width="100%">
							<tbody>
								<tr>
									<td width="35%">Dokter Pemeriksa</td>
									<td width="1%">:</td>
									<td width="64%">{{ $dr }}</td>
								</tr>
								<tr>
									<td>Koord. Team</td>
									<td>:</td>
									<td>{{ $analysis->VDRCOORD }}</td>
								</tr>
								<tr>
									<td>Patologi Klinik</td>
									<td>:</td>
									<td>{{ $analysis->VDRPATHOLOGY }}</td>
								</tr>
								<tr>
									<td>Jantung</td>
									<td>:</td>
									<td>{{ $analysis->VDRHEART }}</td>
								</tr>
								<tr>
									<td>Paru</td>
									<td>:</td>
									<td>{{ $analysis->VDRCHEST }}</td>
								</tr>
								<tr>
									<td>THT</td>
									<td>:</td>
									<td>{{ $analysis->VDRTHT }}</td>
								</tr>
								<tr>
									<td>Radiology</td>
									<td>:</td>
									<td>{{ $analysis->VDRRADIOLOGY }}</td>
								</tr>
							</tbody>
						  </table>
						</div>
					 </div>
					 <div class="row sprint" style="display: none;">
						<div class="col">
							<div class="float-right">
							   <table class="noBorder" width="100%">
								<tbody>
									<tr>
										<td>Pangkalan Kerinci, 04 Desember 2020</td>
									</tr>
									<tr>
										<td>Koord. Team</td>
									</tr>
									<tr style="height: 42px !important;">
										<td></td>
									</tr>
									<tr>
										<td>{{ array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'COORD SIGN'; })[2]['VSETDESC'] }}</td>
									</tr>
									<tr>
										<td>No.Kep. {{ $analysis->VDECISIONNO }}</td>
									</tr>
								</tbody>
							  </table>
							</div>
						</div>
					 </div>
				 @endif
               </div>
            </div>
			<div class="pagebreak"></div>
			@if ((App\Http\Controllers\Controller::check_role("ADM") && $section == 1) || ((Session::get('nameuser') == $resultmcu->VNAME || App\Http\Controllers\Controller::check_role("ADM") || App\Http\Controllers\Controller::check_role("ANALYST") || App\Http\Controllers\Controller::check_role("PRMDC") || App\Http\Controllers\Controller::check_role("DCTR") || App\Http\Controllers\Controller::check_role("HRADM") || App\Http\Controllers\Controller::check_role("HRRCT")) && $section > 1))
				<div class="card">
				   <div class="card-body">
					  @if ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("ADM") && $section == 1)
						  <form id="form-confirm" data-url="/resultmcu/save" method="post">
							 <input name="VREGNO" type="hidden" value="{{ $resultmcu->VREGNO ?? '' }}">
							 <input name="section" type="hidden" value="{{ $section }}">
					  @endif
						 @if (App\Http\Controllers\Controller::check_role("ADM") && $section == 1)
							 <div class="row">
								<div class="col-lg-12 col-sm-12 form-group">
								  <button type="button" class="btn-cstm btn-primary btn-sz" onclick="return toFormDoc(this);">Add New</button>
								</div>
							 </div>
						 @endif
						 <div id="hbutton" class="row table-responsive">
							<div class="col-lg-12 col-sm-12 form-group">
							  <table id="tblfile" border="1" width="100%">
								<thead>
								  <tr>
									@if (!isset($docs))
										<th class="text-center">Action</th>
									@endif
									<th class="text-center">No</th>
									<th class="text-center">Type Doc</th>
									<th class="text-center">File Name</th>
								  </tr>
								</thead>
								<tbody>
									@if (isset($docs))
										@foreach ($docs as $doc)
											<tr>
												<td>{{ $doc->ILINENO }}</td>
												<td>{{ $doc->VDOCDESC }}</td>
												<td><a href="/account/resultmcu/download/{{ $doc->VDOCFILE }}">{{ $doc->VDOCFILE }}</a></td>
											  </tr>
										@endforeach
									@endif
								</tbody>
							  </table>
							</div>
						 </div>
						 
						 <div class="row">
							<div class="col-sm-12">
							   <label class="control-label col-sm-12 text-center">Wawancara dan Pemeriksaan Fisik Umum</label>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
								<b>Riwayat Kesehatan</b>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
							  <table width="100%">
								<tbody>
									<tr>
										<td width="35%">Keluhan Kesehatan Sekarang</td>
										<td width="1%">:</td>
										<td width="64%">@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VRK_NOW" type="text" value="{{ $physics->VRK_NOW ?? '' }}">@else{{ $physics->VRK_NOW }}@endif</td>
									</tr>
									<tr>
										<td>Riwayat Penyakit Terdahulu</td>
										<td>:</td>
										<td>@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VRK_OLD" type="text" value="{{ $physics->VRK_OLD ?? '' }}">@else{{ $physics->VRK_OLD }}@endif</td>
									</tr>
									<tr>
										<td>Riwayat Penyakit Resiko Jantung</td>
										<td>:</td>
										<td>@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VRK_JANTUNG" type="text" value="{{ $physics->VRK_JANTUNG ?? '' }}">@else{{ $physics->VRK_JANTUNG }}@endif</td>
									</tr>
									<tr>
										<td>Riwayat Penyakit pada Keluarga</td>
										<td>:</td>
										<td>@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VRK_KEL" type="text" value="{{ $physics->VRK_KEL ?? '' }}">@else{{ $physics->VRK_KEL }}@endif</td>
									</tr>
									<tr>
										<td>Riwayat Kecelakaan Umum/Bedah</td>
										<td>:</td>
										<td>@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VRK_UMUM" type="text" value="{{ $physics->VRK_UMUM ?? '' }}">@else{{ $physics->VRK_UMUM }}@endif</td>
									</tr>
									<tr>
										<td>Kebiasaan Merokok</td>
										<td>:</td>
										<td>
											<div class="row">
												<div class="col-sm-4">
													<div class="row">
														<div class="col-sm-4 text-center">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IKBS_MEROKOK" type="number" min="1" value="{{ $physics->IKBS_MEROKOK ?? $resultmcu->IKBS_TIMES_MEROKOK }}">@else{{ $physics->IKBS_MEROKOK }}@endif
														</div>
														<div class="col-sm-8">
															Batang / hari
														</div>
													</div>
												</div>
												<div class="col-sm-8">
													<div class="row">
														<div class="col-sm-3 vl">
															Selama
														</div>
														<div class="col-sm-2">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IKBS_YEARS_MEROKOK" type="number" min="1" value="{{ $physics->IKBS_YEARS_MEROKOK ?? '' }}">@else{{ $physics->IKBS_YEARS_MEROKOK }}@endif
														</div>
														<div class="col-sm-7">
															tahun
														</div>
													</div>
												</div>
											</div>
										</td>
									</tr>
									<tr>
										<td>Riwayat Kebiasaan Lain</td>
										<td>:</td>
										<td>@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VKBS_OTHERS" type="text" value="{{ $physics->VKBS_OTHERS ?? '' }}">@else{{ $physics->VKBS_OTHERS }}@endif</td>
									</tr>
									<tr>
										<td>Haid Terakhir</td>
										<td>:</td>
										<td>
											<div class="row">
												<div class="col-sm-4">
													@if ((!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4)) && $resultmcu->VGNDRCODE != 'M')<input name="VHAID_LAST" type="text" value="{{ $physics->VHAID_LAST ?? '' }}">@else{{ $physics->VHAID_LAST ?? '' }}@endif
												</div>
												<div class="col-sm-8">
													<div class="row">
														<div class="col-sm-6 vl">
															Metoda KB yang dipakai
														</div>
														<div class="col-sm-1 text-center">
															:
														</div>
														<div class="col-sm-5">
															@if ((!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4)) && $resultmcu->VGNDRCODE != 'M')<input name="VMETODEKB" type="text" value="{{ $physics->VMETODEKB ?? '' }}">@else{{ $physics->VMETODEKB ?? '' }}@endif
														</div>
													</div>
												</div>
											</div>
										</td>
									</tr>
								</tbody>
							  </table>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
								<b>Riwayat dan Paparan Pekerjaan</b>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
							  <table width="100%">
								<tbody>
									<tr>
										<td width="35%">Paparan Bising</td>
										<td width="1%">:</td>
										<td width="64%">
											<div class="row">
												<div class="col-sm-4">
													<div class="row">
														<div class="col-sm-2 text-center">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IBISING" type="number" min="1" value="{{ $physics->IBISING ?? $resultmcu->IRBLK_HOURS_BISING }}">@else{{ $physics->IBISING }}@endif
														</div>
														<div class="col-sm-10">
															Jam / Hari
														</div>
													</div>
												</div>
												<div class="col-sm-8">
													<div class="row">
														<div class="col-sm-3 vl">
															Selama
														</div>
														<div class="col-sm-2 text-center">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IYEARS_BISING" type="number" min="1" value="{{ $physics->IYEARS_BISING ?? $resultmcu->IRBLK_YEARS_BISING }}">@else{{ $physics->IYEARS_BISING }}@endif
														</div>
														<div class="col-sm-7">
															Tahun Kerja
														</div>
													</div>
												</div>
											</div>
										</td>
									</tr>
									<tr>
										<td>Menggunakan Pelindung Telinga</td>
										<td>:</td>
										<td>
											<div class="row">
												<div class="col-sm-4">
													<div class="row">
														<div class="col-sm-2">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IEAR_PROTECT" type="number" min="1" value="{{ $physics->IEAR_PROTECT ?? '' }}">@else{{ $physics->IEAR_PROTECT }}@endif
														</div>
														<div class="col-sm-10">
															% dari waktu kerja
														</div>
													</div>
												</div>
												<div class="col-sm-8">
													<div class="row">
														<div class="col-sm-3 vl">
															Selama
														</div>
														<div class="col-sm-2">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IYEARS_EAR_PROTECT" type="number" min="1" value="{{ $physics->IYEARS_EAR_PROTECT ?? '' }}">@else{{ $physics->IYEARS_EAR_PROTECT }}@endif
														</div>
														<div class="col-sm-7">
															Tahun Kerja
														</div>
													</div>
												</div>
											</div>
										</td>
									</tr>
									<tr>
										<td>Paparan Debu/Asap/Uap Bahan Kimia</td>
										<td>:</td>
										<td>
											<div class="row">
												<div class="col-sm-4">
													<div class="row">
														<div class="col-sm-2">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IDEBU" type="number" min="1" value="{{ $physics->IDEBU ?? '' }}">@else{{ $physics->IDEBU }}@endif
														</div>
														<div class="col-sm-10">
															Jam / Hari
														</div>
													</div>
												</div>
												<div class="col-sm-8">
													<div class="row">
														<div class="col-sm-3 vl">
															Selama
														</div>
														<div class="col-sm-2">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IYEARS_DEBU" type="number" min="1" value="{{ $physics->IYEARS_DEBU ?? '' }}">@else{{ $physics->IYEARS_DEBU }}@endif
														</div>
														<div class="col-sm-7">
															Tahun Kerja
														</div>
													</div>
												</div>
											</div>
										</td>
									</tr>
									<tr>
										<td>Menggunakan Pelindung Pernafasan</td>
										<td>:</td>
										<td>
											<div class="row">
												<div class="col-sm-4">
													<div class="row">
														<div class="col-sm-2">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IRESPIRATOR_PROTECT" type="number" min="1" value="{{ $physics->IRESPIRATOR_PROTECT ?? '' }}">@else{{ $physics->IRESPIRATOR_PROTECT }}@endif
														</div>
														<div class="col-sm-10">
															% dari waktu kerja
														</div>
													</div>
												</div>
												<div class="col-sm-8">
													<div class="row">
														<div class="col-sm-3 vl">
															Selama
														</div>
														<div class="col-sm-2">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IYEARS_RESPIRATOR_PROTECT" type="number" min="1" value="{{ $physics->IYEARS_RESPIRATOR_PROTECT ?? '' }}">@else{{ $physics->IYEARS_RESPIRATOR_PROTECT }}@endif
														</div>
														<div class="col-sm-7">
															Tahun Kerja
														</div>
													</div>
												</div>
											</div>
										</td>
									</tr>
									<tr>
										<td>Paparan Pekerjaan Lain</td>
										<td>:</td>
										<td>@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VOTHERS_JOB" type="text" value="{{ $physics->VOTHERS_JOB ?? '' }}">@else{{ $physics->VOTHERS_JOB }}@endif</td>
									</tr>
									<tr>
										<td>Riwayat Kecelakaan Kerja</td>
										<td>:</td>
										<td>
											<?php
												$vrkk = '';
												if ($resultmcu->BRKK_JATUH)
												{
													$vrkk .= __('mcu.fall_from_high_places') . ' ' . __('mcu.year') . ' ' . $resultmcu->IRKK_YEARS_JATUH . ', ';
												}
												if ($resultmcu->BRKK_LUKAROBEK)
												{
													$vrkk .= __('mcu.lacerated_wound_punctured_wound') . ' ' . __('mcu.year') . ' ' . $resultmcu->IRKK_YEARS_LUKAROBEK . ' ' . __('mcu.parts_of_body') . ' ' . $resultmcu->VRKK_LUKAROBEK . ', ';
												}
												if ($resultmcu->BRKK_TERSENGAT)
												{
													$vrkk .= __('mcu.electric_shock') . ' ' . __('mcu.year') . ' ' . $resultmcu->IRKK_YEARS_TERSENGAT . ', ';
												}
												if ($resultmcu->BRKK_LUKABAKAR)
												{
													$vrkk .= __('mcu.burn_injury') . ' ' . __('mcu.year') . ' ' . $resultmcu->IRKK_YEARS_LUKABAKAR . ' ' . __('mcu.parts_of_body') . ' ' . $resultmcu->VRKK_LUKABAKAR . ', ';
												}
												if ($resultmcu->BRKK_LUKATERSIRAM)
												{
													$vrkk .= __('mcu.contact_with_other_heat_source') . ' ' . __('mcu.year') . ' ' . $resultmcu->IRKK_YEARS_LUKATERSIRAM . ' ' . __('mcu.parts_of_body') . ' ' . $resultmcu->VRKK_LUKATERSIRAM . ', ';
												}
												if ($resultmcu->BRKK_TERHIRUP)
												{
													$vrkk .= __('mcu.chemical_inhaled_ingested') . ' ' . __('mcu.year') . ' ' . $resultmcu->IRKK_YEARS_TERHIRUP . ', ';
												}
												if ($resultmcu->BRKK_TERGULING)
												{
													$vrkk .= __('mcu.muscle_sprain') . ' ' . __('mcu.year') . ' ' . $resultmcu->IRKK_YEARS_TERGULING . ', ';
												}
												if ($resultmcu->BRKK_TERBENTUR)
												{
													$vrkk .= __('mcu.contusion') . ' ' . __('mcu.year') . ' ' . $resultmcu->IRKK_YEARS_TERBENTUR . ' ' . __('mcu.parts_of_body') . ' ' . $resultmcu->VRKK_TERBENTUR . ', ';
												}
												if ($resultmcu->BRKK_TERTIMPA)
												{
													$vrkk .= __('mcu.hit_by_an_object') . ' ' . __('mcu.year') . ' ' . $resultmcu->IRKK_YEARS_TERTIMPA . ', ';
												}
												if ($resultmcu->BRKK_TERGIGIT)
												{
													$vrkk .= __('mcu.sting') . ' ' . __('mcu.year') . ' ' . $resultmcu->IRKK_YEARS_TERGIGIT . ' ' . __('mcu.parts_of_body') . ' ' . $resultmcu->VRKK_TERGIGIT . ', ';
												}
												if ($resultmcu->BRKK_RUAM)
												{
													$vrkk .= __('mcu.skin_rash') . ' ' . __('mcu.year') . ' ' . $resultmcu->IRKK_YEARS_RUAM . ' ' . __('mcu.parts_of_body') . ' ' . $resultmcu->VRKK_RUAM . ', ';
												}
												if ($resultmcu->BRKK_KEMASUKAN)
												{
													$vrkk .= __('mcu.foreign_body_entering') . ' ' . __('mcu.year') . ' ' . $resultmcu->IRKK_YEARS_KEMASUKAN . ', ';
												}
											?>
											{{ substr($vrkk, 0, -2) }}
										</td>
									</tr>
								</tbody>
							  </table>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
								<b>Profil Fisik Umum</b>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
							  <table width="100%">
								<tbody>
									<tr>
										<td width="35%">Tinggi Badan</td>
										<td width="1%">:</td>
										<td width="64%">
											<div class="row">
												<div class="col-sm-4">
													<div class="row">
														<div class="col-sm-4 text-center">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IHEIGHT" type="number" min="1" onkeyup="countbmi()" value="{{ $physics->IHEIGHT ?? '' }}">@else{{ $physics->IHEIGHT }}@endif
														</div>
														<div class="col-sm-8">
															cm
														</div>
													</div>
												</div>
											</div>
										</td>
									</tr>
									<tr>
										<td>Berat Badan</td>
										<td>:</td>
										<td>
											<div class="row">
												<div class="col-sm-4">
													<div class="row">
														<div class="col-sm-4 text-center">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IWEIGHT" type="number" min="1" onkeyup="countbmi()" value="{{ $physics->IWEIGHT ?? '' }}">@else{{ $physics->IWEIGHT }}@endif
														</div>
														<div class="col-sm-8">
															Kg
														</div>
													</div>
												</div>
												<div class="col-sm-8">
													<div class="row">
														<div class="col-sm-8 vl">
															<div class="row">
																<div class="col-sm-3">
																	BMI=
																</div>
																<div class="col-sm-6">
																	@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="NBMI" type="text" readonly value="{{ $physics->NBMI ?? '' }}">@else{{ $physics->NBMI }}@endif
																</div>
															</div>
														</div>
														<div class="col-sm-4 vl">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VBMI" type="text" readonly value="{{ $physics->VBMI ?? '' }}">@else{{ $physics->VBMI }}@endif
														</div>
													</div>
												</div>
											</div>
										</td>
									</tr>
									<tr>
										<td>Tekanan Darah</td>
										<td>:</td>
										<td>
											<div class="row">
												<div class="col-sm-8">
													<div class="row">
														<div class="col-sm-2 text-center">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IBLOODPRESSURE1" type="number" min="1" value="{{ $physics->IBLOODPRESSURE1 ?? '' }}">@else{{ $physics->IBLOODPRESSURE1 }}@endif
														</div>
														<div class="col-sm-1 text-center">
															/
														</div>
														<div class="col-sm-2 text-center">
															@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IBLOODPRESSURE2" type="number" min="1" value="{{ $physics->IBLOODPRESSURE2 ?? '' }}">@else{{ $physics->IBLOODPRESSURE2 }}@endif
														</div>
														<div class="col-sm-7">
															mmHg
														</div>
													</div>
												</div>
											</div>
										</td>
									</tr>
								</tbody>
							  </table>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
								<b>Penglihatan dan Warna</b>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
							  <table width="100%">
								<tbody>
									<tr>
										<td width="30%">Ketajaman Penglihatan</td>
										<td width="15%" class="text-center">VOD</td>
										<td width="1%">:</td>
										<td width="54%">@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VVOD" type="text" value="{{ $physics->VVOD ?? '' }}">@else{{ $physics->VVOD }}@endif</td>
									</tr>
									<tr>
										<td></td>
										<td>
											<div class="vl text-center">
												VOS
											</div>
										</td>
										<td>:</td>
										<td>@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VVOS" type="text" value="{{ $physics->VVOS ?? '' }}">@else{{ $physics->VVOS }}@endif</td>
									</tr>
									<tr>
										<td>Penglihatan Warna</td>
										<td></td>
										<td>:</td>
										<td>@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<select name="VCOLORVISION"><option value="">-- Pilih Penglihatan Warna --</option>@foreach($COLORVISIONS AS $COLORVISION)<option {{ (isset($physics) && $COLORVISION['VSETDESC'] == $physics->VCOLORVISION) ? 'selected="selected"' : '' }} value="{{$COLORVISION['VSETDESC']}}">{{$COLORVISION['VSETDESC']}}</option>@endforeach</select>@else{{ $physics->VCOLORVISION }}@endif</td>
									</tr>
								</tbody>
							  </table>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
								<b>Pemeriksaan Regional</b>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
							  <table width="100%">
								<tbody>
									<tr>
										<td width="35%">Kulit dan penampakan luar</td>
										<td width="1%">:</td>
										<td width="64%">@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VSKIN" type="text" value="{{ $physics->VSKIN ?? '' }}">@else{{ $physics->VSKIN }}@endif</td>
									</tr>
									<tr>
										<td width="35%">Kepala</td>
										<td width="1%">:</td>
										<td width="64%">@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VHEAD" type="text" value="{{ $physics->VHEAD ?? '' }}">@else{{ $physics->VHEAD }}@endif</td>
									</tr>
									<tr>
										<td width="35%">Leher</td>
										<td width="1%">:</td>
										<td width="64%">@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VNECK" type="text" value="{{ $physics->VNECK ?? '' }}">@else{{ $physics->VNECK }}@endif</td>
									</tr>
									<tr>
										<td width="35%">Dada - Sistem pernafasan</td>
										<td width="1%">:</td>
										<td width="64%">@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VRESPIRATION" type="text" value="{{ $physics->VRESPIRATION ?? '' }}">@else{{ $physics->VRESPIRATION }}@endif</td>
									</tr>
									<tr>
										<td width="35%">Dada - Sistem kardiovaskular</td>
										<td width="1%">:</td>
										<td width="64%">@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VCARDIO" type="text" value="{{ $physics->VCARDIO ?? '' }}">@else{{ $physics->VCARDIO }}@endif</td>
									</tr>
									<tr>
										<td width="35%">Perut</td>
										<td width="1%">:</td>
										<td width="64%">@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VSTOMACH" type="text" value="{{ $physics->VSTOMACH ?? '' }}">@else{{ $physics->VSTOMACH }}@endif</td>
									</tr>
									<tr>
										<td width="35%">Panggul / pelvis</td>
										<td width="1%">:</td>
										<td width="64%">@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VPELVIS" type="text" value="{{ $physics->VPELVIS ?? '' }}">@else{{ $physics->VPELVIS }}@endif</td>
									</tr>
									<tr>
										<td width="35%">Tulang belakang</td>
										<td width="1%">:</td>
										<td width="64%">@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VSPINE" type="text" value="{{ $physics->VSPINE ?? '' }}">@else{{ $physics->VSPINE }}@endif</td>
									</tr>
									<tr>
										<td width="35%">Anggota gerak</td>
										<td width="1%">:</td>
										<td width="64%">@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VMOTION" type="text" value="{{ $physics->VMOTION ?? '' }}">@else{{ $physics->VMOTION }}@endif</td>
									</tr>
									<tr>
										<td width="35%">Temuan Lainnya</td>
										<td width="1%">:</td>
										<td width="64%">@if (!isset($physics) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<textarea name="VOTHER_PHYSIC" rows="3" style="width: 100%;">{{ $physics->VOTHER_PHYSIC ?? '' }}</textarea>@else<span style="white-space: pre-line">{{ $physics->VOTHER_PHYSIC }}</span>@endif</td>
									</tr>
								</tbody>
							  </table>
							</div>
						 </div>
						<br/>
						<div class="float-right">
							<div id="hbutton" class="col-sm-12">
							  @if ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("ADM") && $section == 1)
								  <button type="submit" class="btn-cstm btn-primary btn-sz">Submit</button>
							  @endif
							</div>
						</div>
					  @if ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("ADM") && $section == 1)
						  </form>
					  @endif
				   </div>
				</div>
			@endif
			
			<div class="pagebreak"></div>
			@if ((App\Http\Controllers\Controller::check_role("PRMDC") && $section == 3) || ((Session::get('nameuser') == $resultmcu->VNAME || App\Http\Controllers\Controller::check_role("ADM") || App\Http\Controllers\Controller::check_role("PRMDC") || App\Http\Controllers\Controller::check_role("DCTR") || App\Http\Controllers\Controller::check_role("HRADM") || App\Http\Controllers\Controller::check_role("HRRCT")) && $section > 3))
				<div {{ $resultmcu->BSPIRO == '0' && $resultmcu->BAUDIO == '0' ? 'id=hbutton' : '' }} class="card">
				   <div class="card-body">
					  @if ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("PRMDC") && $section == 3)
						  <form id="form-confirm" data-url="/resultmcu/save" method="post">
							 <input name="VREGNO" type="hidden" value="{{ $resultmcu->VREGNO ?? '' }}">
							 <input name="section" type="hidden" value="{{ $section }}">
					  @endif
						 <div class="row">
							<div class="col-sm-12">
							   <label class="control-label col-sm-12 text-center">Rincian Pemeriksaan Khusus</label>
							</div>
						 </div>
						 <div {{ $resultmcu->BSPIRO == '0' ? 'id=hbutton' : '' }}>
							<div class="row">
								<div class="col-sm-12">
									<b>Hasil Pemeriksaan Spirometri :</b>
								</div>
							 </div>
							 <div class="row">
								<div class="col-sm-12">
								  <table width="100%" class="table-all-border">
									<thead>
										<tr>
											<th class="text-center">Best FVC</th>
											<th class="text-center">Expected FVC</th>
											<th class="text-center">%FVC</th>
											<th class="text-center">Best FEV1</th>
											<th class="text-center">Expected FEV1</th>
											<th class="text-center">%FEV1</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>@if (!isset($spiros) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="NBESTFVC" type="text" onkeyup="countspirofvc()" value="{{ isset($spiros->NBESTFVC) ? $spiros->NBESTFVC + 0 : '' }}">@else{{ $spiros->NBESTFVC + 0 }}@endif</td>
											<td>@if (!isset($spiros) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="NEXPECTEDFVC" type="text" onkeyup="countspirofvc()" value="{{ isset($spiros->NEXPECTEDFVC) ? $spiros->NEXPECTEDFVC + 0 : '' }}">@else{{ $spiros->NEXPECTEDFVC + 0 }}@endif</td>
											<td>@if (!isset($spiros) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="NPERCENTFVC" type="text" readonly value="{{ isset($spiros->NPERCENTFVC) ? $spiros->NPERCENTFVC + 0 : '' }}">@else{{ $spiros->NPERCENTFVC + 0 }}@endif</td>
											<td>@if (!isset($spiros) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="NBESTFEV1" type="text" onkeyup="countspirofev()" value="{{ isset($spiros->NBESTFEV1) ? $spiros->NBESTFEV1 + 0 : '' }}">@else{{ $spiros->NBESTFEV1 + 0 }}@endif</td>
											<td>@if (!isset($spiros) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="NEXPECTEDFEV1" type="text" onkeyup="countspirofev()" value="{{ isset($spiros->NEXPECTEDFEV1) ? $spiros->NEXPECTEDFEV1 + 0 : '' }}">@else{{ $spiros->NEXPECTEDFEV1 + 0 }}@endif</td>
											<td>@if (!isset($spiros) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="NPERCENTFEV1" type="text" readonly value="{{ isset($spiros->NPERCENTFEV1) ? $spiros->NPERCENTFEV1 + 0 : '' }}">@else{{ $spiros->NPERCENTFEV1 + 0 }}@endif</td>
										</tr>
									</tbody>
								  </table>
								</div>
							 </div>
							<br/>
							 <div class="row">
								<div class="col-sm-2">
									<b>Kesimpulan Spirometri :</b>
								</div>
								<div class="col-sm-10">
									@if (!isset($spiros) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="S_VREMARKS" type="text" style="width: 100%;" readonly value="{{ $spiros->VREMARKS ?? '' }}">@else{{ $spiros->VREMARKS }}@endif
								</div>
							 </div>
							 <br/>
							 @if (array_search('Spirometri', array_column($docs->toArray(), 'VDOCDESC')) || array_search('Spirometri', array_column($docs->toArray(), 'VDOCDESC')) === 0)
								 <div class="row">
									<div class="col-sm-6">
										<img src="/account/resultmcu/download/{{ $docs[array_search('Spirometri', array_column($docs->toArray(), 'VDOCDESC'))]['VDOCFILE'] }}">
									</div>
								 </div>
							 @endif
							 @if (isset($analysis))
								<div class="row">
									<div class="col-sm-6"></div>
									<div class="col-sm-6">
										Spesialis Paru  :  {{ $analysis->VDRCHEST }}
									</div>
								</div>
							 @endif
							<br/>
						 </div>
						 <div {{ $resultmcu->BAUDIO == '0' ? 'id=hbutton' : '' }}>
							<div class="row">
								<div class="col-sm-12">
									<b>Hasil Pemeriksaan Audiometri :</b>
								</div>
							 </div>
							 <div class="row">
								<div class="col-sm-12 text-center">
									<b>AUDIOMETRI KANAN</b>
								</div>
							 </div>
							 <div class="row">
								<div class="col-sm-12">
								  <table width="100%" class="table-all-border">
									<thead>
										<tr>
											<th class="text-center">500</th>
											<th class="text-center">1000</th>
											<th class="text-center">2000</th>
											<th class="text-center">3000</th>
											<th class="text-center">4000</th>
											<th class="text-center">6000</th>
											<th class="text-center">8000</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IRIGHT500" type="number" onkeyup="countaudioright()" min="1" value="{{ $audios->IRIGHT500 ?? '' }}">@else{{ $audios->IRIGHT500 }}@endif</td>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IRIGHT1000" type="number" onkeyup="countaudioright()" min="1" value="{{ $audios->IRIGHT1000 ?? '' }}">@else{{ $audios->IRIGHT1000 }}@endif</td>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IRIGHT2000" type="number" onkeyup="countaudioright()" min="1" value="{{ $audios->IRIGHT2000 ?? '' }}">@else{{ $audios->IRIGHT2000 }}@endif</td>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IRIGHT3000" type="number" min="1" value="{{ $audios->IRIGHT3000 ?? '' }}">@else{{ $audios->IRIGHT3000 }}@endif</td>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IRIGHT4000" type="number" onkeyup="countaudioright()" min="1" value="{{ $audios->IRIGHT4000 ?? '' }}">@else{{ $audios->IRIGHT4000 }}@endif</td>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IRIGHT6000" type="number" min="1" value="{{ $audios->IRIGHT6000 ?? '' }}">@else{{ $audios->IRIGHT6000 }}@endif</td>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="IRIGHT8000" type="number" min="1" value="{{ $audios->IRIGHT8000 ?? '' }}">@else{{ $audios->IRIGHT8000 }}@endif</td>
										</tr>
									</tbody>
								  </table>
								</div>
							 </div>
							 <div class="row">
								<div class="col-sm-12 text-center">
									<b>AUDIOMETRI KIRI</b>
								</div>
							 </div>
							 <div class="row">
								<div class="col-sm-12">
								  <table width="100%" class="table-all-border">
									<thead>
										<tr>
											<th class="text-center">500</th>
											<th class="text-center">1000</th>
											<th class="text-center">2000</th>
											<th class="text-center">3000</th>
											<th class="text-center">4000</th>
											<th class="text-center">6000</th>
											<th class="text-center">8000</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="ILEFT500" type="number" onkeyup="countaudioleft()" min="1" value="{{ $audios->ILEFT500 ?? '' }}">@else{{ $audios->ILEFT500 }}@endif</td>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="ILEFT1000" type="number" onkeyup="countaudioleft()" min="1" value="{{ $audios->ILEFT1000 ?? '' }}">@else{{ $audios->ILEFT1000 }}@endif</td>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="ILEFT2000" type="number" onkeyup="countaudioleft()" min="1" value="{{ $audios->ILEFT2000 ?? '' }}">@else{{ $audios->ILEFT2000 }}@endif</td>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="ILEFT3000" type="number" min="1" value="{{ $audios->ILEFT3000 ?? '' }}">@else{{ $audios->ILEFT3000 }}@endif</td>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="ILEFT4000" type="number" onkeyup="countaudioleft()" min="1" value="{{ $audios->ILEFT4000 ?? '' }}">@else{{ $audios->ILEFT4000 }}@endif</td>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="ILEFT6000" type="number" min="1" value="{{ $audios->ILEFT6000 ?? '' }}">@else{{ $audios->ILEFT6000 }}@endif</td>
											<td>@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="ILEFT8000" type="number" min="1" value="{{ $audios->ILEFT8000 ?? '' }}">@else{{ $audios->ILEFT8000 }}@endif</td>
										</tr>
									</tbody>
								  </table>
								</div>
							 </div>
							 <br/>
							 <div class="row">
								<div class="col-sm-2">
									<b>Kesimpulan Audiometri :</b>
								</div>
								<div class="col-sm-10">
									@if (!isset($audios) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="A_VREMARKS" type="text" style="width: 100%;" readonly value="{{ $audios->VREMARKS ?? '' }}"><input name="IRIGHTVALUE" type="hidden" value="{{ $audios->IRIGHTVALUE ?? '' }}"><input name="ILEFTVALUE" type="hidden" value="{{ $audios->ILEFTVALUE ?? '' }}">@else{{ $audios->VREMARKS }}@endif
								</div>
							 </div>
							 <br/>
							 @if (array_search('Audiometri', array_column($docs->toArray(), 'VDOCDESC')) || array_search('Audiometri', array_column($docs->toArray(), 'VDOCDESC')) === 0)
								 <div class="row">
									<div class="col-sm-6">
										<img src="/account/resultmcu/download/{{ $docs[array_search('Audiometri', array_column($docs->toArray(), 'VDOCDESC'))]['VDOCFILE'] }}">
									</div>
								 </div>
							 @endif
							 @if (isset($analysis))
								 <div class="row">
									<div class="col-sm-6"></div>
									<div class="col-sm-6">
										Spesialis THT  :  {{ $analysis->VDRTHT }}
									</div>
								 </div>
							 @endif
							<br/>
						 </div>
						<div class="float-right">
							<div id="hbutton" class="col-sm-12">
							  @if ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("PRMDC") && $section == 3)
								  <button type="submit" class="btn-cstm btn-primary btn-sz">Submit</button>
							  @endif
							</div>
						</div>
					  @if ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("PRMDC") && $section == 3)
						  </form>
					  @endif
				   </div>
				</div>
			@endif
			<div class="pagebreak"> </div>
			@if ((App\Http\Controllers\Controller::check_role("ANALYST") && $section == 2) || ((Session::get('nameuser') == $resultmcu->VNAME || App\Http\Controllers\Controller::check_role("ADM") || App\Http\Controllers\Controller::check_role("ANALYST") || App\Http\Controllers\Controller::check_role("PRMDC") || App\Http\Controllers\Controller::check_role("DCTR") || App\Http\Controllers\Controller::check_role("HRADM") || App\Http\Controllers\Controller::check_role("HRRCT")) && $section > 2))
				<div class="card">
				   <div class="card-body">
					  @if ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("ANALYST") && $section == 2)
						  <form id="form-confirm" data-url="/resultmcu/save" method="post">
							 <input name="VREGNO" type="hidden" value="{{ $resultmcu->VREGNO ?? '' }}">
							 <input name="section" type="hidden" value="{{ $section }}">
					  @endif
						 <div class="row">
							<div class="col-sm-12">
								<b>DARAH LENGKAP</b>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
							  <table width="100%" class="table-all-border darah-lengkap">
								<tbody>
									<tr>
										<td width="30%">Hemoglobin</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NHEMOGLOBIN" type="number" onkeyup="countref(this, 0)" value="{{ isset($checks->NHEMOGLOBIN) ? $checks->NHEMOGLOBIN + 0 : '' }}">
													@else
														{{ isset($checks->NHEMOGLOBIN) ? $checks->NHEMOGLOBIN + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NHEMOGLOBIN }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">g/dL</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">L: 12 - 18; P: 11 - 17</td>
									</tr>
									<tr>
										<td width="30%">Leukosit</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NLEUKOSIT" type="number" onkeyup="countref(this, 1)" value="{{ isset($checks->NLEUKOSIT) ? $checks->NLEUKOSIT + 0 : '' }}">
													@else
														{{ isset($checks->NLEUKOSIT) ? $checks->NLEUKOSIT + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NLEUKOSIT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">10&sup3;/uL</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">4.0 - 11.0</td>
									</tr>
									<tr>
										<td width="30%">LED</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NLED" type="number" onkeyup="countref(this, 2)" value="{{ isset($checks->NLED) ? $checks->NLED + 0 : '' }}">
													@else
														{{ isset($checks->NLED) ? $checks->NLED + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NLED }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">mm/jam</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">L: 0 - 10; P: 0 - 15</td>
									</tr>
									<tr>
										<td width="30%">Trombosit</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NTROMBOSIT" type="number" onkeyup="countref(this, 3)" value="{{ isset($checks->NTROMBOSIT) ? $checks->NTROMBOSIT + 0 : '' }}">
													@else
														{{ isset($checks->NTROMBOSIT) ? $checks->NTROMBOSIT + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NTROMBOSIT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">10&sup3;/uL</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">150 - 450</td>
									</tr>
									<tr>
										<td width="30%">Hematokrit</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NHEMATOKRIT" type="number" onkeyup="countref(this, 4)" value="{{ isset($checks->NHEMATOKRIT) ? $checks->NHEMATOKRIT + 0 : '' }}">
													@else
														{{ isset($checks->NHEMATOKRIT) ? $checks->NHEMATOKRIT + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NHEMATOKRIT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">%</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">37,0 - 54,0</td>
									</tr>
									<tr>
										<td width="30%">Eritrosit</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NERITROSIT" type="number" onkeyup="countref(this, 5)" value="{{ isset($checks->NERITROSIT) ? $checks->NERITROSIT + 0 : '' }}">
													@else
														{{ isset($checks->NERITROSIT) ? $checks->NERITROSIT + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NERITROSIT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">10&sup3;/uL </div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">4,0 - 6,5</td>
									</tr>
									<tr>
										<td width="30%">MCV</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NMCV" type="number" onkeyup="countref(this, 6)" value="{{ isset($checks->NMCV) ? $checks->NMCV + 0 : '' }}">
													@else
														{{ isset($checks->NMCV) ? $checks->NMCV + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NMCV }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">fL</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">80 - 100</td>
									</tr>
									<tr>
										<td width="30%">MCH</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NMCH" type="number" onkeyup="countref(this, 7)" value="{{ isset($checks->NMCH) ? $checks->NMCH + 0 : '' }}">
													@else
														{{ isset($checks->NMCH) ? $checks->NMCH + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NMCH }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">pg</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">27,0 - 32,0</td>
									</tr>
									<tr>
										<td width="30%">MCHC</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NMCHC" type="number" onkeyup="countref(this, 8)" value="{{ isset($checks->NMCHC) ? $checks->NMCHC + 0 : '' }}">
													@else
														{{ isset($checks->NMCHC) ? $checks->NMCHC + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NMCHC }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">g/dL</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">32 - 36</td>
									</tr>
									<tr>
										<td width="30%">RDW</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NRDW" type="number" onkeyup="countref(this, 9)" value="{{ isset($checks->NRDW) ? $checks->NRDW + 0 : '' }}">
													@else
														{{ isset($checks->NRDW) ? $checks->NRDW + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NRDW }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">%</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">11 - 16</td>
									</tr>
									<tr>
										<td width="30%">PDW</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NPDW" type="number" onkeyup="countref(this, 10)" value="{{ isset($checks->NPDW) ? $checks->NPDW + 0 : '' }}">
													@else
														{{ isset($checks->NPDW) ? $checks->NPDW + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NPDW }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">%</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">10 - 18</td>
									</tr>
									<tr>
										<td width="30%">MPV</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NMPV" type="number" onkeyup="countref(this, 11)" value="{{ isset($checks->NMPV) ? $checks->NMPV + 0 : '' }}">
													@else
														{{ isset($checks->NMPV) ? $checks->NMPV + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NMPV }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">fL</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">6,5 - 12</td>
									</tr>
									<tr>
										<td width="30%">PCT</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NPCT" type="number" onkeyup="countref(this, 12)" value="{{ isset($checks->NPCT) ? $checks->NPCT + 0 : '' }}">
													@else
														{{ isset($checks->NPCT) ? $checks->NPCT + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NPCT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">%</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">0,108 - 0,282</td>
									</tr>
									<tr>
										<td width="30%">Difftell</td>
										<td width="40%"></td>
										<td width="30%"></td>
									</tr>
									<tr>
										<td width="30%">&nbsp;&nbsp;&nbsp;Granulosit</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NGRANULOSIT" type="number" onkeyup="countref(this, 13)" value="{{ isset($checks->NGRANULOSIT) ? $checks->NGRANULOSIT + 0 : '' }}">
													@else
														{{ isset($checks->NGRANULOSIT) ? $checks->NGRANULOSIT + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NGRANULOSIT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">%</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">50 - 76</td>
									</tr>
									<tr>
										<td width="30%">&nbsp;&nbsp;&nbsp;Limfosit</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NLIMFOSIT" type="number" onkeyup="countref(this, 14)" value="{{ isset($checks->NLIMFOSIT) ? $checks->NLIMFOSIT + 0 : '' }}">
													@else
														{{ isset($checks->NLIMFOSIT) ? $checks->NLIMFOSIT + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NLIMFOSIT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">%</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">20 - 40</td>
									</tr>
									<tr>
										<td width="30%">&nbsp;&nbsp;&nbsp;Mid range WBC</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NMIDRANGEWBC" type="number" onkeyup="countref(this, 15)" value="{{ isset($checks->NMIDRANGEWBC) ? $checks->NMIDRANGEWBC + 0 : '' }}">
													@else
														{{ isset($checks->NMIDRANGEWBC) ? $checks->NMIDRANGEWBC + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NMIDRANGEWBC }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">%</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">0 - 12</td>
									</tr>
								</tbody>
							  </table>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
								<b>PROFIL LIPID</b>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
							  <table width="100%" class="table-all-border">
								<tbody>
									<tr>
										<td width="30%">Kolesterol Total</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NKOLESTEROLTOT" type="number" onkeyup="countref(this, 16)" value="{{ isset($checks->NKOLESTEROLTOT) ? $checks->NKOLESTEROLTOT + 0 : '' }}">
													@else
														{{ isset($checks->NKOLESTEROLTOT) ? $checks->NKOLESTEROLTOT + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NKOLESTEROLTOT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">mg/dL</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">&lt; 200</td>
									</tr>
									<tr>
										<td width="30%">HDL</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NHDL" type="number" onkeyup="countref(this, 17)" value="{{ isset($checks->NHDL) ? $checks->NHDL + 0 : '' }}">
													@else
														{{ isset($checks->NHDL) ? $checks->NHDL + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NHDL }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">mg/dL</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">L: >45; P >55</td>
									</tr>
									<tr>
										<td width="30%">LDL</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NLDL" type="number" onkeyup="countref(this, 18)" value="{{ isset($checks->NLDL) ? $checks->NLDL + 0 : '' }}">
													@else
														{{ isset($checks->NLDL) ? $checks->NLDL + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NLDL }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">mg/dL</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">&lt; 130</td>
									</tr>
									<tr>
										<td width="30%">Trigliserida</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NTRIGLISERIDA" type="number" onkeyup="countref(this, 19)" value="{{ isset($checks->NTRIGLISERIDA) ? $checks->NTRIGLISERIDA + 0 : '' }}">
													@else
														{{ isset($checks->NTRIGLISERIDA) ? $checks->NTRIGLISERIDA + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NTRIGLISERIDA }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">mg/dL</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">&lt; 150</td>
									</tr>
								</tbody>
							  </table>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
								<b>GULA DARAH</b>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
							  <table width="100%" class="table-all-border">
								<tbody>
									<tr>
										<td width="30%">KGD Puasa</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NKGDPUASA" type="number" onkeyup="countref(this, 20)" value="{{ isset($checks->NKGDPUASA) ? $checks->NKGDPUASA + 0 : '' }}">
													@else
														{{ isset($checks->NKGDPUASA) ? $checks->NKGDPUASA + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NKGDPUASA }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">mg/dL</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">75 - 110</td>
									</tr>
								</tbody>
							  </table>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
								<b>FAAL HATI</b>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
							  <table width="100%" class="table-all-border faal-hati">
								<tbody>
									<tr>
										<td width="30%">SGOT</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NSGOT" type="number" onkeyup="countref(this, 21)" value="{{ isset($checks->NSGOT) ? $checks->NSGOT + 0 : '' }}">
													@else
														{{ isset($checks->NSGOT) ? $checks->NSGOT + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NSGOT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">U/L</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">P: &lt;31  L: &lt;40</td>
									</tr>
									<tr>
										<td width="30%">SGPT</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NSGPT" type="number" onkeyup="countref(this, 22)" value="{{ isset($checks->NSGPT) ? $checks->NSGPT + 0 : '' }}">
													@else
														{{ isset($checks->NSGPT) ? $checks->NSGPT + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NSGPT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">U/L</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">P: &lt;31  L: &lt;42</td>
									</tr>
									<tr>
										<td width="30%">HBsAg</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="matchref" name="VHBSAG" type="text" onkeyup="matchref(this, 0)" value="{{ $checks->VHBSAG ?? '' }}">
													@else
														{{ $checks->VHBSAG }}<input class="matchref" type="hidden" value="{{ $checks->VHBSAG }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">Non reaktif</td>
									</tr>
									<tr>
										<td width="30%">GGT</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input name="NGGT" type="text" value="{{ isset($checks->NGGT) ? $checks->NGGT + 0 : '' }}">
													@else
														{{ isset($checks->NGGT) ? $checks->NGGT + 0 : '' }}<input type="hidden" value="{{ $checks->NGGT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%"></td>
									</tr>
									<tr>
										<td width="30%">Cholinesterase</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NCHOLINESTERASE" type="number" onkeyup="countref(this, 23)" value="{{ isset($checks->NCHOLINESTERASE) ? $checks->NCHOLINESTERASE + 0 : '' }}">
													@else
														{{ isset($checks->NCHOLINESTERASE) ? $checks->NCHOLINESTERASE + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NCHOLINESTERASE }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">U/ml</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">4.9 - 11.9</td>
									</tr>
								</tbody>
							  </table>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
								<b>FAAL GINJAL</b>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
							  <table width="100%" class="table-all-border">
								<tbody>
									<tr>
										<td width="30%">Ureum</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NUREUM" type="number" onkeyup="countref(this, 24)" value="{{ isset($checks->NUREUM) ? $checks->NUREUM + 0 : '' }}">
													@else
														{{ isset($checks->NUREUM) ? $checks->NUREUM + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NUREUM }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">mg/dL</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">10 - 50</td>
									</tr>
									<tr>
										<td width="30%">Creatinin</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NCREATININ" type="number" onkeyup="countref(this, 25)" value="{{ isset($checks->NCREATININ) ? $checks->NCREATININ + 0 : '' }}">
													@else
														{{ isset($checks->NCREATININ) ? $checks->NCREATININ + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NCREATININ }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center">mg/dL</div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">W: 0,4 - 1,1 L:0,6 - 1,3</td>
									</tr>
								</tbody>
							  </table>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
								<b>URINE RUTIN</b>
							</div>
						 </div>
						 <div class="row">
							<div class="col-sm-12">
							  <table width="100%" class="table-all-border urine-rutin">
								<tbody>
									<tr>
										<td width="30%">Reduksi</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="matchref" name="VREDUKSI" type="text" onkeyup="matchref(this, 1)" value="{{ $checks->VREDUKSI ?? '' }}">
													@else
														{{ $checks->VREDUKSI }}<input class="matchref" type="hidden" value="{{ $checks->VREDUKSI }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">Negatif</td>
									</tr>
									<tr>
										<td width="30%">Bilirubin</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="matchref" name="VBILIRUBIN" type="text" onkeyup="matchref(this, 1)" value="{{ $checks->VBILIRUBIN ?? '' }}">
													@else
														{{ $checks->VBILIRUBIN }}<input class="matchref" type="hidden" value="{{ $checks->VBILIRUBIN }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">Negatif</td>
									</tr>
									<tr>
										<td width="30%">Ketones</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="matchref" name="VKETONES" type="text" onkeyup="matchref(this, 1)" value="{{ $checks->VKETONES ?? '' }}">
													@else
														{{ $checks->VKETONES }}<input class="matchref" type="hidden" value="{{ $checks->VKETONES }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">Negatif</td>
									</tr>
									<tr>
										<td width="30%">Berat Jenis</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NBRTJENIS" type="number" onkeyup="countref(this, 26)" value="{{ isset($checks->NBRTJENIS) ? $checks->NBRTJENIS + 0 : '' }}">
													@else
														{{ isset($checks->NBRTJENIS) ? $checks->NBRTJENIS + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NBRTJENIS }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">1,005 - 1,030</td>
									</tr>
									<tr>
										<td width="30%">pH</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NPH" type="number" onkeyup="countref(this, 27)" value="{{ isset($checks->NPH) ? $checks->NPH + 0 : '' }}">
													@else
														{{ isset($checks->NPH) ? $checks->NPH + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NPH }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">5 - 8</td>
									</tr>
									<tr>
										<td width="30%">Protein</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="matchref" name="VPROTEIN" type="text" onkeyup="matchref(this, 1)" value="{{ $checks->VPROTEIN ?? '' }}">
													@else
														{{ $checks->VPROTEIN }}<input class="matchref" type="hidden" value="{{ $checks->VPROTEIN }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">Negatif</td>
									</tr>
									<tr>
										<td width="30%">Urobilinogen</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="matchref"name="VUROBILINOGEN" type="text" onkeyup="matchref(this, 1)" value="{{ $checks->VUROBILINOGEN ?? '' }}">
													@else
														{{ $checks->VUROBILINOGEN }}<input class="matchref" type="hidden" value="{{ $checks->VUROBILINOGEN }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">Negatif</td>
									</tr>
									<tr>
										<td width="30%">Nitrit</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="matchref" name="VNITRIT" type="text" onkeyup="matchref(this, 1)" value="{{ $checks->VNITRIT ?? '' }}">
													@else
														{{ $checks->VNITRIT }}<input class="matchref" type="hidden" value="{{ $checks->VNITRIT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">Negatif</td>
									</tr>
									<tr>
										<td width="30%">Eritrosit</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NURNERITROSIT" type="number" onkeyup="countref(this, 28)" value="{{ isset($checks->NURNERITROSIT) ? $checks->NURNERITROSIT + 0 : '' }}">
													@else
														{{ isset($checks->NURNERITROSIT) ? $checks->NURNERITROSIT + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NURNERITROSIT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">&lt; 5/LPB</td>
									</tr>
									<tr>
										<td width="30%">Leukosit</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NURNLEUKOSIT" type="number" onkeyup="countref(this, 29)" value="{{ isset($checks->NURNLEUKOSIT) ? $checks->NURNLEUKOSIT + 0 : '' }}">
													@else
														{{ isset($checks->NURNLEUKOSIT) ? $checks->NURNLEUKOSIT + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NURNLEUKOSIT }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">&lt; 3/LPB</td>
									</tr>
									<tr>
										<td width="30%">Sel Epitel</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="countref" name="NSELEPITEL" type="number" onkeyup="countref(this, 30)" value="{{ isset($checks->NSELEPITEL) ? $checks->NSELEPITEL + 0 : '' }}">
													@else
														{{ isset($checks->NSELEPITEL) ? $checks->NSELEPITEL + 0 : '' }}<input class="countref" type="hidden" value="{{ $checks->NSELEPITEL }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">&lt; 2/LPB</td>
									</tr>
									<tr>
										<td width="30%">Cast</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="matchref" name="VCAST" type="text" onkeyup="matchref(this, 1)" value="{{ $checks->VCAST ?? '' }}">
													@else
														{{ $checks->VCAST }}<input class="matchref" type="hidden" value="{{ $checks->VCAST }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">Negatif</td>
									</tr>
									<tr>
										<td width="30%">Kristal</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="matchref" name="VKRISTAL" type="text" onkeyup="matchref(this, 1)" value="{{ $checks->VKRISTAL ?? '' }}">
													@else
														{{ $checks->VKRISTAL }}<input class="matchref" type="hidden" value="{{ $checks->VKRISTAL }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">Negatif</td>
									</tr>
									<tr>
										<td width="30%">Plano Test</td>
										<td width="40%">
											<div class="row">
												<div class="col-sm-2"></div>
												<div class="col-sm-3 text-center">
													@if (!isset($checks) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
														<input class="matchref" name="VPLANOTEST" type="text" onkeyup="matchref(this, 1)" value="{{ $checks->VPLANOTEST ?? '' }}">
													@else
														{{ $checks->VPLANOTEST }}<input class="matchref" type="hidden" value="{{ $checks->VPLANOTEST }}">
													@endif
												</div>
												<div class="col-sm-1 text-center form-ref">
													<label class="control-label"></label>
												</div>
												<div class="col-sm-3 text-center"></div>
												<div class="col-sm-3"></div>
											</div>
										</td>
										<td width="30%">Negatif</td>
									</tr>
								</tbody>
							  </table>
							</div>
						 </div>
						<br/>
						<div class="float-right">
							<div id="hbutton" class="col-sm-12">
							  @if ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("ANALYST") && $section == 2)
								  <button type="submit" class="btn-cstm btn-primary btn-sz">Submit</button>
							  @endif
							</div>
						</div>
					  @if ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("ANALYST") && $section == 2)
						  </form>
					  @endif
				   </div>
				</div>
			@endif
			@if ((App\Http\Controllers\Controller::check_role("DCTR") && $section == 4) || ((Session::get('nameuser') == $resultmcu->VNAME || App\Http\Controllers\Controller::check_role("ADM") || App\Http\Controllers\Controller::check_role("DCTR") || App\Http\Controllers\Controller::check_role("HRADM") || App\Http\Controllers\Controller::check_role("HRRCT")) && $section > 4))
				<div id="hbutton" class="card">
				   <div class="card-body">
						 <input name="VREGNO" type="hidden" value="{{ $resultmcu->VREGNO ?? '' }}">
						 <input name="section" type="hidden" value="{{ $section }}">
						 <div class="row">
							<div class="col-sm-2">
								<b>Koord. Team :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4)){{ isset($analysis) ? $analysis->VDRCOORD : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'COORD'; })[1]['VSETDESC'] }}<input name="VDRCOORD" type="hidden" value="{{ isset($analysis) ? $analysis->VDRCOORD : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'COORD'; })[1]['VSETDESC'] }}">@else{{ $analysis->VDRCOORD }}@endif
							</div>
						 </div>
						 <br/>
						 <div class="row">
							<div class="col-sm-2">
								<b>Patologi Klinik :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4)){{ isset($analysis) ? $analysis->VDRPATHOLOGY : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'PATHOLOGY'; })[4]['VSETDESC'] }}<input name="VDRPATHOLOGY" type="hidden" value="{{ isset($analysis) ? $analysis->VDRPATHOLOGY : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'PATHOLOGY'; })[4]['VSETDESC'] }}">@else{{ $analysis->VDRPATHOLOGY }}@endif
							</div>
						 </div>
						 <br/>
						 <div class="row">
							<div class="col-sm-2">
								<b>Jantung :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4)){{ isset($analysis) ? $analysis->VDRHEART : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'HEART'; })[3]['VSETDESC'] }}<input name="VDRHEART" type="hidden" value="{{ isset($analysis) ? $analysis->VDRHEART : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'HEART'; })[3]['VSETDESC'] }}">@else{{ $analysis->VDRHEART }}@endif
							</div>
						 </div>
						 <br/>
						 <div class="row">
							<div class="col-sm-2">
								<b>Paru :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4)){{ isset($analysis) ? $analysis->VDRCHEST : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'CHEST'; })[0]['VSETDESC'] }}<input name="VDRCHEST" type="hidden" value="{{ isset($analysis) ? $analysis->VDRCHEST : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'CHEST'; })[0]['VSETDESC'] }}">@else{{ $analysis->VDRCHEST }}@endif
							</div>
						 </div>
						 <br/>
						 <div class="row">
							<div class="col-sm-2">
								<b>THT :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4)){{ isset($analysis) ? $analysis->VDRTHT : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'THT'; })[6]['VSETDESC'] }}<input name="VDRTHT" type="hidden" value="{{ isset($analysis) ? $analysis->VDRTHT : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'THT'; })[6]['VSETDESC'] }}">@else{{ $analysis->VDRTHT }}@endif
							</div>
						 </div>
						 <br/>
						 <div class="row">
							<div class="col-sm-2">
								<b>Radiology :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4)){{ isset($analysis) ? $analysis->VDRRADIOLOGY : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'RADIOLOGY'; })[5]['VSETDESC'] }}<input name="VDRRADIOLOGY" type="hidden" value="{{ isset($analysis) ? $analysis->VDRRADIOLOGY : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'RADIOLOGY'; })[5]['VSETDESC'] }}">@else{{ $analysis->VDRRADIOLOGY }}@endif
							</div>
						 </div>
						 <br/>
						 <div class="row">
							<div class="col-sm-2">
								<b>No. Kep. :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4)){{ isset($analysis) ? $analysis->VDECISIONNO : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'COORD SIGN'; })[2]['VSETDESC1'] }}<input name="VDECISIONNO" type="hidden" value="{{ isset($analysis) ? $analysis->VDECISIONNO : array_filter($DOCTORS, function ($var) { return $var['VSETCODE'] == 'COORD SIGN'; })[2]['VSETDESC1'] }}">@else{{ $analysis->VDECISIONNO }}@endif
							</div>
						 </div>
						 <br/>
						 <div class="row">
							<div class="col-sm-2">
								<b>Tekanan darah :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VBLOODPRESSURE" type="text" style="width: 100%;" value="{{ isset($analysis) ? $analysis->VBLOODPRESSURE : '' }}">@else{{ $analysis->VBLOODPRESSURE }}@endif
							</div>
						 </div>
						 <br/>
						 <div class="row">
							<div class="col-sm-2">
								<b>Total kolesterol :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VTOTCHOLESTEROL" type="text" style="width: 100%;" value="{{ isset($analysis) ? $analysis->VTOTCHOLESTEROL : '' }}">@else{{ $analysis->VTOTCHOLESTEROL }}@endif
							</div>
						 </div>
						 <br/>
						 <div class="row">
							<div class="col-sm-2">
								<b>Kesimpulan EKG :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VEKG" type="text" style="width: 100%;" value="{{ isset($analysis) ? $analysis->VEKG : '' }}">@else{{ $analysis->VEKG }}@endif
							</div>
						 </div>
						 <br/>
						 @if (array_search('EKG', array_column($docs->toArray(), 'VDOCDESC')) || array_search('EKG', array_column($docs->toArray(), 'VDOCDESC')) === 0)
							 <div class="row">
								<div class="col-sm-6">
									<img src="/account/resultmcu/download/{{ $docs[array_search('EKG', array_column($docs->toArray(), 'VDOCDESC'))]['VDOCFILE'] }}">
								</div>
							 </div>
							 <br/>
						 @endif
						 <div class="row">
							<div class="col-sm-2">
								<b>Kesimpulan Chest X-ray :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VCHESTXRAY" type="text" style="width: 100%;" value="{{ isset($analysis) ? $analysis->VCHESTXRAY : '' }}">@else{{ $analysis->VCHESTXRAY }}@endif
							</div>
						 </div>
						 <br/>
						 @if (array_search('Rontgent', array_column($docs->toArray(), 'VDOCDESC')) || array_search('Rontgent', array_column($docs->toArray(), 'VDOCDESC')) === 0)
							 <div class="row">
								<div class="col-sm-6">
									<img src="/account/resultmcu/download/{{ $docs[array_search('Rontgent', array_column($docs->toArray(), 'VDOCDESC'))]['VDOCFILE'] }}">
								</div>
							 </div>
							 <br/>
						 @endif
						 <div class="row">
							<div class="col-sm-2">
								<b>Pemeriksaan lain :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VOTHERS" type="text" style="width: 100%;" value="{{ isset($analysis) ? $analysis->VOTHERS : '' }}">@else{{ $analysis->VOTHERS }}@endif
							</div>
						 </div>
						 <br/>
						 <div class="row">
							<div class="col-sm-2">
								<b>Kesimpulan okupasi :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VOKUPASI" type="text" style="width: 100%;" value="{{ isset($analysis) ? $analysis->VOKUPASI : '' }}">@else{{ $analysis->VOKUPASI }}@endif
							</div>
						 </div>
						 <br/>
						 <div class="row">
							<div class="col-sm-2">
								<b>Kategori resiko :</b>
							</div>
							<div class="col-sm-10">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<input name="VRISKS" type="text" style="width: 100%;" value="{{ isset($analysis) ? $analysis->VRISKS : '' }}">@else{{ $analysis->VRISKS }}@endif
							</div>
						 </div>
						 <br/>
						 <div class="row">
							<div class="col-sm-2">
								<b>Saran :</b>
							</div>
							<div class="col-sm-8">
								@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))<select name="VADVICE[]" multiple style="width: 100%;">@foreach($ADVICES AS $ADVICE)<option {{ (isset($analysis) && in_array($ADVICE['VGNRLDESC'], preg_split('/[\n]/', $analysis->VADVICE))) ? 'selected="selected"' : '' }} value="{{$ADVICE['VGNRLDESC']}}">{{$ADVICE['VGNRLDESC']}}</option>@endforeach</select>@else<span style="white-space: pre-line">{{ $analysis->VADVICE }}</span>@endif
							</div>
							@if (!isset($analysis) || ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4))
								<div class="col-sm-2">
									Hold down the Ctrl (windows) or Command (Mac) button to select multiple options.
								</div>
							@endif
						 </div>
				   </div>
				</div>
			@endif
			<div class="float-right">
				<div id="hbutton" class="col-sm-12">
				  @if ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4)
					  <button type="submit" class="btn-cstm btn-primary btn-sz">Submit</button>
				  @endif
				  @if ((Session::get('nameuser') == $resultmcu->VNAME || App\Http\Controllers\RoleAccessController::FunctionAccessCheck('P', 'F34')) && $section == 5)
					  <button type="button" class="btn-cstm btn-primary btn-sz" onclick="return print()">Print</button>
				  @endif
				  <a onclick="location.href = '/account/resultmcu'" class="btn-cstm btn-light btn-sz">Close</a>
				</div>
			</div>
			@if ($resultmcu->VDOCSTATUS == 'D' && App\Http\Controllers\Controller::check_role("DCTR") && $section >= 4)
				</form>
			@endif
         </div>
      </div>
		@if (App\Http\Controllers\Controller::check_role("ADM") && $section == 1)
			<div class="modal fade" id="modaldoc" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-md modal-dialog-centered">
					<div class="modal-content">
						<div class="modal-body">
						  <form id="form-doc">
							<input id="ILINENO" name="ILINENO" type="text" style="display: none;">
							<div class="container">
								<div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-12 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class="form-control" id="VDOCTYPE" placeholder="Document Type">
														<option value="">-- Select Type Document --</option>
														@foreach($VDOCTYPES AS $VDOCTYPE)
															<option value="{{$VDOCTYPE['VGNRLDESC']}}">{{$VDOCTYPE['VGNRLDESC']}}</option>
														@endforeach                                 
													</select>
												  </div>
											   </div>
											</div>
										</div>
										<div class="row">
											<div class="col-lg-12 col-sm-12">
											   <div class="form-group">
												  <div id="divFile" class="col-sm-12">
													 <input id="file" type="file" required>
												  </div>
												  <div id="divFileEdit" class="col-sm-12" style="display: none;">
													 <button type="button">Choose File</button>&nbsp;<label></label>
												  </div>
											   </div>
											</div>
										</div>
									</div>
									<div class="col-lg-6 col-sm-12">
									   <div class="form-group">
										  <div class="col-sm-12">
											 <textarea id="VREMARKS" class="form-control" placeholder="Remarks" rows="3"></textarea>
										  </div>
									   </div>
									</div>
								 </div>
								<br/>
								<div style="text-align:center;">
									<button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
									<a onclick="$('#modaldoc').modal('hide');" class="btn btn-cstm btn-light btn-sz">Close</a>
								</div>
							 </div>
						  </form>
						</div>
					</div>
				</div>
			</div>
		@endif
   	</div>
</section>
<script>
	var refMinMale =	[12, 4.0,  0,  150, 37.0, 4.0, 80,  27.0, 32, 11, 10, 6.5, 0.108, 50, 20, 0,  0,   45,   0,   0,   75,  0,  0,  4.9,  10, 0.6, 1.005, 5, 0, 0, 0],
		refMinFemale =	[11, 4.0,  0,  150, 37.0, 4.0, 80,  27.0, 32, 11, 10, 6.5, 0.108, 50, 20, 0,  0,   55,   0,   0,   75,  0,  0,  4.9,  10, 0.4, 1.005, 5, 0, 0, 0],
		refMaxMale =	[18, 11.0, 10, 450, 54.0, 6.5, 100, 32.0, 36, 16, 18, 12,  0.282, 76, 40, 12, 200, 4500, 130, 150, 110, 40, 42, 11.9, 50, 1.3, 1.030, 8, 5, 3, 2],
		refMaxFemale =	[17, 11.0, 15, 450, 54.0, 6.5, 100, 32.0, 36, 16, 18, 12,  0.282, 76, 40, 12, 200, 5500, 130, 150, 110, 31, 31, 11.9, 50, 1.1, 1.030, 8, 5, 3, 2];
	
	var refMatch =	['Non reaktif', 'Negatif'];
	
	var fvc = '', fev = '';
	
	var right = '', left = '';
	
	$(document).ready(function() {
		$('#divFile').on('change', 'input', function(){
			$('#divFile').css('display', 'block');
			$('#divFileEdit').css('display', 'none');
		});
		
		$.each($('.countref'), function( index, value ) {
			countref(value, index);
		});
		
		$.each($('.matchref'), function( index, value ) {
			if (index == 0) {
				matchref(value, index);
			} else {
				matchref(value, 1);
			}
		});
		
		var darahLengkap = '';
		$.each($('.darah-lengkap .required'), function( index, value ) {
			darahLengkap += $($(value).closest('tr').find('td')[0]).text().trim() + ' ' + (parseFloat($(value).closest('.row').find('.countref').val()) + 0) + ' ';
		});
		$('.darah-rutin').text(darahLengkap);
		
		var faalHati = '';
		$.each($('.faal-hati .required'), function( index, value ) {
			if ($(value).closest('.row').find('.countref').length > 0) {
				faalHati += $($(value).closest('tr').find('td')[0]).text().trim() + ' ' + (parseFloat($(value).closest('.row').find('.countref').val()) + 0) + ' ';
			} else {
				faalHati += $($(value).closest('tr').find('td')[0]).text().trim() + ' ' + $(value).closest('.row').find('.matchref').val() + ' ';
			}
		});
		$('.kimia-darah').text(faalHati);
		
		var urineRutin = '';
		$.each($('.urine-rutin .required'), function( index, value ) {
			if ($(value).closest('.row').find('.countref').length > 0) {
				urineRutin += $($(value).closest('tr').find('td')[0]).text().trim() + ' ' + (parseFloat($(value).closest('.row').find('.countref').val()) + 0) + ' ';
			} else {
				urineRutin += $($(value).closest('tr').find('td')[0]).text().trim() + ' ' + $(value).closest('.row').find('.matchref').val() + ' ';
			}
		});
		$('.urinalisa').text(urineRutin);
		
		$('input[type="number"]').attr('step', 'any');
	});
	
	function remove(th) {
		swal.fire({
			text: "Do you want to delete the data?",
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Yes",
			cancelButtonText: "No"
		}).then(function (result) {
			if (result.value) {
				$(th).closest('tr').remove();
				$.each($('#tblfile tbody tr'), function( index, value ) {
					$('#tblfile tbody tr:eq(' + index + ') td:eq(3)').html((index + 1) + '<input name="ILINENO[]" type="hidden" value="' + (index + 1) + '">');
				});
			}
		});
	}

	function countbmi() {
		if ($('input[name="IWEIGHT"]').val() != '' && $('input[name="IHEIGHT"]').val() != '') {
			var vbmi, nbmi = Math.round(((parseInt($('input[name="IWEIGHT"]').val()) / ((parseInt($('input[name="IHEIGHT"]').val()) * parseInt($('input[name="IHEIGHT"]').val())) / 10000)) + Number.EPSILON) * 100) / 100;
			$('input[name="NBMI"]').val(nbmi);
			if (nbmi < 18.5) {
				vbmi = 'Underweight';
			} else if (nbmi < 24.9) {
				vbmi = 'Normal';
			} else if (nbmi < 29.9) {
				vbmi = 'Overweight';
			} else if (nbmi < 34.9) {
				vbmi = 'Obesity (Stage 1)';
			} else if (nbmi < 39.9) {
				vbmi = 'Obesity (Stage 2)';
			} else {
				vbmi = 'Extreme Obesity';
			}
			$('input[name="VBMI"]').val(vbmi);
		}
	}
	
	function toFormDoc(th, id) {
		$('#form-doc').trigger("reset");
		if (id !== undefined) {
			$.each($(th).closest('tr').find('td[data-value]'), function( index, value ) {
				var input = $('#form-doc #' + $(value).data('value') + '');
				if ($(value).data('value') == "VDOCTYPE") {
					if ($(value).text() != '') {
						$('#VDOCTYPE').prop('selectedIndex', $("#VDOCTYPE option:contains(" + $(value).text() + ")")[0].index);
					}
				} else if ($(value).data('value') == "VDOCFILE") {
					$('#divFileEdit label').text($(value).text());
				} else {
					input.val($(value).find('input').val());
				}
			});
			$('#divFile').css('display', 'none');
			$('#divFileEdit').css('display', 'block');
			$('#file').removeAttr('required');
		} else {
			$('#divFile').css('display', 'block');
			$('#divFileEdit').css('display', 'none');
			$('#file').prop('required', true);
		}
		$('#modaldoc').modal('show');
	}
	
	$(document).on("submit", "[id^=form-doc]", function (e) {
		e.preventDefault();
		var th = $('#file')[0];
		if ($('#form-doc input[name="ILINENO"]').val() != '') {
			$.each($('#tblfile tr:has(td input[name="ILINENO[]"][value="' + $('#form-doc input[name="ILINENO"]').val() + '"])').closest('tr').find('td[data-value]'), function( index, value ) {
				if ($(value).data('value') == "VDOCFILE") {
					var tdTag = $(value).closest('tr').children('td').last();
					if (th.files[0]) {
						$(value).html(th.files[0].name);
						if ($(value).closest('tr').find('[name="files[]"]').length > 0) {
							$(value).closest('tr').find('[name="files[]"]').closest('td').remove();
						}
						$(value).closest('tr').prepend('<td id="fileInput" style="display: none;"></td>');
						reloadFile();
						tdTag.html(th.files[0].name + '<input name="VDOCFILE[]" type="hidden" value="' + th.files[0].name + '">');
					} else {
						var aTag = tdTag.find('a');
						if (aTag.length > 0) {
							aTag.html($('#divFileEdit label').text() + '<input name="VDOCFILE[]" type="hidden" value="">');
							$(value).closest('tr').prepend('<td style="display: none;"><input name="files[]"></td>');
						}
					}
				} else if ($(value).data('value') == "VDOCTYPE") {
					if ($('#VDOCTYPE option:selected').val() != '') {
						$(value).html($('#VDOCTYPE option:selected').text() + '<input name="' + $(value).data('value') + '[]" type="hidden" value="' + $('#VDOCTYPE option:selected').val() + '">');
					}
				} else if ($(value).data('value') == "VREMARKS") {
					$(value).html($('#form-doc textarea[id="' + $(value).data('value') + '"]').val() + '<input name="' + $(value).data('value') + '[]" type="hidden" value="' + $('#form-doc textarea[id="' + $(value).data('value') + '"]').val() + '">');
				} else {
					$(value).html($('#form-doc input[id="' + $(value).data('value') + '"]').val() + '<input name="' + $(value).data('value') + '[]" type="hidden" value="' + $('#form-doc input[id="' + $(value).data('value') + '"]').val() + '">');
				}
			});
		} else {
			var ilineno = $('#tblfile tbody tr').length + 1;
			$('#tblfile tbody').append('<tr><td id="fileInput" style="display: none;"></td><td data-value="VREMARKS" style="display: none;"><input name="VREMARKS[]" type="hidden" value="' + $('#VREMARKS').val() + '"></td><td class="text-center"><button onClick="toFormDoc(this, \'' + ilineno + '\')" type="button" class="btn btn btn-link btn-sm"><i title="Edit" class="fas fa-edit"></i></button>&nbsp;<button onClick="remove(this)" data-id="' + ilineno + '" type="button" class="btn btn btn-link btn-sm"><i title="Delete" class="fas fa-times"></i></button></td><td data-value="ILINENO">' + ilineno + '<input name="ILINENO[]" type="hidden" value="' + ilineno + '"></td><td data-value="VDOCTYPE">' + ($('#VDOCTYPE').val() != '' ? $('#VDOCTYPE option:selected').text() : '') + '<input name="VDOCTYPE[]" type="hidden" value="' + $('#VDOCTYPE').val() + '"></td><td data-value="VDOCFILE">' + th.files[0].name + '<input name="VDOCFILE[]" type="hidden" value="' + th.files[0].name + '"></td></tr>');
			reloadFile();
		}
		$('#modaldoc').modal('hide');
	});
	
	function reloadFile () {
		$("#fileInput").append($('#file')).removeAttr("id");
		$("#file").attr('name', 'files[]').removeAttr("id").removeAttr("required");
		$('#divFile').append('<input id="file" type="file" required>');
	}
	
	$('#divFileEdit').on('click', 'button', function () {
		$('#file').trigger('click');
	});

	function countref(th, idx) {
		if ($(th).val() != '') {
			if ($('.gender').text() == 'M') {
				if (parseFloat($(th).val()) < refMinMale[idx] || parseFloat($(th).val()) > refMaxMale[idx]) {
					$(th).parent().siblings('.form-ref').addClass('required');
				} else {
					$(th).parent().siblings('.form-ref').removeClass('required');
				}
			} else {
				if (parseFloat($(th).val()) < refMinFemale[idx] || parseFloat($(th).val()) > refMaxFemale[idx]) {
					$(th).parent().siblings('.form-ref').addClass('required');
				} else {
					$(th).parent().siblings('.form-ref').removeClass('required');
				}
			}
		}
	}
	
	function matchref(th, idx) {
		if ($(th).val() != refMatch[idx] && $(th).val() != '') {
			$(th).parent().siblings('.form-ref').addClass('required');
		} else {
			$(th).parent().siblings('.form-ref').removeClass('required');
		}
	}
	
	function countspirofvc() {
		if ($('input[name="NBESTFVC"]').val() != '' && $('input[name="NEXPECTEDFVC"]').val() != '') {
			var nfvc = Math.round(((parseFloat($('input[name="NBESTFVC"]').val()) * 100 / parseFloat($('input[name="NEXPECTEDFVC"]').val())) + Number.EPSILON) * 10) / 10;
			$('input[name="NPERCENTFVC"]').val(nfvc);
			if (nfvc > 80) {
				fvc = 'Normal Restriction';
			} else if (nfvc >= 60) {
				fvc = 'Mild Restriction';
			} else if (nfvc >= 30) {
				fvc = 'Moderate Restriction';
			} else {
				fvc = 'Severe Restriction';
			}
			$('input[name="S_VREMARKS"]').val(fvc + ' - ' + fev);
		}
	}
	
	function countspirofev() {
		if ($('input[name="NBESTFEV1"]').val() != '' && $('input[name="NEXPECTEDFEV1"]').val() != '') {
			var nfev = Math.round(((parseFloat($('input[name="NBESTFEV1"]').val()) * 100 / parseFloat($('input[name="NEXPECTEDFEV1"]').val())) + Number.EPSILON) * 10) / 10;
			$('input[name="NPERCENTFEV1"]').val(nfev);
			if (nfev > 75) {
				fev = 'Normal Obstruction';
			} else if (nfev >= 60) {
				fev = 'Mild Obstruction';
			} else if (nfev >= 30) {
				fev = 'Moderate Obstruction';
			} else {
				fev = 'Severe Obstruction';
			}
			$('input[name="S_VREMARKS"]').val(fvc + ' - ' + fev);
		}
	}
	
	function countaudioright() {
		if ($('input[name="IRIGHT500"]').val() != '' && $('input[name="IRIGHT1000"]').val() != '' && $('input[name="IRIGHT2000"]').val() != '' && $('input[name="IRIGHT4000"]').val() != '') {
			var nright = (parseInt($('input[name="IRIGHT500"]').val()) + parseInt($('input[name="IRIGHT1000"]').val()) + parseInt($('input[name="IRIGHT2000"]').val()) + parseInt($('input[name="IRIGHT4000"]').val())) / 4;
			$('input[name="IRIGHTVALUE"]').val(nright);
			if (nright < 25) {
				right = 'Normal';
			} else if (nright <= 40) {
				right = 'Mild hearing impairment';
			} else if (nright <= 55) {
				right = 'Moderate Hearing Impairement';
			} else if (nright <= 70) {
				right = 'Moderately severe hearing impairement';
			} else if (nright <= 90) {
				right = 'Severe hearing impairement';
			} else {
				right = 'Profound Hearing Impairment';
			}
			right = 'Telinga Kanan : ' + right;
			$('input[name="A_VREMARKS"]').val(right + ' ' + left);
		}
	}
	
	function countaudioleft() {
		if ($('input[name="ILEFT500"]').val() != '' && $('input[name="ILEFT1000"]').val() != '' && $('input[name="ILEFT2000"]').val() != '' && $('input[name="ILEFT4000"]').val() != '') {
			var nleft = (parseInt($('input[name="ILEFT500"]').val()) + parseInt($('input[name="ILEFT1000"]').val()) + parseInt($('input[name="ILEFT2000"]').val()) + parseInt($('input[name="ILEFT4000"]').val())) / 4;
			$('input[name="ILEFTVALUE"]').val(nleft);
			if (nleft < 25) {
				left = 'Normal';
			} else if (nleft <= 40) {
				left = 'Mild hearing impairment';
			} else if (nleft <= 55) {
				left = 'Moderate Hearing Impairement';
			} else if (nleft <= 70) {
				left = 'Moderately severe hearing impairement';
			} else if (nleft <= 90) {
				left = 'Severe hearing impairement';
			} else {
				left = 'Profound Hearing Impairment';
			}
			left = 'Telinga Kiri : ' + left;
			$('input[name="A_VREMARKS"]').val(right + ' ' + left);
		}
	}
</script>
@endsection