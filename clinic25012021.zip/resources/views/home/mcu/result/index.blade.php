@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Result MCU</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Result MCU
                  </h3>
               </div>
			   <div class="card-header">
				  <h3 class="row card-title">
					 <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('E', 'F34')) { ?>
                        &nbsp;
                        <form action="resultmcu/export_excel" method="POST">
                              @csrf
                              <input type="hidden" name="no">
                              <input type="hidden" name="registration_no">
                              <input type="hidden" name="sap_id">
                              <input type="hidden" name="employee_name">
							  <input type="hidden" name="department">
							  <input type="hidden" name="verified_date">
                              <input type="hidden" name="completed_date">
                              <input type="hidden" name="result_date">
                              <input id="search" type="hidden" name="search">
                              <button class="btn btn-sz btn-primary" type="submit">Export to Excel</button>
                        </form>
                     <?php } ?>
				  </h3>
			   </div>
			   <!-- /.card-header -->
			   <div class="card-body">
               @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div>
               @endif
                  <div class="table-responsive">
                     <table id="cmresultmcu" class="table table-bordered table-striped display compact nowrap" style="width:100%">
                        <thead>
                           <tr>
                              <th>No.</th>
                              <th>Registration No.</th>
                              <th>SAP ID</th>
                              <th>Employee Name</th>
                              <th>Department</th>
							  <th data-class='verifiedDate'>Verified Date</th>
                              <th data-class='completedDate'>Completed Date</th>
                              <th data-class='resultDate'>Result Date</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
	  <div class="modal fade" id="modalchange" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-sm modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-body">
				  <form id="form-change">
					<input name="VREGNO" type="text" style="display: none;">
					<div class="container">
						<div class="row">
							<div class="col-lg-12 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="DRESERVEDOLD" class="form-control" type="text" disabled>
								  </div>
							   </div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-12 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <div class="input-group date" id="DRESERVED" data-target-input="nearest">
										<input type="text" class="form-control datetimepicker-input readonly" style="background-color: #e9ecef;" name="DRESERVED" data-target="#DRESERVED" placeholder="Reschedule to" autocomplete="off" required>
										<div class="input-group-append" data-target="#DRESERVED" data-toggle="datetimepicker">
										   <div class="input-group-text"><i class="fa fa-calendar"></i></div>
										</div>
									 </div>
								  </div>
							   </div>
							</div>
						</div>
						<br/>
						<div style="text-align:center;">
							<button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
							<a onclick="$('#modalchange').modal('hide');" class="btn-cstm btn-light btn-sz">Close</a>
						</div>
					 </div>
				  </form>
				</div>
			</div>
		</div>
	</div>
   </div>
</section>
<script>
	$(".readonly").on('keydown paste', function(e) {
        e.preventDefault();
    });
	
	function cancel(th) {
		swal.fire({
			text: "Are you sure to process data ?",
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Yes",
			cancelButtonText: "No"
		}).then(function (result) {
			if (result.value) {
				$.ajax({
					url: "/account/mcu/cancel/" + $(th).data("id"),
					type: "GET",
					dataType: "JSON",
					success: function () {
						swal.fire({
							icon: "success",
							title: "SUCCESS !!",
							text: "Cancel Success!",
						});
						location.reload();
					},
					error: function (jqXHR, textStatus, errorThrown) {
						alert("Error get data from ajax");
					}
				});
			}
		});
	}
	
	function toFormChange(th, id, old) {
		$('#form-change').trigger("reset");
		$('input[name="VREGNO"]').val(id);
		$('input[name="DRESERVEDOLD"]').val(old);
		$('#DRESERVED').datetimepicker({
			format: 'DD-MMM-YYYY',
			minDate: new Date(new Date(old).setDate(new Date(old).getDate() - 1)),
			maxDate: new Date(new Date(old).setDate(new Date(old).getDate() + 1))
		});
		$('#modalchange').modal('show');
	}
	
	$(document).on("submit", "[id=form-change]", function (e) {
		e.preventDefault();
		if ($('input[name="DRESERVED"]').val() == $('input[name="DRESERVEDOLD"]').val()) {
            swal.fire('Error', 'Reschedule to cannot be same with current schedule.', 'error');
            return false;
        }
		swal.fire({
			html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
			allowOutsideClick: false,
			showCancelButton: false,
			showConfirmButton: false,
		});
		$.ajax({
			url: "/account/mcu/reschedule/" + $('input[name="VREGNO"]').val() + "/" + $('input[name="DRESERVED"]').val(),
			type: "GET",
			dataType: "JSON",
			success: function () {
				swal.fire({
					icon: "success",
					title: "SUCCESS !!",
					text: "Reschedule Success!",
				});
				location.reload();
			},
			error: function (jqXHR, textStatus, errorThrown) {
				alert("Error get data from ajax");
			}
		});
	});
</script>
<style>
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::after{display: none}
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::before{display: none}
</style>
@endsection