@extends('layout.app') 
@section('content')
<style>
	.row .required .control-label:after { content: "*"; color: red; }
</style>
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
			<div class="col-sm-6">
				<ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
					<li class="breadcrumb-item"><a href="/account/home">Home</a></li>
					<li class="breadcrumb-item active">Registration List</li>
				</ol>
			</div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               @if (!isset($mcu))
				   <div class="card-header card-color">
					  <h3 class="card-title text-white">
						 Add Registration
					  </h3>
				   </div>
				   <!-- /.card-header -->
               @endif
			   <div class="card-body">
                  <form id="form-confirm" data-url="/mcu/save" method="post">
                     <input name="VREGNO" type="hidden" value="{{ $mcu->VREGNO ?? '' }}">
					 @if (!isset($mcu) || substr(Request::url(), strrpos(Request::url(), '/') + 1) == 'first')
						 @if (substr(Request::url(), strrpos(Request::url(), '/') + 1) == 'first')
							 <fieldset disabled="disabled">
						 @endif
						 <div class="row">
							<div class="col-lg-4 col-sm-12">
								<label class="control-label">Registration No :</label>
								<label>{{ $mcu->VREGNO ?? '' }}</label>
							</div>
							<div class="col-lg-6 col-sm-12">
								<label class="control-label">Date :</label>
								<label>{{ isset($mcu) ? $mcu->DSUBMIT->format('d F Y') : \Carbon\Carbon::now()->format('d F Y') }}</label>
							</div>
						 </div>
						 <hr style="margin-top:-0.1em">  
						 <div class="row" style="margin-top:-0.5em">
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									<div class="form-check-inline" style="padding-top:10px">
									   <input class="form-check-input" name="VIDTYPE" type="radio" value="1" {{ isset($mcu) && $mcu->VIDTYPE == '1' ? 'checked' : '' }} required>
									   <label class="form-check-label">{{ Session::get("nameuser") }}</label>
									</div>
								  </div>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									<div class="form-check-inline">
									   <input class="form-check-input" name="VIDTYPE" type="radio" value="2" {{ isset($mcu) && $mcu->VIDTYPE == '2' ? 'checked' : '' }} required {{ !isset($user) || $user->BOTHERS == '0' ? 'disabled' : '' }}>
									   <label class="form-check-label">Others</label>
									   &nbsp &nbsp
									   <div class="input-group">
											<input name="VIDNOA" class="form-control readonly" style="background-color: #e9ecef;" type="text" value="{{ isset($mcu) && $mcu->VIDTYPE == '2' ? $mcu->VIDNO : '' }}" autocomplete="off" disabled>
											<div class="input-group-append" style="cursor: pointer;" data-target="#myEmployeeModal">
											   <div class="input-group-text"><i class="fa fa-search"></i></div>
											</div>
										 </div>
									</div>
								  </div>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									<div class="form-check-inline">
									   <input class="form-check-input" name="VIDTYPE" type="radio" value="3" {{ isset($mcu) && $mcu->VIDTYPE == '3' ? 'checked' : '' }} required {{ !App\Http\Controllers\Controller::check_role("HRADM") && !App\Http\Controllers\Controller::check_role("HRRCT") ? 'disabled' : '' }}>
									   <label class="form-check-label">Candidate</label>
									   &nbsp &nbsp
										<div class="input-group">
											<input name="VNAMEB" class="form-control readonly" style="background-color: #e9ecef;" type="text" value="{{ isset($mcu) && $mcu->VIDTYPE == '3' ? $mcu->VNAME : '' }}" autocomplete="off" disabled>
											<input name="VIDNOB" class="form-control readonly" style="background-color: #e9ecef;" type="text" value="{{ isset($mcu) && $mcu->VIDTYPE == '3' ? $mcu->VIDNO : '' }}" autocomplete="off" disabled hidden>
										</div>
									</div>
								  </div>
							   </div>
							</div>
						 </div>
						 <hr style="margin-top:-0.5em">
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">Date</label>
							   </div>
							</div>
							<div class="col-lg-3 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <div class="input-group">
										<input name="DRESERVED" placeholder="Date" class="form-control readonly" style="background-color: #e9ecef;" type="text" value="{{ isset($mcu) ? $mcu->DRESERVED->format('d F Y') : '' }}" autocomplete="off" required>
										<div class="input-group-append" style="cursor: pointer;" data-toggle="{{ !isset($mcu) ? 'modal' : '' }}" data-target="#myDateModal">
										   <div class="input-group-text"><i class="fa fa-search"></i></div>
										</div>
									 </div>
								  </div>
							   </div>
							</div>
						 </div>
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">Schedule</label>
							   </div>
							</div>
							<div class="col-lg-3 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 @if (!isset($mcu))
										 <select class='form-control' name='TSESSIONTIME' required>
											<option value="">-- Select Schedule --</option>
										</select>
									 @else
										 <label>{{ $mcu->TSESSIONTIME }}</label>
									 @endif
								  </div>
							   </div>
							</div>
							<div class="col-lg-3 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <div class="form-check-inline">
									   @if (App\Http\Controllers\Controller::check_role("HRADM"))
										   <input class="form-check-input" type="checkbox" name="BDEDUCTQUOTA" value="1" {{ !isset($mcu) || $mcu->BDEDUCTQUOTA == '1' ? 'checked' : '' }}>
									   @else
										   <input class="form-check-input" type="checkbox" name="BDEDUCTQUOTA" value="1" onclick="return false;" {{ !isset($mcu) || $mcu->BDEDUCTQUOTA == '1' ? 'checked' : '' }}>
									   @endif
									   <label class="form-check-label">Deduct Quota</label>
									</div>
								  </div>
							   </div>
							</div>
						 </div>
						 @if (!isset($mcu))
							 <div class="row">
								<div class="col-lg-2 col-sm-12">
								   <div class="form-group">
									  <label class="control-label col-sm-12">Quota</label>
								   </div>
								</div>
								<div class="col-lg-2 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="QUOTA" placeholder="" class="form-control" type="text" value="{{ $mcu->QUOTA ?? '' }}" disabled>
									  </div>
								   </div>
								</div>
								<div class="col-lg-2 col-sm-12">
								   <div class="form-group">
									  <label class="control-label col-sm-12">Reserved</label>
								   </div>
								</div>
								<div class="col-lg-2 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="RESERVED" placeholder="" class="form-control" type="text" value="{{ $mcu->RESERVED ?? '' }}" disabled>
									  </div>
								   </div>
								</div>
								<div class="col-lg-2 col-sm-12">
								   <div class="form-group">
									  <label class="control-label col-sm-12">Remaining</label>
								   </div>
								</div>
								<div class="col-lg-2 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="REMAINING" placeholder="" class="form-control" type="text" value="{{ $mcu->REMAINING ?? '' }}" disabled>
									  </div>
								   </div>
								</div>
							 </div>
						 @endif
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">Format</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									<div class="form-check form-check-inline">
									   <input class="form-check-input" name="BBAHASA" type="radio" value="1" {{ isset($mcu) && $mcu->BBAHASA == '1' ? 'checked' : '' }} required>
									   <label class="form-check-label">Bahasa</label>
									</div>
									<div class="form-check form-check-inline">
									   <input class="form-check-input" name="BBAHASA" type="radio" value="0" {{ isset($mcu) && $mcu->BBAHASA == '0' ? 'checked' : '' }} required>
									   <label class="form-check-label">English</label>
									</div>
								  </div>
							   </div>
							</div>
						 </div>
						 <div class="row">
							<div class="col-lg-12 col-sm-12">
							  <label class="control-label col-sm-12"><b>History Changes Schedule</b></label>
							</div>
						 </div>
						 <div class="row">
							<div class="table-responsive  col-lg-12 col-sm-12">
							  <table border="1" width="100%">
								<thead>
								  <tr>
									<th class="text-center">No</th>
									<th class="text-center">Reserved Date</th>
									<th class="text-center">Reserved Time</th>
									<th class="text-center">Submitted Date</th>
								  </tr>
								</thead>
								<tbody>
									@foreach ($histories as $history)
										<tr>
											<td>{{ $history->ILINENO }}</td>
											<td>{{ $history->DRESERVED->format('d F Y') }}</td>
											<td>{{ $history->TSESSIONTIME }}</td>
											<td>{{ $history->DDATE->format('d F Y h:i:s A') }}</td>
										  </tr>
									@endforeach
								</tbody>
							  </table>
							</div>
						 </div>
						 <div id="candidate"></div>
						 @if (substr(Request::url(), strrpos(Request::url(), '/') + 1) == 'first')
							 </fieldset>
						 @endif
					@else
						 @if ($mcu->VDOCSTATUS == 'O' || $mcu->VDOCSTATUS == 'C' || $mcu->VDOCSTATUS == 'D' || $mcu->VDOCSTATUS == 'E' || !App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', 'F33'))
							 <fieldset disabled="disabled">
						 @endif
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div>
								  <label class="control-label col-sm-12">SAP ID</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div>
								  <div class="col-sm-12">
									 <label>{{ $mcu->VIDNO }}</label>
								  </div>
							   </div>
							</div>
							<div class="col-lg-2 col-sm-12">
							   <div>
								  <label class="control-label col-sm-12">{{ __('mcu.gender') }}</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div>
								  <div class="col-sm-12">
									 <label>{{ $mcu->VSETDESC }}</label>
								  </div>
							   </div>
							</div>
						 </div>
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div>
								  <label class="control-label col-sm-12">{{ __('mcu.employee_name') }}</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div>
								  <div class="col-sm-12">
									 <label>{{ $mcu->VNAME }}</label>
								  </div>
							   </div>
							</div>
							<div class="col-lg-2 col-sm-12">
							   <div>
								  <label class="control-label col-sm-12">Sub Personnel Area</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div>
								  <div class="col-sm-12">
									 <label>{{ $mcu->VSUBPRSNL }}</label>
								  </div>
							   </div>
							</div>
						 </div>
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div>
								  <label class="control-label col-sm-12">Personnel Area</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div>
								  <div class="col-sm-12">
									 <label>{{ $mcu->VPRSNL }}</label>
								  </div>
							   </div>
							</div>
							<div class="col-lg-2 col-sm-12">
							   <div>
								  <label class="control-label col-sm-12">Phone No.</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div>
								  <div class="col-sm-12">
									 <label>{{ $mcu->VPHONENO }}</label>
								  </div>
							   </div>
							</div>
						 </div>
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div>
								  <label class="control-label col-sm-12">Cost Center</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div>
								  <div class="col-sm-12">
									 <label>{{ $mcu->VCOSTCNTR }}</label>
								  </div>
							   </div>
							</div>
							<div class="col-lg-2 col-sm-12">
							   <div>
								  <label class="control-label col-sm-12">{{ __('mcu.address') }}</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div>
								  <div class="col-sm-12">
									 <label>{{ $mcu->VADDRESS }}</label>
								  </div>
							   </div>
							</div>
						 </div>
						 <div class="row">
							<div class="col-lg-12 col-sm-12 required">
							  <label class="control-label col-sm-12">{{ __('mcu.occupational_hazard_exposure') }}</label>
							</div>
						 </div>
						 <div class="row mcu-required">
							 <div class="col-lg-12 col-sm-12">
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRBLK_BISING" value="1" {{ isset($mcu) && $mcu->BRBLK_BISING == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.noise') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_HOURS_BISING' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_HOURS_BISING ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.hour_s_per_day_length') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_YEARS_BISING' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_YEARS_BISING ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.year_s') }}</label>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRBLK_ASAP" value="1" {{ isset($mcu) && $mcu->BRBLK_ASAP == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.smoke_gass') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_HOURS_ASAP' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_HOURS_ASAP ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.hour_s_per_day_length') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_YEARS_ASAP' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_YEARS_ASAP ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.year_s') }}</label>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRBLK_GETARAN" value="1" {{ isset($mcu) && $mcu->BRBLK_GETARAN == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.vibration') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_HOURS_GETARAN' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_HOURS_GETARAN ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.hour_s_per_day_length') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_YEARS_GETARAN' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_YEARS_GETARAN ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.year_s') }}</label>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRBLK_MONITOR" value="1" {{ isset($mcu) && $mcu->BRBLK_MONITOR == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.computer') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_HOURS_MONITOR' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_HOURS_MONITOR ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.hour_s_per_day_length') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_YEARS_MONITOR' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_YEARS_MONITOR ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.year_s') }}</label>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRBLK_DEBU" value="1" {{ isset($mcu) && $mcu->BRBLK_DEBU == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.dust') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_HOURS_DEBU' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_HOURS_DEBU ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.hour_s_per_day_length') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_YEARS_DEBU' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_YEARS_DEBU ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.year_s') }}</label>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRBLK_GERAKAN" value="1" {{ isset($mcu) && $mcu->BRBLK_GERAKAN == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.movement') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_HOURS_GERAKAN' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_HOURS_GERAKAN ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.hour_s_per_day_length') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_YEARS_GERAKAN' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_YEARS_GERAKAN ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.year_s') }}</label>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRBLK_ZATKIMIA" value="1" {{ isset($mcu) && $mcu->BRBLK_ZATKIMIA == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.chemical') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_HOURS_ZATKIMIA' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_HOURS_ZATKIMIA ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.hour_s_per_day_length') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_YEARS_ZATKIMIA' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_YEARS_ZATKIMIA ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.year_s') }}</label>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRBLK_MENDORONG" value="1" {{ isset($mcu) && $mcu->BRBLK_MENDORONG == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.pushing') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_HOURS_MENDORONG' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_HOURS_MENDORONG ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.hour_s_per_day_length') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_YEARS_MENDORONG' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_YEARS_MENDORONG ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.year_s') }}</label>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRBLK_PANAS" value="1" {{ isset($mcu) && $mcu->BRBLK_PANAS == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.heat') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_HOURS_PANAS' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_HOURS_PANAS ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.hour_s_per_day_length') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_YEARS_PANAS' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_YEARS_PANAS ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.year_s') }}</label>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRBLK_MENGANGKAT" value="1" {{ isset($mcu) && $mcu->BRBLK_MENGANGKAT == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.lifting') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_HOURS_MENGANGKAT' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_HOURS_MENGANGKAT ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.hour_s_per_day_length') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IRBLK_YEARS_MENGANGKAT' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IRBLK_YEARS_MENGANGKAT ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.year_s') }}</label>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
							 </div>
						 </div>
						 <div class="row">
							<div class="col-lg-12 col-sm-12">
							  <label class="control-label col-sm-12" style="color: red;">(*){{ __('mcu.must_be_filled_at_least_one_checkbox') }}</label>
							</div>
						 </div>
						 <div class="row">
							<div class="col-lg-12 col-sm-12">
							  <label class="control-label col-sm-12">{{ __('mcu.accident_history') }}</label>
							</div>
						 </div>
						 <div class="row">
							 <div class="col-lg-12 col-sm-12">
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-6 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRKK_JATUH" value="1" {{ isset($mcu) && $mcu->BRKK_JATUH == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.fall_from_high_places') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-1 col-sm-12">
											   <div class="form-group">
												  <label class="control-label">{{ __('mcu.year') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div>
													 <select class='form-control' name='IRKK_YEARS_JATUH' disabled>
														<option value="">-- Select --</option>
														@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
															<option {{ $i == $mcu->IRKK_YEARS_JATUH ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-6 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRKK_TERGULING" value="1" {{ isset($mcu) && $mcu->BRKK_TERGULING == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.muscle_sprain') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-1 col-sm-12">
											   <div class="form-group">
												  <label class="control-label">{{ __('mcu.year') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div>
													 <select class='form-control' name='IRKK_YEARS_TERGULING' disabled>
														<option value="">-- Select --</option>
														@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
															<option {{ $i == $mcu->IRKK_YEARS_TERGULING ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-6 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRKK_LUKAROBEK" value="1" {{ isset($mcu) && $mcu->BRKK_LUKAROBEK == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.lacerated_wound_punctured_wound') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-1 col-sm-12">
											   <div class="form-group">
												  <label class="control-label">{{ __('mcu.year') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div>
													 <select class='form-control' name='IRKK_YEARS_LUKAROBEK' disabled>
														<option value="">-- Select --</option>
														@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
															<option {{ $i == $mcu->IRKK_YEARS_LUKAROBEK ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													<input name="VRKK_LUKAROBEK" class="form-control" type="text" value="{{ $mcu->VRKK_LUKAROBEK }}" placeholder="{{ __('mcu.parts_of_body') }}" disabled>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-6 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRKK_TERBENTUR" value="1" {{ isset($mcu) && $mcu->BRKK_TERBENTUR == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.contusion') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-1 col-sm-12">
											   <div class="form-group">
												  <label class="control-label">{{ __('mcu.year') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div>
													 <select class='form-control' name='IRKK_YEARS_TERBENTUR' disabled>
														<option value="">-- Select --</option>
														@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
															<option {{ $i == $mcu->IRKK_YEARS_TERBENTUR ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													<input name="VRKK_TERBENTUR" class="form-control" type="text" value="{{ $mcu->VRKK_TERBENTUR }}" placeholder="{{ __('mcu.parts_of_body') }}" disabled>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-6 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRKK_TERSENGAT" value="1" {{ isset($mcu) && $mcu->BRKK_TERSENGAT == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.electric_shock') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-1 col-sm-12">
											   <div class="form-group">
												  <label class="control-label">{{ __('mcu.year') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div>
													 <select class='form-control' name='IRKK_YEARS_TERSENGAT' disabled>
														<option value="">-- Select --</option>
														@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
															<option {{ $i == $mcu->IRKK_YEARS_TERSENGAT ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-6 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRKK_TERTIMPA" value="1" {{ isset($mcu) && $mcu->BRKK_TERTIMPA == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.hit_by_an_object') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-1 col-sm-12">
											   <div class="form-group">
												  <label class="control-label">{{ __('mcu.year') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div>
													 <select class='form-control' name='IRKK_YEARS_TERTIMPA' disabled>
														<option value="">-- Select --</option>
														@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
															<option {{ $i == $mcu->IRKK_YEARS_TERTIMPA ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-6 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRKK_LUKABAKAR" value="1" {{ isset($mcu) && $mcu->BRKK_LUKABAKAR == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.burn_injury') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-1 col-sm-12">
											   <div class="form-group">
												  <label class="control-label">{{ __('mcu.year') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div>
													 <select class='form-control' name='IRKK_YEARS_LUKABAKAR' disabled>
														<option value="">-- Select --</option>
														@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
															<option {{ $i == $mcu->IRKK_YEARS_LUKABAKAR ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													<input name="VRKK_LUKABAKAR" class="form-control" type="text" value="{{ $mcu->VRKK_LUKABAKAR }}" placeholder="{{ __('mcu.parts_of_body') }}" disabled>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-6 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRKK_TERGIGIT" value="1" {{ isset($mcu) && $mcu->BRKK_TERGIGIT == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.sting') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-1 col-sm-12">
											   <div class="form-group">
												  <label class="control-label">{{ __('mcu.year') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div>
													 <select class='form-control' name='IRKK_YEARS_TERGIGIT' disabled>
														<option value="">-- Select --</option>
														@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
															<option {{ $i == $mcu->IRKK_YEARS_TERGIGIT ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													<input name="VRKK_TERGIGIT" class="form-control" type="text" value="{{ $mcu->VRKK_TERGIGIT }}" placeholder="{{ __('mcu.parts_of_body') }}" disabled>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-6 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRKK_LUKATERSIRAM" value="1" {{ isset($mcu) && $mcu->BRKK_LUKATERSIRAM == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.contact_with_other_heat_source') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-1 col-sm-12">
											   <div class="form-group">
												  <label class="control-label">{{ __('mcu.year') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div>
													 <select class='form-control' name='IRKK_YEARS_LUKATERSIRAM' disabled>
														<option value="">-- Select --</option>
														@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
															<option {{ $i == $mcu->IRKK_YEARS_LUKATERSIRAM ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													<input name="VRKK_LUKATERSIRAM" class="form-control" type="text" value="{{ $mcu->VRKK_LUKATERSIRAM }}" placeholder="{{ __('mcu.parts_of_body') }}" disabled>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-6 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRKK_RUAM" value="1" {{ isset($mcu) && $mcu->BRKK_RUAM == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.skin_rash') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-1 col-sm-12">
											   <div class="form-group">
												  <label class="control-label">{{ __('mcu.year') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div>
													 <select class='form-control' name='IRKK_YEARS_RUAM' disabled>
														<option value="">-- Select --</option>
														@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
															<option {{ $i == $mcu->IRKK_YEARS_RUAM ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													<input name="VRKK_RUAM" class="form-control" type="text" value="{{ $mcu->VRKK_RUAM }}" placeholder="{{ __('mcu.parts_of_body') }}" disabled>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-6 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRKK_TERHIRUP" value="1" {{ isset($mcu) && $mcu->BRKK_TERHIRUP == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.chemical_inhaled_ingested') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-1 col-sm-12">
											   <div class="form-group">
												  <label class="control-label">{{ __('mcu.year') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div>
													 <select class='form-control' name='IRKK_YEARS_TERHIRUP' disabled>
														<option value="">-- Select --</option>
														@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
															<option {{ $i == $mcu->IRKK_YEARS_TERHIRUP ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-6 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRKK_KEMASUKAN" value="1" {{ isset($mcu) && $mcu->BRKK_KEMASUKAN == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.foreign_body_entering') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-1 col-sm-12">
											   <div class="form-group">
												  <label class="control-label">{{ __('mcu.year') }}</label>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div>
													 <select class='form-control' name='IRKK_YEARS_KEMASUKAN' disabled>
														<option value="">-- Select --</option>
														@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
															<option {{ $i == $mcu->IRKK_YEARS_KEMASUKAN ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
							 </div>
						 </div>
						 <div class="row">
							<div class="col-lg-12 col-sm-12">
							  <label class="control-label col-sm-12">{{ __('mcu.habit_per_second_nature') }}</label>
							</div>
						 </div>
						 <div class="row">
							 <div class="col-lg-12 col-sm-12">
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BKBS_OLAHRAGA" value="1" {{ isset($mcu) && $mcu->BKBS_OLAHRAGA == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.physical_exercise') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IKBS_TIMES_OLAHRAGA' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IKBS_TIMES_OLAHRAGA ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.time_s_per_week') }}</label>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BKBS_ALKOHOL" value="1" {{ isset($mcu) && $mcu->BKBS_ALKOHOL == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.alcohol') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IKBS_TIMES_ALKOHOL' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IKBS_TIMES_ALKOHOL ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.bottle_s_per_day') }}</label>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BKBS_MEROKOK" value="1" {{ isset($mcu) && $mcu->BKBS_MEROKOK == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.cigarettes_smoke') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IKBS_TIMES_MEROKOK' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IKBS_TIMES_MEROKOK ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.pcs_per_day') }}</label>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-3 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BKBS_MINUMKOPI" value="1" {{ isset($mcu) && $mcu->BKBS_MINUMKOPI == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.coffee') }}</label>
													</div>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <select class='form-control' name='IKBS_TIMES_MINUMKOPI' disabled>
														<option value="">-- Select --</option>
														@for ($i = 1; $i <= 8; $i++)
															<option {{ $i == $mcu->IKBS_TIMES_MINUMKOPI ? 'selected="selected"' : '' }} value="{{ $i }}">{{ $i }}</option>
														@endfor
													</select>
												  </div>
											   </div>
											</div>
											<div class="col-lg-2 col-sm-12" style="padding-left: 0; padding-right: 0;">
											   <div class="form-group">
												  <label class="control-label col-sm-12">{{ __('mcu.glass_es_per_day') }}</label>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
							 </div>
						 </div>
						 <div class="row">
							<div class="col-lg-12 col-sm-12">
							  <label class="control-label col-sm-12">{{ __('mcu.history_of_family_disease') }}</label>
							</div>
						 </div>
						 <div class="row">
							 <div class="col-lg-12 col-sm-12">
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-7 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRPK_JANTUNG" value="1" {{ isset($mcu) && $mcu->BRPK_JANTUNG == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.heart_disease') }}</label>
													</div>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-7 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRPK_KANKER" value="1" {{ isset($mcu) && $mcu->BRPK_KANKER == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.tumor_or_cancer') }}</label>
													</div>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-7 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRPK_DARAHTINGGI" value="1" {{ isset($mcu) && $mcu->BRPK_DARAHTINGGI == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.hypertension') }}</label>
													</div>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-7 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRPK_GANGGUANJIWA" value="1" {{ isset($mcu) && $mcu->BRPK_GANGGUANJIWA == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.mental_disorder') }}</label>
													</div>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-7 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRPK_DIABETES" value="1" {{ isset($mcu) && $mcu->BRPK_DIABETES == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.diabetes_melitus') }}</label>
													</div>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-7 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRPK_GINJAL" value="1" {{ isset($mcu) && $mcu->BRPK_GINJAL == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.kidney_disease') }}</label>
													</div>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-7 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRPK_STROKE" value="1" {{ isset($mcu) && $mcu->BRPK_STROKE == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.stroke') }}</label>
													</div>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-7 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRPK_SALURAN" value="1" {{ isset($mcu) && $mcu->BRPK_SALURAN == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.disorder_of_digestive_system') }}</label>
													</div>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
								 <div class="row">
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-7 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <div class="form-check-inline">
													   <input class="form-check-input" type="checkbox" name="BRPK_PARU" value="1" {{ isset($mcu) && $mcu->BRPK_PARU == '1' ? 'checked' : '' }}>
													   <label class="form-check-label">{{ __('mcu.lung_disease') }}</label>
													</div>
												  </div>
											   </div>
											</div>
									   </div>
									</div>
									<div class="col-lg-6 col-sm-12">
										<div class="row">
											<div class="col-lg-7 col-sm-12">
											   <div class="form-group">
												  <div class="col-sm-12">
													 <input name="VRPK_OTHER" class="form-control" type="text" value="{{ $mcu->VRPK_OTHER }}" placeholder="{{ __('mcu.other') }}">
												  </div>
											   </div>
											</div>
									   </div>
									</div>
								 </div>
							 </div>
						 </div>
						 <div class="row">
							<div class="col-lg-12 col-sm-12">
							  <label class="control-label col-sm-12">{{ __('mcu.working_history') }}</label>
							</div>
						 </div>
						 <div class="row">
							<div class="table-responsive col-lg-12 col-sm-12 form-group">
								<table id="tbldtl" border="1" class="display" style="width:100%">
									<thead>
										<tr>
											<th rowspan="2" class="text-center" style="width:5%"></th>
											<th colspan="2" class="text-center">{{ __('mcu.year_s') }}</th>
											<th rowspan="2" class="text-center">{{ __('mcu.company') }}</th>
											<th rowspan="2" class="text-center">{{ __('mcu.job_classification') }}</th>
											<th colspan="4" class="text-center">{{ __('mcu.working_exposure') }}</th>
											<th rowspan="2" class="text-center">{{ __('mcu.length') }}<br>{{ __('mcu.hour_s_per_day') }}</th>
											<th rowspan="2" class="text-center">{{ __('mcu.remarks') }}</th>
										</tr>
										<tr>
											<th class="text-center" width="5%">{{ __('mcu.from') }}</th>
											<th class="text-center" width="5%">{{ __('mcu.to') }}</th>
											<th class="text-center" width="5%">{{ __('mcu.dust') }}</th>
											<th class="text-center" width="5%">{{ __('mcu.smoke') }}</th>
											<th class="text-center" width="5%">{{ __('mcu.gass') }}</th>
											<th class="text-center" width="5%">{{ __('mcu.noise') }}</th>
										</tr>
									</thead>
									<tbody>
										@foreach ($dtls as $dtl)
											<tr>
												<td></td>
												<td>{{ $dtl->IRWP_FROM }}</td>
												<td>{{ $dtl->IRWP_TO }}</td>
												<td>{{ $dtl->VRWP_CO }}</td>
												<td>{{ $dtl->VRWP_JOBTYPE }}</td>
												<td>@if ($dtl->BRWP_DEBU == 1) <i class="fas fa-check-square"></i> @endif</td>
												<td>@if ($dtl->BRWP_ASAP == 1) <i class="fas fa-check-square"></i> @endif</td>
												<td>@if ($dtl->BRWP_GAS == 1) <i class="fas fa-check-square"></i> @endif</td>
												<td>@if ($dtl->BRWP_BISING == 1) <i class="fas fa-check-square"></i> @endif</td>
												<td>{{ $dtl->IRWP_TIME }}</td>
												<td>{{ $dtl->VRWP_REMARK }}</td>
											</tr>
										@endforeach
									</tbody>
								</table>
							</div>
						 </div>
						<div class="row">
							<div class="col-lg-12 col-sm-12 form-group">
								<button type="button" class="btn btn-cstm btn-primary btn-sz" onclick="return toForm(this);">Add Row</button>
							</div>
						</div>
						 @if ($mcu->VDOCSTATUS == 'O' || $mcu->VDOCSTATUS == 'C' || $mcu->VDOCSTATUS == 'D' || $mcu->VDOCSTATUS == 'E' || !App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', 'F33'))
							 </fieldset>
						 @endif
					@endif
					<br/>
					<div class="float-right">
						<div class="col-sm-12">
						  @if (isset($mcu) && ($mcu->VDOCSTATUS == 'O' || $mcu->VDOCSTATUS == 'E' || $mcu->VDOCSTATUS == 'D') && substr(Request::url(), strrpos(Request::url(), '/') + 1) == 'second' && App\Http\Controllers\RoleAccessController::FunctionAccessCheck('P', 'F33'))
							  <a target="_blank" href="/mcu/print/{{ base64_encode($mcu->VREGNO) }}" class="btn btn-cstm btn-primary btn-sz">Print</a>
						  @endif
						  @if ((!isset($mcu) || ($mcu->VDOCSTATUS == 'V' && substr(Request::url(), strrpos(Request::url(), '/') + 1) == 'second')) && App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', 'F33'))
							  @if (!isset($mcu))
								  <button type="submit" class="btn-cstm btn-primary btn-sz">Submit</button>
							  @else
								  <button type="submit" class="btn-cstm btn-primary btn-sz" onclick="return sbmt();">Submit</button>
							  @endif
						  @endif
						  @if (isset($mcu))
							  @if (substr(Request::url(), strrpos(Request::url(), '/') + 1) == 'first')
								  <button type="button" onclick="location.href = location.href.substring(0, location.href.indexOf(location.href.split('/')[location.href.split('/').length - 1]) - 1) + '/second'" class="btn-cstm btn-primary btn-sz">Next</button>
							  @else
								  <button type="button" onclick="location.href = location.href.substring(0, location.href.indexOf(location.href.split('/')[location.href.split('/').length - 1]) - 1) + '/first'" class="btn-cstm btn-primary btn-sz">Previous</button>
							  @endif
						  @endif
						  <a onclick="location.href = '/account/mcu'" class="btn btn-cstm btn-light btn-sz">Close</a>
						</div>
					</div>
                  </form>
               </div>
            </div>
         </div>
      </div>
	  @if (isset($user) && $user->BOTHERS == '1')
		  <div class="modal fade in" id="myEmployeeModal" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-lg modal-content">
				<div class="card mb-4">
					<div class="card-header bg-info">
						<h5 class="card-title text-white" align="center">Employee List</h5>
						<button type="button" class="close text-white" data-dismiss="modal">×</button>
					</div>
					<div class="card-body p-3">
						<div class="table-responsive">
							<table id="tblemployee" class="display" style="width:100%">
								<thead>
									<tr>
										<th>User ID</th>
										<th>Employee SAP ID</th>
										<th>Name</th>
										<th>Email Address</th>
									</tr>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		  </div>
	  @endif
	  @if (App\Http\Controllers\Controller::check_role("HRADM") || App\Http\Controllers\Controller::check_role("HRRCT"))
		  <div class="modal fade" id="modaladdnew" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-hidden="true">
			 <div class="modal-dialog modal-md modal-dialog-centered">
				<div class="modal-content">
				   <div class="modal-body">
					  <form id="form-addnew">
						 <div class="container">
							<div class="row">
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="VNAME" class="form-control" type="text" placeholder="Candidate Name" required data-required="true">
									  </div>
								   </div>
								</div>
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <div class="form-check form-check-inline">
										   <input class="form-check-input" name="VGNDRCODE" type="radio" value="M" required data-required="true">
										   <label class="form-check-label">Male</label>
										</div>
										<div class="form-check form-check-inline">
										   <input class="form-check-input" name="VGNDRCODE" type="radio" value="F" required>
										   <label class="form-check-label">Female</label>
										</div>
									  </div>
								   </div>
								</div>
							 </div>
							<div class="row">
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="VCITYBIRTH" class="form-control" type="text" placeholder="Place of birth" required data-required="true">
									  </div>
								   </div>
								</div>
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <div class="input-group date" id="DBIRTH" data-target-input="nearest">
											<input type="text" class="form-control datetimepicker-input" name="DBIRTH" data-target="#DBIRTH" placeholder="Date of birth" required data-required="true">
											<div class="input-group-append" data-target="#DBIRTH" data-toggle="datetimepicker">
											   <div class="input-group-text"><i class="fa fa-calendar"></i></div>
											</div>
										 </div>
									  </div>
								   </div>
								</div>
							 </div>
							<div class="row">
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <select class="form-control" name="VIDTYPEC" placeholder="Identity Type" required data-required="true">
											<option value="">-- Select Type Identity --</option>
											<option value="KTP">KTP</option>
											<option value="PASSPORT">PASSPORT</option>
										</select>
									  </div>
								   </div>
								</div>
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="VIDCARDNO" class="form-control" type="text" placeholder="Identity No." required data-required="true">
									  </div>
								   </div>
								</div>
							 </div>
							<div class="row">
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="VAPPLPOS" class="form-control" type="text" placeholder="Applied Position" required data-required="true">
									  </div>
								   </div>
								</div>
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="VUSRID" class="form-control" type="text" placeholder="Recruiter Name" required data-required="true">
									  </div>
								   </div>
								</div>
							 </div>
							<div class="row">
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										<div class="input-group">
											<input name="TEXT_VCOSTCNTRCODE" class="form-control readonly" style="background-color: #e9ecef;" type="text" placeholder="Department" autocomplete="off" required>
											<input name="VCOSTCNTRCODE" type="hidden" data-required="true">
											<div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myDepartmentModal">
											   <div class="input-group-text"><i class="fa fa-search"></i></div>
											</div>
										</div>
									  </div>
								   </div>
								</div>
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <div class="input-group">
											<input name="TEXT_VPRSNLAREACODE" class="form-control readonly" style="background-color: #e9ecef;" type="text" placeholder="Business Unit" autocomplete="off" required>
											<input name="VPRSNLAREACODE" type="hidden" data-required="true">
											<div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myBusinessUnitModal">
											   <div class="input-group-text"><i class="fa fa-search"></i></div>
											</div>
										</div>
									  </div>
								   </div>
								</div>
							 </div>
							 <br/>
							 <div style="text-align:center;">
								<button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
								<a onclick="closeForm();" class="btn-cstm btn-light btn-sz">Close</a>
							</div>
						 </div>
					  </form>
				   </div>
				</div>
			 </div>
		  </div>
		  <div class="modal fade in" id="myDepartmentModal" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-lg modal-content">
				<div class="card mb-4">
					<div class="card-header bg-info">
						<h5 class="card-title text-white" align="center">Department List</h5>
						<button type="button" class="close text-white" data-dismiss="modal">×</button>
					</div>
					<div class="card-body p-3">
						<div class="table-responsive">
							<table id="tbldepartment" class="display" style="width:100%">
								<thead>
									<tr>
										<th>Department Code</th>
										<th>Department Name</th>
									</tr>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		  </div>
		  <div class="modal fade in" id="myBusinessUnitModal" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-dialog modal-lg modal-content">
				<div class="card mb-4">
					<div class="card-header bg-info">
						<h5 class="card-title text-white" align="center">Business Unit List</h5>
						<button type="button" class="close text-white" data-dismiss="modal">×</button>
					</div>
					<div class="card-body p-3">
						<div class="table-responsive">
							<table id="tblbusinessunit" class="display" style="width:100%">
								<thead>
									<tr>
										<th>Business Unit Code</th>
										<th>Business Unit Name</th>
									</tr>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		  </div>
	  @endif
	  <div class="modal fade in" id="myDateModal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-lg modal-content">
			<div class="card mb-4">
				<div class="card-header bg-info">
					<h5 class="card-title text-white" align="center">Date List</h5>
					<button type="button" class="close text-white" data-dismiss="modal">×</button>
				</div>
				<div class="card-body p-3">
					<div class="table-responsive">
						<table id="tbldate" class="display" style="width:100%">
							<thead>
								<tr>
									<th>Dates</th>
									<th>Days</th>
									<th>Quota</th>
									<th>Reserved</th>
									<th>Remaining</th>
								</tr>
							</thead>
						</table>
					</div>
				</div>
			</div>
		</div>
	  </div>
	  <div class="modal fade" id="modaladdnewdtl" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-hidden="true">
		 <div class="modal-dialog modal-md modal-dialog-centered">
			<div class="modal-content">
			   <div class="modal-body">
				  <form id="form-addnewdtl">
					 <input name="ILINE" type="hidden" data-required="true">
					 <div class="container">
						<div class="row">
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <select class='form-control' name='IRWP_FROM' required data-required="true">
										<option value="">-- Select {{ __('mcu.year_s') }} {{ __('mcu.from') }} --</option>
										@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
											<option value="{{ $i }}">{{ $i }}</option>
										@endfor
									</select>
								  </div>
							   </div>
							</div>
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <select class='form-control' name='IRWP_TO' required data-required="true">
										<option value="">-- Select {{ __('mcu.year_s') }} {{ __('mcu.to') }} --</option>
										@for ($i = \Carbon\Carbon::now()->subYears(8)->format('Y'); $i <= \Carbon\Carbon::now()->format('Y'); $i++)
											<option value="{{ $i }}">{{ $i }}</option>
										@endfor
									</select>
								  </div>
							   </div>
							</div>
						 </div>
						<div class="row">
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="VRWP_CO" class="form-control" type="text" placeholder="{{ __('mcu.company') }}" required data-required="true">
								  </div>
							   </div>
							</div>
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="VRWP_JOBTYPE" class="form-control" type="text" placeholder="{{ __('mcu.job_classification') }}" required data-required="true">
								  </div>
							   </div>
							</div>
						 </div>
						<div class="row">
							<div class="col-lg-3 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <div class="form-check-inline">
									   <input class="form-check-input not-trigger-change" type="checkbox" name="BRWP_DEBU" value="1" data-required="true">
									   <label class="form-check-label">{{ __('mcu.dust') }}</label>
									</div>
								  </div>
							   </div>
							</div>
							<div class="col-lg-3 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <div class="form-check-inline">
									   <input class="form-check-input not-trigger-change" type="checkbox" name="BRWP_ASAP" value="1" data-required="true">
									   <label class="form-check-label">{{ __('mcu.smoke') }}</label>
									</div>
								  </div>
							   </div>
							</div>
							<div class="col-lg-3 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <div class="form-check-inline">
									   <input class="form-check-input not-trigger-change" type="checkbox" name="BRWP_GAS" value="1" data-required="true">
									   <label class="form-check-label">{{ __('mcu.gass') }}</label>
									</div>
								  </div>
							   </div>
							</div>
							<div class="col-lg-3 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <div class="form-check-inline">
									   <input class="form-check-input not-trigger-change" type="checkbox" name="BRWP_BISING" value="1" data-required="true">
									   <label class="form-check-label">{{ __('mcu.noise') }}</label>
									</div>
								  </div>
							   </div>
							</div>
						 </div>
						<div class="row">
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <select class='form-control' name='IRWP_TIME' required data-required="true">
										<option value="">-- Select {{ __('mcu.length') }} {{ __('mcu.hour_s_per_day') }} --</option>
										@for ($i = 1; $i <= 8; $i++)
											<option value="{{ $i }}">{{ $i }}</option>
										@endfor
									</select>
								  </div>
							   </div>
							</div>
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="VRWP_REMARK" class="form-control" type="text" placeholder="{{ __('mcu.remarks') }}" data-required="true">
								  </div>
							   </div>
							</div>
						 </div>
						 <br/>
						 <div style="text-align:center;">
							<button type="submit" class="btn-cstm btn-primary btn-sz" onclick="return sbmtmodal();">Save</button>
							<a onclick="$('#modaladdnewdtl').modal('hide');" class="btn-cstm btn-light btn-sz">Close</a>
						</div>
					 </div>
				  </form>
			   </div>
			</div>
		 </div>
	  </div>
   	</div>
</section>
<script>
	$(".readonly").on('keydown paste', function(e) {
        e.preventDefault();
    });
	
	var vt, serial = 1;
	
	$(document).ready(function() {
		$('#DBIRTH').datetimepicker({ format: 'DD-MMM-YYYY' });
		
		var table = $("#tbldepartment").DataTable({ ajax: { url: '/getdepartmentlookup', type: "GET", }, columns: [ { data: "VCOSTCNTRCODE", name: "VCOSTCNTRCODE" }, { data: "VCOSTCNTRNAME", name: "VCOSTCNTRNAME" } ] });
		$('#tbldepartment tbody').on('dblclick', 'tr', function () {
			var data = table.row(this).data();
			$('input[name="TEXT_VCOSTCNTRCODE"]').val(data['VCOSTCNTRCODE'] + ' - ' + data['VCOSTCNTRNAME']);
			$('input[name="VCOSTCNTRCODE"]').val(data['VCOSTCNTRCODE']);
			$(this).closest('.card').find('button').trigger('click');
		});
		
		var tableb = $("#tblbusinessunit").DataTable({ ajax: { url: '/getbusinessunitlookup', type: "GET", }, columns: [ { data: "VPRSNLAREACODE", name: "VPRSNLAREACODE" }, { data: "VPRSNLNAME", name: "VPRSNLNAME" } ] });
		$('#tblbusinessunit tbody').on('dblclick', 'tr', function () {
			var data = tableb.row(this).data();
			$('input[name="TEXT_VPRSNLAREACODE"]').val(data['VPRSNLAREACODE'] + ' - ' + data['VPRSNLNAME']);
			$('input[name="VPRSNLAREACODE"]').val(data['VPRSNLAREACODE']);
			$(this).closest('.card').find('button').trigger('click');
		});
		
		$('input[type=radio][name=VIDTYPE]').change(function() {
			if (this.value == '1') {
				$('input[name="VIDNOA"]').removeAttr('required').val('').prop('disabled', true).siblings().removeAttr('data-toggle');
				$('input[name="VIDNOB"]').removeAttr('required').val('').prop('disabled', true);
				vt = 1;
				$('#candidate').html('');
			}
			else if (this.value == '2') {
				$('input[name="VIDNOA"]').removeAttr('disabled').prop('required', true).siblings().attr('data-toggle', 'modal');
				$('input[name="VIDNOB"]').removeAttr('required').val('').prop('disabled', true);
				vt = 2;
				$('#candidate').html('');
			}
			else if (this.value == '3') {
				$('input[name="VIDNOA"]').removeAttr('required').val('').prop('disabled', true).siblings().removeAttr('data-toggle');
				$('#form-addnew').trigger("reset");
				$('#modaladdnew').modal('show');
			}
		});
		
		if ($('input[name=VIDTYPE]:checked').val() == undefined) {
			$('input[name="VIDTYPE"]').filter('[value=1]').prop('checked', true).trigger('change');
		}
		
		<?php
			if (isset($user) && $user->BOTHERS == '1')
			{
		?>
				var tblemployee = $("#tblemployee").DataTable({ ajax: { url: "/getemployeelookup", type: "GET" }, columns: [ { data: "VUSRID", name: "VUSRID" }, { data: "VEMPSAPID", name: "VEMPSAPID" }, { data: "VNAME", name: "VNAME" }, { data: "VMAIL", name: "VMAIL" } ] });
				$('#tblemployee').on('dblclick', 'tbody tr', function () {
					var data = tblemployee.row(this).data();
					$('input[name="VIDNOA"]').val(data['VEMPSAPID']);
					$(this).closest('.card').find('button').trigger('click');
				});
		<?php
			}
		?>
		
		<?php
			if (!isset($mcu))
			{
		?>
			var tbldate = $("#tbldate").DataTable({ ajax: { url: "/getdatelookup", type: "GET" }, columns: [ { data: "DATES", name: "DATES" }, { data: "DAYS", name: "DAYS" }, { data: "QUOTA", name: "QUOTA" }, { data: "RESERVED", name: "RESERVED" }, { data: "REMAINING", name: "REMAINING" } ] });
			$('#tbldate').on('dblclick', 'tbody tr', function () {
				var data = tbldate.row(this).data();
				if (data['REMAINING'] == '0') {
					alert('There is no remaining quota for this date');
				} else {
					$('input[name="DRESERVED"]').val(data['DATES']);
					$('input[name="QUOTA"]').val(data['QUOTA']);
					$('input[name="RESERVED"]').val(data['RESERVED']);
					$('input[name="REMAINING"]').val(data['REMAINING']);
					$(this).closest('.card').find('button').trigger('click');
					swal.fire({
						html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
						allowOutsideClick: false,
						showCancelButton: false,
						showConfirmButton: false
					});
					$.ajax({
						url: "/getschdlist/" + moment($('input[name="DRESERVED"]').val()).format('YYYY-MM-DD') + "/" + data['DAYS'],
						type: "GET",
						success: function (data) {
							$("select[name='TSESSIONTIME']").find('option').not(':first').remove();
							$.each(data, function( index, value ) {
								$("select[name='TSESSIONTIME']").append(new Option(value['TSESSIONTIME'], value['TSESSIONTIME']));
							});
							swal.close();
						}
					});
				}
			});
		<?php
			}
		?>
	});
	
	function closeForm() {
		vt == undefined ? $('input[name="VIDTYPE"]').prop('checked', false) : $('input[name="VIDTYPE"]').filter('[value=' + vt + ']').prop('checked', true);
		$('#modaladdnew').modal('hide');
	}
	
	function sbmt() {
		if ($('.mcu-required input[type="checkbox"]:checked').length == 0) {
			alert('<?php echo __('mcu.occupational_hazard_exposure') ?> <?php echo __('mcu.must_be_filled_at_least_one_checkbox') ?>');
			return false;
		}
	}
	
	function toForm(th, id) {
		$('#form-addnewdtl').trigger("reset");
		$('input[name="ILINE"]').val('');
		if (id !== undefined) {
			var trRow = $(th).closest('tr');
			$.each($('#form-addnewdtl [data-required="true"]'), function( index, value ) {
				if ($(value).is("select")) {
					$('select[name="' + $(value).attr('name') + '"]').val(trRow.find('input[name="' + $(value).attr('name') + '[]"]').val());
				} else if ($(value).attr('type') == 'checkbox') {
					if (trRow.find('input[name="' + $(value).attr('name') + '[]"]').val() == '1') {
						$('input[name="' + $(value).attr('name') + '"]').prop('checked', true);
					}
				} else {
					$('input[name="' + $(value).attr('name') + '"]').val(trRow.find('input[name="' + $(value).attr('name') + '[]"]').val());
				}
			});
		}
		$('#modaladdnewdtl').modal('show');
	}
	
	function sbmtmodal() {
		if ($('input.not-trigger-change[type="checkbox"]:checked').length == 0) {
			alert('<?php echo __('mcu.must_be_filled_at_least_one_checkbox') ?>');
			return false;
		}
	}
	
	function remove(th) {
		swal.fire({
			text: "Do you want to delete the data?",
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Yes",
			cancelButtonText: "No"
		}).then(function (result) {
			if (result.value) {
				$(th).closest('tr').remove();
			}
		});
	}
	
	$(document).on("submit", "[id=form-addnew]", function (e) {
		e.preventDefault();
		var input = '';
		$.each($('#form-addnew [data-required="true"]'), function( index, value ) {
			if ($(value).attr('name') == 'VGNDRCODE') {
				input += '<input name="' + $(value).attr('name') + '" type="hidden" value="' + $('input[name="VGNDRCODE"]:checked').val() + '">';
			} else {
				if ($(value).attr('name') == 'VNAME') {
					$('input[name="VIDNOB"]').val($(value).val());
					$('input[name="VNAMEB"]').val($(value).val());
				}
				input += '<input name="' + $(value).attr('name') + '" type="hidden" value="' + $(value).val() + '">';
			}
		});
		$('#candidate').append(input);
		$('#modaladdnew').modal('hide');
	});
	
	$(document).on("submit", "[id=form-addnewdtl]", function (e) {
		e.preventDefault();
		if ($('#form-addnewdtl input[name="ILINE"]').val() != '') {
			$.each($('#tbldtl input[value="' + $('#form-addnewdtl input[name="ILINE"]').val() + '"]').closest('tr').find('td'), function( index, value ) {
				if (index == 0) {
					
				} else if ($(value).data('value').substring(0, 1) == 'B') {
					if ($('#form-addnewdtl input[name="' + $(value).data('value') + '"]').prop('checked')) {
						$(value).html('<i class="fas fa-check-square"></i><input name="' + $(value).data('value') + '[]" type="hidden" value="' + $('#form-addnewdtl input[name="' + $(value).data('value') + '"]').val() + '">');
					} else {
						$(value).html('<input name="' + $(value).data('value') + '[]" type="hidden" value="0">');
					}
				}
				else {
					$(value).html($('#form-addnewdtl [name="' + $(value).data('value') + '"]').val() + '<input name="' + $(value).data('value') + '[]" type="hidden" value="' + $('#form-addnewdtl [name="' + $(value).data('value') + '"]').val() + '">');
				}
			});
		} else {
			var td = '';
			$.each($('#form-addnewdtl [data-required="true"]'), function( index, value ) {
				if (index == 0) {
					td += '<td data-value="' + $(value).attr('name') + '"><button onClick="toForm(this, \'' + serial.toString().padStart(13, '0') + '\')" type="button" class="btn btn-link btn-sm"><i class="fas fa-edit"></i></button>&nbsp;<button onClick="remove(this)" data-id="' + serial.toString().padStart(13, '0') + '" type="button" class="btn btn-link btn-sm"><i class="fas fa-times"></i></button><input name="' + $(value).attr('name') + '[]" type="hidden" value="' + serial.toString().padStart(13, '0') + '"></td>';
				} else if ($(value).attr('type') == 'checkbox') {
					if ($(value).prop('checked')) {
						td += '<td data-value="' + $(value).attr('name') + '"><i class="fas fa-check-square"></i><input name="' + $(value).attr('name') + '[]" type="hidden" value="' + $(value).val() + '"></td>';
					} else {
						td += '<td data-value="' + $(value).attr('name') + '"><input name="' + $(value).attr('name') + '[]" type="hidden" value="0"></td>';
					}
				} else {
					td += '<td data-value="' + $(value).attr('name') + '">' + $(value).val() + '<input name="' + $(value).attr('name') + '[]" type="hidden" value="' + $(value).val() + '"></td>';
				}
			});
			$('#tbldtl tbody').append('<tr>' + td + '</tr>');
			serial++;
		}
		$('#modaladdnewdtl').modal('hide');
	});
	
	<?php
		if (!(!isset($mcu) || substr(Request::url(), strrpos(Request::url(), '/') + 1) == 'first'))
		{
	?>
		$(document).on("change", "[type=checkbox]:not(.not-trigger-change)", function () {
			if ($(this).prop('checked')) {
				$(this).closest('.row').find('select,input').not("[type='checkbox']").removeAttr('disabled').prop('required', true);
			} else {
				$(this).closest('.row').find('select,input').not("[type='checkbox']").removeAttr('required').prop('disabled', true);
			}
		});
	<?php
		}
	?>
</script>
@endsection