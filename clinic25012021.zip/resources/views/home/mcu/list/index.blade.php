@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Registration List</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Registration List
                  </h3>
               </div>
			   <div class="card-header">
				  <div class="form-group">
					 <div class="form-group row">
						<label class="col-form-label control-label col-sm-1">Date from</label>
						<div class="col-sm-4 col-lg-2">
						   <div class="input-group date" id="DFROM" data-target-input="nearest">
							  <input type="text" class="form-control datetimepicker-input" name="DFROM" data-target="#DFROM" placeholder="DD-MMM-YYYY" required>
							  <div class="input-group-append" data-target="#DFROM" data-toggle="datetimepicker">
								 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
							  </div>
						   </div>
						</div>
						<label class="col-form-label control-label col-sm-1" style="text-align:center">to</label>
						<div class="form-group col-sm-4 col-lg-2">
						   <div class="input-group date" id="DTO" data-target-input="nearest">
							  <input type="text" class="form-control datetimepicker-input" name="DTO" data-target="#DTO" placeholder="DD-MMM-YYYY" required>
							  <div class="input-group-append" data-target="#DTO" data-toggle="datetimepicker">
								 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
							  </div>
						   </div>
						</div>
						<div class="col-lg-2 col-sm-12">
						   <div class="form-group">
							  <button class="btn btn-sz btn-primary" onclick="return LoadTable();" role="button" style="color:white;">Search</button>
						   </div>
						</div>
					 </div>
				  </div>
			   </div>
			   <div class="card-header">
				  <h3 class="row card-title">
					 <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('C', 'F33')) { ?>
						<a class="btn btn-sz btn-primary" href="mcu/form" role="button">Add Registration</a>
					 <?php } ?>
					 <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('E', 'F33')) { ?>
                        &nbsp;
                        <form action="mcu/export_excel" method="POST">
                              @csrf
                              <input type="hidden" name="from_date">
                              <input type="hidden" name="to_date">
                              <input type="hidden" name="registration_no">
                              <input type="hidden" name="sap_id">
                              <input type="hidden" name="employee_name">
							  <input type="hidden" name="personnel_area">
                              <input type="hidden" name="sub_personnel_area">
                              <input type="hidden" name="cost_center">
                              <input type="hidden" name="package">
                              <input type="hidden" name="gender">
                              <input type="hidden" name="reserved_date">
                              <input type="hidden" name="time">
                              <input type="hidden" name="document_status">
							  <input type="hidden" name="verified_date">
                              <input type="hidden" name="completed_date">
                              <input type="hidden" name="created_name">
                              <input type="hidden" name="created_date">
                              <input type="hidden" name="last_modified_name">
                              <input type="hidden" name="modified_date">
                              <input id="search" type="hidden" name="search">
                              <button class="btn btn-sz btn-primary" type="submit">Export to Excel</button>
                        </form>
                     <?php } ?>
				  </h3>
			   </div>
			   <!-- /.card-header -->
			   <div class="card-body">
               @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div>
               @endif
                  <div class="table-responsive">
                     <table id="cmmcu" class="table table-bordered table-striped display compact nowrap" style="width:100%">
                        <thead>
                           <tr>
                              <th>Action</th>
                              <th>Registration No.</th>
                              <th>SAP ID</th>
                              <th>Employee Name</th>
							  <th>Personnel Area</th>
							  <th>Sub Personnel Area</th>
							  <th>Cost Center</th>
							  <th>Package</th>
							  <th>Gender</th>
                              <th>Reserved Date</th>
                              <th>Time</th>
                              <th>Document Status</th>
                              <th>Verified Date</th>
                              <th>Completed Date</th>
                              <th>Created Name</th>
                              <th>Created Date</th>
                              <th>Last Modified Name</th>
                              <th>Modified Date</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
	  <div class="modal fade" id="modalchange" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-sm modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-body">
				  <form id="form-change">
					<input name="VREGNO" type="text" style="display: none;">
					<div class="container">
						<div class="row">
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="DRESERVEDOLD" class="form-control" type="text" disabled>
								  </div>
							   </div>
							</div>
							<div class="col-lg-6 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="TSESSIONTIMEOLD" class="form-control" type="text" disabled>
								  </div>
							   </div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-12 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <select class="form-control" name="DRESERVED" required>
										<option value="">-- Select Reschedule Date to --</option>
										@foreach($dates AS $date)
											@if($date->REMAINING > 0)
												<option data-day="{{ $date->DAYS }}" value="{{ Carbon\Carbon::parse($date->DATES)->format('d-M-Y') }}">{{ Carbon\Carbon::parse($date->DATES)->format('d-M-Y') }}</option>
											@endif
										@endforeach
									 </select>
								  </div>
							   </div>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-12 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <select class='form-control' name='TSESSIONTIME' required>
										<option value="">-- Select Reschedule Time to --</option>
									 </select>
								  </div>
							   </div>
							</div>
						</div>
						<br/>
						<div style="text-align:center;">
							<button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
							<a onclick="$('#modalchange').modal('hide');" class="btn btn-cstm btn-light btn-sz">Close</a>
						</div>
					 </div>
				  </form>
				</div>
			</div>
		</div>
	</div>
   </div>
</section>
<script>
	function proceed(th, type) {
		swal.fire({
			text: "Are you sure to process data ?",
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Yes",
			cancelButtonText: "No"
		}).then(function (result) {
			if (result.value) {
				var status = "Cancel";
				if (type == "D") {
					status = "Complete";
				} else if (type == "E") {
					status = "Verify";
				}
				swal.fire({
					html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
					allowOutsideClick: false,
					showCancelButton: false,
					showConfirmButton: false,
				});
				$.ajax({
					url: "/account/mcu/proceed/" + $(th).data("id") + "/" + type,
					type: "GET",
					dataType: "JSON",
					success: function () {
						swal.fire({
							icon: "success",
							title: "SUCCESS !!",
							text: status + " Success!",
						});
						location.reload();
					},
					error: function (jqXHR, textStatus, errorThrown) {
						alert("Error get data from ajax");
					}
				});
			}
		});
	}
	
	function toFormChange(th, id, old, oldTime) {
		$('#form-change').trigger("reset");
		$('input[name="VREGNO"]').val(id);
		$('input[name="DRESERVEDOLD"]').val(old);
		$('input[name="TSESSIONTIMEOLD"]').val(oldTime);
		$('#modalchange').modal('show');
	}
	
	function LoadTable() {
		tablemcu = $("#cmmcu").DataTable({
			pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
			destroy: true,
			processing: true,
			serverSide: true,
			dom: '<lf<t><r>ip>',
			columnDefs: [
				{ "width": "5%", "targets": 0 }
			],
			ajax: {
				url: '/ajaxmcu',
				type: "GET",
				data: function (d) {
					d.reserved_date = $('input.reserved_date').val(),
					d.verified_date = $('input.verified_date').val(),
					d.completed_date = $('input.completed_date').val(),
					d.created_date = $('input.created_date').val(),
					d.modified_date = $('input.modified_date').val(),
					d.search = $('input[type="search"]').val(),
					d.DFROM = $('input[name="DFROM"]').val(), 
					d.DTO = $('input[name="DTO"]').val()
				}
			},
			order: [[ 2, 'asc' ]],
			columns: [
				{
					data: "action",
					name: "action",
					render: function (data, type, row) {
						if (row.VDOCSTATUS == 'Cancel' || row.VDOCSTATUS == 'Complete' || row.VDOCSTATUS == 'Verify') {
							if (row.VDOCSTATUS == 'Cancel' && row.EMPNAME == '<?php echo Session::get('nameuser'); ?>') {
								return '</button>&nbsp;<button onClick="toFormChange(this, \'' + data + '\', \'' + row.DRESERVED + '\', \'' + row.TSESSIONTIME + '\')" type="button" class="btn btn-link btn-sm"><i title="Reschedule" class="fas fa-edit"></i>';
							}
							if (row.VDOCSTATUS == 'Verify' && '<?php echo App\Http\Controllers\Controller::check_role("ADM"); ?>') {
								var complete = "D";
								return '</button>&nbsp<button onClick="proceed(this, \'' + complete + '\')" data-id="' + data + '" type="button" class="btn btn-link btn-sm"><i title="Complete" class="fas fa-check"></i>';
							}
							return ''
						} else {
							var cancel = "C";
							var verify = "E";
							var action = '';
							<?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', 'F33')) { ?>
								action += '</button>&nbsp;<button onClick="toFormChange(this, \'' + data + '\', \'' + row.DRESERVED + '\', \'' + row.TSESSIONTIME + '\')" type="button" class="btn btn-link btn-sm"><i title="Reschedule" class="fas fa-edit"></i>';
							<?php } ?>
							<?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('D/C', 'F33')) { ?>
								action += '</button>&nbsp<button onClick="proceed(this, \'' + cancel + '\')" data-id="' + data + '" type="button" class="btn btn-link btn-sm"><i title="Cancel" class="fas fa-times"></i>';
							<?php } ?>
							<?php if(App\Http\Controllers\Controller::check_role("ADM")) { ?>
								action += '</button>&nbsp<button onClick="proceed(this, \'' + verify + '\')" data-id="' + data + '" type="button" class="btn btn-link btn-sm"><i title="Verify" class="fas fa-bell"></i>';
							<?php } ?>
							return action
						}
					}
				},
				{
					data: "VREGNO",
					name: "VREGNO",
					render: function (data) {
						return "<a href='mcu/form/"+ btoa(data) +"/first'>" + data + "</a>"
					}
				},
				{
					data: "VIDNO",
					name: "VIDNO"
				},
				{
					data: "EMPNAME",
					name: "EMPNAME"
				},
				{
					data: "PERSONALAREA",
					name: "PERSONALAREA"
				},
				{
					data: "SUBPERSONALAREA",
					name: "SUBPERSONALAREA"
				},
				{
					data: "COSTCENTER",
					name: "COSTCENTER"
				},
				{
					data: "PACKAGE",
					name: "PACKAGE"
				},
				{
					data: "GENDER",
					name: "GENDER"
				},
				{
					data: "DRESERVED",
					name: "DRESERVED",
					searchable: false
				},
				{
					data: "TSESSIONTIME",
					name: "TSESSIONTIME"
				},
				{
					data: "VDOCSTATUS",
					name: "VDOCSTATUS"
				},
				{
					data: "DVERIFIED",
					name: "DVERIFIED",
					searchable: false
				},
				{
					data: "DCOMPLETED",
					name: "DCOMPLETED",
					searchable: false
				},
				{
					data: "VCREA",
					name: "VCREA"
				},
				{
					data: "DCREA",
					name: "DCREA",
					searchable: false
				},
				{
					data: "VMODI",
					name: "VMODI"
				},
				{
					data: "DMODI",
					name: "DMODI",
					searchable: false
				}
			]
		});
		$('input[name="from_date"]').val($('input[name="DFROM"]').val());
		$('input[name="to_date"]').val($('input[name="DTO"]').val());
	}
	
	$(document).on("submit", "[id=form-change]", function (e) {
		e.preventDefault();
		if ($('select[name="DRESERVED"]').val() == $('input[name="DRESERVEDOLD"]').val() && $('select[name="TSESSIONTIME"]').val() == $('input[name="TSESSIONTIMEOLD"]').val()) {
            swal.fire('Error', 'Reschedule to cannot be same with current schedule.', 'error');
            return false;
        }
		<?php if(App\Http\Controllers\Controller::check_role("HRADM")) { ?>
			if (Math.round((new Date($('input[name="DRESERVEDOLD"]').val())-new Date($('select[name="DRESERVED"]').val()))/(1000*60*60*24)) == 1) {
				swal.fire('Error', 'Reschedule to cannot be h-1 with current schedule.', 'error');
				return false;
			}
		<?php } ?>
		swal.fire({
			html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
			allowOutsideClick: false,
			showCancelButton: false,
			showConfirmButton: false,
		});
		$.ajax({
			url: "/account/mcu/reschedule/" + $('input[name="VREGNO"]').val() + "/" + $('select[name="DRESERVED"]').val() + "/" + $('select[name="TSESSIONTIME"]').val(),
			type: "GET",
			dataType: "JSON",
			success: function () {
				swal.fire({
					icon: "success",
					title: "SUCCESS !!",
					text: "Reschedule Success!",
				});
				location.reload();
			},
			error: function (jqXHR, textStatus, errorThrown) {
				alert("Error get data from ajax");
			}
		});
	});
	
	$(document).ready(function() {
		$('select[name=DRESERVED]').change(function() {
			swal.fire({
				html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
				allowOutsideClick: false,
				showCancelButton: false,
				showConfirmButton: false
			});
			$.ajax({
				url: "/getschdlist/" + moment($('select[name="DRESERVED"]').val()).format('YYYY-MM-DD') + "/" + $(this).find(":selected").data('day'),
				type: "GET",
				success: function (data) {
					$("select[name='TSESSIONTIME']").find('option').not(':first').remove();
					$.each(data, function( index, value ) {
						$("select[name='TSESSIONTIME']").append(new Option(value['TSESSIONTIME'], value['TSESSIONTIME']));
					});
					swal.close();
				}
			});
		});
		
		$('#DFROM').datetimepicker({
			format: 'DD-MMM-YYYY',
			defaultDate: new Date().setFullYear( new Date().getFullYear() - 1 )
		});
		
		$('#DTO').datetimepicker({
			format: 'DD-MMM-YYYY',
			defaultDate: Date.now()
		});
		
		LoadTable();
		$('#cmmcu thead tr').clone(true).appendTo( '#cmmcu thead' );
	
		$('#cmmcu thead tr:eq(1) th').each( function (i) {
			var title = $(this).text();
			if (title.indexOf('Date') != -1) {
				$(this).html( '<input type="date" class="input-sm ' + title.toLowerCase().replace(" ", "_").replace(".", "") + '" placeholder="Search '+title+'" />' );
			} else {
				$(this).html( '<input type="text" class="input-sm ' + title.toLowerCase().replace(" ", "_").replace(".", "") + '" placeholder="Search '+title+'" />' );
			}
			$( 'input', this ).on( 'keyup change', function () {
				if ( tablemcu.column(i).search() !== this.value ) {
					tablemcu
						.column(i)
						.search( this.value )
						.draw();
					$('input[name="' + $(this).attr('class').replace('input-sm ', '') + '"]').val($('.' + $(this).attr('class').replace('input-sm ', '')).val());
				}
			});
		});

		tablemcu.columns().every(function (index) {
			$('#cmmcu thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
				tablemcu.column($(this).parent().index() + ':visible')
					.search(this.value)
					.draw();
			});
		});
		
		$('input[type="search"]').on( 'keyup change', function () {
			$('#search').val($('input[type="search"]').val());
		});
	});
</script>
<style>
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::after{display: none}
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::before{display: none}
</style>
@endsection