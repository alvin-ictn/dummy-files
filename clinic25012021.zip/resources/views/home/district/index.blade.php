@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Master District</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Master District
                  </h3>
               </div>
               <div class="card-header">
                  <h3 class="row card-title">
                     <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('C', 'F11')) { ?>
                        <a class="btn btn-sz btn-primary" href="district/add" role="button">Add New</a>
                     <?php } ?>
                     <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('E', 'F11')) { ?>
                        &nbsp;
                        <form action="district/export_excel" method="POST">
                              @csrf
                              <input type="hidden" value="" name="code" id="code">
                              <input type="hidden" value="" name="name" id="name">
                              <input type="hidden" value="" name="provname" id="provname">
                              <input type="hidden" value="" name="lastmo" id="date">
                              <input type="hidden" value="" name="status" id="st">
                              <input type="hidden" value="" name="modifiedn" id="modifiedn">
                              <input type="hidden" value="" name="no" id="no">
                              <input type="hidden" value="" name="search" id="search">
                              <button class="btn btn-sz btn-primary" type="submit">Export to Excel</button>
                        </form>
                     <?php } ?>
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
               @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div>
               @endif
                  <div class="table-responsive">
                     <table id="cmdistrict" class="table table-bordered table-striped display compact nowrap"  style="width:100%">
                        <thead>
                           <tr>
                              <th>No</th>
                              <th>District Code</th>
                              <th>District Name</th>
                              <th>Province Name</th>
                              <th>Status</th>
                              <th>Last Modified Name</th>
                              <th>Last Modified Date</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<style>
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::after{display: none}
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::before{display: none}
</style>
@endsection