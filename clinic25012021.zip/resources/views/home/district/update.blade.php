@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Edit District</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Edit Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/district/update" id="form-edit">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">District Code</label>
                              <div class="col-sm-4">
                                 <input name="distcode" placeholder="District Code" value="{{$district->VDISTRICTCODE}}" class="form-control" type="text" maxlength="5" required readonly>
                                 <span class="help-block"></span>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Province Name</label>
                              <div class="col-sm-4">
                                 <input name="kodeprov" placeholder="Province Code"  class="form-control" type="text" value="{{$district->VPROVCODE}}{{isset($prov->VPROVNAME) && $prov->VPROVNAME != '' ?' - '.$prov->VPROVNAME:''}}" readonly>{{$district->VPROVNAME}}</input>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-md-2">District Name</label>
                              <div class="col-sm-4">
                                 <input name="distname" placeholder="District Name" value="{{$district->VDISTRICTNAME}}" class="form-control" type="text" maxlength="50" required>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Status</label>
                              <div class="col-sm-4">
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a1" value="1" {{ ($district->BACTIVE==="1")? "checked" : "" }}>
                                    <label class="form-check-label" for="a1">Active</label>
                                 </div>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a2" value="0" {{ ($district->BACTIVE==="0")? "checked" : "" }}>
                                    <label class="form-check-label" for="a2">InActive</label>
                                 </div>
                              </div>
                           </div>
                           <div class="form-group row">
                              <div class="col-md-12">
                                 <div class="float-right">
                                    <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                    <a href="/account/district" class="btn btn-cstm btn-light btn-sz">Close</a>
                                 </div>
                              </div>
                           </div>
                        </div>
						   </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
@endsection