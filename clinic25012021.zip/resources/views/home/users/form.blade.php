@extends('layout.app') 
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Add User</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     User Form
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form id="form-confirm" data-url="/user/save" method="post" enctype="multipart/form-data">
                     <input name="user" type="hidden" value="{{ $user->VUSRID ?? '' }}">
					 @if (isset($user) && isset($user->VEMPSAPID))
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">Employee SAP ID</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="VEMPSAPID" placeholder="Employee SAP ID" class="form-control" type="text" value="{{ $user->VEMPSAPID ?? '' }}" required>
								  </div>
							   </div>
							</div>
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">Business Title</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="VBUSSTITLE" placeholder="Business Title" class="form-control" type="text" value="{{ $user->VBUSSTITLE ?? '' }}" required>
								  </div>
							   </div>
							</div>
						 </div>
					 @endif
					 <div class="row">
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group required">
                              <label class="control-label col-sm-12">User ID</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
                                 <input name="VUSRID" placeholder="User ID" class="form-control" type="text" value="{{ $user->VUSRID ?? '' }}" maxlength="50" required readonly>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group required">
                              <label class="control-label col-sm-12">Name</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
                                 <input name="VNAME" placeholder="Name" class="form-control" type="text" value="{{ $user->VNAME ?? '' }}" maxlength="50" required>
                              </div>
                           </div>
                        </div>
                     </div>
					 <div class="row">
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group required">
                              <label class="control-label col-sm-12">Gender</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
								<div class="form-check form-check-inline">
								   <input class="form-check-input" name="VGNDRCODE" type="radio" value="M" {{ isset($user) && $user->VGNDRCODE == 'M' ? 'checked' : '' }} required>
								   <label class="form-check-label">Male</label>
								</div>
								<div class="form-check form-check-inline">
								   <input class="form-check-input" name="VGNDRCODE" type="radio" value="F" {{ isset($user) && $user->VGNDRCODE == 'F' ? 'checked' : '' }} required>
								   <label class="form-check-label">Female</label>
								</div>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group required">
                              <label class="control-label col-sm-12">Email Address</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
                                 <input name="VMAIL" placeholder="Email Address" class="form-control" type="email" value="{{ $user->VMAIL ?? '' }}" maxlength="50" required>
                              </div>
                           </div>
                        </div>
                     </div>
					 @if (isset($user) && isset($user->VEMPSAPID))
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">User Type</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									<select class="form-control" id="VEMPTYPE" name="VEMPTYPE" onchange="FieldUserType()" required>
										<option value="">-- Select User Type --</option>
										@foreach($VEMPTYPES AS $VEMPTYPE)
											<option {{ isset($user) && $VEMPTYPE['VSETCODE'] === $user->VEMPTYPE ? 'selected="selected"' : '' }} value="{{$VEMPTYPE['VSETCODE']}}">{{$VEMPTYPE['VSETDESC']}}</option>
										@endforeach                                 
									</select>
								  </div>
							   </div>
							</div>
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">Email Dept Head</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="VDEPTHEADMAIL" class="form-control" type="email" value="{{ $user->VDEPTHEADMAIL ?? '' }}" required>
								  </div>
							   </div>
							</div>
						 </div>
					 @endif
                     <div class="row">
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group required">
                              <label class="control-label col-sm-12">City of birth</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
                                 <input name="VCITYBIRTH" placeholder="City of Birth" class="form-control" type="text" value="{{ $user->VCITYBIRTH ?? '' }}" maxlength="50" required>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group required">
                              <label class="control-label col-sm-12">Date of birth</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
                                 <div class="input-group date" id="DBIRTH" data-target-input="nearest">
                                    <input type="text" value="{{ isset($user) && isset($user->DBIRTH) ? $user->DBIRTH->format('d-m-Y') : '' }}" class="form-control datetimepicker-input" name="DBIRTH" data-target="#DBIRTH" placeholder="DD-MMM-YYYY" required>
                                    <div class="input-group-append" data-target="#DBIRTH" data-toggle="datetimepicker">
                                       <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        @if (isset($user) && isset($user->VEMPSAPID))
							 <div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">Country of birth</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="VCNTRYBIRTH" placeholder="Country of Birth" class="form-control" type="text" value="{{ $user->VCNTRYBIRTH ?? '' }}" required>
								  </div>
							   </div>
							</div>
						@else
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group">
								  <label class="control-label col-sm-12">Coordinator</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <div class="input-group">
										<input name="TEXT_VCOORDINATOR" placeholder="Coordinator" class="form-control" type="text" value="{{ $user->VCOORDINATOR ?? '' }}{{ isset($coordinator_name) && $coordinator_name != '' ? ' - '.$coordinator_name : ''}}" readonly>
										<input name="VCOORDINATOR" class="form-control" type="hidden" value="{{ $user->VCOORDINATOR ?? '' }}" readonly>
										<div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myModal">
										   <div class="input-group-text"><i class="fa fa-search"></i></div>
										</div>
									 </div>
								  </div>
							   </div>
							</div>
						@endif
						<div class="col-lg-2 col-sm-12">
                           <div class="form-group required">
                              <label class="control-label col-sm-12">Phone No.</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
                                 <input name="VPHONENO" placeholder="Phone No" class="form-control" type="text" value="{{ $user->VPHONENO ?? '' }}" maxlength="100" required>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group required">
                              <label class="control-label col-sm-12">Marital Status</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
								<select class="form-control" name="VMARITALSTS" required>
                                    <option value="">-- Select Marital Status --</option>
                                    @foreach($VMARITALSTSS AS $VMARITALSTS)
										<option {{ isset($user) && $VMARITALSTS['VSETCODE'] === $user->VMARITALSTS ? 'selected="selected"' : '' }} value="{{$VMARITALSTS['VSETCODE']}}">{{$VMARITALSTS['VSETDESC']}}</option>
                                    @endforeach                                 
								</select>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group required">
                              <label class="control-label col-sm-12">ID Card</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
                                 <input name="VIDCARDNO" placeholder="ID Card" class="form-control" type="text" value="{{ $user->VIDCARDNO ?? '' }}" maxlength="50" required>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        @if (isset($user) && isset($user->VEMPSAPID))
							 <div class="col-lg-6 col-sm-12">
								<div class="row">
									<div class="col-lg-4 col-sm-12">
									   <div class="form-group">
										  <label class="control-label col-sm-12">Marital Date</label>
									   </div>
									</div>
									<div class="col-lg-8 col-sm-12">
									   <div class="form-group">
										  <div class="col-sm-12">
											<div class="input-group date" id="DMARITAL" data-target-input="nearest">
												<input type="text" value="{{ isset($user) && isset($user->DMARITAL) ? $user->DMARITAL->format('d-m-Y') : '' }}" class="form-control datetimepicker-input" name="DMARITAL" data-target="#DMARITAL" placeholder="DD-MMM-YYYY">
												<div class="input-group-append" data-target="#DMARITAL" data-toggle="datetimepicker">
												   <div class="input-group-text"><i class="fa fa-calendar"></i></div>
												</div>
											 </div>
										  </div>
									   </div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-4 col-sm-12">
									   <div class="form-group">
										  <label class="control-label col-sm-12">Personnel Area</label>
									   </div>
									</div>
									<div class="col-lg-8 col-sm-12">
									   <div class="form-group">
										  <div class="col-sm-12">
											<select class="form-control" name="VPRSNLAREACODE" onchange="FieldSubPersonnelArea();">
												<option value="">-- Select Personnel Area --</option>
												@foreach($VPRSNLAREACODES AS $VPRSNLAREACODE)
													<option {{ isset($user) && $VPRSNLAREACODE['VPRSNLAREACODE'] === $user->VPRSNLAREACODE ? 'selected="selected"' : '' }} value="{{$VPRSNLAREACODE['VPRSNLAREACODE']}}">{{$VPRSNLAREACODE['VPRSNLAREACODE']}}{{isset($VPRSNLAREACODE['VPRSNLNAME'])?' - '.$VPRSNLAREACODE['VPRSNLNAME']:''}}</option>
												@endforeach                                 
											</select>
										  </div>
									   </div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-4 col-sm-12">
									   <div class="form-group">
										  <label class="control-label col-sm-12">Sub Personnel Area</label>
									   </div>
									</div>
									<div class="col-lg-8 col-sm-12">
									   <div class="form-group">
										  <div class="col-sm-12">
											<select class="form-control" name="VSUBPRSNLAREACODE">
												<option value="">-- Select Sub Personnel Area --</option>
												@foreach($VSUBPRSNLAREACODES AS $VSUBPRSNLAREACODE)
													<option {{ isset($user)&& $VSUBPRSNLAREACODE['VPRSNLAREACODE'] === $user->VPRSNLAREACODE && $VSUBPRSNLAREACODE['VSUBPRSNLAREACODE'] === $user->VSUBPRSNLAREACODE ? 'selected="selected"' : '' }} value="{{$VSUBPRSNLAREACODE['VSUBPRSNLAREACODE']}}" code="{{$VSUBPRSNLAREACODE['VPRSNLAREACODE']}}">{{$VSUBPRSNLAREACODE['VSUBPRSNLAREACODE']}}{{isset($VSUBPRSNLAREACODE['VSUBPRSNLNAME'])?' - '.$VSUBPRSNLAREACODE['VSUBPRSNLNAME']:''}}</option>
												@endforeach                                 
											</select>
										  </div>
									   </div>
									</div>
								</div>
							</div>
						@else
							<div class="col-lg-6 col-sm-12">
								<div class="row">
									<div class="col-lg-4 col-sm-12">
									   <div class="form-group required">
										  <label class="control-label col-sm-12">Position</label>
									   </div>
									</div>
									<div class="col-lg-8 col-sm-12">
									   <div class="form-group">
										  <div class="col-sm-12">
											<select class="form-control" id="VPOSCODE" name="VPOSCODE" onchange="FieldPosition()" required>
												<option value="">-- Select Position --</option>
												@foreach($VPOSCODES AS $VPOSCODE)
													<option {{ isset($user) && $VPOSCODE['VGNRLCODE'] === $user->VPOSCODE ? 'selected="selected"' : '' }} value="{{$VPOSCODE['VGNRLCODE']}}">{{$VPOSCODE['VGNRLDESC']}}</option>
												@endforeach                                 
											</select>
										  </div>
									   </div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-4 col-md-12">
									   <div class="form-group">
										  <label class="control-label col-md-12">Doctor</label>
									   </div>
									</div>
									<div class="col-lg-8 col-sm-12">
									   <div class="form-group">
										  <div class="col-md-12">
											<select class="form-control" id="VDRTYPE" name="VDRTYPE" onchange="FieldDoctor()" disabled>
												<option value="">-- Select Doctor --</option>
												@foreach($VDRTYPES AS $VDRTYPE)
													<option {{ isset($user) && $VDRTYPE['VSETCODE'] === $user->VDRTYPE ? 'selected="selected"' : '' }} value="{{$VDRTYPE['VSETCODE']}}">{{$VDRTYPE['VSETDESC']}}</option>
												@endforeach                                 
											</select>
										  </div>
									   </div>
									</div>
								</div>
								<div class="row">
									<div class="col-lg-4 col-md-12">
									   <div class="form-group">
										  <label class="control-label col-md-12">Specialist</label>
									   </div>
									</div>
									<div class="col-lg-8 col-sm-12">
									   <div class="form-group">
										  <div class="col-md-12">
											<select class="form-control" id="VSPCCODE" name="VSPCCODE" disabled>
												<option value="">-- Select Specialist --</option>
												@foreach($VSPCCODES AS $VSPCCODE)
													<option {{ isset($user) && $VSPCCODE['VGNRLCODE'] === $user->VSPCCODE ? 'selected="selected"' : '' }} value="{{$VSPCCODE['VGNRLCODE']}}">{{$VSPCCODE['VGNRLDESC']}}</option>
												@endforeach                                 
											</select>
										  </div>
									   </div>
									</div>
								</div>
							</div>
						@endif
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group required">
                              <label class="control-label col-sm-12">Address</label>
                           </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                           <div class="form-group">
                              <div class="col-sm-12">
                                 <textarea class="form-control" placeholder="Address" name="VADDRESS" rows="5" required>{{ $user->VADDRESS ?? '' }}</textarea>
                              </div>
                           </div>
                        </div>
                     </div>
					 @if (isset($user) && isset($user->VEMPSAPID))
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">Cost Center</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <select class="form-control" name="VCOSTCNTRCODE" required>
										<option value="">-- Select Cost Center --</option>
										@foreach($VCOSTCNTRCODES AS $VCOSTCNTRCODE)
											<option {{ isset($user) && $VCOSTCNTRCODE['VCOSTCNTRCODE'] === $user->VCOSTCNTRCODE ? 'selected="selected"' : '' }} value="{{$VCOSTCNTRCODE['VCOSTCNTRCODE']}}">{{$VCOSTCNTRCODE['VCOSTCNTRCODE']}}{{isset($VCOSTCNTRCODE['VCOSTCNTRNAME'])?' - '.$VCOSTCNTRCODE['VCOSTCNTRNAME']:''}}</option>
										@endforeach                                 
									</select>
								  </div>
							   </div>
							</div>
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">Package</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
								  	<select class="form-control" name="VPACKAGECODE" required>
										<option value="">-- Select Package --</option>
										@foreach($PACKAGE AS $PACKAGE)
											<option {{ isset($user) && $PACKAGE['VPCKGCODE'] === $user->VPACKAGECODE ? 'selected="selected"' : '' }} value="{{$PACKAGE['VPCKGCODE']}}">{{$PACKAGE['VPCKGNAME']}}</option>
										@endforeach                                 
									</select>
									 <!-- <input name="VPACKAGECODE" placeholder="Package" class="form-control" type="text" value="{{ $user->VPACKAGECODE ?? '' }}" required> -->
								  </div>
							   </div>
							</div>
						 </div>
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">Job Position</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <select class="form-control" name="VJOBPOSITION" required>
										<option value="">-- Select Job Position --</option>
										@foreach($VJOBPOSITIONS AS $VJOBPOSITION)
											<option {{ isset($user) && $VJOBPOSITION['VGNRLCODE'] === $user->VJOBPOSITION ? 'selected="selected"' : '' }} value="{{$VJOBPOSITION['VGNRLCODE']}}">{{$VJOBPOSITION['VGNRLDESC']}}</option>
										@endforeach                                 
									</select>
								  </div>
							   </div>
							</div>
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">Job Area</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <select class="form-control" name="VJOBAREA" required>
										<option value="">-- Select Job Area --</option>
										@foreach($VJOBAREAS AS $VJOBAREA)
											<option {{ isset($user) && $VJOBAREA['VGNRLCODE'] === $user->VJOBAREA ? 'selected="selected"' : '' }} value="{{$VJOBAREA['VGNRLCODE']}}">{{$VJOBAREA['VGNRLDESC']}}</option>
										@endforeach                                 
									</select>
								  </div>
							   </div>
							</div>
						 </div>
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">Hire Date</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <div class="input-group date" id="DHIRE" data-target-input="nearest">
										<input type="text" value="{{ isset($user) && isset($user->DHIRE) ? $user->DHIRE->format('d-m-Y') : '' }}" class="form-control datetimepicker-input" name="DHIRE" data-target="#DHIRE" placeholder="DD-MMM-YYYY" required>
										<div class="input-group-append" data-target="#DHIRE" data-toggle="datetimepicker">
										   <div class="input-group-text"><i class="fa fa-calendar"></i></div>
										</div>
									 </div>
								  </div>
							   </div>
							</div>
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">Contract End Date</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <div class="input-group date" id="DENDCNTRCT" data-target-input="nearest">
										<input type="text" value="{{ isset($user) && isset($user->DENDCNTRCT) ? $user->DENDCNTRCT->format('d-m-Y') : '' }}" class="form-control datetimepicker-input" name="DENDCNTRCT" data-target="#DENDCNTRCT" placeholder="DD-MMM-YYYY" required>
										<div class="input-group-append" data-target="#DENDCNTRCT" data-toggle="datetimepicker">
										   <div class="input-group-text"><i class="fa fa-calendar"></i></div>
										</div>
									 </div>
								  </div>
							   </div>
							</div>
						 </div>
						 <div class="row">
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">BPJS No.</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="VBPJSNO" placeholder="BPJS No" class="form-control" type="text" value="{{ $user->VBPJSNO ?? '' }}" required>
								  </div>
							   </div>
							</div>
							<div class="col-lg-2 col-sm-12">
							   <div class="form-group required">
								  <label class="control-label col-sm-12">JHT No.</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-sm-12">
									 <input name="VJHTNO" placeholder="JHT No" class="form-control" type="text" value="{{ $user->VJHTNO ?? '' }}" required>
								  </div>
							   </div>
							</div>
						 </div>
						<div class="row">
						 @if(isset($user))
								<div class="col-lg-2 col-sm-12">
									<div class="form-group">
										<label class="control-label col-sm-12">Status</label>
									</div>
								</div>
								<div class="col-lg-4 col-sm-12">
									<div class="form-group">
										<div class="col-sm-12">
											<div class="form-check form-check-inline">
												@if($VUSRFLAG == 'NAD')
												<input class="form-check-input" name="BACTIVE" type="radio" value="1" required {{ ($user->BACTIVE != '' && $user->BACTIVE == '1') ? 'checked' : '' }} >
												@else
												<input class="form-check-input" name="BACTIVE" type="radio" value="1" disabled {{ ($user->BACTIVE != '' && $user->BACTIVE == '1') ? 'checked' : '' }} >
												@endif
												<label class="form-check-label">Active</label>
											</div>
											<div class="form-check form-check-inline">
												@if($VUSRFLAG == 'NAD')
												<input class="form-check-input" name="BACTIVE" type="radio" value="0" required {{ ($user->BACTIVE != '' && $user->BACTIVE == '0') ? 'checked' : '' }} >
												@else
												<input class="form-check-input" name="BACTIVE" type="radio" value="0" disabled {{ ($user->BACTIVE != '' && $user->BACTIVE == '0') ? 'checked' : '' }} >
												@endif
												<label class="form-check-label">Inactive</label>
											</div>
										</div>
									</div>
								</div> 
								<div class="col-lg-2 col-sm-12">
									<div class="form-group">
										<label class="control-label col-sm-12">Is Allow Create Others</label>
									</div>
								</div>
								<div class="col-lg-4 col-sm-12">
									<div class="form-group">
										<div class="col-sm-12">
											<div class="form-check form-check-inline">
												@if(isset($BOTHERS) && $BOTHERS == true)
													<input type="checkbox" name="BOTHERS" checked>
												@else
													<input type="checkbox" name="BOTHERS">
												@endif
											</div>
										</div>
									</div>
								</div> 
							@endif
						</div>
					 @else
						 <div class="row">
							<div class="col-lg-2 col-md-12">
							   <div class="form-group">
								  <label class="control-label col-md-12">Rate</label>
							   </div>
							</div>
							<div class="col-lg-4 col-sm-12">
							   <div class="form-group">
								  <div class="col-md-12">
									 <input id='NRATE' name="NRATE" placeholder="Rate" class="form-control" type="number" value="{{ isset($user) ? str_replace('.00', '', $user->NRATE) : '' }}">
								  </div>
							   </div>
							</div>
							@if(isset($user))
								<div class="col-lg-2 col-sm-12">
									<div class="form-group">
										<label class="control-label col-sm-12">Status</label>
									</div>
								</div>
								<div class="col-lg-4 col-sm-12">
									<div class="form-group">
										<div class="col-sm-12">
											<div class="form-check form-check-inline">
												@if($VUSRFLAG == 'NAD')
												<input class="form-check-input" name="BACTIVE" type="radio" value="1" required {{ ($user->BACTIVE != '' && $user->BACTIVE == '1') ? 'checked' : '' }} >
												@else
												<input class="form-check-input" name="BACTIVE" type="radio" value="1" disabled {{ ($user->BACTIVE != '' && $user->BACTIVE == '1') ? 'checked' : '' }} >
												@endif
												<label class="form-check-label">Active</label>
											</div>
											<div class="form-check form-check-inline">
												@if($VUSRFLAG == 'NAD')
												<input class="form-check-input" name="BACTIVE" type="radio" value="0" required {{ ($user->BACTIVE != '' && $user->BACTIVE == '0') ? 'checked' : '' }} >
												@else
												<input class="form-check-input" name="BACTIVE" type="radio" value="0" disabled {{ ($user->BACTIVE != '' && $user->BACTIVE == '0') ? 'checked' : '' }} >
												@endif
												<label class="form-check-label">Inactive</label>
											</div>
										</div>
									</div>
								</div> 
							@endif
						 </div>

						 <div class="row">
						 	<div class="col-sm-12">
								<div class="form-check form-check-inline col-sm-2">
								  <label class="col-form-label col-sm-10">Safety Driving</label>
								  	@if(isset($user) && $user->BSAFETY == "1")
										<input type="checkbox" name="BSAFETY" checked>
									@else
										<input type="checkbox" name="BSAFETY">
									@endif
								</div>
								<div class="form-check form-check-inline col-sm-2">
								  <label class="col-form-label col-sm-8">Hyperkes</label>
								  	@if(isset($user) && $user->BHYPERKES == "1")
										<input type="checkbox" name="BHYPERKES" checked>
									@else
										<input type="checkbox" name="BHYPERKES">
									@endif
								</div>
								<div class="form-check form-check-inline col-sm-2">
								  <label class="col-form-label col-sm-8">Contract</label>
								  	@if(isset($user) && $user->BCONTRACT == "1")
										<input type="checkbox" name="BCONTRACT" checked>
									@else
										<input type="checkbox" name="BCONTRACT">
									@endif
								</div>
							</div>
						 </div>
					 @endif

				
					 <hr>
					 @if (isset($user) && isset($user->VEMPSAPID))
						 <div class="row">
							<div class="col-lg-12 col-sm-12 form-group">
							  <button type="button" class="btn-cstm btn-primary btn-sz" onclick="return toForm(this);">Add New</button>
							</div>
						 </div>
						 <div class="row">
							<div class="col-lg-12 col-sm-12 form-group">
							  <table id="tblmember" border="1" width="100%">
								<thead>
								  <tr>
									<th class="text-center">Name</th>
									<th class="text-center">Family Relationship</th>
									<th class="text-center">Gender</th>
									<th class="text-center">Date of birth</th>
									<th class="text-center">Country of birth</th>
									<th class="text-center">City of birth</th>
									<th class="text-center">BPJS No.</th>
									<th class="text-center">JHT No.</th>
									<!--<th class="text-center">Insurance No.</th>
									<th class="text-center">Insurance Name</th>-->
								  </tr>
								</thead>
								<tbody>
									@foreach ($members as $member)
										<tr>
											<td data-value="ILINE" style="display: none;">{{ $member->ILINE }}</td>
											<td data-value="VRELNAME"><button class="btn btn-link btn-sm" type="button" onclick="return toForm(this, '{{ $member->ILINE }}');">{{ $member->VRELNAME }}</button></td>
											<td data-value="VRELATION">{{ $member->VRELATION }}</td>
											<td data-value="VRELGENDER">{{ $member->VRELGENDER }}</td>
											<td data-value="DRELBIRTH">{{ $member->DRELBIRTH }}</td>
											<td data-value="VRELCTRYBIRTH">{{ $member->VRELCTRYBIRTH }}</td>
											<td data-value="VRELCITYBIRTH">{{ $member->VRELCITYBIRTH }}</td>
											<td data-value="VRELBPJSNO">{{ $member->VRELBPJSNO }}</td>
											<td data-value="VRELJHTNO">{{ $member->VRELJHTNO }}</td>
											<!--<td></td>
											<td></td>-->
										  </tr>
									@endforeach
								</tbody>
							  </table>
							</div>
						 </div>
					 @else
						 <div class="row">
							<div class="col-lg-12 col-sm-12 form-group">
							  <button type="button" class="btn-cstm btn-primary btn-sz" onclick="return toFormDoc(this);">Add New</button>
							</div>
						 </div>
						 <div class="row table-responsive">
							<div class="col-lg-12 col-sm-12 form-group">
							  <table id="tblfile" border="1" width="100%">
								<thead>
								  <tr>
									<th class="text-center">Action</th>
									<th class="text-center">No</th>
									<th class="text-center">Doc Type</th>
									<th class="text-center">Doc No</th>
									<th class="text-center">Valid From</th>
									<th class="text-center">Valid To</th>
									<th class="text-center">File Name</th>
								  </tr>
								</thead>
								<tbody>
									<?php $inc = 1;?>
									@if (isset($docs))
										@foreach ($docs as $doc)
											<tr>
												<td data-value="VID" style="display: none;">{{ $doc->VID }}</td>
												<td data-value="VDOCFILENAME" style="display: none;">{{ $doc->VDOCFILENAME }}</td>
												<td class="text-center"><button onClick="toFormDoc(this, '{{ $doc->VID }}')" type="button" class="btn btn btn-link btn-sm"><i title="Edit" class="fas fa-edit"></i></button>&nbsp;<button onClick="remove(this)" data-id="{{ $doc->VID }}" type="button" class="btn btn btn-link btn-sm"><i title="Delete" class="fas fa-times"></i></button></td>
												<td>{{ $inc }}</td>
												<td data-value="VDOCTYPE">{{ $doc->VGNRLDESC }}</td>
												<td data-value="VDOCNO">{{ $doc->VDOCNO }}</td>
												<td data-value="DPERIODFR">{{ isset($doc->DPERIODFR) ? $doc->DPERIODFR->format('d-m-Y') : '' }}</td>
												<td data-value="DPERIODTO">{{ isset($doc->DPERIODTO) ? $doc->DPERIODTO->format('d-m-Y') : '' }}</td>
												<td><a href="/account/download/{{ strtolower($doc->VID . substr($doc->VDOCFILENAME, strrpos($doc->VDOCFILENAME, '.'))) }}">{{ $doc->VDOCFILENAME }}</a></td>
											  </tr>
											  <?php $inc++; ?>
										@endforeach
									@endif
								</tbody>
							  </table>
							</div>
						 </div>
					 @endif
                        <div class="float-right">
                           	<div class="col-sm-12">
                              <button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                              <a href="/account/users" class="btn btn-cstm btn-light btn-sz">Close</a>
                           	</div>
						</div>
                  </form>
               </div>
            </div>
         </div>
      </div>
	  @if (isset($user) && isset($user->VEMPSAPID))
		  <div class="modal fade" id="modaladdnew" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
			 <div class="modal-dialog modal-md modal-dialog-centered">
				<div class="modal-content">
				   <div class="modal-body">
					  <form id="form-addnew">
						 <input name="ILINE" type="text" style="display: none;">
						 <div class="container">
							<div class="row">
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="VRELNAME" class="form-control" type="text" placeholder="Name" required>
									  </div>
								   </div>
								</div>
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="VRELATIONS" class="form-control" type="text" placeholder="Family Relationship" required style="display: none;">
										 <select class="form-control" name="VRELATION" id="VRELATION" required onchange="myVRELATION()">
                                    		<option value="">-- Select Family Relationship --</option>
                                    			@foreach($FAMILY AS $FAMILYS)
													<option  value="{{$FAMILYS['VSETCODE']}}">{{$FAMILYS['VSETDESC']}}</option>
                                    			@endforeach                                 
											</select>
									  </div>
								   </div>
								</div>
							 </div>
							<div class="row">
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <div class="form-check form-check-inline">
										   <input class="form-check-input" name="VRELGENDER" type="radio" value="M" required>
										   <label class="form-check-label">Male</label>
										</div>
										<div class="form-check form-check-inline">
										   <input class="form-check-input" name="VRELGENDER" type="radio" value="F" required>
										   <label class="form-check-label">Female</label>
										</div>
									  </div>
								   </div>
								</div>
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <div class="input-group date" id="DRELBIRTH" data-target-input="nearest">
											<input type="text" class="form-control datetimepicker-input" name="DRELBIRTH" data-target="#DRELBIRTH" placeholder="Date of birth" required>
											<div class="input-group-append" data-target="#DRELBIRTH" data-toggle="datetimepicker">
											   <div class="input-group-text"><i class="fa fa-calendar"></i></div>
											</div>
										 </div>
									  </div>
								   </div>
								</div>
							 </div>
							<div class="row">
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="VRELCTRYBIRTH" class="form-control" type="text" placeholder="Country of birth" required>
									  </div>
								   </div>
								</div>
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="VRELCITYBIRTH" class="form-control" type="text" placeholder="City of birth" required>
									  </div>
								   </div>
								</div>
							 </div>
							<div class="row">
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="VRELBPJSNO" class="form-control" type="text" placeholder="BPJS No." required>
									  </div>
								   </div>
								</div>
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input name="VRELJHTNO" class="form-control" type="text" placeholder="JHT No." required>
									  </div>
								   </div>
								</div>
							 </div>
							<!--<div class="row">
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input class="form-control" type="text" placeholder="Insurance No." required>
									  </div>
								   </div>
								</div>
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input class="form-control" type="text" placeholder="Insurance Name" required>
									  </div>
								   </div>
								</div>
							 </div>-->
							 <br/>
							 <div style="text-align:center;">
								<button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
								<a onclick="$('#modaladdnew').modal('hide');" class="btn btn-cstm btn-light btn-sz">Close</a>
							</div>
						 </div>
					  </form>
				   </div>
				</div>
			 </div>
		  </div>
	  @else
		  <div class="modal fade in" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg modal-content">
				<div class="card mb-4">
					<div class="card-header bg-info">
						<h5 class="card-title text-white" align="center">Coordinator List</h5>
						<button type="button" class="close text-white" data-dismiss="modal">×</button>
					</div>
					<div class="card-body p-3">
						<div id="dvData" class="table-responsive">
							<table id="tblcoordinator" class="display" style="width:100%">
								<thead>
									<tr>
										<th>
											User ID
										</th>
										<th>
											Name
										</th>
									</tr>
								</thead>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade" id="modaldoc" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-md modal-dialog-centered">
				<div class="modal-content">
				   	<div class="modal-body">
					  <form id="form-doc">
						<input id="VID" name="VID" type="text" style="display: none;">
						<div class="container">
							<div class="row">
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <select class="form-control" id="VDOCTYPE" placeholder="Document Type">
											<option value="">-- Select Document Type  --</option>
											@foreach($VDOCTYPES AS $VDOCTYPE)
												<option value="{{$VDOCTYPE['VGNRLCODE']}}">{{$VDOCTYPE['VGNRLDESC']}}</option>
											@endforeach                                 
										</select>
									  </div>
								   </div>
								</div>
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <input id="VDOCNO" class="form-control" type="text" placeholder="Document No" maxlength="30">
									  </div>
								   </div>
								</div>
							 </div>
							<div class="row">
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <div class="input-group date" id="PERIODFR" data-target-input="nearest">
											<input type="text" class="form-control datetimepicker-input" id="DPERIODFR" data-target="#PERIODFR" placeholder="Valid From">
											<div class="input-group-append" data-target="#PERIODFR" data-toggle="datetimepicker">
											   <div class="input-group-text"><i class="fa fa-calendar"></i></div>
											</div>
									 	</div>
									  </div>
								   </div>
								</div>
								<div class="col-lg-6 col-sm-12">
								   <div class="form-group">
									  <div class="col-sm-12">
										 <div class="input-group date" id="PERIODTO" data-target-input="nearest">
											<input type="text" class="form-control datetimepicker-input" id="DPERIODTO" data-target="#PERIODTO" placeholder="to">
											<div class="input-group-append" data-target="#PERIODTO" data-toggle="datetimepicker">
											   <div class="input-group-text"><i class="fa fa-calendar"></i></div>
											</div>
										 </div>
									  </div>
								   </div>
								</div>
							</div>
							<div class="row">
								<div class="col-lg-12 col-sm-12">
								   <div class="form-group">
									  <div id="divFile" class="col-sm-12">
										 <input id="file" type="file" required>
									  </div>
									  <div id="divFileEdit" class="col-sm-12" style="display: none;">
										 <button type="button">Choose File</button>&nbsp;<label></label>
									  </div>
								   </div>
								</div>
							</div>
							<br/>
							<div style="text-align:center;">
								<button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
								<a onclick="$('#modaldoc').modal('hide');" class="btn btn-cstm btn-light btn-sz">Close</a>
							</div>
						 </div>
					  </form>
				   	</div>
				</div>
		  	</div>
   		</div>
		@endif
   	</div>
</section>
<script>

	var AllSubPersonnelAreaOption;	// for saving all Sub Personnel Area options

	function myVRELATION() {
		var x = document.getElementById("VRELATION").value;
		//   document.getElementById("VRELATIONS").value =  x;
  		$('input[name="VRELATIONS"]').val(x);
	}

	$(document).ready(function() {
		var table = $("#tblcoordinator").DataTable({ pagingType: $(window).width() < 768 ? "simple" : "simple_numbers", ajax: { url: '/getcoordinatorlookup', type: "GET", }, columns: [ { data: "VUSRID", name: "VUSRID" }, { data: "VNAME", name: "VNAME" } ] });
		$('#tblcoordinator tbody').on('dblclick', 'tr', function () {
			var data = table.row(this).data();
			$('input[name="TEXT_VCOORDINATOR"]').val(data['VUSRID'] + ' - ' + data['VNAME']);
			$('input[name="VCOORDINATOR"]').val(data['VUSRID']);
			$(this).closest('.card').find('button').trigger('click');
		});

		$('#PERIODFR, #PERIODTO, #DMARITAL, #DHIRE, #DENDCNTRCT, #DHIRE').datetimepicker({
			format: 'DD-MMM-YYYY'
		});
		
		// Birthday
		var date = new Date();
		var yesterday = new Date(date);
		yesterday.setDate(yesterday.getDate() - 1);
		$('#DRELBIRTH').datetimepicker({
			format: 'DD-MMM-YYYY',
			maxDate: yesterday
			
		});
		$('#DBIRTH').datetimepicker({
			format: 'DD-MMM-YYYY',
			maxDate: yesterday,
			<?php if(isset($user->DBIRTH)) {?>
				date: '{{$user->DBIRTH}}'

			<?php } ?>
		});
		// {{ isset($user) && isset($user->DBIRTH) ? $user->DBIRTH->format('d-m-Y') : '' }}
		$('#divFile').on('change', 'input', function(){
			$('#divFile').css('display', 'block');
			$('#divFileEdit').css('display', 'none');
		});

		//---- Initial(all) Sub Personnel Area option
		AllSubPersonnelAreaOption = $("select[name='VSUBPRSNLAREACODE'] option").clone();

		//---- Enable/Disable Fields
		FieldPosition();
		FieldDoctor();
		FieldUserType();
		FieldSubPersonnelArea();
	});

	var files = 0;
	
	function remove(th) {
		swal.fire({
			text: "Do you want to delete the data?",
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Yes",
			cancelButtonText: "No"
		}).then(function (result) {
			if (result.value) {
				if ($(th).data('id').length == 36) {
					$.ajax({
						url: "/account/users/deldoc/" + $(th).data('id'),
						type: "GET",
						headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
						success: function () {
							location.reload();
						}
					});
				} else {
					$(th).closest('tr').remove();
					$.each($('#tblfile tbody tr'), function( index, value ) {
						$('#tblfile tbody tr:eq(' + index + ') td:eq(1)').text(index + 1);
					});
				}
			}
		});
	}
	
	function toFormDoc(th, id) {
		$('#form-doc').trigger("reset");
		if (id !== undefined) {
			$.each($(th).closest('tr').find('td[data-value]'), function( index, value ) {
				var input = $('#form-doc #' + $(value).data('value') + '');
				if ($(value).data('value') == "VDOCTYPE") {
					if ($(value).text() != '') {
						$('#VDOCTYPE').prop('selectedIndex', $("#VDOCTYPE option:contains(" + $(value).text() + ")")[0].index);
					}
				} else if ($(value).data('value') == "VDOCFILENAME") {
					$('#divFileEdit label').text($(value).text());
				} else {
					input.val($(value).text());
				}
			});
			$('#divFile').css('display', 'none');
			$('#divFileEdit').css('display', 'block');
			$('#file').removeAttr('required');
		} else {
			$('#divFile').css('display', 'block');
			$('#divFileEdit').css('display', 'none');
			$('#file').prop('required', true);
		}
		$('#modaldoc').modal('show');
	}
	
	function toForm(th, id) {
		$('#form-addnew').trigger("reset");
		if (id !== undefined) {
			$.each($(th).closest('tr').find('td'), function( index, value ) {
				var input = $('#form-addnew input[name="' + $(value).data('value') + '"]');
				if (input.attr('type') == 'radio') {
					if ($(value).text() != '') {
						input.filter('[value=' + $(value).text().substring(0, 1) + ']').prop('checked', true);
					}
				}
				else {
					input.val($(value).text());
				}
			});
		}
		$('#modaladdnew').modal('show');
	}
	
	$('#form-addnew').trigger("reset");

	var serial = 1;
	
	$(document).on("submit", "[id^=form-addnew]", function (e) {
		e.preventDefault();
		if ($('#form-addnew input[name="ILINE"]').val() != '') {
			$.each($('#tblmember td:contains(' + $('#form-addnew input[name="ILINE"]').val() + ')').closest('tr').find('td'), function( index, value ) {
				if (index == 3) {
					$(value).html($('#form-addnew input[name="VRELGENDER"]:checked').siblings('label').text() + '<input name="VRELGENDER[]" type="hidden" value="' + $('#form-addnew input[name="VRELGENDER"]').val() + '">');
				}
				else if (index == 1) {
					$(value).html('<button class="btn btn-link btn-sm" type="button" onclick="return toForm(this, \'' + $('#form-addnew input[name="ILINE"]').val() + '\');">' + $('#form-addnew input[name="' + $(value).data('value') + '"]').val() + '</button><input name="' + $(value).data('value') + '[]" type="hidden" value="' + $('#form-addnew input[name="' + $(value).data('value') + '"]').val() + '">');
				}
				else {
					$(value).html($('#form-addnew input[name="' + $(value).data('value') + '"]').val() + '<input name="' + $(value).data('value') + '[]" type="hidden" value="' + $('#form-addnew input[name="' + $(value).data('value') + '"]').val() + '">');
				}
			});
		} else {
			var td = '';
			// $.each( ($('#VRELATION option:selected') ), function( index, value ) {
			// 	td += '<td data-value="' + value.value + '">' + value.value + '<input name="VRELATION[]" type="hidden" value="' + value.value + '"></td>';

			// });
			$.each( ($('#form-addnew input[type="text"]')), function( index, value ) {
				console.log(index, value );
				if (index == 3) {
					td += '<td data-value="VRELGENDER">' + $('#form-addnew input[name="VRELGENDER"]:checked').siblings('label').text() + '<input name="VRELGENDER[]" type="hidden" value="' + $('#form-addnew input[name="VRELGENDER"]').val() + '"></td>';
				}
				if (index == 0) {
					td += '<td data-value="' + $(value).attr('name') + '" style="display: none;">' + serial.toString().padStart(13, '0') + '<input name="' + $(value).attr('name') + '[]" type="hidden" value="' + serial.toString().padStart(13, '0') + '"></td>';
				}
				else if (index == 1) {
					td += '<td data-value="' + $(value).attr('name') + '"><button class="btn btn-link btn-sm" type="button" onclick="return toForm(this, \'' + serial.toString().padStart(13, '0') + '\');">' + $(value).val() + '</button><input name="' + $(value).attr('name') + '[]" type="hidden" value="' + $(value).val() + '"></td>';
					serial++;
				}
				else {
					td += '<td data-value="' + $(value).attr('name') + '">' + $(value).val() + '<input name="' + $(value).attr('name') + '[]" type="hidden" value="' + $(value).val() + '"></td>';
				}
			});

			$('#tblmember tbody').append('<tr>' + td + '</tr>');
		}
		$('#modaladdnew').modal('hide');
	});
	
	$(document).on("submit", "[id^=form-doc]", function (e) {
		e.preventDefault();

		var periodfrParts = $('#DPERIODFR').val().split("-");
		var periodfr = new Date(+periodfrParts[2], periodfrParts[1] - 1, +periodfrParts[0]);
		var periodtoParts = $('#DPERIODTO').val().split("-");
		var periodto = new Date(+periodtoParts[2], periodtoParts[1] - 1, +periodtoParts[0]);
        if(periodfr >= periodto){
            Swal.fire('Error', 'Time is invalid.', 'error');
            return false;
        }

		
		var th = $('#file')[0];
		if ($('#form-doc input[name="VID"]').val() != '') {
			$.each($('#tblfile td:contains(' + $('#form-doc input[name="VID"]').val() + ')').closest('tr').find('td[data-value]'), function( index, value ) {
				if ($(value).data('value') == "VDOCFILENAME") {
					var tdTag = $(value).closest('tr').children('td').last();
					if (th.files[0]) {
						$(value).html(th.files[0].name);
						if ($(value).closest('tr').find('[name="files[]"]').length > 0) {
							$(value).closest('tr').find('[name="files[]"]').closest('td').remove();
						}
						$(value).closest('tr').prepend('<td id="fileInput" style="display: none;"></td>');
						reloadFile();
						tdTag.html(th.files[0].name + '<input name="VDOCFILENAME[]" type="hidden" value="' + th.files[0].name + '">');
					} else {
						var aTag = tdTag.find('a');
						if (aTag.length > 0) {
							aTag.html($('#divFileEdit label').text() + '<input name="VDOCFILENAME[]" type="hidden" value="">');
							$(value).closest('tr').prepend('<td style="display: none;"><input name="files[]"></td>');
						}
					}
				} else if ($(value).data('value') == "VDOCTYPE") {
					if ($('#VDOCTYPE option:selected').val() != '') {
						$(value).html($('#VDOCTYPE option:selected').text() + '<input name="' + $(value).data('value') + '[]" type="hidden" value="' + $('#VDOCTYPE option:selected').val() + '">');
					}
				} else {
					$(value).html($('#form-doc input[id="' + $(value).data('value') + '"]').val() + '<input name="' + $(value).data('value') + '[]" type="hidden" value="' + $('#form-doc input[id="' + $(value).data('value') + '"]').val() + '">');
				}
			});
		} else {
			$('#tblfile tbody').append('<tr><td id="fileInput" style="display: none;"></td><td data-value="VID" style="display: none;">' + files.toString().padStart(13, '0') + '<input name="VID[]" type="hidden" value="' + files.toString().padStart(13, '0') + '"></td><td data-value="VDOCFILENAME" style="display: none;">' + th.files[0].name + '</td><td class="text-center"><button onClick="toFormDoc(this, \'' + files.toString().padStart(13, '0') + '\')" type="button" class="btn btn btn-link btn-sm"><i title="Edit" class="fas fa-edit"></i></button>&nbsp;<button onClick="remove(this)" data-id="' + files.toString().padStart(13, '0') + '" type="button" class="btn btn btn-link btn-sm"><i title="Delete" class="fas fa-times"></i></button></td><td>' + ($('#tblfile tbody tr').length + 1) + '</td><td data-value="VDOCTYPE">' + ($('#VDOCTYPE').val() != '' ? $('#VDOCTYPE option:selected').text() : '') + '<input name="VDOCTYPE[]" type="hidden" value="' + $('#VDOCTYPE').val() + '"></td><td data-value="VDOCNO">' + $('#VDOCNO').val() + '<input name="VDOCNO[]" type="hidden" value="' + $('#VDOCNO').val() + '"></td><td data-value="DPERIODFR">' + $('#DPERIODFR').val() + '<input name="DPERIODFR[]" type="hidden" value="' + $('#DPERIODFR').val() + '"></td><td data-value="DPERIODTO">' + $('#DPERIODTO').val() + '<input name="DPERIODTO[]" type="hidden" value="' + $('#DPERIODTO').val() + '"></td><td>' + th.files[0].name + '<input name="VDOCFILENAME[]" type="hidden" value="' + th.files[0].name + '"></td></tr>');
			reloadFile();
			files++;
		}
		$('#modaldoc').modal('hide');
	});
	
	function reloadFile () {
		$("#fileInput").append($('#file')).removeAttr("id");
		$("#file").attr('name', 'files[]').removeAttr("id").removeAttr("required");
		$('#divFile').append('<input id="file" type="file" required>');
	}
	
	$('#divFileEdit').on('click', 'button', function () {
		$('#file').trigger('click');
	});



	//==== Enable/Disable Doctor & Rate field (including disabling Speacialist field)
	function FieldPosition(){
		if($('#VPOSCODE').val() == "04") 
		{
			$('#VDRTYPE').prop('disabled', false);
			$('#NRATE').prop('disabled', false);
		}
		else{
			$('#VDRTYPE').prop('disabled', true);
			$('#VDRTYPE').val('');
			$('#VSPCCODE').prop('disabled', true);
			$('#VSPCCODE').val('');
			$('#NRATE').prop('disabled', true);
			$('#NRATE').val('');
		}
	}

	//==== Enable/Disable Specialist field
	function FieldDoctor(){
		if($('#VDRTYPE').val() == "SPCL") $('#VSPCCODE').prop('disabled', false);
		else 
		{
			$('#VSPCCODE').prop('disabled', true);
			$('#VSPCCODE').val('');
		}
	}

	//==== Mandatory/Not Mandatory 
	function FieldUserType(){
		if($('#VEMPTYPE').val() == "CT") 
		{
			$('#DENDCNTRCT input[name="DENDCNTRCT"]').attr('required', true);
			$('input[name="VBPJSNO"]').removeAttr("required");
			$('input[name="VJHTNO"]').removeAttr("required");
		}
		else 
		{
			$('#DENDCNTRCT input[name="DENDCNTRCT"]').removeAttr("required");
			$('input[name="VBPJSNO"]').attr('required', true);
			$('input[name="VJHTNO"]').attr('required', true);
		}
	}
	
	//==== Sub Personnel Area
	function FieldSubPersonnelArea(){
		// filter the options
		var options = AllSubPersonnelAreaOption.filter(function(e){
                return $(this).attr("code") == $("select[name='VPRSNLAREACODE'] option:selected").val();
			}).clone();
			
		$("select[name='VSUBPRSNLAREACODE']").empty();
		$("select[name='VSUBPRSNLAREACODE']").append(options);
	}

</script>
@endsection