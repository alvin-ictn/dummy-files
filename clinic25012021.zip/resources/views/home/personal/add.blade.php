@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Add Personnel Area</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Add New Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/addpersonel/insert" id="form-confirm">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Personnel Area Code</label>
                              <div class="col-sm-4">
                                 <input name="code" placeholder="Personnel Area Code" class="form-control" type="text" maxlength="20" required>
                                 <span class="help-block"></span>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Personnel Area Name</label>
                              <div class="col-sm-4">
                                 <input name="name" placeholder="Personnel Area Name" class="form-control" type="text" maxlength="50" required>
                              </div>
                           </div>
                        </div>
                        <div class="form-group row">
                           <div class="col-md-12">
                              <div class="float-right">
                                 <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                 <a href="/account/personel" class="btn btn-cstm btn-light btn-sz">Close</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
@endsection