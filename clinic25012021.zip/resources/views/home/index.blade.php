@extends('layout.app')
@section('content')
<section class="content">
<div class="container">


  <div class="alert alert-success" id="legal">
    <button type="button" data-dismiss="alert" aria-hidden="true" class="close">×</button>
    <div class="icon hidden-xs">
      <i class="fa fa-info-circle"></i>
    </div>
       <button type="button" class="btn btn-link" data-judul="LEGAL COMPLIANCE" data-toggle="modal" data-target="#modal-dashboard-legal" style="color:white;">LEGAL COMPLIANCE</button>
  </div>
  <div class="alert alert-success" id="drugsreceive">
    <button type="button" data-dismiss="alert" aria-hidden="true" class="close">×</button>
    <div class="icon hidden-xs">
      <i class="fa fa-exclamation-circle"></i>
    </div>
    
    <button type="button" class="btn btn-link" data-judul="DRUGS STOCK" data-toggle="modal" data-target="#modal-dashboard-drugs" style="color:white;">DRUGS STOCK</button>

  </div>
  <div class="alert alert-success" id="tools">
    <button type="button" data-dismiss="alert" aria-hidden="true" class="close">×</button>
    <div class="icon hidden-xs">
      <i class="fa fa-info-circle"></i>
    </div>
    <button type="button" class="btn btn-link" data-judul="TOOLS CALIBRATION" data-toggle="modal" data-target="#modal-dashboard-tools-calibration" style="color:white;">TOOLS CALIBRATION</button>

  </div>
  <div class="alert alert-success" id="routinedrugs">
    <button type="button" data-dismiss="alert" aria-hidden="true" class="close">×</button>
    <div class="icon hidden-xs">
      <i class="fa fa-info-circle"></i>
    </div>
    <button type="button" class="btn btn-link" data-judul="ROUTINE DRUGS RECEIVE" data-toggle="modal" data-target="#modal-dashboard-drugs-receive" style="color:white;">ROUTINE DRUGS RECEIVE</button>

  </div>

</div>
</section>
<!-- Modal Legal Bootstrap -->
<div class="modal fade" id="modal-dashboard-legal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-content">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title header" id="exampleModalLabel"></h5>

      </div>
      <div class="modal-body">
            <div id="legal" class="table-responsive">
               <table id="table-legal" class="table table-bordered table-striped display compact nowrap" style="width:100%">
                  <thead>
                     <tr>
                        <th>
                           Clinic
                        </th>
                        <th>
                           Type
                        </th>
                        <th>
                           Name
                        </th>
                        <th>
                           Position
                        </th>
                        <th>
                           Expired Date
                        </th>
                     </tr>
                  </thead>
               </table>
            </div>

      </div>
      <div class="modal-footer text-align">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- TOOLS CALIBRATION -->
<div class="modal fade" id="modal-dashboard-tools-calibration" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-content">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title header" id="exampleModalLabel"></h5>

      </div>
      <div class="modal-body">

            <div id="patienttools" class="table-responsive" >
               <table id="table-patienttools" class="table table-bordered table-striped display compact nowrap"  style="width:100%">
                  <thead>
                     <tr>
                        <th>
                           Clinic
                        </th>
                        <th>
                           Medical Kits Name
                        </th>
                        <th>
                           Medical Kits Brand
                        </th>
                        <th>
                           Expired Date
                        </th>
                     </tr>
                  </thead>
               </table>
            </div>
            
      </div>
      <div class="modal-footer text-align">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- DRUGS STOCK -->
<div class="modal fade" id="modal-dashboard-drugs" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-content">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title header" id="exampleModalLabel"></h5>

      </div>
      <div class="modal-body">

            <div id="modaldrugs" class="table-responsive">
               <table id="table-modaldrugs" class="table table-bordered table-striped display compact nowrap"  style="width:100%">
                  <thead>
                     <tr>
                        <th>
                           Clinic
                        </th>
                        <th>
                           Drugs Code
                        </th>
                        <th>
                           Brand
                        </th>
                       
                     </tr>
                  </thead>
               </table>
            </div>
            
      </div>
      <div class="modal-footer text-align">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- ROUTINE PATIENT SERVICE -->
<div class="modal fade" id="modal-dashboard-drugs-receive" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-content">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title header" id="exampleModalLabel"></h5>

      </div>
      <div class="modal-body">

            <div id="drugs-receive" class="table-responsive">
               <table id="table-drugs-receive" class="table table-bordered table-striped display compact nowrap" style="width:100%">
                  <thead>
                     <tr>
                        <th>
                           Clinic
                        </th>
                        <th>
                           Drugs Code
                        </th>
                        <th>
                            Contain
                        </th>
                        <th>
                            Brand
                        </th>
                       
                     </tr>
                  </thead>
               </table>
            </div>
            
      </div>
      <div class="modal-footer text-align">
        <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="modalnotifikasi" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-sm modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-body">
					<label class="text-label"><b>There is an alert you need to read/action</b></label>

					<div style="text-align:center;">
              <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>

					</div>
				</div>
			</div>
		</div>
	</div>

<script>
$.ajax({
    url: "/tools-calibrate/1",
    type: "GET",
    success: function(data) {
        if (data.result === 'Red') {
            var element = document.getElementById("tools");
            element.classList.add("alert-danger");
            element.classList.remove("alert-success");
        } else if (data.result === 'Yellow') {
            var element = document.getElementById("tools");
            element.classList.add("alert-warning");
            element.classList.remove("alert-success");

        } else if (data.result === 'Green') {
            var element = document.getElementById("tools");
            element.classList.add("alert-success");
            element.classList.remove("alert-success");

        }
    }
});
$.ajax({
    url: "/routinedrugs/1",
    type: "GET",
    success: function(data) {
        if (data.result === 'Red') {
            var element = document.getElementById("routinedrugs");
            element.classList.add("alert-danger");
            element.classList.remove("alert-success");
        } else if (data.result === 'Yellow') {
            var element = document.getElementById("routinedrugs");
            element.classList.add("alert-warning");
            element.classList.remove("alert-success");

        } else if (data.result === 'Green') {
            var element = document.getElementById("routinedrugs");
            element.classList.add("alert-success");
            element.classList.remove("alert-success");

        }
    }
});
$.ajax({
    url: "/drugsreceive/1",
    type: "GET",
    success: function(data) {
        if (data.result === 'Red') {
            var element = document.getElementById("drugsreceive");
            element.classList.add("alert-danger");
            element.classList.remove("alert-success");
        } 
    }
});
$.ajax({
    url: "/legalcompliance/1",
    type: "GET",
    success: function(data) {

      if (data.result === 'Red') {
            var element = document.getElementById("legal");
            element.classList.add("alert-danger");
            element.classList.remove("alert-success");
        } else if (data.result === 'Yellow') {
            var element = document.getElementById("legal");
            element.classList.add("alert-warning");
            element.classList.remove("alert-success");

        } else if (data.result === 'Green') {
            var element = document.getElementById("legal");
            element.classList.add("alert-success");
            element.classList.remove("alert-success");

        }
    }
});
$.ajax({
    url: "/api/getnotif",
    type: "GET",
    success: function(data) {
      if (data.null === '1') {

        $("#modalnotifikasi").modal("show");

        }
    }
});
$(document).ready(function() {
    //// ajax tools

    // Initilize tab id
    $('#modal-dashboard-drugs-receive').on('show.bs.modal', function(e) {
        var header = $(e.relatedTarget).attr('data-judul');
        $(this).find('.header').text(header);
      //   $('#legal').show();
      //   $('#tools').hide();
      //   $('#drugscode').hide();
      //   $('#patienttools').hide();
      $("#table-drugs-receive").DataTable({
            destroy: true,
            searching: true,
            processing: true,
            serverSide: true,
            order: [1, "desc"],
            dom: '<lf<t><r>ip>',
            columnDefs: [{
                "width": "5%",
                "targets": 0
            }],
            ajax: {
                url: '/routinedrugs/',
                type: "GET",
            },
            columns: [{
                    data: "Clinic",
                    name: "Clinic",

                },
                {
                    data: "Code",
                    name: "Code",
                },
                {
                    data: "Contain",
                    name: "Contain",
                },
                {
                    data: "Brand",
                    name: "Brand",
                    orderable: true,
                }

            ],
            fnRowCallback : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
            if (aData['COLOR'] >= 'Yellow') {
               $('td', nRow).css('background-color', 'Yellow');
            }
         }


        });




    });
    $('#modal-dashboard-legal').on('show.bs.modal', function(e) {
        var header = $(e.relatedTarget).attr('data-judul');
        $(this).find('.header').text(header);
      //   $('#legal').show();
      //   $('#tools').hide();
      //   $('#drugscode').hide();
      //   $('#patienttools').hide();
      $("#table-legal").DataTable({
            destroy: true,
            searching: true,
            processing: true,
            serverSide: true,
            order: [1, "desc"],
            dom: '<lf<t><r>ip>',
            columnDefs: [{
                "targets": 0
            }],
            ajax: {
                url: '/legalcompliance/',
                type: "GET",
            },
            columns: [{
                    data: "ClinicName",
                    name: "ClinicName",

                },
                {
                    data: "DocName",
                    name: "DocName",
                },
                {
                    data: "Name",
                    name: "Name",
                    orderable: true,
                },
                {
                    data: "Position",
                    name: "Position",
                },
               
                {
                    data: "ExpDate",
                    name: "ExpDate",
                }

            ],
            fnRowCallback : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
            if (aData['COLOR'] >= 'Yellow') {
               $('td', nRow).css('background-color', 'Yellow');
            }
         }


        });




    });
    $('#modal-dashboard-drugs').on('show.bs.modal', function(e) {
        var header = $(e.relatedTarget).attr('data-judul');
        $(this).find('.header').text(header);
      //   $('#legal').show();
      //   $('#tools').hide();
      //   $('#drugscode').hide();
      //   $('#patienttools').hide();
      $("#table-modaldrugs").DataTable({
            destroy: true,
            searching: true,
            processing: true,
            serverSide: true,
            order: [1, "desc"],
            dom: '<lf<t><r>ip>',
            columnDefs: [{
                "targets": 0
            }],
            ajax: {
                url: '/drugsreceive/',
                type: "GET",
            },
            columns: [{
                    data: "Clinic",
                    name: "Clinic",

                },
                {
                    data: "Code",
                    name: "Code",
                },

               
                {
                    data: "Brand",
                    name: "Brand",
                }

               ]
         


        });

       


    });
    
    $('#modal-dashboard-patient-service').on('show.bs.modal', function(e) {
        console.log("aaa");
        var header = $(e.relatedTarget).attr('data-judul');
        $(this).find('.header').text(header);
        //       $('#legal').show();
        //       $('#tools').hide();
        //       $('#drugscode').hide();
        //       $('#patienttools').hide();


        $("#table-patient-service").DataTable({
            destroy: true,
            searching: false


        });


    });

    $('#modal-dashboard-tools-calibration').on('show.bs.modal', function(e) {
        console.log("aaa");
        var header = $(e.relatedTarget).attr('data-judul');
        $(this).find('.header').text(header);
        //       $('#legal').show();
        //       $('#tools').hide();
        //       $('#drugscode').hide();
        //       $('#patienttools').hide();


        $("#table-patienttools").DataTable({
            destroy: true,
            searching: true,
            processing: true,
            serverSide: true,
            order: [1, "desc"],
            dom: '<lf<t><r>ip>',
            columnDefs: [{
                "targets": 0
            }],
            ajax: {
                url: '/tools-calibrate/',
                type: "GET",
            },
            columns: [{
                    data: "ClinicName",
                    name: "ClinicName",

                },
                {
                    data: "Description",
                    name: "Description",
                    orderable: true,
                },
                {
                    data: "Brand",
                    name: "Brand",
                },
                
                {
                    data: "LastCalibrate",
                    name: "LastCalibrate",
                }

            ],
            fnRowCallback : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
            if (aData['COLOR'] >= 'Yellow') {
               $('td', nRow).css('background-color', 'Yellow');
            }
         }



        });


    });
});
</script>


@endsection