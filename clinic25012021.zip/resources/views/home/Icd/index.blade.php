@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">ICD Diagnosis</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                        ICD Diagnosis
                  </h3>
               </div>
               <div class="card-header">
				  <h3 class="row card-title">
                  <button type="button"  class="btn btn-sz btn-primary" data-toggle="modal" data-target="#Modalicd">Import</button>
                  &nbsp;
                        <form action="/icd/export_excel" method="POST">
                           @csrf

                           <input type="hidden" value="" name="no" id="no">
                           <input type="hidden" value="" name="diagcode" id="diagcode">
                           <input type="hidden" value="" name="diagname" id="diagname">
                           <input type="hidden" value="" name="remaks" id="remaks">
                           <input type="hidden" value="" name="date" id="date">

                           <input type="hidden" value="" name="search" id="search">
                           <button class="btn btn-sz btn-primary" type="submit">Export to Excel</button>
                        </form>   
                  &nbsp;
                  <a href="{{ asset('file_diagnosis/TEMPLATE_ICDDIAGNOSIS.xls') }}"  class="btn btn-sz btn-primary">Download Template</a>

				  </h3>
			   </div>
			   <!-- /.card-header -->
			   <div class="card-body">
               @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div>
               @endif
                  <div class="table-responsive">
                     <table id="cmicd" class="table table-bordered table-striped display compact nowrap" style="width:100%">
                        <thead>
                           <tr>
                              <th>No</th>

                              <th>Diagnosis Code</th>
                              <th>Diagnosis Name</th>
                              <th>Remaks</th>
                              <th>Last Modified Name</th>
                              <th>Last Modified Date</th>

                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>

<!-- Modal -->
<div class="modal fade" id="Modalicd" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Import ICD</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" data-url="/icd/import_excel" id="formicd"  enctype="multipart/form-data">
        {{ csrf_field() }}
        <label>Pilih file excel</label>
			<div class="form-group">
				<input type="file" id="file" name="file" required="required">
			</div>
      </div>
      <div class="modal-footer">
         <button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
         <button type="button" class="btn btn-cstm btn-light btn-sz" data-dismiss="modal">Close</button>
      </div>
      </form>
    </div>
  </div>
</div>
   </div>
</section>
<script>
   $(document).ready(function() {
      $(document).on("submit", "[id^=formicd]", function (e) {
       e.preventDefault();
       var url = $(this).data("url");
       var formData = new FormData($(this)[0]);

       $.ajax({
               url: url,
               type: "POST",
               headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
               dataType: "JSON",
               data: formData,
               async: false,
               processData: false,
               contentType: false,
               beforeSend: function() {
                     swal.fire({
                           html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
                           allowOutsideClick: false,
                           showCancelButton: false,
                           showConfirmButton: false,
                     });
                  },
               success: function(data){
                  swal.close();
                  location.reload();
                  $("#file").val('');

            }, error: function(error){
               swal.close();
               $('#Modalicd').modal('toggle');
               $("#file").val('');

               Swal.fire({
                   
                     text: error.responseJSON[0],
                     icon: 'error',
                     confirmButtonText: 'OK'
               })
   
          }
       }); 
       return false;
      });
     
   });
</script>
<style>
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::after{display: none}
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::before{display: none}
</style>
@endsection