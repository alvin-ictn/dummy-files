@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Edit District</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Edit Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/drugs/update" id="form-edit">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Drugs Code</label>
                              <div class="col-sm-4">
                                 <input name="code" placeholder="Drugs Code" value="{{$drugs->VDRUGSCODE}}" class="form-control" type="text" maxlength="10" readonly>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Drugs Type</label>
                              <div class="col-sm-4">
                                 <div class="input-group">
                                    <input name="TYPE" value="{{$drugs->VGNRLCODE}}{{isset($drugs->VGNRLDESC) && $drugs->VGNRLDESC != '' ?' - '.$drugs->VGNRLDESC:''}}"  class="form-control" type="text" readonly>
                                    <input name="VDRUGSTYPE" placeholder="Drugs Type" value="{{$drugs->VGNRLCODE}}" class="form-control" type="hidden" readonly>
                                    <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myDrugs">
                                       <div class="input-group-text"><i class="fa fa-search"></i></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Contain</label>
                              <div class="col-sm-4">
                                 <input name="cont" placeholder="Contain" value="{{$drugs->VCONTAIN}}" class="form-control" type="text" required>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Brand</label>
                              <div class="col-sm-4">
                                 <input name="brand" placeholder="Brand" value="{{$drugs->VBRAND}}" class="form-control" type="text" required>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="col-form-label col-sm-2">Vendor Pharmacy</label>
                              <div class="col-sm-4">
                                 <input name="pharmacy" placeholder="Vendor Pharmacy" value="{{$drugs->VPHARMACY}}" class="form-control" type="text">
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">UoM</label>
                              <div class="col-sm-4">
                                 <select class="form-control" name="uom" id="uom" required>
                                    <option value="">-- Select UoM --</option>
                                    @foreach($uom AS $a)
                                    <option value="{{$a->VGNRLCODE}}" {{ $drugs->VUOM == $a->VGNRLCODE ? 'selected="selected"' : '' }}>{{$a->VGNRLDESC}}</option>
                                    @endforeach
                                 </select>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Price</label>
                              <div class="col-sm-4">
                                 <input type="text" class="form-control" placeholder="0" id="rupiah" name="rp" required onkeypress="return (event.charCode !=8 && event.charCode ==0 || ( event.charCode == 46 || (event.charCode >= 48 && event.charCode <= 57)))" />
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Status</label>
                              <div class="col-sm-4">
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a1" value="1" {{ ($drugs->BACTIVE==="1")? "checked" : "" }} required>
                                    <label class="form-check-label" for="a1">Active</label>
                                 </div>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input" name="BACTIVEs" type="radio" id="a2" value="0"  {{ ($drugs->BACTIVE==="0")? "checked" : "" }} required>
                                    <label class="form-check-label" for="a2">InActive</label>
                                 </div>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">PBF</label>
                              <div class="col-sm-4">
                                 <select class="form-control" name="pbf" id="pbf" required>
                                    <option value="">-- Select PBF --</option>
                                    @foreach($pbf1 AS $a)
                                    <option value="{{$a->VSETCODE}}" {{ $pbf->VSETCODE == $a->VSETCODE ? 'selected="selected"' : '' }}>{{$a->VSETDESC}}</option>
                                    @endforeach
                                 </select>
                              </div>
                           </div>
                           <div class="form-group row">
                              <div class="col-md-12">
                                 <div class="float-right">
                                    <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                    <a href="/account/drugs" class="btn btn-cstm btn-light btn-sz">Close</a>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade in" id="myDrugs" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-lg modal-content">
            <div class="card mb-4">
               <div class="card-header bg-info">
                  <h5 class="card-title text-white" align="center">Drugs Type List</h5>
                  <button type="button" class="close text-white" data-dismiss="modal">×</button>
               </div>
               <div class="card-body p-3">
                  <div id="dvData" class="table-responsive">
                     <table id="tbldrugs" class="display" style="width:100%">
                        <thead>
                           <tr>
                              <th>
                                 Drugs Code
                              </th>
                              <th>
                                 Drugs Type
                              </th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<script>
   var rupi = "<?php echo $drugs->NPRICE ?>";
   if(rupi == '.00' || rupi == '') rupi = '0';
   $("#rupiah").val(parseInt(rupi));
   $(document).ready(function() {
		var table = $("#tbldrugs").DataTable({ pagingType: $(window).width() < 768 ? "simple" : "simple_numbers", ajax: { url: '/getdrugslookup', type: "GET", }, columns: [ { data: "VGNRLCODE", name: "VGNRLCODE" }, { data: "VGNRLDESC", name: "VGNRLDESC" } ] });
   	$('#tbldrugs tbody').on('dblclick', 'tr', function () {
   		var data = table.row(this).data();
   		$('input[name="TYPE"]').val(data['VGNRLCODE'] + ' - ' + data['VGNRLDESC']);
   		$('input[name="VDRUGSTYPE"]').val(data['VGNRLCODE']);
   		$(this).closest('.card').find('button').trigger('click');
   	});
   });
   var rupiah = document.getElementById('rupiah');
      rupiah.addEventListener("keyup", function(e) {
      rupiah.value = convertRupiah(this.value);
   });

	rupiah.addEventListener('keydown', function(e){
		// tambahkan 'Rp.' pada saat form di ketik
      // gunakan fungsi formatRupiah() untuk mengubah angka yang di ketik menjadi format angka
      return isNumberKey(this.value);
   });
   function convertRupiah(angka, prefix) {
      var number_string = angka.replace(/[^\d]/g, "").toString(),
      split  = number_string.split(","),
      sisa   = split[0].length % 3,
      rupiah = split[0].substr(0, sisa),
      ribuan = split[0].substr(sisa).match(/\d{3}/gi);

	   if (ribuan) {
		   separator = sisa ? "," : "";
		   rupiah += separator + ribuan.join(",");
	   }
      $('input[name="NPRICE"]').val(number_string)
	   rupiah = split[1] != undefined ? rupiah + "," + split[1] : rupiah;
	   return prefix == undefined ? rupiah : rupiah ? prefix + rupiah : "";
   }

   function isNumberKey(evt){
      key = evt.which || evt.keyCode;
	   if ( 	key != 188 // Comma
		&& key != 8 // Backspace
		&& key != 17 && key != 86 & key != 67 // Ctrl c, ctrl v
      && (key < 48 || key > 57) // Non digit
      ){
		evt.preventDefault();
		return;
	   }
   }
</script>
@endsection
