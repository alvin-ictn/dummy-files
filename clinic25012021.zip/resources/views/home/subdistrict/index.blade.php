@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Master Sub District</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Master Sub District
                  </h3>
               </div>
               <div class="card-header">
                  <h3 class="row card-title">
                     <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('C', 'F21')) { ?>
                        <a class="btn btn-sz btn-primary" href="subdistrict/add" role="button">Add New</a>
                     <?php } ?>
                     <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('E', 'F21')) { ?>
                        &nbsp;
                        <form action="subdistrict/export_excel" method="POST">
                              @csrf
                              <input type="hidden" value="" name="no" id="no">
                              <input type="hidden" value="" name="subdistcode" id="subdistcode">
                              <input type="hidden" value="" name="subdistname" id="subdistname">
                              <input type="hidden" value="" name="distname" id="distname">
                              <input type="hidden" value="" name="status" id="st">
                              <input type="hidden" value="" name="lmname" id="lmname">
                              <input type="hidden" value="" name="lmdate" id="lmdate">
                              <input type="hidden" value="" name="search" id="search">
                              <button class="btn btn-sz btn-primary" type="submit">Export to Excel</button>
                        </form>
                     <?php } ?>
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
               @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div>
               @endif
                  <div class="table-responsive">
                     <table id="cmsubdistrict" class="table table-bordered table-striped display compact nowrap" style="width:100%">
                        <thead>
                           <tr>
                              <th>No</th>
                              <th>Sub District Code</th>
                              <th>Sub District Name</th>
                              <th>District Name</th>
                              <th>Status</th>
                              <th>Last Modified Name</th>
                              <th>Last Modified Date</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<style>
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::after{display: none}
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::before{display: none}
</style>
@endsection