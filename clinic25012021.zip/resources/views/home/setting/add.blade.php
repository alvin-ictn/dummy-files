@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Add Parameter</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                  Add New Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/addsetting/insert" id="form-confirm">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Parameter ID</label>
                              <div class="col-sm-4">
                                 <input name="settingidss" placeholder="Parameter ID" class="form-control" type="text" maxlength="20" required>
                                 <span class="help-block"></span>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-md-2">Parameter Code</label>
                              <div class="col-sm-4">
                                 <input name="settingcodes" placeholder="Parameter Code" class="form-control" type="text" maxlength="10" required>
                              </div>
                           </div>
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Description</label>
                              <div class="col-sm-4">
                                 <input name="deskripsis" placeholder="Description" class="form-control" type="text" maxlength="50" required>
                              </div>
                              <label for="example-text-input" class="col-form-label col-sm-2">Additional Description</label>
                              <div class="col-sm-4">
                                 <input name="deskripsi1s" placeholder="Additional Description 1" class="form-control" type="text" required>
                              </div>
                           </div>
                           <div class="form-group row">
                              <div class="col-md-12">
                                 <div class="float-right">
                                    <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                    <a href="/account/setting" class="btn btn-cstm btn-light btn-sz">Close</a>
                                 </div>
                              </div>
                           </div>
                        </div>
						   </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
@endsection