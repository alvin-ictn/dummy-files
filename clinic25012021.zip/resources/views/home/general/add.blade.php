@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Add General</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Add New Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form method="POST" data-url="/addgeneral/insert" id="form-confirm">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">General Type</label>
                              <div class="col-sm-4">
                                 <div class="input-group">
                                    <input name="TYPE" placeholder="General Type" class="form-control" type="text" value="{{ $user->VCOORDINATOR ?? '' }}" readonly>
                                    <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myType">
                                       <div class="input-group-text"><i class="fa fa-search"></i></div>
                                    </div>
                                 </div>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">General Code</label>
                              <div class="col-sm-4">
                                 <input name="code" placeholder="General Code" class="form-control" type="text" maxlength="10" required>
                              </div>
                           </div>
                           <div class="form-group required row">
                              <label for="example-text-input" class="req col-form-label col-sm-2">General Description</label>
                              <div class="col-sm-4">
                                 <textarea class="form-control" name="desc" placeholder="General Description" rows="3"></textarea>

                                 <!-- <input name="desc" placeholder="General Description" class="form-control" type="text" maxlength="50" required> -->
                              </div>
                              <label for="example-text-input" class="col-form-label col-sm-2">General Remarks</label>
                              <div class="col-sm-4">
                                 <textarea class="form-control" name="rmrks" placeholder="General Remarks" rows="3"></textarea>

                              </div>
                           </div>
                        </div>
                        <div class="form-group row">
                           <div class="col-md-12">
                              <div class="float-right">
                                 <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                 <a href="/account/general" class="btn btn-cstm btn-light btn-sz">Close</a>
                              </div>
                           </div>
                        </div>
						   </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade in" id="myType" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-lg modal-content">
            <div class="card mb-4">
               <div class="card-header bg-info">
                  <h5 class="card-title text-white" align="center">General Type</h5>
                  <button type="button" class="close text-white" data-dismiss="modal">×</button>
               </div>
               <div class="card-body p-3">
                  <div id="dvData" class="table-responsive">
                     <table id="tbltype" class="display" style="width:100%">
                        <thead>
                           <tr>
                              <th>
                                 General Type
                              </th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<script>
   $(document).ready(function() {
		var table = $("#tbltype").DataTable({ pagingType: $(window).width() < 768 ? "simple" : "simple_numbers", ajax: { url: '/getgenerallookup', type: "GET", }, columns: [ { data: "VGNRLTYPE", name: "VGNRLTYPE" }]});
   	$('#tbltype tbody').on('dblclick', 'tr', function () {
   		var data = table.row(this).data();
   		$('input[name="TYPE"]').val(data['VGNRLTYPE']);
   		$(this).closest('.card').find('button').trigger('click');
   	});
	});
</script>
@endsection