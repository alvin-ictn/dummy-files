@extends('layout.app')
@section('content')

<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-12">
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
     
            <div class="card">
               <!-- /.card-header -->
               <div class="card-body">
                  <form data-url="choosebooking" id="idform">
                     <div class="row">
                        <div class="col-lg-1 col-sm-12">
                           <label class="col-sm-2 col-form-label col-sm-12"><h6>Clinic</h6></label>
                        </div>
                        <div class="col-lg-2 col-sm-12">
                          
                             
                                 <div class="form-group">
                                    <select class="form-control" id="clinic"  {{  Session::get('namaclinic')   ?   'disabled' : ''   }}>
                                       <option >----</option>
                                       @foreach ($clinic as $b)
                                       <option id="{{$b->VCLINICCODE}}" value="{{$b->VCLINICCODE}}" {{  Session::get('namaclinic') === $b->VCLINICCODE ? 'selected="selected"' : '' }} >{{$b->VCLINICNAME}}</option>
                                       @endforeach
                                    </select>
                                 </div>
                             
                           
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-lg-1 col-sm-12">
                           <label class="col-sm-2 col-form-label col-sm-12"><h6>Doctor</h6></label>
                        </div>
                        <div class="col-lg-2 col-sm-12">
                                 <div class="form-group">
                                    <select class="form-control" id="coose">
                                       <option value="">choose a doctor</option>
                                    </select>
                                 </div>
                        </div>
                        <div class="col-lg-3 col-sm-12 specialist">
                                 <div class="form-group">
                                    <div id="specialist1"></div>
                                 </div>
                        </div> 
                        <div class="col-lg-2 col-sm-12">
                         <button type="submit" class="btn btn-sz btn-primary">Search</button>
                        </div>
                     </div>
                     
                  </form>
                  <!-- <div class="row">
                     <div class="col-1"><h6>Clinic</h6></div>
                     <div class="col-3">
                     <form data-url="choosebooking" id="idform">

                           <div  class="form-group ">
                                    <select class="form-control " id="clinic"  {{  Session::get('namaclinic')   ?   'disabled' : ''   }}>
                                       <option >----</option>
                                       @foreach ($clinic as $b)
                                       <option id="{{$b->VCLINICCODE}}" value="{{$b->VCLINICCODE}}" {{  Session::get('namaclinic') === $b->VCLINICCODE ? 'selected="selected"' : '' }} >{{$b->VCLINICNAME}}</option>
                                       @endforeach
                                    </select>
                           </div>
                     </div>
                     <div class="col-2"></div>
                     <div class="col-5"></div>

                  </div>
                  <div class="row">
                     <div class="col-1"><h6>Doctor</h6></div>
                        <div class="col-3">
                           <div  class="form-group ">
                                 <select class="form-control" id="coose">
                                    <option value="">choose a doctor</option>
                                 </select>
                           </div>
                        </div>
                        <div class="col-2 specialist"> 
                           <div  id="specialist1"></div>
                          
                        </div>
                     <div class="col-5">
                         <button type="submit" class="btn btn-sz btn-primary">Search</button>
                     </div>
                  </form> -->
                  <!-- </div> -->
                  <div id="hiddenview">
                     </div>
                  </div>


                 
            </div>
         
   </div>
</section>
<input type="hidden" id="idclinic" value="{{Session::get('namaclinic') }}">
<script>
$('.specialist').hide();
$('#specialist1').hide();

$base64 = btoa($( "#clinic  option:selected" ).val());
$clinic = $( "#idclinic" ).val();
// window.onload = function() {

// var name = $('#clinic');
// if (name !== null) $('#clinic').val("name");

// // ...
// }
if(!$clinic){
   $("#clinic").change(function() {
            $.ajax({
                type: "GET",
                dataType: "JSON",
                url: "/ajaxdoctor/" + $base64,
                success: function(data) {
                   var html = '';
                   var i;
                   html +='<option selected>----</option>';

                   for (i = 0; i < data.length; i++) {
                    html += '<option value=' + data[i].VSETCODE + '>' + data[i].VSETDESC + '</option>';
                   }
                $('#coose').html(html);
                $('.specialist').hide();
               $("#hiddenview").hide();
                }
            });
      

    });

}else{
            $.ajax({
                type: "GET",
                dataType: "JSON",
                url: "/ajaxdoctor/" + $base64,
                success: function(data) {
                   var html = '';
                   var i;
                   html +='<option selected>----</option>';

                   for (i = 0; i < data.length; i++) {
                    html += '<option value=' + data[i].VSETCODE + '>' + data[i].VSETDESC + '</option>';
                   }
                $('#coose').html(html);
                $('.specialist').hide();
               $("#hiddenview").hide();
                }
            });

}

$(document).ready(function() {
  
    $("#coose").change(function() {

        $choose = $("#coose  option:selected" ).val();
         
            $base64 = btoa($( "#coose  option:selected" ).val());
          if($choose === 'SPCL'){
            $.ajax({
                type: "GET",
                dataType: "JSON",
                url: "/choosespecialist/" + $base64,
                success: function(data) {
                  if (data.null === 'GIGI') {
                     $('.specialist').hide();
                     $("#hiddenview").hide();
                } else {
                  var html = '';
                html +="<div id='hidden-setting'><select class='form-control' id='specialist'><option value=''>choose a Specialist</option>"+data.data+"</select></div>";
                  $('.specialist').show();
                  $('#specialist1').show();
                  $("#hiddenview").hide();
                    $("#specialist1").html(html);
                }
                
                    


                }
            });
         }else{

            $('.specialist').hide();
            $('#specialist1').hide();
            $("#hiddenview").hide();
         }
         

    });
    $(document).on("submit", "[id^=idform]", function(e) {
        e.preventDefault();
        var url = $(this).data("url");
        var durl = btoa($('#coose').val() + ',' + $('#specialist').val() + ',' + $('#clinic').val() );
        $.ajax({
            type: "GET",
            dataType: "JSON",
            url: "/choosedoctor/" + durl,
            success: function(data) {
               if (data.null === 'G') {
                     window.location.href = "/account/booking/add/appointment/"  + data.crypt ;
                     $('.specialist').hide();
                } else if(data.null === 'U'){
                  window.location.href = "/account/booking/add/appointment/" + data.crypt;
                     $('.specialist').hide();
                }else {
               if (data.null === '') {
                  $("#hiddenview").hide();
                } else {
                    $("#hiddenview").html(data.null);
                    $("#hiddenview").show();
                }

                }
               

            }
        });
        return false;

    });
});
</script>
@endsection