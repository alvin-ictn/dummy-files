@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-12">
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header card-color">
                        <h3 class="card-title text-white">
                        Upload Attachment Form
                    </h3>
                </div>
               <!-- /.card-header -->
                <div class="card-body">
                    <form id="form-confirm" data-url="/patientlist/attachmentform" method="POST" enctype="multipart/form-data">
                        @csrf
                        <!-- <input name="VSCHCODE" type="hidden" value="{{ $tmp->VSCHCODE ?? '' }}"> -->
                        <div class="row">
                            <div class="col-lg-2 col-sm-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">MR No</label>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-12">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <div class="input-group">
                                            <input name="VMRNO" class="form-control" type="text" value="{{ $tmp->VMRNO ?? '' }}" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-2 col-sm-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">Patient Name</label>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-12">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <div class="input-group">
                                            <input name="VNAME" class="form-control" type="text" value="{{ $tmp->VNAME ?? '' }}" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <br/>

                        <div class="row">
                            <div class="col-lg-2 col-sm-12">
                                <div class="form-group">
                                    <label class="control-label col-sm-12">File Name</label>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-12">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <div class="input-group">
                                            <input name="VFILENAME" class="form-control" type="text" value="{{ $tmp->VFILENAME ?? '' }}" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-4 col-sm-12">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <div class="input-group">
                                            <input id="file" type="file" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>

                        <div class="row">
                            <div class="col-lg-12 col-sm-12 form-group">
                                <table id="tblmember" border="1" width="100%">
                                    <thead>
                                        <tr>
                                            <th class="text-center">File Name</th>
                                            <th class="text-center">Document</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if(isset($tmp))
                                            @foreach ($tmp as $member)
                                                <tr>
                                                    <td data-value="VFNAME"> {{$member->VFNAME }}  <input name="VFNAME[]" type="hidden" value='{{$member->VFNAME }}'></td>
                                                    <td data-value="VDOC"> {{$member->VDOC }} <input name="VDOC[]" type="hidden" value='{{$member->VDOC }}'></td>

                                                </tr>
                                            @endforeach
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <br/>
                        <div class="form-group row">
                            <div class="col-md-12">
                                <div class="float-right">
                                    <a href="/account/booking/patientlist/" class="btn-cstm btn-light btn-sz">Close</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
	$(document).ready(function() {
        

        // DEBUG
        // $('#startDiv').on('click', function()
        // {
        //     alert("VSCHCODE val : " + $('input[name="VSCHCODE"]').val());
        // });
    });
   


</script>
@endsection