@extends('layout.app')
@section('content')

<script>
   function IsPatientList()
   {
      if(window.location.hash.includes("#ptntlst")) return true;
      else return false;
   }
</script>
<style>


</style>
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-12"></div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color ">
                  <h3 class="card-title">
                     <h3 class="card-title text-white">Patient Information</h3>
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <svg class="hidden" style="display: none;">
                     <defs>
                        <path id="tabshape" d="M80,60C34,53.5,64.417,0,0,0v60H80z" />
                     </defs>
                  </svg>
                  @if(Session::get('groupuser')[0] === "DCTR" || Session::get('groupuser')[0] === "HRADM")
                  <fieldset id="fieldset">
                  @endif
                     <section class="m-t-40">
                        <div class="sttabs tabs-style-shape">
                           <nav>
                              <ul>
                                 <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F01' : 'NOTALLOWED')) { ?>
                                 <li style="z-index: 1" onclick="SetFront(this.id)" id="0" name="tab">
                                    <a href="#section-1">
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <span>Booking</span>
                                    </a>
                                 </li>
                                 <?php } ?>
                                 <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F02' : 'F28')) { ?>
                                 <li style="z-index: 0" onclick="SetFront(this.id)" id="1" name="tab" tab="General">
                                    <a href="#section-shape-2">
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <span>General</span>
                                    </a>
                                 </li>
                                 <?php } ?>
                                 <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F03' : 'F29')) { ?>
                                 <li style="z-index: 0" onclick="SetFront(this.id)" id="2" name="tab" tab="Examination">
                                    <a href="#section-shape-3">
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <span>Examination</span>
                                    </a>
                                 </li>
                                 <?php } ?>
                                 <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F05' : 'F30')) { ?>
                                 <li style="z-index: 0" onclick="SetFront(this.id)" id="3" name="tab" tab="Treatment">
                                    <a href="#section-shape-4">
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <span>Treatment</span>
                                    </a>
                                 </li>
                                 <?php } ?>
                                 <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F06' : 'F31')) { ?>
                                 <li style="z-index: 0" onclick="SetFront(this.id)" id="4" name="tab">
                                    <a href="#section-shape-5">
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <span>History MR</span>
                                    </a>
                                 </li>
                                 <?php } ?>
                                 <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F07' : 'F32')) { ?>
                                 <li style="z-index: 0" onclick="SetFront(this.id)" id="5" name="tab" >
                                    <a href="#section-shape-6">
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <span>Result MCU</span>
                                    </a>
                                 </li>
                                 <?php } ?>
                                 <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'NOTALLOWED' : 'F27')) { ?>
                                 <li style="z-index: 0" onclick="SetFront(this.id)" id="6" name="tab" tab="Document List">
                                    <a href="#section-shape-7">
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <svg viewBox="0 0 80 60" preserveAspectRatio="none">
                                          <use xlink:href="#tabshape"></use>
                                       </svg>
                                       <span>Document List</span>
                                    </a>
                                 </li>
                                 <?php } ?>
                              </ul>
                           </nav>
                           <div class="content-wrap">
                              <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F01' : 'NOTALLOWED')) { ?>
                              <section id="section-1">
                                 <form data-url="/patientbooking" class="form-confirm"  method="POST" >
                                    <input type="hidden" name="vbooking" class="vbooking" value="{{$db}}">
                                    @csrf
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">MR No.</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input class="form-control tab-booking-r" type="text" value="{{$patient->VMRNO}}" name="VMRNO" readonly>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-8">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Queue No.</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input class="form-control tab-booking-d" type="text" value="{{$patient->IQUEUENO}} / {{$db}}" disabled>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Patient Name</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VPatientName" class="form-control tab-booking-d" type="text" value="{{$patient->VNAME}}" required disabled>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Place/Date of birth </label>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input class="form-control tab-booking-d" type="text" value="{{$patient->VCITYBIRTH}}" disabled>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input class="form-control tab-booking-d" type="text" value="{{$DBIRTH}}" disabled>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-sm-12">
                                          <div class="form-group">
                                             <label class="control-label col-sm-12">Entry Date</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-sm-12">
                                          <div class="form-group">
                                             <div class="col-sm-12">
                                                <input name="VAge" class="form-control tab-booking-d" type="text" value="{{$DCREAS}}" disabled>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-sm-12">
                                          <div class="form-group">
                                             <label class="control-label col-sm-12">Age</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-sm-12">
                                          <div class="form-group">
                                             <div class="col-sm-12">
                                                <input name="VAge" class="form-control tab-booking-d" type="text" value="{{$y}}" disabled>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Visit Date</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VSITDATE" class="form-control tab-booking-d" type="text" value="{{$visitdate}}" disabled>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-sm-12">
                                          <div class="form-group">
                                             <label class="control-label col-sm-12">Gender </label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-sm-12">
                                          <div class="form-group">
                                             <div class="col-sm-12">
                                                <div class="form-check form-check-inline gender-general">
                                                   <input class="form-check-input tab-booking-d" name="VGNDRCODEX" type="radio" value="M" {{ isset($patient) && $patient->gender == 'M' ? 'checked' : '' }} disabled >
                                                   <label class="form-check-label">Male</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                   <input class="form-check-input tab-booking-d" name="VGNDRCODEX" type="radio" value="F" {{ isset($patient) && $patient->gender == 'F' ? 'checked' : '' }} disabled>
                                                   <label class="form-check-label">Female</label>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       @if(!$patient->VEMPSAPID)
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">ID Card</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VPROFESSION tab-booking-r" class="form-control" type="text" value="{{$patient->VIDCARDNO}}" readonly>
                                             </div>
                                          </div>
                                       </div>
                                       @else
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">SAP ID</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="SAPIDS" class="form-control tab-booking-r" type="text" value="{{$patient->VEMPSAPID}}" readonly>
                                             </div>
                                          </div>
                                       </div>
                                       @endif
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Phone No.</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <div class="input-group">
                                                   <input name="VINSURANCENAME" class="form-control tab-booking-r" type="text" value="{{$patient->nohp}}" readonly>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Doctor</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <div class="input-group">
                                                   <!-- GROUPUSER -->
                                                   @if( Session::get('typeuser') === "NE" && in_array('PRMDC', Session::get('groupuser')) !== false)
                                                   @if($patient->VPOSCODE !== 'SPCL')
                                                   <input name="DOCTOR" class="form-control tab-booking-r" type="text" value="{{$patient->NAMADOCTOR ?? ''}}" readonly>
                                                   <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#dctr1">
                                                      <div class="input-group-text"><i class="fa fa-search"></i></div>
                                                   </div>
                                                   <input type="hidden" value="{{$patient->VDRID ?? ''}}" name="DOCTR" >
                                                   @else
                                                   <input name="DOCTOR" class="form-control tab-booking-r" type="text" value="{{$patient->NAMADOCTOR ?? ''}}" readonly>
                                                   <input type="hidden" value="{{$patient->VDRID}}" name="DOCTR" >
                                                   @endif
                                                   @else
                                                   <input name="DOCTOR" class="form-control tab-booking-r" type="text" value="{{$patient->NAMADOCTOR}}" readonly>
                                                   @endif
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <!-- <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Doctor</label>
                                          </div>
                                          </div>
                                          <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="DOCTR" class="form-control" type="text" value="{{$patient->NAMADOCTOR}}" disabled>
                                             </div>
                                          </div>
                                          </div> -->
                                       @if( Session::get('typeuser') === "NE" && in_array('PRMDC', Session::get('groupuser')) !== false)
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Alternative Doctor</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <div class="input-group">
                                                   <input name="ALTERNATIVE" class="form-control tab-booking-r" type="text" value="{{$patient->VOTHDRID1 ?? ''}}" readonly>
                                                   <input name="ALTERNATIVES" class="form-control"  value="{{$patient->VOTHDRID ?? ''}}" type="hidden">
                                                   <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#alterdctr">
                                                      <div class="input-group-text"><i class="fa fa-search"></i></div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       @else
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">BPJS No.</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <div class="input-group">
                                                   <input name="VINSURANCENAME" class="form-control tab-booking-r" type="text" value="" readonly>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       @endif
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <div class="input-group">
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    @if( Session::get('typeuser') === "NE" && in_array('PRMDC', Session::get('groupuser')) !== false)
                                    <button id="startDivExamination" type="submit" class="btn btn-cstm btn-primary btn-sz">Submit</button>
                                    @endif
                                    <a class="btn-cstm btn-light btn-sz close_button" target="popup" role="button">Close</a>
                                 </form>
                              </section>
                              <?php } ?>

                              <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F02' : 'F28')) { ?>
                              <section id="section-shape-2">
                                 <form  data-url="/updategeneral" class="form-confirm general" method="post" id="general">
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">MR No.</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input class="form-control" type="text" value="{{$patient->VMRNO}}" name="VMRNO" readonly>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group required">
                                             <label class="control-label col-md-12">Place/Date of birth</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input class="form-control" type="text" value="{{$patient->VCITYBIRTH}}" readonly>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input class="form-control" type="text" value="{{$DBIRTH}}" readonly>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group required">
                                             <label class="control-label col-md-12">Patient Name</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group required">
                                             <div class="col-md-12">
                                                <input name="VPatientName" class="form-control" type="text" value="{{$patient->VNAME}}" required>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Age.</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VAge" class="form-control" type="text" value="{{$y}}" disabled>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-sm-12">
                                          <div class="form-group required">
                                             <label class="control-label col-sm-12">Status</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-sm-12">
                                          <div class="form-group">
                                             <div class="col-sm-12">
                                                <select class="form-control relation-vmarital" name="VSTS"  required >
                                                   <option value="">-- Select Status --</option>
                                                   @foreach($setting AS $a)
                                                   <option value="{{$a->VSETCODE}}" {{ isset($patient->VMARITALSTS) && $a->VSETCODE === $patient->VMARITALSTS ? 'selected="selected"' : '' }}>{{$a->VSETDESC}}</option>
                                                   @endforeach
                                                </select>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-sm-12">
                                          <div class="form-group required">
                                             <label class="control-label col-sm-12">Gender</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-sm-12">
                                          <div class="form-group gender-general ">
                                             <div class="col-sm-12">
                                                <div class="form-check form-check-inline">
                                                   <input class="form-check-input" name="VGNDRCODEX" type="radio" value="M" {{ isset($patient) && $patient->gender == 'M' ? 'checked' : '' }} readonly required>
                                                   <label class="form-check-label">Male</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                   <input class="form-check-input" name="VGNDRCODEX" type="radio" value="F" {{ isset($patient) && $patient->gender == 'F' ? 'checked' : '' }} readonly required>
                                                   <label class="form-check-label">Female</label>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-6 col-sm-12">
                                          <div class="row">
                                             <div class="col-lg-4 col-md-12">
                                                <div class="form-group required">
                                                   <label class="control-label col-md-12">Address</label>
                                                </div>
                                             </div>
                                             <div class="col-lg-8 col-md-12">
                                                <div class="form-group">
                                                   <div class="col-md-12">
                                                      <textarea class="form-control" name="VADDRESSX" rows="3" required>{{$patient->VADDRESS}}</textarea>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                   <label class="control-label col-md-12">Postal Code</label>
                                                </div>
                                             </div>
                                             <div class="col-lg-8 col-md-12">
                                                <div class="form-group">
                                                   <div class="col-md-12">
                                                      <input name="VPOSTALCODEX" class="form-control" type="text" value="{{$patient->VPOSTALCODE}}">
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-6 col-sm-12">
                                          <div class="row">
                                             <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                   <label class="control-label col-md-12">Province</label>
                                                </div>
                                             </div>
                                             <div class="col-lg-8 col-md-12">
                                                <div class="form-group">
                                                   <div class="col-md-12">
                                                      <select class="form-control province relation select22"  name="province">
                                                         <option value="">-- Select Province --</otpion>
                                                            @foreach($province AS $p)
                                                            <option value="{{$p->VPROVCODE}}" {{ isset($patient) && $patient->VPROVCODE === $p->VPROVCODE ? 'selected="selected"' : '' }}>{{$p->VPROVNAME}}
                                                         </option>
                                                         @endforeach
                                                      </select>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                   <label class="control-label col-md-12">District </label>
                                                </div>
                                             </div>
                                             <div class="col-lg-8 col-md-12">
                                                <div class="form-group">
                                                   <div class="col-md-12">
                                                      <select class="form-control district relation select22" id="district" name="district">
                                                      <option value="">-- Select District --</otpion>

                                                      @if(isset($patient->VDISTRICTCODES))
                                                      @foreach($district AS $d)
                                                      <option value="{{$d->VDISTRICTCODE}}" {{ isset($patient) && $patient->VDISTRICTCODES === $d->VDISTRICTCODE ? 'selected="selected"' : '' }}>{{$d->VDISTRICTNAME}}</option>
                                                      @endforeach
                                                      @endif
                                                      </select>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                   <label class="control-label col-md-12 select22">Sub District</label>
                                                </div>
                                             </div>
                                             <div class="col-lg-8 col-md-12">
                                                <div class="form-group">
                                                   <div class="col-md-12">
                                                      <select class="form-control subdistrict relation" id="subdistrict relation" name="subdistrict">
                                                      <option value="">-- Select Sub District --</otpion>

                                                      @if(isset($patient->VSUBDISTRICTCODES))
                                                      @foreach($subdistrict AS $d)
                                                      <option value="{{$d->VSUBDISTRICTCODE}}" {{ isset($patient) && $patient->VSUBDISTRICTCODES === $d->VSUBDISTRICTCODE ? 'selected="selected"' : '' }}>{{$d->VSUBDISTRICTNAME}}</option>
                                                      @endforeach
                                                      @endif
                                                      </select>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Phone No .</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VPHONENO" class="form-control" type="text" value="{{$patient->nohp}}">
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group required">
                                             <label class="control-label col-md-12">ID Card</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="idcard" class="form-control" type="text" value="{{$patient->idcard}}" required>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Profession</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VPROFESSION" class="form-control" type="text" value="{{$patient->profesi}}">
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Blood Type</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <div class="form-check form-check-inline">
                                                   <input class="form-check-input" name="VBLOODTYPE" type="radio" value="O" {{ isset($patient) && $patient->VBLOODTYPE == 'O' ? 'checked' : '' }} >
                                                   <label class="form-check-label">O</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                   <input class="form-check-input" name="VBLOODTYPE" type="radio" value="A" {{ isset($patient) && $patient->VBLOODTYPE == 'A' ? 'checked' : '' }} >
                                                   <label class="form-check-label">A</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                   <input class="form-check-input" name="VBLOODTYPE" type="radio" value="B" {{ isset($patient) && $patient->VBLOODTYPE == 'B' ? 'checked' : '' }} >
                                                   <label class="form-check-label">B</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                   <input class="form-check-input" name="VBLOODTYPE" type="radio" value="AB" {{ isset($patient) && $patient->VBLOODTYPE == 'AB' ? 'checked' : '' }}>
                                                   <label class="form-check-label">AB</label>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">BPJS No.</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VBPJS" class="form-control" type="text" value="{{$patient->BPJS}}">
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Insurance Name</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <select class="form-control relation" name="VSTSX">
                                                   <option value="">-- Select Insurance Name --</option>
                                                   @foreach($asurance AS $a)
                                                   <option value="{{$a->VGNRLCODE}}" {{ isset($patient) && $patient->VINSCODE === $a->VGNRLCODE ? 'selected="selected"' : '' }}>{{$a->VGNRLDESC}}</option>
                                                   @endforeach
                                                </select>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Insurance No</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VINSURANCENO" class="form-control" type="text" value="{{$patient->VINSNO}}">
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group required">
                                             <label class="control-label col-md-12">Group Patient</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group " >
                                             <div class="col-md-12">
                                                <div class="form-check form-check-inline" >
                                                   <input class="form-check-input VGRPPATIENT"  name="VGRPPATIENT" type="radio" value="E" {{ $patient->VTYPEPATIENT == 'E' ? 'checked' : '' }} required disabled>
                                                   <label class="form-check-label">Employee</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                   <input class="form-check-input VGRPPATIENT"  name="VGRPPATIENT" type="radio" value="C" {{ $patient->VTYPEPATIENT == 'C' ? 'checked' : '' }} required disabled>
                                                   <label class="form-check-label">Contractor</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                   <input class="form-check-input VGRPPATIENT"  name="VGRPPATIENT" type="radio" value="R" {{ $patient->VTYPEPATIENT == 'R' ? 'checked' : '' }} required disabled>
                                                   <label class="form-check-label">Public</label>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group required">
                                             <label class="control-label col-md-12">SAP ID</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VSAPID" class="form-control" type="text" value="{{$patient->VEMPSAPID}}" readonly>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group required">
                                             <label class="control-label col-md-12">Company</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VCOMPANY" class="form-control" type="text" value="" {{ $patient->VTYPEPATIENT == 'C' ? '' : 'readonly' }}  >
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Employee Name</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <div class="input-group">
                                                   <input name="VEMPLOYEENAME" class="form-control" type="text" value="{{$vsapid->VNAME ?? ''}}" readonly>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group required">
                                             <label class="control-label col-md-12">Department</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VDEPARTMENT" class="form-control" type="text" value="" readonly>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <p style="background-color:#6dc7e1; color:white;" class="p-1"><b>Person in charge of patient</b></p>
                                    <br />
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">PIC Name</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VPICNAME" class="form-control" type="text" value="{{$patient->VPICNAME}}">
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">ID Card</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <div class="input-group">
                                                   <input name="VPICIDCARDNO" class="form-control" type="text" value="{{$patient->VIDCARDNO}}">
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-6 col-sm-12">
                                          <div class="row">
                                             <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                   <label class="control-label col-md-12">Address</label>
                                                </div>
                                             </div>
                                             <div class="col-lg-8 col-md-12">
                                                <div class="form-group">
                                                   <div class="col-md-12">
                                                      <textarea class="form-control" name="VPICADDRESS" rows="3">{{$patient->VPICADDRESS}}</textarea>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                   <label class="control-label col-md-12">Postal Code</label>
                                                </div>
                                             </div>
                                             <div class="col-lg-8 col-md-12">
                                                <div class="form-group">
                                                   <div class="col-md-12">
                                                      <input name="VPICPOSTALCODE" class="form-control" type="text" value="{{$patient->VPICPOSTALCODE}}">
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-6 col-sm-12">
                                          <div class="row">
                                             <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                   <label class="control-label col-md-12">Province</label>
                                                </div>
                                             </div>
                                             <div class="col-lg-8 col-md-12">
                                                <div class="form-group">
                                                   <div class="col-md-12">
                                                      <div class="input-group">
                                                         <select class="form-control province1 relation" name="VPICPROVCODE">
                                                            <option value="">-- Select Province --</option>
                                                            @foreach($province AS $p)
                                                            <option value="{{$p->VPROVCODE}}" {{ isset($patient) && $patient->VPICPROVCODE === $p->VPROVCODE ? 'selected="selected"' : '' }}>{{$p->VPROVNAME}}</option>
                                                            @endforeach
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                   <label class="control-label col-md-12">District</label>
                                                </div>
                                             </div>
                                             <div class="col-lg-8 col-md-12">
                                                <div class="form-group">
                                                   <div class="col-md-12">
                                                      <div class="input-group">
                                                         <select class="form-control district1 relation" name="VPICDISTRICTCODE">
                                                         @if(isset($patient->VPICDISTRICTCODE))
                                                         @foreach($district AS $d)
                                                         <option value="{{$d->VDISTRICTCODE}}" {{ isset($patient) && $patient->VPICDISTRICTCODE === $d->VDISTRICTCODE ? 'selected="selected"' : '' }}>{{$d->VDISTRICTNAME}}</option>
                                                         @endforeach
                                                         @endif
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div class="col-lg-4 col-md-12">
                                                <div class="form-group">
                                                   <label class="control-label col-md-12">Sub District</label>
                                                </div>
                                             </div>
                                             <div class="col-lg-8 col-md-12">
                                                <div class="form-group">
                                                   <div class="col-md-12">
                                                      <div class="input-group">
                                                         <select class="form-control relation subdistrict1 relation" name="VPICSUBDISTRICTCODE">
                                                         @if(isset($patient->VPICSUBDISTRICTCODE))
                                                         @foreach($subdistrict AS $d)
                                                         <option value="{{$d->VSUBDISTRICTCODE}}" {{ isset($patient) && $patient->VPICSUBDISTRICTCODE === $d->VSUBDISTRICTCODE ? 'selected="selected"' : '' }}>{{$d->VSUBDISTRICTNAME}}</option>
                                                         @endforeach
                                                         @endif
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <div class="input-group">
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-sm-12">
                                          <div class="form-group">
                                             <label class="control-label col-sm-12">Relationship</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-sm-12">
                                          <div class="form-group">
                                             <div class="col-sm-12">
                                                <select class="form-control relation"  name="VPICRELATION">
                                                   <option value="">-- Select Status --</option>
                                                   @foreach($relation AS $a)
                                                   <option value="{{$a->VSETCODE}} " {{ isset($patient) && $patient->VPICRELATION === $a->VSETCODE ? 'selected="selected"' : '' }}>{{$a->VSETDESC}}</option>
                                                   @endforeach
                                                </select>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <p style="background-color:#6dc7e1; color:white;" class="p-1"><b>Relationship to Employee</b></p>
                                    <br />
                                    <div class="row table-responsive">
                                       <div class="col-lg-12 col-sm-12 form-group">
                                          <table id="tblfile" border="1" width="100%">
                                             <thead>
                                                <tr>
                                                   <th class="text-center">No</th>
                                                   <th class="text-center">Name</th>
                                                   <th class="text-center">Family Relationship</th>
                                                   <th class="text-center">Gender</th>
                                                   <th class="text-center">Date of Birth</th>
                                                   <th class="text-center">Country of Birth</th>
                                                   <th class="text-center">City of Birth</th>
                                                   <th class="text-center">BPJS No.</th>
                                                   <th class="text-center">JHT No.</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                @if (isset($members))
                                                <?php $inc = 1;?>
                                                @foreach ($members as $member)                                         
                                                <tr>
                                                   <td data-value="No" >{{ $inc }}</td>
                                                   <td data-value="ILINE" style="display: none;">{{ $member->ILINE }}</td>
                                                   <td data-value="VRELNAME">{{ $member->VRELNAME }}</td>
                                                   <td data-value="VRELATION">{{ $member->VRELATION }}</td>
                                                   <td data-value="VRELGENDER">{{ $member->VRELGENDER }}</td>
                                                   <td data-value="DRELBIRTH">{{ $member->DRELBIRTH }}</td>
                                                   <td data-value="VRELCTRYBIRTH">{{ $member->VRELCTRYBIRTH }}</td>
                                                   <td data-value="VRELCITYBIRTH">{{ $member->VRELCITYBIRTH }}</td>
                                                   <td data-value="VRELBPJSNO">{{ $member->VRELBPJSNO }}</td>
                                                   <td data-value="VRELJHTNO">{{ $member->VRELJHTNO }}</td>
                                                   <?php $inc++; ?>
                                                   <!--<td></td>
                                                      <td></td>-->
                                                </tr>
                                                @endforeach
                                                @endif
                                             </tbody>
                                          </table>
                                       </div>
                                    </div>
                                    <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', !str_contains($hash, 'ptntlst') ? 'F02' : 'NOTALLOWED')) { ?>
                                    <button id="startDiv" type="submit" class="btn btn-cstm btn-primary btn-sz">Submit</button>
                                    <?php } ?>
                                    <a class="btn-cstm btn-light btn-sz close_button" target="popup" role="button">Close</a>
                                 </form>
                              </section>
                              <?php } ?>

                              <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F03' : 'F29', !str_contains($hash, 'ptntlst') ? 'F04' : 'F29')) { ?>
                              <section id="section-3">
                                 <form data-url="/patientexamination" class="form-confirm" id="examination_post" method="POST" >
                                    @csrf
                                    <input type="hidden" name="vbooking" class="vbooking" value="{{$db}}">
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Doctor</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VPatientName" class="form-control" type="text" value="{{$patient->NAMADOCTOR ?? ''}}" required disabled>
                                                <!-- <input name="DCTR" class="form-control" type="text" value="{{$patient->NAMADOCTOR}}" disabled> -->
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Patient Name</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input name="VPatientName" class="form-control" type="text" value="{{$patient->VNAME ?? ''}}" required disabled>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F03' : 'F29')) { ?>
                                    <p style="background-color:#6dc7e1; color:white; padding:3px; font-size:14px;"><b>Vital Signs</b></p>
                                    <br />
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Patient Height</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group required">
                                             <div class="col-md-12">
                                                <input class="form-control tab-preexam-r" type="text" id="patienth" value="{{$exame->NHEIGHT ?? ''}}" name="patienth" maxlength="3" required>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <label class="control-label col-md-12">cm</label>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-8">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Patient Weight</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input class="form-control tab-preexam-r" id="patientwe" type="text" value="{{$exame->NWEIGHT ?? ''}}" name="patientwe" maxlength="2">
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <label class="control-label col-md-12">kg</label>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Pulse</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input class="form-control tab-preexam-r" type="text" id="NPLUSE" name="NPLUSE" value="{{$exame->NPULSE ?? ''}}" maxlength="10">
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <label class="control-label col-md-12">Pulse/min</label>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-8">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Breath frequency</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input class="form-control tab-preexam-r" id="NBREATHFREQ" type="text" name="NBREATHFREQ" value="{{$exame->NBREATHFREQ ?? ''}}" maxlength="10">
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <label class="control-label col-md-12">breaths/min</label>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Blood pressure</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input class="form-control tab-preexam-r" id="NBLOOD" type="text" value="{{$exame->NBLOOD ?? ''}}"  name="NBLOOD" maxlength="10">
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <label class="control-label col-md-12">mmhg</label>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-8">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Temperature</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <input class="form-control tab-preexam-r" id="temprature" type="text" value="{{$exame->NTEMPERATURE ?? ''}}" name="NTEMPERATURE" maxlength="6">
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <label class="control-label col-md-12">&deg;C</label>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <?php } ?>
                                    <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F04' : 'F29')) { ?>
                                    <p style="background-color:#6dc7e1; color:white; padding:3px; font-size:14px;"><b>Diagnosis</b> </p>
                                    <br />
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Clinical Diagnosis</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <div class="input-group">
                                                   <input name="mydiagnosis" class="form-control" type="text" value="{{$exame->VICDCODE ?? ''}}{{ isset($diag->VDXNAME) && $diag->VDXNAME != '' ? ' - '.$diag->VDXNAME : '' }}"  readonly>
                                                   <div class=" input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myDiagnosis">
                                                      <div class="input-group-text"><i class="fa fa-search"></i></div>
                                                   </div>
                                                   <input type="hidden" value="{{$exame->VICDCODE ?? ''}}" name="mydiagnosisi" >
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">List drug allergies</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <div class="input-group">
                                                   <textarea class="form-control" name="VDRUGALLERGIES" value="{{$exame->VDRUGALLERGIES ?? ''}}"  rows="5">{{$exame->VDRUGALLERGIES ?? ''}}</textarea>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-6 col-md-12">
                                          <table>
                                             <tr>
                                                <td>
                                                   <label class="control-label col-md-12">Istirahat</label>
                                                </td>
                                                <td>
                                                   <select class="form-control" name="istirahat" id="istirahat">
                                                   <option value="">-- Select Istirahat --</option>

                                                   <option value="1" {{ isset($exame->BREST) && '1' === $exame->BREST ? 'selected="selected"' : '' }}>Ya</option>
                                                   <option value="0" {{ isset($exame->BREST) && '0' === $exame->BREST ? 'selected="selected"' : '' }}>Tidak</option>
                                                   </select>
                                                </td>
                                                <td>
                                                   <label class="control-label col-md-12">Jumlah hari istirahat</label>
                                                </td>
                                                <td>
                                                   <input class="form-control jumlahari" id="jumlahari" type="number" value="{{$exame->IRESTDAY ?? ''}}" name="jmlahhari" maxlength="6">
                                                </td>
                                             </tr>
                                             <tr>
                                                <td><label class="control-label col-md-12">Rujukan</label></td>
                                                <td>
                                                   <select class="form-control" id="rujukan" name="rujukan">
                                                      <option value="">-- Select Insurance Name --</option>
                                                      @foreach($asurance AS $a)
                                                      <option value="{{$a->VGNRLCODE}}" {{ isset($exame) && $exame->VINSCODE === $a->VGNRLCODE ? 'selected="selected"' : '' }}>{{$a->VGNRLDESC}}</option>
                                                      @endforeach
                                                   </select>
                                                </td>
                                                <td><label class="control-label col-md-12">Provider</label></td>
                                                <td>
                                                   <textarea class="form-control" name="provider" value="{{$exame->VPROVIDER ?? ''}}"  rows="5">{{$exame->VPROVIDER ?? ''}}</textarea>

                                                </td>
                                             </tr>
                                             <tr>
                                                <td><label class="control-label col-md-12">Poli Rujukan</label></td>
                                                <td>
                                                   <textarea class="form-control" name="profil" value="{{$exame->VREFERENCE ?? ''}}"  rows="5">{{$exame->VREFERENCE ?? ''}}</textarea>
                                                </td>
                                             </tr>
                                          </table>
                                       </div>
                                    </div>
                                    <br />
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Anamnesis</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <div class="input-group">
                                                   <textarea class="form-control" name="VAMNESIS" value="{{$exame->VAMNESIS ?? ''}}" rows="3" >{{$exame->VAMNESIS ?? ''}}</textarea>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-6 col-md-12">
                                          <div class="font-sidebar">
                                             <table>
                                                <tr>
                                                   <td>
                                                      <h6><a href='/downloadletter/healthcertificate/<?php echo base64_encode($patient->VMRNO.','.$db); ?>'>Health Certificate</a></h6>
                                                   </td>
                                                   <td>
                                                      <h6><a href='/downloadletter/sicknessletter/<?php echo base64_encode($patient->VMRNO.','.$db); ?>'>Sickness Letter</a></h6>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td>
                                                      <h6><a href="/downloadletter/referalletter/<?php echo base64_encode($patient->VMRNO.','.$db); ?>">Referall Letter</a></h6>
                                                   </td>
                                                   <td>
                                                      <h6><a href="/downloadletter/informedconsent/<?php echo base64_encode($patient->VMRNO.','.$db); ?>">Informed Consent</a></h6>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td>
                                                      <h6><a href="/downloadletter/referallabletter/<?php echo base64_encode($patient->VMRNO.','.$db); ?>">Referall Lab Letter</a></h6>
                                                   </td>
                                                </tr>
                                             </table>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                             <label class="control-label col-md-12">Additional Notes</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                                <div class="input-group">
                                                   <textarea class="form-control" name="VNOTES" value="{{$exame->VNOTES ?? ''}}" rows="4">{{$exame->VNOTES ?? ''}}</textarea>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="col-lg-6 col-md-12">
                                       <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', !str_contains($hash, 'ptntlst') ? 'F04' : 'NOTALLOWED')) { ?>

                                          <button type="button" class="btn btn-cstm form-group btn-primary btn-sz" onclick="return toFormDocExamination(this);">Upload</button>
                                       <?php } ?>
                                          <table id="tbldocexam" class="table-bordered" width="100%">
                                             <thead>
                                                <tr>
                                                   <th>Action.</th>
                                                   <th>No</th>
                                                   <th>Document Type</th>
                                                   <th>Document No.</th>
                                                   <th>File Name</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                @if (isset($docs))
                                                <?php $inc = 1;?>
                                                @foreach ($docs as $doc)
                                                @if (isset($doc->VSETDESC))
                                                <tr>
                                                   <td data-value="VID" style="display: none;">{{ $doc->VID }}</td>
                                                   <td data-value="VDOCFILENAME" style="display: none;">{{ $doc->VDOCFILENAME }}</td>
                                                   <td><button onClick="toFormDocExamination(this, '{{ $doc->VID }}')" type="button" class="btn btn btn-link btn-sm deleteupldoc"><i title="Edit" class="fas fa-edit"></i></button>&nbsp;<button onClick="removeUplDoc(this)" data-id="{{ $doc->VID }}" type="button" class="btn btn btn-link btn-sm deleteupldoc"><i title="Delete" class="fas fa-times"></i></button></td>
                                                   <td>{{ $inc }}</td>
                                                   <td data-value="VDOCTYPE">{{ $doc->VSETDESC ?? 'Lab' }}</td>
                                                   <td data-value="VDOCNO">{{ $doc->VDOCNO }}</td>
                                                   <td><a href="/account/download/examination/{{ strtolower($doc->VID . substr($doc->VDOCFILENAME, strrpos($doc->VDOCFILENAME, '.'))) }}">{{ $doc->VDOCFILENAME }}</a></td>
                                                </tr>
                                                <?php $inc++; ?>
                                                @endif 
                                                @endforeach
                                                @endif
                                             </tbody>
                                          </table>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group required">
                                             <label class="control-label col-md-12">Accident </label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-check form-check-inline">
                                             <input class="form-check-input" name="BWORKDISEASE" type="radio" value="1" {{ isset($exame->BWORKDISEASE) && $exame->BWORKDISEASE == '1' ? 'checked' : '' }} required>
                                             <label class="form-check-label">Yes</label>
                                          </div>
                                          <div class="form-check form-check-inline">
                                             <input class="form-check-input" name="BWORKDISEASE" type="radio" value="0" {{ isset($exame->BWORKDISEASE) && $exame->BWORKDISEASE == '0' ? 'checked' : '' }}>
                                             <label class="form-check-label">No</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-2 col-md-12">
                                          <div class="form-group">
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-md-12">
                                          <div class="form-group">
                                             <div class="col-md-12">
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <p style="background-color:#6dc7e1; color:white; padding:3px; font-size:14px;"><b>Items use</b></p>
                                    <br />
                                    <div class="row">
                                       <div class="col-lg-12 col-md-12">
                                          <table id="itemiuses" class="table table-bordered" border="1" width="100%">
                                             <thead>
                                                <tr>
                                                   <th class="text-center" style="width:1%;">Action</th>
                                                   <th class="text-center" style="width:1%;">Brand</th>
                                                   <th class="text-center" style="width:4%;">Contain</th>
                                                   <th class="text-center" style="width:1%;">Qty</th>
                                                   <th class="text-center" style="width:1%;">UoM</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                @if(isset($examdtls))
                                                @foreach($examdtls AS $exam)
                                                <tr id="{{ $exam->DRUGS_CODE }}">
                                                   <td data-value='VBOOKINGNO' style='display: none;'>{{$db}}</td>
                                                   <td data-value='VDRUGSCODE' style='display: none;'>{{ $exam->DRUGS_CODE }}</td>
                                                   <td data-value='ILINENO' style='display: none;'>{{$exam->ILINENO }}</td>
                                                   <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', !str_contains($hash, 'ptntlst') ? 'F04' : 'NOTALLOWED')) { ?>
                                                   <td class="text-center" style="width:1%;"><button onClick="toFormExamination(this, '{{$exam->ILINENO }}')" type="button" class="btn btn btn-link btn-sm deletebooking"><i title="Edit" class="fas fa-edit"></i></button>&nbsp;<button onClick="removeexam(this)" data-id="{{ $exam->DRUGS_CODE }}" type="button" class="btn btn btn-link btn-sm deletebooking"><i title="Delete" class="fas fa-times"></i></button></td>
                                                   <?php } else{ ?>
                                                   <td></td>
                                                   <?php } ?>

                                                   <td style="width:1%;">{{$exam->DRUGS_BRAND}}</td>
                                                   <td data-value="VCONTAIN" style="width:4%;">{{$exam->DRUGS_CONTAIN}}</td>
                                                   <td data-value="IQTY" style="width:1%;">{{$exam->IQTY}}</td>
                                                   <td data-value="VUOM" style="width:1%;">{{$exam->DRUGS_UOM}}</td>
                                                </tr>
                                                @endforeach
                                                @endif
                                             </tbody>
                                          </table>
                                       </div>
                                    </div>
                                    
                                    <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', !str_contains($hash, 'ptntlst') ? 'F04' : 'F29')) { ?>
                                       <button type="button" class="btn btn-cstm btn-primary btn-sz text-white " data-toggle="modal" data-target="#examination">Add row</button>
                                    <?php } ?>

                                    <br/>
                                    <br/>
                                    <br/>
                                    <?php } ?>

                                    <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('C', !str_contains($hash, 'ptntlst') ? 'F04' : 'F29', !str_contains($hash, 'ptntlst') ? 'F03' : 'F29')) { ?>
                                       <button id="startDivbooking" type="submit" class="btn btn-cstm btn-primary btn-sz">Submit</button>
                                    <?php } ?>

                                    <a class="btn-cstm btn-light btn-sz close_button" target="popup" role="button">Close</a>
                                 </form>
                              </section>
                              <?php } ?>

                              <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F05' : 'F30')) { ?>
                              <section id="section-4">
                                 <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('P', !str_contains($hash, 'ptntlst') ? 'F05' : 'F30')) { ?>
                                 @if(count($treatment) > 0)
                                 <button class="btn-cstm btn-light btn-sz btn-sz text-white" target="popup" onclick="window.open('/treatment/print_pdf/<?php echo Crypt::encryptString(base64_encode($db)); ?>','name','width=1000,height=600')" role="button">Print</button>
                                 @else
                                 @endif
                                 <?php } ?>
                                 <label><b>&nbsp; Patient Name : {{ $patient->VNAME ?? '' }}</b></label>
                                 <br/>
                                 <br/>
                                 <form method="POST" data-url="/addtreatment/insert" class="form-confirm">
                                    @csrf
                                    <input type="hidden" name="vbooking" class="vbooking" value="{{$db}}">
                                    <input type="hidden" name="vcliniccode" class="vcliniccode" value="{{$patient->VCLINICCODE}}">
                                    <table id="treat" border="1" class="table table-bordered" width="100%">
                                       <thead>
                                          <tr>
                                             <?php $inc = 1;?>
                                             <th class="text-center">Action</th>
                                             <th class="text-center">No</th>
                                             <th class="text-center">Name</th>
                                             <th class="text-center">Scan items</th>
                                             <th class="text-center">Dosage</th>
                                             <th class="text-center">Qty</th>
                                             <th class="text-center">UOM</th>
                                             <th class="text-center">Remarks</th>
                                          </tr>
                                       </thead>
                                       <tbody>
                                          @if (isset($treatment))
                                          @foreach($treatment as $treatment)
                                          <tr id="{{ $treatment->VDRUGSCODE }}" iline="{{ $inc }}">
                                             <td data-value="VBOOKINGNO" style="display: none;">
                                                <b>{{ $treatment->VBOOKINGNO }}</b>
                                             </td>
                                             <td data-value="ILINENO" style="display: none;">
                                                <b>{{ $treatment->ILINENO }}</b>
                                             </td>
                                             <td data-value="VDRUGSCODE_OLDS"  style="display: none;">
                                                <b>{{ $treatment->VDRUGSCODE }}</b>
                                                <!-- <input type='hidden' value='' name='drugcode[]'> -->
                                             </td>
                                             <td data-value="VDRUGSCODE"  style="display: none;">
                                                <b>{{ $treatment->VDRUGSCODE }}</b>
                                                <!-- <input type='hidden' value='' name='drugcode[]'> -->
                                             </td>
                                             <td>
                                             
                                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', !str_contains($hash, 'ptntlst') ? 'F05' : 'F31')) { ?>
                                                <button onClick="toFormtreatment(this, '{{ $treatment->ILINENO }}')" type="button" class="btn btn btn-link btn-sm deletebooking"><i title="Edit" class="fas fa-edit"></i></button>
                                                <?php } ?>
                                                &nbsp;
                                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('D/C', !str_contains($hash, 'ptntlst') ? 'F05' : 'F31')) { ?>
                                                <button onClick="remove(this)" data-drugs="{{ $treatment->VDRUGSCODE }}" data-id="{{ $treatment->VDRUGSCODE }}" type="button" class="btn btn btn-link btn-sm"><i title="Delete" class="fas fa-times"></i></button>
                                             </td>
                                             <?php } ?>
                                             <td><b>{{ $inc }}</b></td>
                                             <td data-value="VCONTAIN"><b>{{ $treatment->DRUGS_CONTAIN }}</b></td>
                                             <td data-value="VDOCNO">
                                                <div class="row">
                                                   <div class="col-12">
                                                      @if(!$treatment->VSCANNAME)
                                                      @if(Session::get('groupuser')[0] === "PMCY")

                                                      <input type="text" class="form-control form-control-sm drugscodescan" name="drugscodescan" placeholder="Scan Item">
                                                      <input type="hidden" class="form-control form-control-sm" value="{{ $treatment->VBOOKINGNO }}" name="vbookingnos[]" placeholder="Scan Item">
                                                      <input type="hidden" class="form-control form-control-sm" value="{{ $treatment->ILINENO }}" name="ilinenos[]" placeholder="Scan Item">
                                                      <input type="hidden" class="form-control form-control-sm hasilbarcode1" value="" name="hasilbarcode1[]" placeholder="Scan Item">
                                                      @endif

                                                      @else
                                                      <input type="text" class="form-control form-control-sm hasilbarcode" value="{{ $treatment->DRUGS_CONTAIN }}" name="hasilbarcode" placeholder="Scan Item" disabled>
                                                      @endif
                                                   </div>
                                                </div>
                                             </td>
                                             <td data-value="VDOSAGE"><b>{{ $treatment->VDOSAGE }}</b></td>
                                             <td data-value="QTY"><b>{{ $treatment->IQTY }}</b></td>
                                             <td data-value="VUOM"><b>{{ $treatment->DRUGS_UOM }}</b></td>
                                             <td data-value="VREMARKS"><b>{{ $treatment->VREMARKS }}</b></td>
                                          </tr>
                                          <?php $inc++; ?>
                                          @endforeach
                                          @endif
                                       </tbody>
                                    </table>
                                    <br/>
                                    <br/>

                                    <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('C', !str_contains($hash, 'ptntlst') ? 'F05' : 'F31')) { ?>
                                    <button  type="button" class="btn btn-cstm btn-primary btn-sz" id="addRow">Add row</button>
                                    <?php } ?>
                                    
                                    <br/>
                                    <br/>
                                    <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('C', !str_contains($hash, 'ptntlst') ? 'F05' : 'F31')) { ?>
                                    <button  type="submit" class="btn btn-cstm btn-primary btn-sz">Submit</button>
                                    <?php } ?>
                                    <a class="btn-cstm btn-light btn-sz close_button" target="popup" role="button">Close</a>
                                 </form>
                              </section>
                              <?php } ?>
                              <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F06' : 'F31')) { ?>
                              <section id="section-5">
                                 <div class="form-group row">
                                    <label class="col-form-label control-label col-sm-2"><b>Visit date from</b></label>
                                    <div class="col-sm-3">
                                       <div class="input-group date" id="startdate" data-target-input="nearest">
                                          <input type="text" class="form-control datetimepicker-input" name="DFROM" data-target="#startdate" placeholder="DD-MM-YYYY" required>
                                          <div class="input-group-append" data-target="#startdate" data-toggle="datetimepicker">
                                             <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                          </div>
                                       </div>
                                    </div>
                                    <label class="col-form-label control-label col-sm-1"><b>to</b></label>
                                    <div class="form-group col-sm-4">
                                       <div class="input-group date" id="enddate" data-target-input="nearest">
                                          <input type="text" class="form-control datetimepicker-input" name="DTO" data-target="#enddate" placeholder="DD-MM-YYYY" required>
                                          <div class="input-group-append" data-target="#enddate" data-toggle="datetimepicker">
                                             <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-lg-2 col-sm-12">
                                       <div class="form-group">
                                          <button class="btn btn-sz btn-primary" onclick="return LoadTableMr();" role="button" style="color:white;">Search</button>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-12 col-sm-12 form-group">
                                       <div class="table-responsive">
                                          <table id="cmresultmr" class="table-bordered" width="100%">
                                             <thead>
                                                <tr>
                                                   <th class="text-center">No</th>
                                                   <th class="text-center">Date</th>
                                                   <th class="text-center">Clinic</th>
                                                   <th class="text-center">Doctor</th>
                                                   <th class="text-center">Clinic Diagnosis</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                             </tbody>
                                          </table>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </section>
                              <?php } ?>
                              <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F07' : 'F32')) { ?>
                              <section id="section-6">
                                 <div class="form-group row">
                                    <label class="col-form-label control-label col-sm-2"><b>Visit date from</b></label>
                                    <div class="col-sm-3">
                                       <div class="input-group date" id="startmcu" data-target-input="nearest">
                                          <input type="text" class="form-control datetimepicker-input" name="DFROM" data-target="#startmcu" placeholder="DD-MM-YYYY" required>
                                          <div class="input-group-append" data-target="#startmcu" data-toggle="datetimepicker">
                                             <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                          </div>
                                       </div>
                                    </div>
                                    <label class="col-form-label control-label col-sm-1"><strong>to</strong></label>
                                    <div class="form-group col-sm-4">
                                       <div class="input-group date" id="endmcu" data-target-input="nearest">
                                          <input type="text" class="form-control datetimepicker-input" name="DTO" data-target="#endmcu" placeholder="DD-MM-YYYY" required>
                                          <div class="input-group-append" data-target="#endmcu" data-toggle="datetimepicker">
                                             <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="col-lg-2 col-sm-12">
                                       <div class="form-group">
                                          <button class="btn btn-sz btn-primary" onclick="return LoadTableMCU();" role="button" style="color:white;">Search</button>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-12 col-sm-12 form-group">
                                       <table id="tblmcu" class="cell-border table-bordered" width="100%">
                                          <thead>
                                             <tr>
                                                <th class="text-center" width="5%">No</th>
                                                <th class="text-center" width="15%">MCU Date</th>
                                                <th class="text-center" width="15%">Document MCU No.</th>
                                             </tr>
                                          </thead>
                                          <tbody>
                                          </tbody>
                                       </table>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                    </div>
                                    <div class="col-lg-2 col-md-12">
                                       <div class="form-group">
                                       </div>
                                    </div>
                                    <div class="col-lg-4 col-md-12">
                                       <div class="form-group">
                                          <div class="col-md-12">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </section>
                              <?php } ?>
                              <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'NOTALLOWED' : 'F27')) { ?>
                              <section id="section-shape-7">
                                 <form id="form-confirm" data-url="/patientlist/uploaddocument" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    <input type="hidden" name="VBOOKINGNO" value="{{$db}}">
                                    <div class="row">
                                       <div class="col-lg-2 col-sm-12">
                                          <div class="form-group">
                                             <label class="control-label col-sm-12">MR No</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-sm-12">
                                          <div class="form-group">
                                             <div class="col-sm-12">
                                                <div class="input-group">
                                                   <input name="VMRNO" class="form-control" type="text" value="{{ $patient->VMRNO ?? '' }}" readonly>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-lg-2 col-sm-12">
                                          <div class="form-group">
                                             <label class="control-label col-sm-12">Patient Name</label>
                                          </div>
                                       </div>
                                       <div class="col-lg-4 col-sm-12">
                                          <div class="form-group">
                                             <div class="col-sm-12">
                                                <div class="input-group">
                                                   <input name="VNAME" class="form-control" type="text" value="{{ $patient->VNAME ?? '' }}" readonly>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <br/>
                                    <hr>
                                    <div class="row">
                                       <div class="col-lg-4 col-sm-12">
                                          <div class="form-group">
                                             <div class="col-sm-12">
                                                <div class="input-group">
                                                   <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', !str_contains($hash, 'ptntlst') ? 'NOTALLOWED' : 'F27')) { ?>
                                                   <button type="button" class="btn-cstm btn-primary btn-sz" onclick="return toFormDoc(this);">Upload</button>
                                                   <?php } ?>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="row table-responsive">
                                       <div class="col-lg-12 col-sm-12 form-group">
                                          <table id="tbldocument" border="1" width="100%">
                                             <thead>
                                                <tr>
                                                   <th class="text-center">Action</th>
                                                   <th class="text-center">No</th>
                                                   <th class="text-center">Document Type</th>
                                                   <th class="text-center">Document No</th>
                                                   <th class="text-center">File Name</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <?php $inc = 1;?>
                                                @if (isset($docs))
                                                @foreach ($docs as $doc)
                                                <tr>
                                                   <td data-value="VID" style="display: none;">{{ $doc->VID }}</td>
                                                   <td data-value="VDOCFILENAME" style="display: none;">{{ $doc->VDOCFILENAME }}</td>
                                                   <td style="text-align: center;"><button onClick="toFormDoc(this, '{{ $doc->VID }}')" type="button" class="btn btn btn-link btn-sm deleteupldoc"><i title="Edit" class="fas fa-edit"></i></button>&nbsp;<button onClick="removeUplDoc(this)" data-id="{{ $doc->VID }}" type="button" class="btn btn btn-link btn-sm deleteupldoc"><i title="Delete" class="fas fa-times"></i></button></td>
                                                   <td>{{ $inc }}</td>
                                                   <td data-value="VDOCTYPE">{{ $doc->VSETDESC ?? 'Lab' }}</td>
                                                   <td data-value="VDOCNO">{{ $doc->VDOCNO }}</td>
                                                   <td><a href="/account/download/examination/{{ strtolower($doc->VID . substr($doc->VDOCFILENAME, strrpos($doc->VDOCFILENAME, '.'))) }}">{{ $doc->VDOCFILENAME }}</a></td>
                                                </tr>
                                                <?php $inc++; ?>
                                                @endforeach
                                                @endif
                                             </tbody>
                                          </table>
                                       </div>
                                    </div>
                                    <br/>
                                    <div class="form-group row">
                                       <div class="col-md-12">
                                          <div class="float-left">
                                             <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', !str_contains($hash, 'ptntlst') ? 'NOTALLOWED' : 'F27')) { ?>
                                             <button type="submit" class="btn-cstm btn-primary btn-sz">Submit</button>
                                             <?php } ?>
                                             <a class="btn-cstm btn-light btn-sz close_button" target="popup" role="button">Close</a>
                                          </div>
                                       </div>
                                    </div>
                                 </form>
                              </section>
                              <?php } ?>
                           </div>
                        </div>
                     </section>
                  @if(Session::get('groupuser')[0] === "DCTR" || Session::get('groupuser')[0] === "HRADM")
                  </fieldset>
                  @endif
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- Modal Doctor List 2 -->
<div class="modal fade in" id="dctr2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg modal-content">
      <div class="card mb-4">
         <div class="card-header bg-info">
            <h5 class="card-title text-white" align="center">Doctor </h5>
            <button type="button" class="close text-white" data-dismiss="modal">×</button>
         </div>
         <div class="card-body p-3">
            <div id="dvData" class="table-responsive">
               <table id="mydctrlist1" class="display" style="width:100%">
                  <thead>
                     <tr>
                        <th>
                           ID Doctor
                        </th>
                        <th>
                           Name Doctor
                        </th>
                        <th>
                           Day
                        </th>
                        <th>
                           Start
                        </th>
                        <th>
                           End
                        </th>
                     </tr>
                  </thead>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Modal Doctor List -->
<div class="modal fade in" id="dctr1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg modal-content">
      <div class="card mb-4">
         <div class="card-header bg-info">
            <h5 class="card-title text-white" align="center">Doctor</h5>
            <button type="button" class="close text-white" data-dismiss="modal">×</button>
         </div>
         <div class="card-body p-3">
            <div id="dvData" class="table-responsive">
               <table id="mydctrlist" class="display" style="width:100%">
                  <thead>
                     <tr>
                        <th>
                           ID Doctor
                        </th>
                        <th>
                           Name Doctor
                        </th>
                        <th>
                           Day
                        </th>
                        <th>
                           Start
                        </th>
                        <th>
                           End
                        </th>
                     </tr>
                  </thead>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Modal Doctor Alternatif List-->
<div class="modal fade in" id="alterdctr" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg modal-content">
      <div class="card mb-4">
         <div class="card-header bg-info">
            <h5 class="card-title text-white" align="center">Doctor</h5>
            <button type="button" class="close text-white" data-dismiss="modal">×</button>
         </div>
         <div class="card-body p-3">
            <div id="dvData" class="table-responsive">
               <table id="mydctr" class="display" style="width:100%">
                  <thead>
                     <tr>
                        <th>
                           ID Doctor
                        </th>
                        <th>
                           Name Doctor
                        </th>
                        <th>
                           Day
                        </th>
                        <th>
                           Start
                        </th>
                        <th>
                           End
                        </th>
                     </tr>
                  </thead>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Modal Treatment -->
<div class="modal fade in" id="treatment" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg modal-content">
      <div class="card mb-4">
         <div class="card-header bg-info">
            <h5 class="card-title text-white" align="center">Drugs</h5>
            <button type="button" class="close text-white" data-dismiss="modal">×</button>
         </div>
         <div class="card-body p-3">
            <div id="dvData" class="table-responsive">
               <table id="tbltreatment" class="display" style="width:100%">
                  <thead>
                     <tr>
                        <th>
                           Drugs Code
                        </th>
                        <th>
                           Contain
                        </th>
                        <th>
                           Brand
                        </th>
                        <th>
                           UoM
                        </th>
                        <th>
                           Stock
                        </th>
                     </tr>
                  </thead>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="modal fade in" id="treatmentUpdate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg modal-content">
      <div class="card mb-4">
         <div class="card-header bg-info">
            <h5 class="card-title text-white" align="center">Drugs</h5>
            <button type="button" class="close text-white" data-dismiss="modal">×</button>
         </div>
         <div class="card-body p-3">
            <div id="dvData" class="table-responsive">
               <table id="tbltreatmentUpdate" class="display" style="width:100%">
                  <thead>
                     <tr>
                        <th>
                           Drugs Code
                        </th>
                        <th>
                           Contain
                        </th>
                        <th>
                           UoM
                        </th>
                     </tr>
                  </thead>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Modal Examination-->
<div class="modal fade in" id="examination" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg modal-content">
      <div class="card mb-4">
         <div class="card-header bg-info">
            <h5 class="card-title text-white" align="center">Drugs</h5>
            <button type="button" class="close text-white" data-dismiss="modal">×</button>
         </div>
         <div class="card-body p-3">
            <div id="dvData" class="table-responsive">
               <table id="tblexamination" class="display" style="width:100%">
                  <thead>
                     <tr>
                        <th>
                           Drugs Code
                        </th>
                        <th>
                           Contain
                        </th>
                        <th>
                           Brand
                        </th>
                        <th>
                           UoM
                        </th>
                        <th>
                           Stock
                        </th>
                     </tr>
                  </thead>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="modal fade in" id="ExaminationUpdate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg modal-content">
      <div class="card mb-4">
         <div class="card-header bg-info">
            <h5 class="card-title text-white" align="center">Drugs</h5>
            <button type="button" class="close text-white" data-dismiss="modal">×</button>
         </div>
         <div class="card-body p-3">
            <div id="dvData" class="table-responsive">
               <table id="tblexaminationUpdate" class="display" style="width:100%">
                  <thead>
                     <tr>
                        <th>
                           Drugs Code
                        </th>
                        <th>
                           Contain
                        </th>
                        <th>
                           Brand
                        </th>
                        <th>
                           UoM
                        </th>
                        <th>
                           Stock
                        </th>
                     </tr>
                  </thead>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Modal Diagnosis-->
<div class="modal fade in" id="myDiagnosis" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg modal-content">
      <div class="card mb-4">
         <div class="card-header bg-info">
            <h5 class="card-title text-white" align="center">Clinical Diagnosis</h5>
            <button type="button" class="close text-white" data-dismiss="modal">×</button>
         </div>
         <div class="card-body p-3">
            <div id="dvData" class="table-responsive">
               <table id="clinical" class="display" style="width:100%">
                  <thead>
                     <tr>
                        <th>
                           ID clinical Diagnosis
                        </th>
                        <th>
                           Name clinical Diagnosis
                        </th>
                     </tr>
                  </thead>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Modal Users -->
<div class="modal fade" id="modaldoc" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-md modal-dialog-centered">
      <div class="modal-content">
         <div class="modal-body">
            <form  data-url="/treatment/update" class="form-confirm"  method="POST">
               @csrf
               <input id="VBOOKINGNO" name="VBOOKINGNOS" value="{{$db}}" type="hidden" >
               <input id="ILINENO" name="ILINENOS"  type="hidden" >
               <input id="VDRUGSCODE" name="VDRUGSCODES"  type="hidden" >
               <input id="VDRUGSCODE_OLDS" name="VDRUGSCODE_OLDS"  type="hidden">

               <div class="container">
                  <div class="row">
                     <div class="col-lg-6 col-sm-12">
                           <label>Drugs Name</label>

                           <div class='input-group'>
                              <input  name='VCONTAIN' id="VCONTAIN" class='form-control form-control-sm' type='text' value='' readonly>
                              <div class='input-group-append' style='cursor: pointer;' data-toggle='modal' data-target='#treatmentUpdate'>
                                 <div class='input-group-text'><i class='fa fa-search'></i></div>
                              </div>
                           </div>
                     </div>
                     <div class="col-lg-6 col-sm-12">
                        <div class="form-group">
                           <label>Dosage</label>

                           <input id="VDOSAGE" name="VDOSAGE" class="form-control" type="text" placeholder="Dosagge">
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-6 col-sm-12">
                        <div class="form-group">
                              <label>Qty</label>

                              <input id="QTY" name="QTY" class="form-control" type="number" placeholder="iqty">
                        </div>
                     </div>
                     <div class="col-lg-6 col-sm-12">
                        <div class="form-group">
                              <label>Remarks</label>

                              <input id="VREMARKS" name="VREMARKS" class="form-control" type="text" placeholder="Remarks">
                        </div>
                     </div>
                  </div>
                  <br/>
                  <div style="text-align:center;">
                     <button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                     <a onclick="$('#modaldoc').modal('hide');" class="btn btn-cstm btn-light btn-sz">Close</a>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
<div class="modal fade" id="modalexam" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-md modal-dialog-centered">
      <div class="modal-content">
         <div class="modal-body">
            <form id="form-examination" data-url="/examination/update" class="form-confirm"  method="POST">
               @csrf
               <input class="VBOOKINGNO" name="VBOOKINGNO"  type="text" style="display: none;">
               <input class="ILINENO" name="ILINENO"  type="text" style="display: none;">
               <input class="VDRUGSCODE" name="VDRUGSCODE"  type="text" style="display: none;">
               <input class="VDRUGSCODE" name="VDRUGSCODE_OLD"  type="text" style="display: none;">

               <div class="container">
                  <div class="row">
                     <div class="col-lg-6 col-sm-12">

                        <div class="col-sm-12">
                           <label >Drugs Name</label>

                           <div class='input-group'>
                              <input  name='VCONTAIN' class='form-control form-control-sm VCONTAIN' type='text' value='' readonly>
                              <div class='input-group-append' style='cursor: pointer;' data-toggle='modal' data-target='#ExaminationUpdate'>
                                 <div class='input-group-text'><i class='fa fa-search'></i></div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-6 col-sm-12">
                        <div class="form-group">
                           <label for="exampleInputPassword1">Qty</label>

                           <input  name="IQYT" class="form-control IQTY" type="text" placeholder="QTY">
                        </div>
                     </div>
                  </div>
                  <br/>
                  <div style="text-align:center;">
                     <button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                     <a onclick="$('#modalexam').modal('hide');" class="btn btn-cstm btn-light btn-sz">Close</a>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
<!-- Modal Upload Examination -->
<div class="modal fade" id="modalupExamination" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-md modal-dialog-centered">
      <div class="modal-content">
         <div class="modal-body">
            <form id="form-upload" class="upldocexam" data-url="/uploadExamination" method="POST" enctype="multipart/form-data">
               <input id="VBOOKINGNO_ExamDoc" class="VBOOKINGNO" name="VBOOKINGNO" type="text" value="{{$db}}" style="display: none;">
               {{ csrf_field() }}
               <input id="VID_ExamDoc" name="VID" type="hidden">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-6 col-sm-12">
                        <div class="form-group">
                           <div class="col-sm-12">
                              <select id="VDOCTYPE_ExamDoc" class="form-control VDOCTYPE" name="VDOCTYPE" placeholder="Type Document">
                                 <option value="">-- Select Type Document --</option>
                                 @foreach($doctypes AS $doctype)
                                 <option value="{{$doctype['VSETCODE']}}">{{$doctype['VSETDESC']}}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-6 col-sm-12">
                        <div class="form-group">
                           <div  class="col-sm-12">
                              <input id="file_ExamDoc" type="file" name="file" required>
                           </div>
                           <div id="divFileEdit_ExamDoc" class="divFileEdit" class="col-sm-12" style="display: none;">
                              <button type="button" onclick="$('#file_ExamDoc').click()">Choose File</button>&nbsp;<label></label>
                           </div>
                        </div>
                     </div>
                  </div>
                  <br/>
                  <div style="text-align:center;">
                     <button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                     <a onclick="$('#modalupExamination').modal('hide');" class="btn btn-cstm btn-light btn-sz">Close</a>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
<!-- Modal Document -->
<div class="modal fade" id="modalupldoc" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-md modal-dialog-centered">
      <div class="modal-content">
         <div class="modal-body">
            <form id="form-upldoc">
               <input id="VID" name="VID" type="text" style="display: none;">
               <div class="container">
                  <div class="row">
                     <div class="col-lg-6 col-sm-12">
                        <div class="form-group">
                           <div class="col-sm-12">
                              <select class="form-control" id="VDOCTYPE" placeholder="Document Type">
                                 <option value="">-- Select Type Document --</option>
                                 @foreach($doctypes AS $doctype)
                                 <option value="{{$doctype['VSETCODE']}}">{{$doctype['VSETDESC']}}</option>
                                 @endforeach
                                 <option value="LAB">Lab</option>
                              </select>
                           </div>
                        </div>
                     </div>
                     <div class="col-lg-6 col-sm-12">
                        <div class="form-group">
                           <div class="col-sm-12">
                              <input id="VDOCNO" class="form-control" type="text" placeholder="Document No" maxlength="30">
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-lg-12 col-sm-12">
                        <div class="form-group">
                           <div id="divFile" class="col-sm-12">
                              <input id="file" type="file" required>
                           </div>
                           <div id="divFileEdit" class="col-sm-12" style="display: none;">
                              <button type="button">Choose File</button>&nbsp;<label></label>
                           </div>
                        </div>
                     </div>
                  </div>
                  <br/>
                  <div style="text-align:center;">
                     <button type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                     <a onclick="$('#modalupldoc').modal('hide');" class="btn btn-cstm btn-light btn-sz">Close</a>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
<!-- Modal Mr-->
<div class="modal fade" id="modalresultMR" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog  modal-xl">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="judul">Patient Medical History</h5>
         </div>
         <div class="modal-body">
            ...
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
         </div>
      </div>
   </div>
</div>

<script>
   var session_groupuser = '{{ Session::get('groupuser')[0] }}';     // Current User Role
 
   // 
   if(!'{{$patient->VEMPSAPID}}'){
      var VCIDs = "<?php echo $patient->VIDCARDNO ?>";

   }else{

      $('[name="VPatientName"],[name="VPHONENO"]').attr('readonly', 'readonly');
      $('.relation-vmarital').prop("disabled", true); 
      $('textarea[name="VADDRESSX"]').prop('disabled', true);
      $('#general .gender-general :radio:not(:checked)').attr('disabled', true);

      var VCIDs = "<?php echo $patient->VEMPSAPID ?>";

   }

   var vsitdate = $('[name="VSITDATE"]').val();
   var vbooking = $('.vbooking').val();
   $('.hasilbarcode1').hide();

   // 
   $(document).on("submit", "[class^=form-confirm]", function (e) {
      $(".form-confirm-examination").css("display", "block");

       var url = $(this).data("url");
       swal.fire({
           html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
           allowOutsideClick: false,
           showCancelButton: false,
           showConfirmButton: false,
       });
       e.preventDefault();
       var prop = {
               url: url,
               type: "POST",
               headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
		         dataType: "JSON",
               success: function (data) {
                  // location.reload();
                  // history.go(-1)
                   window.location.hash = data;
                  //  alert(data);
                  location.reload();

                                    // window.location.href = '..'+data;
               },
               error: function(error) {
                  Swal.fire({
                        icon: "error",
                        
                        text: error.responseJSON.error,
                    });

                  // Handle error
               }
           };
           var formData = false;
	   if ($(this).find('input[type="file"]').length > 0) {
		$.each($(this).find('input[type="file"]'), function( index, value ) {
			if ($(value).prop('files')[0] !== undefined) {
				if (formData === false) {
					formData = new FormData($(".form-confirm")[0]);
					prop.contentType = false;
					prop.processData = false;
				}
				formData.append('files[]', $(value).prop('files')[0]);
			}
		});
	   }
    prop.data = formData ? formData : $(".form-confirm").serialize();
    $.ajax(prop);
    return false;
   });
   
   // 
   $(document).on("submit", "[class^=form-confirm-examination]", function (e) {
       var url = $(this).data("url");
       swal.fire({
           html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
           allowOutsideClick: false,
           showCancelButton: false,
           showConfirmButton: false,
       });
       e.preventDefault();
       
       var prop = {
               url: url,
               type: "POST",
               headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
		         dataType: "JSON",
               success: function (data) {
                  // location.reload();
                  // history.go(-1)
                   window.location.hash = data;
                  //  alert(data);
                  location.reload();

                                    // window.location.href = '..'+data;
               }
           };
           var formData = false;
	   if ($(this).find('input[type="file"]').length > 0) {
		$.each($(this).find('input[type="file"]'), function( index, value ) {
			if ($(value).prop('files')[0] !== undefined) {
				if (formData === false) {
					formData = new FormData($(".form-confirm-examination")[0]);
					prop.contentType = false;
					prop.processData = false;
				}
				formData.append('files[]', $(value).prop('files')[0]);
			}
		});
	   }
    prop.data = formData ? formData : $(".form-confirm-examination").serialize();
    $.ajax(prop);
    return false;
   });
   
   // 
   $(document).on("submit", "[id^=form-upload]", function (e) {
       var url = $(this).data("url");
       swal.fire({
           html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
           allowOutsideClick: false,
           showCancelButton: false,
           showConfirmButton: false,
       });
       e.preventDefault();
       var prop = {
               url: url,
               type: "POST",
               headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
		         dataType: "JSON",
               success: function (data) {
                  // location.reload();
                  // history.go(-1)
                   window.location.hash = data;
                  //  alert(data);
                  location.reload();

                                    // window.location.href = '..'+data;
               },
               error: function(error) {
                  Swal.fire({
                        icon: "error",
                        
                        text: error.responseJSON.error,
                    });
                  // Handle error
               }
           };
           var formData = false;
	   if ($(this).find('input[type="file"]').length > 0) {
		$.each($(this).find('input[type="file"]'), function( index, value ) {
			if ($(value).prop('files')[0] !== undefined) {
				if (formData === false) {
					formData = new FormData($("#form-upload")[0]);
					prop.contentType = false;
					prop.processData = false;
				}
				formData.append('files[]', $(value).prop('files')[0]);
			}
		});
	   }
    prop.data = formData ? formData : $("#form-upload").serialize();
    $.ajax(prop);
    return false;
   });


   // ???
    (function() {
        [].slice.call(document.querySelectorAll('.sttabs')).forEach(function(el) {
            new CBPFWTabs(el);
        });
   })();

   //==== Set tab position(z) to front
   function SetFront(id) {
      var all_li = document.getElementsByName('tab');
      // set all tab to the back
      for (var i = 0; i < all_li.length; i++) {
         all_li[i].style.zIndex = 0;
      }

      all_li[parseInt(id)].style.zIndex = 1;  // set clicked tab to front
   }

   //==== Initialize tab id
   function SetTabID(){
      var all_li = document.getElementsByName('tab');
      
      all_li[0].style.zIndex = 1; // set first tab zIndex to front
      
      // initialize id
      for (var i = 0; i < all_li.length; i++) {
         all_li[i].id = i;
      }
   }

   //==== Tab: Examination, open upload document modal 
   function toFormDocExamination(th, id) {
      $('.upldocexam').trigger("reset");
		   if (id !== undefined) {
		   	$.each($(th).closest('tr').find('td[data-value]'), function( index, value ) {
		   		var input = $('#' + $(value).attr('data-value') + '_ExamDoc');
		   		if ($(value).attr('data-value') == "VDOCTYPE") {
		   			if ($(value).text() != '') {
		   				$('#VDOCTYPE_ExamDoc').prop('selectedIndex', $("#VDOCTYPE_ExamDoc option:contains(" + $(value).text() + ")")[0].index);
                     $('#VDOCTYPE').prop('disabled',true);
		   			}
               } 
               else if ($(value).attr('data-value') == "VDOCNO") {
		   			$('#VDOCNO_ExamDoc').val($(value).text());
               } 
               else if ($(value).attr('data-value') == "VDOCFILENAME") {
		   			$('#divFileEdit_ExamDoc label').text($(value).text());
               }  
               else if ($(value).attr('data-value') == "VID") {
		   			$('#VID_ExamDoc').val($(value).text());
               } 
               else {
		   			input.val($(value).text());
		   		}
		   	});
		   	$('#divFile_ExamDoc').css('display', 'none');
		   	$('#divFileEdit_ExamDoc').css('display', 'block');
            $('#file_ExamDoc').css('display', 'none');
		   	$('#file_ExamDoc').removeAttr('required');
         } 
         else {
		   	$('#divFile_ExamDoc').css('display', 'block');
		   	$('#divFileEdit_ExamDoc').css('display', 'none');
            $('#file_ExamDoc').css('display', 'block');
            $('#file_ExamDoc').prop('required',true);
		   }
		$('#modalupExamination').modal('show');

      $('#file_ExamDoc').on('change', function(e){ 
         $('#divFileEdit_ExamDoc label').text(e.target.files[0].name);
      });
   }

    
   //==== Ready function 1
   $(document).ready(function() {
		$('#divFile').on('change', 'input', function(){
			$('#divFile').css('display', 'block');
			$('#divFileEdit').css('display', 'none');
		});
   });

    //==== Tab: Document List, open upload document modal
    function toFormDoc(th, id) {
		$('#form-upldoc').trigger("reset");
		if (id !== undefined) {
			$.each($(th).closest('tr').find('td[data-value]'), function( index, value ) {
				var input = $('#form-upldoc #' + $(value).attr('data-value') + '');
				if ($(value).attr('data-value') == "VDOCTYPE") {
					if ($(value).text() != '') {
                  $('#VDOCTYPE').prop('selectedIndex', $("#VDOCTYPE option:contains(" + $(value).text() + ")")[0].index);
                  $('#VDOCTYPE').prop('disabled',true);
					}
            } 
            else if ($(value).attr('data-value') == "VDOCFILENAME") {
					$('#divFileEdit label').text($(value).text());
            } 
            else {
					input.val($(value).text());
				}
			});
			$('#divFile').css('display', 'none');
         $('#divFileEdit').css('display', 'block');
			$('#file').removeAttr('required');
         // $('#file').css('display', 'none');
      } 
      else {
			$('#divFile').css('display', 'block');
         $('#divFileEdit').css('display', 'none');
         $('#VDOCTYPE').prop('disabled',false);
         // $('#file').css('display', 'block');
		}
		$('#modalupldoc').modal('show');
    }
   
   //==== save/add row of upload document
   // var files_num = 0;
   // $(document).on("submit", "[id^=form-upldocexam]", function (e) {
	// 	e.preventDefault();
		
   //    var th = $('#file')[0]; // uploaded file
		
	// 	$('#modalupExamination').modal('hide');
   // });

   //==== Tab: Document List, add a new row of document
   var files_num = 0;
   $(document).on("submit", "[id^=form-upldoc]", function (e) {
		e.preventDefault();
		var th = $('#file')[0]; // uploaded file
		if ($('#form-upldoc input[name="VID"]').val() != '') {
			$.each($('#tbldocument td:contains(' + $('#form-upldoc input[name="VID"]').val() + ')').closest('tr').find('td[data-value]'), function( index, value ) {
				if ($(value).attr('data-value') == "VDOCFILENAME") {
					var tdTag = $(value).closest('tr').children('td').last();
					if (th.files[0]) {
						$(value).html(th.files[0].name);
						if ($(value).closest('tr').find('[name="files[]"]').length > 0) {
							$(value).closest('tr').find('[name="files[]"]').closest('td').remove();
						}
						$(value).closest('tr').prepend('<td id="fileInput" style="display: none;"></td>');
						reloadFile();
						tdTag.html(th.files[0].name + '<input name="VDOCFILENAME[]" type="hidden" value="' + th.files[0].name + '">');
					} else {
						var aTag = tdTag.find('a');
						if (aTag.length > 0) {
							aTag.html($('#divFileEdit label').text() + '<input name="VDOCFILENAME[]" type="hidden" value="">');
							$(value).closest('tr').prepend('<td style="display: none;"><input name="files[]"></td>');
						}
					}
            } 
            else if ($(value).attr('data-value') == "VDOCTYPE") {
					if ($('#VDOCTYPE option:selected').val() != '') {
						$(value).html($('#VDOCTYPE option:selected').text() + '<input name="' + $(value).attr('data-value') + '[]" type="hidden" value="' + $('#VDOCTYPE option:selected').val() + '">');
					}
            } 
            else {
					$(value).html($('#form-upldoc input[id="' + $(value).attr('data-value') + '"]').val() + '<input name="' + $(value).attr('data-value') + '[]" type="hidden" value="' + $('#form-upldoc input[id="' + $(value).attr('data-value') + '"]').val() + '">');
				}
			});
      } 
      else {
			$('#tbldocument tbody').append(
            '<tr>'+
               '<td id="fileInput" style="display: none;"></td>'+
               '<td data-value="VID" style="display: none;">' + files_num.toString().padStart(13, '0') + 
                  '<input name="VID[]" type="hidden" value="' + files_num.toString().padStart(13, '0') + '">'+
               '</td>'+
               '<td data-value="VDOCFILENAME" style="display: none;">' + th.files[0].name + '</td>'+
               '<td style="text-align: center;">'+
                  '<button title="Edit" onClick="toFormDoc(this, \'' + files_num.toString().padStart(13, '0') + '\')" type="button" class="btn btn btn-link btn-sm deleteupldoc"><i class="fas fa-edit"></i></button>&nbsp;'+
                  '<button title="Delete" onClick="removeUplDoc(this)" data-id="' + files_num.toString().padStart(13, '0') + '" type="button" class="btn btn btn-link btn-sm deleteupldoc"><i class="fas fa-times"></i></button>'+
               '</td>'+
               '<td>' + ($('#tbldocument tbody tr').length + 1) + '</td>'+
               '<td data-value="VDOCTYPE">' + ($('#VDOCTYPE').val() != '' ? $('#VDOCTYPE option:selected').text() : '') + '<input name="VDOCTYPE[]" type="hidden" value="' + $('#VDOCTYPE').val() + '"></td>'+
               '<td data-value="VDOCNO">' + $('#VDOCNO').val() + '<input name="VDOCNO[]" type="hidden" value="' + $('#VDOCNO').val() + '"><td>' + th.files[0].name + '<input name="VDOCFILENAME[]" type="hidden" value="' + th.files[0].name + '"></td>'+
            '</tr>'
         );
			reloadFile();
			files_num++;
		}
		$('#modalupldoc').modal('hide');
	});

	//==== Reloading file (used for form-upldoc when adding/editing a row)
	function reloadFile () {
		$("#fileInput").append($('#file')).removeAttr("id");
		$("#file").attr('name', 'files[]').removeAttr("id").removeAttr("required");
		$('#divFile').append('<input id="file" type="file" required>');
	}
   
   //==== Edit file
	$('#divFileEdit').on('click', 'button', function () {
		$('#file').trigger('click');
   });
   
   //==== Tab: Document List, remove a row of document
	function removeUplDoc(th) {
		swal.fire({
			text: "Do you want to delete the data?",
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Yes",
			cancelButtonText: "No"
		}).then(function (result) {
			if (result.value) {
				if ($(th).attr('data-id').length == 36) {
					$.ajax({
						url: "/account/users/deldoc/" + $(th).attr('data-id'),
						type: "GET",
						headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
						success: function () {
							location.reload();
						}
					});
				} else {
					$(th).closest('tr').remove();
					$.each($('#tbldocument tbody tr'), function( index, value ) {
						$('#tbldocument tbody tr:eq(' + index + ') td:eq(1)').text(index + 1);
					});
				}
			}
		});
   }
   
   // Modal Result MR
   $(document).on('click', '.resultmr', function(e) {
      var id = $(this).data('id');
      
      // AJAX request
      $.ajax({
            url: "/history/mr/" + id,
            type: "GET",
            headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
            beforeSend: function() {
               swal.fire({
                     html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
                     allowOutsideClick: false,
                     showCancelButton: false,
                     showConfirmButton: false,
               });
            },
            success: function (data) {
               // var data = data.Treatment[0];
               swal.close();

               console.log(data);
               $('#modalresultMR').modal('show');
               $('#modalresultMR').find('#judul').text("Patient Medical History");
               $('#modalresultMR').find('.modal-body').html(data);

            }
      });
   });

   //==== Ready function 2
   $(document).ready(function() {
      // Checking Role Access for input fields
      RoleAccessFunctionsCheck();

      // Get decoded hash 
      var hash = "<?php echo $hash; ?>";

      // when pressing close button, redirecting to previous page (where user is coming from)
      if(hash.includes("ptntlst")) $('.close_button').click(function(){ window.location.replace('/account/booking/patientlist'); });
      else  $('.close_button').click(function(){ window.location.replace('/account/bookingsm'); });

      // $('#modalresultMR').on('show.bs.modal', function (e) {
      //    var id = $(e.relatedTarget).attr('data-id');
      //    $.ajax({
      //             url: "/history/mr/" + id,
      //             type: "GET",
      //             headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
      //             success: function (data) {
      //                var data = data.Treatment[0];
      //                console.log(data);
      //                // $('#modalresultMR').modal('show');
      //                $(this).find('#judul').text("Patient Medical History");
      //             }
      //    });
      //  return false;
      // });

      LoadTableMCU();

      // Initilize tab id
      tableresultMR = $("#cmresultmr").DataTable({
         destroy: true,
         searching: false,
         processing: true,
         serverSide: true,
         dom: 'Bfrtip',
         lengthMenu: [ 3 ],
         pageLength: 3,
         bLengthChange: false,
         bInfo : false,
         dom: '<lf<t><r>ip>',
         columnDefs: [
            { "width": "5%", "className": "text-center", "targets": 0}
         ],
         ajax: {
            url: '/resultmr/',
            type: "GET",
            data: function (d) {

               d.search = $('input[type="search"]').val()
            },
            data: {
               'DFROM': $('input[name="DFROM"]').val(), 
               'DTO': $('input[name="DTO"]').val(),
               'BOOKING': btoa("<?php echo $patient->VMRNO ?>")

            },
         },
         columns: [
            {
               data: "No",
               name: "No",
            },
            // {
            //     data: "no",
            //     name: "no",
            // },

            {
               data: "visitdate",
               name: "visitdate",
            },
            {
               data: "VCLINICNAME",
               name: "VCLINICNAME",
            },
            {
               data: "VNAME",
               name: "VNAME",
               searchable: false,

            },
            {
               data: "VDXNAME",
               name: "VDXNAME",
               searchable: false,
            }
         ],
      })
      SetTabID();
      
      if(window.location.hash === '#tabexamination') $("li[name='tab'][tab='Examination']").click();
      if(window.location.hash === '#tabgeneral') $("li[name='tab'][tab='General']").click();

      if(window.location.hash === '#tabtreatment') $("li[name='tab'][tab='Treatment']").click();
      if(window.location.hash === '#uplddoc') $("li[name='tab'][tab='Document List']").click();
      else if(hash.includes('ptntlst'))
      {
         if(session_groupuser === "DCTR" || session_groupuser === "HRADM"){
            $('#fieldset:not(.btn)').prop('disabled',true);
            $('.input-group-append').click(false);
         }
      }

      //Load table: 
      //LoadTable();

      $('.province').select2({
         theme: 'bootstrap4',
         width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
         allowClear: Boolean($(this).data('allow-clear')),
      });
      $('.district').select2({
         theme: 'bootstrap4',
         width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
         allowClear: Boolean($(this).data('allow-clear')),
      });
      $('.subdistrict').select2({
         theme: 'bootstrap4',
         width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
         allowClear: Boolean($(this).data('allow-clear')),
      });
      // person in change
      $('.province1').select2({
         theme: 'bootstrap4',
         width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
         allowClear: Boolean($(this).data('allow-clear')),
      });
      $('.district1').select2({
         theme: 'bootstrap4',
         width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
         allowClear: Boolean($(this).data('allow-clear')),
      });
      $('.subdistrict1').select2({
         theme: 'bootstrap4',
         width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
         allowClear: Boolean($(this).data('allow-clear')),
      });

      // Set format for date input
      $('#DBIRTH, #PERIODFR, #PERIODTO, #DMARITAL, #DHIRE, #DENDCNTRCT, #DRELBIRTH, #startdate, #enddate, #startmcu, #endmcu').datetimepicker({
         format: 'DD-MMM-YYYY'
      });

      // Tab: Examination, Clinical Diagnosis lookup
      var table = $("#clinical").DataTable({
            ajax: {
               url: '/geticddiagnosislookup',
               type: "GET",
            },
            columns: [
               {
                  data: "VDXCODE",
                  name: "VDXCODE"
               }, 
               {
                  data: "VDXNAME",
                  name: "VDXNAME"
               }
            ]
         });
         $('#clinical tbody').on('dblclick', 'tr', function() {
            var data = table.row(this).data();
            $('input[name="mydiagnosis"]').val(data['VDXCODE'] + ' - ' + data['VDXNAME']);
            $('input[name="mydiagnosisi"]').val(data['VDXCODE']);
         
            $(this).closest('.card').find('button').trigger('click');
         });

      // Tab: Examination, Drugs lookup
      var tablex = $("#tblexamination").DataTable({
         ajax: {
               url: '/getdrugslookupexamination/{{$patient->VCLINICCODE}}',
               type: "GET",
         },
         columns: [
            {
               data: "VDRUGSCODE",
               name: "VDRUGSCODE"
            },
            {
               data: "VCONTAIN",
               name: "VCONTAIN"
            },
            {
               data: "VBRAND",
               name: "VBRAND"
            },
            {
               data: "VUOM",
               name: "VUOM"
            },
            {
               data: "STOCK",
               name: "STOCK"
            }
         ],
         fnRowCallback : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
            if (aData['STOCK'] <= '0') {
               $('td', nRow).css('background-color', '#ff8080');
            }
         }
      });
      $('#tblexamination tbody').on('dblclick', 'tr', function() {

         var data = tablex.row(this).data();

            $.ajax({
               url: '/itemiuses/' + btoa(data['VDRUGSCODE']),
               type: "GET",
               dataType: "JSON",
               success: function (data) {
                     var table = document.getElementById("itemiuses");
                  
                     $(table).find('tbody').append(
                        "<tr>"+
                        "<td data-value='VID' style='display: none;'></td>"+
                        "<td data-value='DRUGSCODE' style='display: none;'>"+data.data[0].DRUGS_CODE+"</td>"+
                        "<td class='text-center' width='1%'><button onClick='' type='button' class='btn btn btn-link btn-sm deletebooking'><i title='Edit' class='fas fa-edit'></i></button>&nbsp;<button onClick='removeexam(this)' data-id='0' type='button' class='btn btn btn-link btn-sm deletebooking'><i title='Delete' class='fas fa-times'></i></button><input type='hidden' value='"+data.data[0].DRUGS_CODE+"' name='drugcode[]'></td>"+
                        "<td width='1%'><b>"+data.data[0].DRUGS_BRAND+"</b></td>"+
                        "<td width='5%'><b>"+data.data[0].DRUGS_CONTAIN+"</b></td>"+
                        "<td width='1%'><input type='number' class='form-control' name='qty[]' required></td>"+
                        "<td width='1%'><b>"+data.data[0].DRUGS_UOM+"</b></td></tr>");
                        
                     
               }
            
            });
         // $('input[name="VCOORDINATOR"]').val(data['VDRUGSCODE'] + ' - ' + data['VDRUGSTYPE']);
         $(this).closest('.card').find('button').trigger('click');
      });

      // Tab: tab_name, explain_function
      var treatment = $("#tbltreatment").DataTable({
         ajax: {
               url: '/getdrugslookup1/{{$patient->VCLINICCODE}}',
               type: "GET",
         },
         columns: [
            {
               data: "VDRUGSCODE",
               name: "VDRUGSCODE"
            },
            {
               data: "VCONTAIN",
               name: "VCONTAIN"
            },
            {
               data: "VBRAND",
               name: "VBRAND"
            },
            {
               data: "VUOM",
               name: "VUOM"
            },
            {
               data: "STOCK",
               name: "STOCK"
            }
         ],
         fnRowCallback : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
            if (aData['STOCK'] <= '0') {
               $('td', nRow).css('background-color', '#ff8080');
            }
         }
      });
      $('#tbltreatment tbody').on('dblclick', 'tr', function() {

         var data = treatment.row(this).data();

                  
         if (data['STOCK'] <= '0')return;
         // console.log(data['DRUGS_UOM']);
         var table = document.getElementById("treat");
         var count = $('#treat tbody').find("tr").length;
         var UOM = $('#treat tbody').find("tr").find("td#"+count).eq(6);
         var NAME = $('#treat tbody').find("tr").find("td#"+count).eq(2);
         var hidden = $('#treat tbody').find("tr").find("td#"+count).eq(8);
         hidden.html("<input type='text' name='drugcode[]' value='"+data['VDRUGSCODE']+"' required></input>");
         // [6].innerHTML = data['DRUGS_UOM'];
         $(UOM).text(data['VUOM']);
         // $('#treat tbody').find("td").eq(6).innerHTML = data['DRUGS_UOM'];
         $(NAME).text(data['VDRUGSCODE'] + ' - ' + data['VCONTAIN'] + ' - ' + data['VBRAND']);
         // $('input [name="VCOORDINATOR[]"]').val(data['DRUGS_CODE'] + ' - ' + data['DRUGS_CONTAIN']);
         // $(table).find('tbody').append("<tr>"+
         // "<td width='10%'><button onClick='' type='button' class='btn btn btn-link btn-sm'><i class='fas fa-edit'></i></button>&nbsp;<button onClick='remove(this)'  type='button' class='btn btn btn-link btn-sm deletebooking'><i class='fas fa-times'></i></button><input type='hidden'  name='drugcode[]'></td>"+
         // "<td width='10%'></td>"+
      
         // "<td  width='20%'></td><td  width='15%'></td>"+
         // "<td  width='20%'></td>"+
      
         // "<td width='8%'><input type='number' class='form-control' name='qty[]'></td>"+
         // "<td  width='20%'></td>"+
         // "<td  width='20%'></td>"+
      
         // "</tr>");
      
         $(this).closest('.card').find('button').trigger('click');
      });
      
      // Tab: tab_name, explain_function
      let row_id_idx = $('#treat tbody tr').length + 1;

      if(document.getElementById('addRow') != null){
         var addRow = document.getElementById('addRow');
         addRow.addEventListener('click', function() {
            var table = document.getElementById("treat");

            $(table).find('tbody').append("<tr id='"+ ($('#treat tbody tr').length + 1) +"'>"+
            "<td data-id='remove' class='text-center' style='text-align: center;' width='5%' id='"+ ($('#treat tbody tr').length + 1) +"'><button onClick='remove(this)' title='Delete' type='button' data-id='' class='btn btn btn-link btn-sm deletebooking'><i class='fas fa-times'></i></button><input type='hidden' name='vbookings[]' class='vbooking' value='{{$db}}'></td>"+
            "<td data-id='no' width='5%' id='"+ ($('#treat tbody tr').length + 1) +"' class='no'>"+ ($('#treat tbody tr').length + 1) +"<input type='hidden' name='no_line[]' value="+ ($('#treat tbody tr').length + 1) + "></td>"+
            "<td data-id='VCONTAIN' width='25%' id='"+ ($('#treat tbody tr').length + 1) +"'><div class='input-group'><input  name='VCOORDINATORS[]' class='form-control form-control-sm' type='text' value='' readonly><div class='input-group-append' style='cursor: pointer;' data-toggle='modal' data-target='#treatment'><div class='input-group-text'><i class='fa fa-search'></i></div></div></div></td>"+
            "<td data-id='VDOCNO'  width='25%' id='"+ ($('#treat tbody tr').length + 1) +"'> <input type='hidden' class='form-control form-control-sm hasilbarcode1' value='' name='hasilbarcode1' placeholder='Scan Item'></td>"+
            "<td data-id='VDOSAGE' width='10%' id='"+ ($('#treat tbody tr').length + 1) +"'><input type='text' class='form-control' name='dosaggeS[]' required></td>"+
            "<td data-id='QTY' width='8%' id='"+ ($('#treat tbody tr').length + 1) +"'><input type='number' class='form-control' name='qtyS[]' required></td>"+
            "<td data-id='VUOM'  width='10%' id='"+ ($('#treat tbody tr').length + 1) +"' class='uom'></td>"+
            "<td data-id='VREMARKS' width='20%' id='"+ ($('#treat tbody tr').length + 1) +"'><input type='text' class='form-control' name='remarksS[]' required></td>"+
            "<td data-id='id' id='"+ ($('#treat tbody tr').length + 1) +"' class='i' style='display:none;'><input type='text' id='box"+ ($('#treat tbody tr').length + 1) +"' value=''></input></td>"+
            "</tr>");      
         }, false);
      }
      
      // Tab : Update Examination
      var tblexaminationUpdate = $("#tblexaminationUpdate").DataTable({
         ajax: {
               url: '/getdrugslookupexamination/{{$patient->VCLINICCODE}}',
               type: "GET",
         },
         columns: [
            {
               data: "VDRUGSCODE",
               name: "VDRUGSCODE"
            },
            {
               data: "VCONTAIN",
               name: "VCONTAIN"
            },
            {
               data: "VBRAND",
               name: "VBRAND"
            },
            {
               data: "VUOM",
               name: "VUOM"
            },
            {
               data: "STOCK",
               name: "STOCK"
            }
         ],
         fnRowCallback : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
            if (aData['STOCK'] <= '0') {
               $('td', nRow).css('background-color', '#ff8080');
            }
         }
      });
      $('#tblexaminationUpdate tbody').on('dblclick', 'tr', function() {
         var data = tblexaminationUpdate.row(this).data();
         $('input[name="VCONTAIN"]').val(data['VDRUGSCODE'] + ' - ' + data['VCONTAIN']+ ' - ' + data['VBRAND']);
         $('input[name="VDRUGSCODE"]').val(data['VDRUGSCODE']);
      
         // "</tr>");
      
         $(this).closest('.card').find('button').trigger('click');
      });
      
      // Tab: tab_name, explain_function
      var treatmentUpdate = $("#tbltreatmentUpdate").DataTable({
         ajax: {
               url: '/getdrugslookup1/{{$patient->VCLINICCODE}}',
               type: "GET",
         },
         columns: [
            {
               data: "VDRUGSCODE",
               name: "VDRUGSCODE"
            },
            {
               data: "VCONTAIN",
               name: "VCONTAIN"
            },
            {
               data: "VBRAND",
               name: "VBRAND"
            }
           
         ],
         fnRowCallback : function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
            if (aData['STOCK'] <= '0') {
               $('td', nRow).css('background-color', '#ff8080');
            }
         }
      });
      $('#tbltreatmentUpdate tbody').on('dblclick', 'tr', function() {
         var data = treatmentUpdate.row(this).data();
         $('input[name="VCONTAIN"]').val(data['VDRUGSCODE'] + ' - ' + data['VCONTAIN']+ ' - ' + data['VBRAND']);
         $('input[name="VDRUGSCODES"]').val(data['VDRUGSCODE']);
      
         // "</tr>");
      
         $(this).closest('.card').find('button').trigger('click');
      });
      
      // Tab: tab_name, explain_function
      if(document.getElementById('addRow') != null){
         var addRowUpdate = document.getElementById('addRow');
         addRowUpdate.addEventListener('click', function() {
            var table = document.getElementById("treat");        
         }, false);
      }

      // (PatientQueue/Booking only) If View for tab:Booking is allowed
      <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', !str_contains($hash, 'ptntlst') ? 'F01' : 'NOTALLOWED')) { ?>
         // Tab: Booking, Doctor lookup
         var tbldoctorlist = $("#mydctrlist").DataTable({
            ajax: {
               url: '/doctorlist/'+btoa(vsitdate+';'+'{{$patient->VPOSCODE}}'+';'+'{{$patient->VCLINICCODE}}'),
               type: "GET",
            },
            columns: [
               {
                  data: "VUSRID",
                  name: "VUSRID"
               }, 
               {
                  data: "VNAME",
                  name: "VNAME"
               },
               {
                  data: "VSCHDAY",
                  name: "VSCHDAY"
               
               },
               {
               
                  data: "TSCHSTART",
                  name: "TSCHSTART"
               },
               {
                  data: "TSCHEND",
                  name: "TSCHEND"
               }
            ]
         });
         $('#mydctrlist tbody').on('dblclick', 'tr', function() {
            var data = tbldoctorlist.row(this).data();
            $('input[name="DOCTOR"]').val(data['VUSRID'] + ' - ' + data['VNAME'] + ' - ' +  data['VSCHDAY'] + ' - ' +  data['TSCHSTART']);
            $('input[name="DOCTR"]').val(data['VUSRID']);
            
            $(this).closest('.card').find('button').trigger('click');
         });

         // Tab: Booking, Alternative Doctor lookup
         var tbldoctor = $("#mydctr").DataTable({
            ajax: {
               url: '/alternativedoctor/'+btoa(vbooking),
               type: "GET",
            },
            columns: [
               {
                  data: "VUSRID",
                  name: "VUSRID"
               }, 
               {
                  data: "VNAME",
                  name: "VNAME"
               },
               {
                  data: "VSCHDAY",
                  name: "VSCHDAY"
               
               },
               {
               
                  data: "TSCHSTART",
                  name: "TSCHSTART"
               },
               {
                  data: "TSCHEND",
                  name: "TSCHEND"
               }
            ]
         });
         $('#mydctr tbody').on('dblclick', 'tr', function() {
            var data = tbldoctor.row(this).data();
            $('input[name="ALTERNATIVE"]').val(data['VUSRID']  + ' - ' + data['VNAME']);
            $('input[name="ALTERNATIVES"]').val(data['VUSRID']);

            $(this).closest('.card').find('button').trigger('click');
         });
      <?php } ?>
   });


   //
   var idV =  $('#istirahat').find(":selected").text(); 
   if(idV === 'Tidak'){
         document.getElementById("jumlahari").disabled = true;
         
      }

   $(document).on("change", '#istirahat', function(e) {
      var id = $(this).val(); 
      if(id === '0'){
         document.getElementById("jumlahari").disabled = true;
         
      }else{

         document.getElementById("jumlahari").disabled = false;
         document.getElementById("jumlahari").required;
      }  

   });
   $(document).on("change", '.province', function(e) {
      var id = $(this).val();   
      $.ajax({
         dataType: 'json',
         type: 'GET',
         url: '/getajaxdistrict/' + id,
         success: function(result) {

            $('.district').html(result);
            getsubdistrict();
         }
      });
   });
      
   // 
   $(".province1").change(function() {
      var id = $(this).val();
      $.ajax({
         dataType: 'json',
         type: 'GET',
         url: '/getajaxdistrict/' + id,
         success: function(result) {

            $('.district1').html(result);
            getsubdistrict1();
         }
      });
   });
        
   $(".district").change(getsubdistrict);    // 
   $(".district1").change(getsubdistrict1);  // 

   // 
   function getsubdistrict1() {
      var id_district = $(".district1").val();
      $.ajax({
         dataType: 'json',
         type: 'GET',
         url: '/getajaxsubdistrict/' + id_district,
         success: function(result) {

            $('.subdistrict1').html(result);

         }
      });
   }
       
   // 
   function getsubdistrict() {
      var id_district = $(".district").val();
      $.ajax({
         dataType: 'json',
         type: 'GET',
         url: '/getajaxsubdistrict/' + id_district,
         success: function(result) {

            $('.subdistrict').html(result);

         }
      });
   }
    
   // 
   function toFormExamination(th, id) {
		$('#form-examination').trigger("reset");
		if (id !== undefined) {
			$.each($(th).closest('tr').find('td[data-value]'), function( index, value ) {
				var input = $('#form-examination .' + $(value).attr('data-value') + '');
            input.val($(value).text());
         });
         
			$('#divFile').css('display', 'none');
			$('#divFileEdit').css('display', 'block');
			$('#file').removeAttr('required');
      } 
      else {
			$('#divFile').css('display', 'block');
			$('#divFileEdit').css('display', 'none');
		}
		$('#modalexam').modal('show');
   }
   
   // 
   function toFormtreatment(th, id) {
		$('.form-confirm').trigger("reset");
		if (id !== undefined) {
			$.each($(th).closest('tr').find('td[data-value]'), function( index, value ) {
				var input = $('.form-confirm #' + $(value).attr('data-value') + '');
            input.val($(value).text());
         });
         
			$('#divFile').css('display', 'none');
			$('#divFileEdit').css('display', 'block');
			$('#file').removeAttr('required');
      } 
      else {
			$('#divFile').css('display', 'block');
			$('#divFileEdit').css('display', 'none');
		}
		$('#modaldoc').modal('show');
	}

   // 
   $(document).on('show.bs.modal', '.modal', function (event) {
      var zIndex = 1040 + (10 * $('.modal:visible').length);
      $(this).css('z-index', zIndex);
      setTimeout(function() {
            $('.modal-backdrop').not('.modal-stack').css('z-index', zIndex - 1).addClass('modal-stack');
      }, 0);
   });

   function onEnter(e){// => Digunakan untuk membaca karakter enter
       var key=e.keyCode || e.which;
       if(key==13){// => Karakter enter dikenali sebagai angka 13
           showCell();
       }
   }

   // 
   function removeexam(th){
      swal.fire({
         text: "Do you want to delete the data?",
         icon: "warning",
         showCancelButton: true,
         confirmButtonText: "Yes",
         cancelButtonText: "No"
      })
      .then(function (result) {
         if (result.value) {
            if ($(th).attr('data-id').length > 6) {
               var ext = btoa(vbooking +','+$(th).closest("tr").attr("id"));
               $.ajax({
                  url: "/examination/delete/" + ext,
                  type: "GET",
						headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
                  success: function (data) {
                     // // location.reload();
                     window.location.hash = data;
                     location.reload();
                  }
               });
            } 
            else {
               $(th).closest('tr').remove();
               $.each($('#treat tbody tr'), function( index, value ) {
                  $('#treat tbody tr:eq(' + index + ') td:eq(1)').text(index + 1);
               });
            }
         }
      });
   }

   // 
   function remove(th) {
		swal.fire({
			text: "Do you want to delete the data?",
			icon: "warning",
			showCancelButton: true,
			confirmButtonText: "Yes",
			cancelButtonText: "No"
		}).then(function (result) {
			if (result.value) {
				if ($(th).attr('data-id').length > 9) {
               var ext = btoa(vbooking +','+$(th).closest("tr").attr("id"));

					$.ajax({
						url: "/treatment/delete/" + ext,
						type: "GET",
						headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
						success: function (data) {
                     
							window.location.hash = data;
                     location.reload();
						}
					});
				} else {
					$(th).closest('tr').remove();
					$.each($('#treat tbody tr'), function( index, value ) {
						$('#treat tbody tr:eq(' + index + ') td:eq(1)').text(index + 1);
					});
				}
			}
		});
	}

   // 
   $('#treat').on('keyup', function(e){
      var ext = btoa($(e.target).closest("tr").attr("iline") + ',' + vbooking + ',' + $(e.target).val());
      $.ajax({
         url: '/scanbarcode/' + ext,
         type: "GET",
         dataType: "JSON",
         statusCode: {
            200: function(data) {
               $(e.target).closest("td").find('input[name="drugscodescan"]').show();
               $(e.target).closest("td").find('input[name="hasilbarcode1"]').show();
               $(e.target).closest("td").find('input[name="drugscodescan"]').removeClass('is-invalid');

               $(e.target).closest("td").find('input[name="drugscodescan"]').val(data.VCONTAIN);
               $(e.target).closest("td").find('input[name="hasilbarcode1[]"]').val(data.VDRUGSCODE);

            },
            400: function(data){
               $(e.target).closest("td").find('input[name="drugscodescan"]').addClass("is-invalid");
            }
         }
      });
   });
                 
   //==== Load the main table
   function LoadTableMr(){
      tableresultMR = $("#cmresultmr").DataTable({
         destroy: true,
         searching: false,
         processing: true,
         serverSide: true,
         ordering: false,
         dom: '<lf<t><r>ip>',
         columnDefs: [
            { "width": "5%", "className": "text-center", "targets": 0,"orderable": false}
            
         ],
         ajax: {
            url: '/resultmr/',
            type: "GET",
            data: function (d) {

               d.search = $('input[type="search"]').val()
            },
            data: {
               'DFROM': $('input[name="DFROM"]').val(), 
               'DTO': $('input[name="DTO"]').val(),
               'BOOKING': btoa("<?php echo $patient->VMRNO ?>")

            },
         },
         columns: [
            {
               data: "No",
               name: "No",
            },
            // {
            //     data: "no",
            //     name: "no",
            // },

            {
               data: "visitdate",
               name: "visitdate",

            },
            {
               data: "VCLINICNAME",
               name: "VCLINICNAME",
            },
            {
               data: "VNAME",
               name: "VNAME",
               searchable: false,

            },
            {
               data: "VDXNAME",
               name: "VDXNAME",
               searchable: false,
            }
         ],
      });
   }
   function LoadTableMCU(){
      tableresultMR = $("#tblmcu").DataTable({
         destroy: true,
         searching: false,
         processing: true,
         serverSide: true,
         dom: 'Bfrtip',
         lengthMenu: [ 3 ],
         pageLength: 3,
         bLengthChange: false,
         bInfo : false,
         dom: '<lf<t><r>ip>',
         columnDefs: [
            { "width": "5%", "className": "text-center", "targets": 0}
         ],
         ajax: {
            url: '/resultmcu/',
            type: "GET",
            data: function (d) {

               d.search = $('input[type="search"]').val()
            },
            data: {
               'DFROM': $('input[name="DFROM"]').val(), 
               'DTO': $('input[name="DTO"]').val(),
               'VIDNO': btoa(VCIDs)

            },
         },
         columns: [
            {
               data: "No",
               name: "No",
            },
            // {
            //     data: "no",
            //     name: "no",
            // },

            {
               data: "DRESULT",
               name: "DRESULT",
            },
            {
               data: "VREGNO",
               name: "VREGNO",
               render: function (data, type, row) {
          
							return "<a href='/account/resultmcu/form/"+ btoa(data) +"'>" + data + "</a>"
					
				}
            }
         ],
      });

   }

   //==== Disable/Readonly Fields
   function RoleAccessFunctionsCheck()
   {
      //---- Edit Functions
      // Booking tab, input fields
      <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', !str_contains($hash, 'ptntlst') ? 'F01' : 'NOTALLOWED')) { ?>
         $(".tab-booking-r").attr('readonly', false);
         $(".tab-booking-d").attr('disabled', false);
      <?php } else { ?>
         $(".tab-booking-r").attr('readonly', true);
         $(".tab-booking-d").attr('disabled', true);
      <?php } ?>

      // General tab, input fields
      <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', !str_contains($hash, 'ptntlst') ? 'F02' : 'F28')) { ?>
         $('#general input').attr('readonly', false);
         $('.relation').prop("disabled", false); 
         $('#subdistrict').select2().prop("disabled", false); 
         $('textarea[name="VADDRESSX"]').prop('disabled', false);
         $('textarea[name="VPICADDRESS"]').prop('disabled', false);
         $('#general :radio:not(:checked)').attr('disabled', false);
         $('.relation-vmarital').prop("disabled", false); 
      <?php } else { ?>
         $('#general input').attr('readonly', true);
         $('.relation').prop("disabled", true); 
         $('#subdistrict').select2().prop("disabled", true); 
         $('textarea[name="VADDRESSX"]').prop('disabled', true);
         $('textarea[name="VPICADDRESS"]').prop('disabled', true);
         $('#general :radio:not(:checked)').attr('disabled', true);
         $('.relation-vmarital').prop("disabled", true); 
      <?php } ?>

      // Pre-Examination tab (Vital Signs), input fields
      <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', !str_contains($hash, 'ptntlst') ? 'F03' : 'F29')) { ?>
         $(".tab-preexam-r").attr('readonly', false);
      <?php } else { ?>
         $(".tab-preexam-r").attr('readonly', true);
      <?php } ?>

      // Examination tab (Diagnosis, Item use), input fields
      <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('U', !str_contains($hash, 'ptntlst') ? 'F04' : 'F29')) { ?>
         //$('#jumlahari input').attr('readonly', false);
         $('#jumlahari').attr('readonly', false);

         //$('.relation').prop("disabled", false); 
         $('#istirahat').select2().prop("disabled", false); 
         $('#rujukan').prop("disabled", false); 

         $('textarea[name="VDRUGALLERGIES"]').prop('disabled', false);
         $('textarea[name="VAMNESIS"]').prop('disabled', false);
         $('textarea[name="VNOTES"]').prop('disabled', false);
         $('textarea[name="profil"]').prop('disabled', false);
         $('textarea[name="provider"]').prop('disabled', false);

         $('#examination_post :radio:not(:checked)').attr('disabled', false);
      <?php } else { ?>
         //$('#jumlahari input').attr('readonly', 'readonly');
         $('#jumlahari').attr('readonly', true);

         //$('.relation').prop("disabled", true); 
         $('#istirahat').select2().prop("disabled", true); 
         $('#rujukan').prop("disabled", true); 

         $('textarea[name="VDRUGALLERGIES"]').prop('disabled', true);
         $('textarea[name="VAMNESIS"]').prop('disabled', true);
         $('textarea[name="VNOTES"]').prop('disabled', true);
         $('textarea[name="profil"]').prop('disabled', true);
         $('textarea[name="provider"]').prop('disabled', true);

         $('#examination_post :radio:not(:checked)').attr('disabled', true);
      <?php } ?>
   }




   // var rupiah = document.getElementById('temprature');
   //    rupiah.addEventListener("keyup", function(e) {
   //    rupiah.value = convertRupiah(this.value);
   // });

	// rupiah.addEventListener('keydown', function(e){
	// 	// tambahkan 'Rp.' pada saat form di ketik
   //    // gunakan fungsi formatRupiah() untuk mengubah angka yang di ketik menjadi format angka
   //    return isNumberKey(this.value);
   // });
   // function convertRupiah(angka, prefix) {
   //    var number_string = angka.replace(/[^\d]/g, "").toString(),
   //    split  = number_string.split("."),
   //    sisa   = split[0].length % 2,
   //    rupiah = split[0].substr(0, sisa),
   //    ribuan = split[0].substr(sisa).match(/\d{2}/gi);

	//    if (ribuan) {
	// 	   separator = sisa ? "." : "";
	// 	   rupiah += separator + ribuan.join(".");
	//    }
   //    // $('input[name="NPRICE"]').val(number_string)
	//    rupiah = split[1] != undefined ? rupiah + "." + split[1] : rupiah;
	//    return prefix == undefined ? rupiah : rupiah ? prefix + rupiah : "";
   // }
</script>

@endsection