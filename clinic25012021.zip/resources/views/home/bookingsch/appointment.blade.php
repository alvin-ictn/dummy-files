@extends('layout.app') @section('content')
<style>
   #inner {
   display: table;
   margin: 0 auto;
   padding: 10px;
   }
   #outer {
   width:50%
   }
   #outer-e {
   width:100%
   }
</style>
<section class="content">
<section class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-12"></div>
      </div>
   </div>
   <!-- /.container-fluid -->
</section>
<div class="container-fluid">
   <div class="row">
      <div class="col-12">
         <div class="card">
            <!-- /.card-header -->
            <form id="formbooking" method="POST" data-url="/booking/addpointment">
               <input type="hidden" name="VSCHCODE" value="{{$day->VSCHCODE   ?? $mstclinic->VCLINICINIT  }}"/>
               <input type="hidden" value="{{$day->VUSRID  ??  $code  }}" id="id" name="dctr"/>
               <input type="hidden" value="{{$setting2->VSETDESC   ?? $code }}" id="vsetid" />
               <input type="hidden" value="{{$mstclinic->VCLINICCODE   ?? '' }}" name="cliniccode" id="clinicint" />
               <input type="hidden" value="{{$mstclinic->VCLINICINIT   ?? '' }}" name="clinicint"/>
               <input type="hidden" value="{{$typedctr }}" name="typedctr"/>

               <div class="card-body">
                  <div class="row">
                     <div class="col-lg-1 col-sm-12">
                        <label class="col-sm-2 col-form-label col-sm-12">Date</label>
                     </div>
                     <div class="col-lg-3 col-sm-12">
                        <div class="form-group">
                           <div class="col-sm-12">
                              <div class="input-group date" id="datetimeappointment" data-target-input="nearest">
                                 <input type="text" name="datech" class="form-control datetimepicker-input" data-target="#datetimeappointment"  readonly required/>
                                 <div class="input-group-append" data-target="#datetimeappointment" data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <label for="example-text-input" class="col-sm-1 col-form-label datau">
                     Time
                     </label>
                     <div class="col-sm-3 datau">
                        <select class="form-control " name="timefirst" id="timedata" required>
                           <option>Please pick date first</option>
                        </select>
                     </div>
                     <!-- <div class="col-lg-2 col-sm-12">
                        <div class="form-group">
                           <label class="control-label col-sm-12">Date</label>
                        </div>
                        </div>
                        <div class="col-lg-3 col-sm-12">
                        <div class="input-group date" id="datetimeappointment" data-target-input="nearest">
                           <input type="text" name="datech" class="form-control datetimepicker-input" data-target="#datetimeappointment"  readonly required/>
                           <div class="input-group-append" data-target="#datetimeappointment" data-toggle="datetimepicker">
                              <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                           </div>
                        </div>
                        </div>
                        <label for="example-text-input" class="col-sm-2 col-form-label datau">
                        Time
                        </label>
                        <div class="col-sm-3 datau">
                        <select class="form-control" name="timefirst" id="timedata">
                           <option>Please pick date first</option>
                        </select>
                        </div> -->
                  </div>
                  @if(Session::get('typeuser') === "NE")
                  <div id="formpilih">
                     <div class="row">
                        <div class="col-lg-2 col-sm-12">
                           <label class="control-label col-sm-12">Category</label>
                        </div>
                        <div class="col-lg-5 col-sm-12">
                           <div class="form-group row">
                              <div class="col-sm-12">
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input cate" type="radio" name="cate" value="e" />
                                    <label class="form-check-label" for="inlineRadio1">Employee</label>
                                 </div>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input cate" type="radio" name="cate" value="c" />
                                    <label class="form-check-label" for="inlineRadio1">Contractor</label>
                                 </div>
                                 <div class="form-check form-check-inline">
                                    <input class="form-check-input cate" type="radio" name="cate" value="p" />
                                    <label class="form-check-label" for="inlineRadio1">Public</label>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <!-- <div class="form-group row">
                        <label  class="col-sm-2 col-form-label">Category</label>
                        <div class="col-sm-10">
                           <div class="form-check form-check-inline">
                              <input class="form-check-input cate" type="radio" name="cate" value="e" />
                              <label class="form-check-label" for="inlineRadio1">Employee</label>
                           </div>
                           <div class="form-check form-check-inline">
                              <input class="form-check-input cate" type="radio" name="cate" value="c" />
                              <label class="form-check-label" for="inlineRadio1">Contractor</label>
                           </div>
                           <div class="form-check form-check-inline">
                              <input class="form-check-input cate" type="radio" name="cate" value="p" />
                              <label class="form-check-label" for="inlineRadio1">Public</label>
                           </div>
                        </div>
                        </div> -->
                     <div id="employee"></div>

                  </div>
                  <div id="outer" class="btn-closed">
                     <div id="inner">
                              <a href="/account/bookingsm" class="btn btn btn-light btn-sz" type="submit" id="redirct">Close</a>                     </div>
                  </div>
               </div>
               
            </form>
            
         </div>
      </div>
   </div>
   
</div>
<div class="modal fade" id="popupbanking">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-body">
            <div style="text-align: center;">
               <h5 id="mrnno"></h5>
               <br />
               <h6>
                  <div id="QUEQU"></div>
               </h6>
               <h6>
                  <div id="doctor"></div>
               </h6>
               <h6>
                  <div id="dvisit"></div>
               </h6>
               <br />
               <h6>
                  <b>
                     <div id="setting"></div>
                  </b>
               </h6>
               <form action="/account/bookingsm">
                  <button class="btn btn-primary" type="submit" id="redirct">Close</button>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<script>
   var idc = btoa($('#id').val() +","+$('#clinicint').val());
   
   $("#hidden-setting").hide();
   $('#formpilih').hide();
   $(document).ready(function() {
     
      $('input[name=cate]').click(function() {
       var ida = $('input[name=cate]:checked').val();
       $.ajax({
               dataType: 'json',
               type: 'GET',
               url: '/ajaxcategory/' + ida,
               success: function(result) {
                  
                   $('#employee').html(result);
                  
               }
           });
         
       });
   
   
   
       $.ajax({
           dataType: 'json',
           type: 'GET',
           url: '/ajaxdetaildoctor/' + idc,
           success: function(result) {
               var u = JSON.parse(JSON.stringify(result[0]));
               var day = $('#vsetid').val();
               var arr = new Date();
               if(result === 'U'){
   
                  $('#formpilih').show();
                  $('.datau').hide();
                  $(".datau").attr("disabled", false);
                  $('#datetimeappointment').datetimepicker({
                  
                     format: 'DD-MMM-YYYY',
                   //locale: "en-au",
                   minDate: arr,
                   ignoreReadonly: true
                     
   
               });
                 
               }else if(result[1] === 'G'){
   
                  // $('#formpilih').show();
                  // $('.datau').hide();
                  // $(".datau").attr("disabled", false);
                  $('#datetimeappointment').datetimepicker({
                  
                     format: 'DD-MMM-YYYY',
                  //locale: "en-au",
                   minDate: arr,
                   <?php if(Session::get('typeuser') === 'E'){ ?>
                   maxDate: moment().add(day, 'day'),
                   <?php } ?>
                   useCurrent: false,
                   daysOfWeekDisabled: u,
                   ignoreReadonly: true
   
               });
               }else if(result[1] === 'S'){

                  $('#datetimeappointment').datetimepicker({
                  
                     format: 'DD-MMM-YYYY',
                  //  locale: "en-au",
                   minDate: arr,
                   <?php if(Session::get('typeuser') === 'E'){ ?>
                   maxDate: moment().add(day, 'day'),
                   <?php } ?>
                   useCurrent: false,
                   daysOfWeekDisabled: u,
                   
                   ignoreReadonly: true
                  });
                
                
   
               }
               
           }
       });
   
       $('#datetimeappointment').on("change.datetimepicker", function(e) {
           date = $(this).datetimepicker('viewDate');
           var dt = moment(date).format('dddd');
           var m = moment(date).format('Y-MM-DD');
           var id = $('#id').val() +','+ $('#clinicint').val() ;
           var data = btoa(dt + ',' + id + ',' + m);
           $.ajax({
               dataType: 'json',
               type: 'GET',
               url: '/ajaxtime/' + data,
               success: function(result) {
                   var html = '';
                   var i;
                   
                   for (i = 0; i < result.length; i++) {
   
                       html += result[i];
                   }
                   $('#timedata').html(html);
                   $('#formpilih').show();
               }
           });
       });
   
       $("#coose").change(function() {
           $("#hidden-setting").hide();
   
           $choose = $(this).val()
           if ($choose === '1') {
   
           } else if ($choose === 'SPCL') {
               $base64 = btoa($choose);
               $.ajax({
                   type: "GET",
                   dataType: "JSON",
                   url: "/choosespecialist/" + $base64,
                   success: function(data) {
                       $("#specialist").html(data.data);
                       $("#hidden-setting").show();
   
   
                   }
               });
           }
   
       });
   });
      
</script>
@else
<input type="hidden" id="vsuir" name="sapid" value="{{$user->VEMPSAPID}}">
<div class="row">
   <div class="col-lg-1 col-sm-12">
      <div class="form-check form-check-inline">
         <input class="form-check-input" name="fma" type="checkbox" id="checkbox" value="family">
         <label class="form-check-label" for="fm">Family</label>
      </div>
   </div>
   <div class="col-lg-3 col-sm-12">
      <div class="form-group">
         <div class="col-sm-12">
            <select class="form-control" name="fmax" id="familyt">
               <option>-</option>
            </select>
            <div class="col-sm-8">
               <input type="hidden" id="fullname"  name="name"  value="{{$user->VNAME}}">
               <input type="hidden"  value="{{$user->VCITYBIRTH}}" name="city"  id="country">
               <input type="hidden"  value="{{  Carbon\Carbon::parse($user->DBIRTH)->format('d-M-Y') }}" name="dtgl"  id="dateofbirth">
               <input type="hidden" value="{{$user->VPHONENO }}" name="tlpn" id="tlp">
               <input type="hidden" value="e" name="cate" >
            </div>
            <div id="outer-e">
               <div id="inner">
                  <div class="form-group row">
                     <div class="col-sm-12">
                        <button id="startDiv" type="submit" class="align-middle btn-primary btn btn-sz">Confirm</button>
                        <a href="/account/bookingsm" class="btn btn btn-light btn-sz" type="submit" id="redirct">Close</a>
                      
                     </div>
                  </div>
               </div>
            </div>

         </div>
      </div>
   </div>
   <div class="col-sm-3">
   </div>
   <!-- <div class="col-lg-2 col-sm-12">
      <div class="form-group">
         <label class="control-label col-sm-12">Date</label>
      </div>
      </div>
      <div class="col-lg-3 col-sm-12">
      <div class="input-group date" id="datetimeappointment" data-target-input="nearest">
         <input type="text" name="datech" class="form-control datetimepicker-input" data-target="#datetimeappointment"  readonly required/>
         <div class="input-group-append" data-target="#datetimeappointment" data-toggle="datetimepicker">
            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
         </div>
      </div>
      </div>
      <label for="example-text-input" class="col-sm-2 col-form-label datau">
      Time
      </label>
      <div class="col-sm-3 datau">
      <select class="form-control" name="timefirst" id="timedata">
         <option>Please pick date first</option>
      </select>
      </div> -->
</div>

</form>
<div class="modal fade" id="popupbanking">
   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-body">
            <div style="text-align: center;">
               <h5 id="mrnno"></h5>
               <br />
               <h6>
                  <div id="QUEQU"></div>
               </h6>
               <h6>
                  <div id="doctor"></div>
               </h6>
               <h6>
                  <div id="dvisit"></div>
               </h6>
               <br />
               <h6>
                  <b>
                     <div id="setting"></div>
                  </b>
               </h6>
               <form action="/account/bookingsm">
                  <button class="btn btn-primary" type="submit" id="redirct">Close</button>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
   <script>
      $("#familyt").attr("disabled", true);
      $(document).ready(function() {
         $('input[name=cate]').click(function() {
          var ida = $('input[name=cate]:checked').val();
          $.ajax({
                  dataType: 'json',
                  type: 'GET',
                  url: '/ajaxcategory/' + ida,
                  success: function(result) {
                    
                      $('#employee').html(result);
                     
                  }
              });
            
          });
      
          var idc = btoa($('#id').val() +","+$('#clinicint').val());
      
      
          $.ajax({
           dataType: 'json',
           type: 'GET',
           url: '/ajaxdetaildoctor/' + idc,
           success: function(result) {
               var u = JSON.parse(JSON.stringify(result[0]));
               var day = $('#vsetid').val();
               var arr = new Date();
               if(result === 'U'){
   
                  $('#formpilih').show();
                  $('.datau').hide();
                  $(".datau").attr("disabled", false);
                  $('#datetimeappointment').datetimepicker({
                  
                     format: "DD-MMM-YYYY",
                   //locale: "en-au",
                   minDate: arr,
                   ignoreReadonly: true
   
   
               });
                 
               }else if(result[1] === 'G'){
   
                  // $('#formpilih').show();
                  // $('.datau').hide();
                  // $(".datau").attr("disabled", false);
                  $('#datetimeappointment').datetimepicker({
                  
                     format: "DD-MMM-YYYY",
                   //locale: "en-au",
                   minDate: arr,
                   <?php if(Session::get('typeuser') === 'E'){ ?>
                   maxDate: moment().add(day, 'day'),
                   <?php } ?>
                   useCurrent: false,
                   daysOfWeekDisabled: u,
                   ignoreReadonly: true
   
               });
               }else if(result[1] === 'S'){

                  $('#datetimeappointment').datetimepicker({
                  
                     format: "DD-MMM-YYYY",
                   //locale: "en-au",
                   minDate: arr,
                   <?php if(Session::get('typeuser') === 'E'){ ?>
                   maxDate: moment().add(day, 'day'),
                   <?php } ?>
                   useCurrent: false,
                   daysOfWeekDisabled: u,
                   ignoreReadonly: true
                  });
                
                
   
               }
               
           }
       });
      
          $('#datetimeappointment').on("change.datetimepicker", function(e) {
              date = $(this).datetimepicker('viewDate');
              var dt = moment(date).format('dddd');
              var m = moment(date).format('Y-MM-DD');
              var id = $('#id').val() +','+ $('#clinicint').val() ;
              var data = btoa(dt + ',' + id + ',' + m);

              $.ajax({
                  dataType: 'json',
                  type: 'GET',
                  url: '/ajaxtime/' + data,
                  success: function(result) {
                      var html = '';
                      var i;
                      for (i = 0; i < result.length; i++) {
      
                          html += result[i];
                      }
                      $('#timedata').html(html);
                      $('#formpilih').show();
                  }
              });
          });
      
          $("input#checkbox").click(function() {
             
              if ($(this).is(":checked")) {
                  $("#familyt").attr("disabled", false);

                  $idw = btoa($("#vsuir").val());
                  $.ajax({
                      dataType: 'json',
                      type: 'GET',
                      url: '/ajaxfamily/' + $idw,
                      success: function(result) {
                        $("#fullname").val(result.data.VNAME);

                       $("#country").val(result.data.VCITYBIRTH);
                       $("#tlp").val(result.data.VPHONENO);
                       $("#dateofbirth").val(result.data.DBIRTH);
                        var html = "";
                           var i;
                           html += "<option>---</option>";
                           html += result.array;
                     
                          $("#familyt").html(html);
                      }
                  });
              } else {

                  $("#familyt").attr("disabled", true);
                  $("#fullname").val("{{$user->VNAME}}");
                  $("#country").val("{{$user->VCITYBIRTH}}");
                  $("#tlp").val("{{$user->VPHONENO }}");
                  $("#dateofbirth").val("{{$user->DBIRTH }}");
              }
          });
          $("#familyt").change(function() {
                  var idr = btoa($(this).val());
                  $.ajax({
                     dataType: "json",
                     type: "GET",
                     url: "/ajaxmember/" + idr,
                     success: function(result) {
                    
                          $("#fullname").val(result.fullname);
         
                          $("#country").val(result.city);
                          
                          $("#dateofbirth").datetimepicker("date", moment(result.date, "DD/MMM/YYYY"));
                         
                     
                      }
             
                     
                     });
               });
      });
      
      
                     
   </script>
   @endif
   

</section>
<script>
   var id = btoa($('#id').val());
   
   
   $("#hidden-setting").hide();
   $('#formpilih').hide();
   $(document).ready(function() {
      $(document).on("submit", "[id^=formbooking]", function (e) {
       e.preventDefault();
       var url = $(this).data("url");
       $.ajax({
               url: url,
               type: "POST",
               headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
               dataType: "JSON",
               data: $("#formbooking").serialize(),
               beforeSend: function() {
                     swal.fire({
                           html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
                           allowOutsideClick: false,
                           showCancelButton: false,
                           showConfirmButton: false,
                     });
                  },
               success: function(data){
                  swal.close();
                $mrn = "MR NO : "+data.MRN;
                $quequ = "Queue No."+data.QUEQU;
                $praktek = "Praktek "+data.doctor;
                $setting = data.setting;
                $('#mrnno').html($mrn);
                $('#QUEQU').html($quequ);
                $('#doctor').html($praktek);
                $('#dvisit').html(data.dvisit);
                $('#setting').html($setting);
   
                
               $('#popupbanking').modal({backdrop: "static"},'show');
            }, error: function(error){
               Swal.fire({
                   
                     text: 'Incomplete Patient Data, Please contact your administrator',
                     icon: 'error',
                     confirmButtonText: 'OK'
               })
   
          }
       }); 
       return false;
      });
     
   });
</script>
@endsection