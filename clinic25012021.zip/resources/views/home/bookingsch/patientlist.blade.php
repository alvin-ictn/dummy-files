@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                        <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                        <li class="breadcrumb-item active">Patient List</li>
                    </ol>
                </div>
            </div>
        </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
                <div class="card-header card-color">
                    <h3 class="card-title text-white">
                        Patient List
                    </h3>
               </div>
               <div class="card-header">
                  <h3 class="row card-title">
                     <form action="/account/patientlist/export_excel" method="POST">
                           @csrf
                           <input type="hidden" value="" name="start_date" id="start_date">
                           <input type="hidden" value="" name="end_date" id="end_date">
                           <input type="hidden" value="" name="no" id="no">
                           <input type="hidden" value="" name="mrno" id="mrno">
                           <input type="hidden" value="" name="patientname" id="patientname">
                           <input type="hidden" value="" name="datebirth" id="datebirth">
                           <input type="hidden" value="" name="gender" id="gender">
                           <input type="hidden" value="" name="lvdate" id="lvdate">
                           <input type="hidden" value="" name="phoneno" id="phoneno">
                           <input type="hidden" value="" name="doctor" id="doctor">
                           <input id="search" type="hidden" name="search">
                     
                           <button class="btn btn-sz btn-primary" type="submit">Export to Excel</button>
                     </form>
                  </h3>
               </div>
               <div class="card-body">
                  <div class="form-group">
                     <div class="form-group row">
                        <label class="col-form-label control-label col-sm-1">Date from</label>
                        <div class="col-sm-4">
                           <div class="input-group date" id="DFROM" data-target-input="nearest">
                              <input value="{{Carbon\Carbon::now()->startofMonth()->format('d-M-Y')}}" type="text" class="form-control datetimepicker-input" name="DFROM" data-target="#DFROM" placeholder="DD-MMM-YYYY" required>
                              <div class="input-group-append" data-target="#DFROM" data-toggle="datetimepicker">
                                 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                              </div>
                           </div>
                        </div>
                        <label class="col-form-label control-label col-sm-1">to</label>
                        <div class="form-group col-sm-4">
                           <div class="input-group date" id="DTO" data-target-input="nearest">
                              <input value="{{Carbon\Carbon::now()->endOfMonth()->format('d-M-Y')}}" type="text" class="form-control datetimepicker-input" name="DTO" data-target="#DTO" placeholder="DD-MMM-YYYY" required>
                              <div class="input-group-append" data-target="#DTO" data-toggle="datetimepicker">
                                 <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                              </div>
                           </div>
                        </div>
                        <div class="col-lg-2 col-sm-12">
                           <div class="form-group">
                              <button class="btn btn-sz btn-primary" onclick="return LoadTable();" role="button" style="color:white;">Search</button>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  @if ($errors->any())
                  <div class="alert alert-danger">
                     <ul>
                        @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                        @endforeach
                     </ul>
                  </div>
                  @endif
                  <div class="table-responsive">
                     <table id="cmpatientlist" class="table table-bordered table-striped display compact nowrap" style="width:100%">
                        <thead>
                           <tr>
                              <th>No</th>
                              <th>Action</th>
                              <th>MR No</th>
                              <th>Patient Name</th>
                              <th>Date of Birth</th>
                              <th>Gender</th>
                              <th>Last Visit Date</th>
                              <th>Phone No</th>
                              <th>Doctor</th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<style>
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::after{display: none}
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::before{display: none}
</style>

<script>
	$(document).ready(function() {
      $('#DFROM, #DTO').datetimepicker({
         format: 'DD-MMM-YYYY',
      });

   });
   
	$(document).ready(function() {
      //====Main table
      LoadTable();    
      $('#cmpatientlist thead tr').clone(true).appendTo( '#cmpatientlist thead' );
      $('#cmpatientlist thead tr:eq(1) th').each( function (i) {
         var title = $(this).text();
         
         if (title === "No"){
             $(this).html( '<input type="text" class="input-sm no" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Action"){
            $(this).html( '<input type="text" class="input-sm action" placeholder="Search ' + title + '" />' );
         }
         else if (title === "MR No"){
            $(this).html( '<input type="text" class="input-sm mrno" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Patient Name"){
            $(this).html( '<input type="text" class="input-sm patientname" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Date of Birth"){
            $(this).html( '<input type="date" class="input-sm datebirth" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Gender"){
            $(this).html( '<input type="text" class="input-sm gender" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Last Visit Date"){
            $(this).html( '<input type="date" class="input-sm lvdate" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Phone No"){
            $(this).html( '<input type="text" class="input-sm phoneno" placeholder="Search ' + title + '" />' );
         }
         else if (title === "Doctor"){
            $(this).html( '<input type="text" class="input-sm doctor" placeholder="Search ' + title + '" />' );
         }
      
         $( 'input', this ).on( 'keyup change', function () {
              if ( tablepatientlist.column(i).search() !== this.value ) {
                  tablepatientlist
                      .column(i)
                      .search( this.value )
                      .draw();

                      var no = $('.no').val();
                      var mrno = $('.mrno').val();
                      var patientname = $('.patientname').val();
                      var datebirth = $('.datebirth').val();
                      var gender = $('.gender').val();
                      var lvdate = $('.lvdate').val();
                      var phoneno = $('.phoneno').val();
                      var doctor = $('.doctor').val();

                      $('#no').val(no);
                      $('#mrno').val(mrno);
                      $('#patientname').val(patientname);
                      $('#datebirth').val(datebirth);
                      $('#gender').val(gender);
                      $('#lvdate').val(lvdate);
                      $('#phoneno').val(phoneno);
                      $('#doctor').val(doctor);
            }
         });
      });
    tablepatientlist.columns().every(function (index) {
        $('#cmpatientlist thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
            tablepatientlist.column($(this).parent().index() + ':visible')
               .search(this.value)
               .draw();
        });
      });
   });

   //==== Load the main table
   function LoadTable()
   {
      tablepatientlist = $("#cmpatientlist").DataTable({
        destroy: true,
        processing: true,
        serverSide: true,
        //order: [],
        dom: '<lf<t><r>ip>',
        ajax: {
            url: '/ajaxpatientlist',
            type: "GET",
            data: function (d) {
                d.datebirth = $('.datebirth').val(),
                d.lvdate = $('.lvdate').val(),
                d.search = $('input[type="search"]').val(),
                d.DFROM = $('input[name="DFROM"]').val(), 
                d.DTO = $('input[name="DTO"]').val()
            },
        },
        columns: [
            {
                data: "no",
                name: "no",
            },
            {
                data: "ADMIN_ACTION",
                name: "ADMIN_ACTION",
            },
            {
                data: "action",
                name: "action",
                render: function(data, type, row){
                    if(data != null) return "<a href='/account/booking/patientinfo/"+ btoa(row.VBOOKINGNO + "#ptntlst") + "'>" + row.VMRNO + "</a>";
                    else return row.VMRNO;
                },
            },
            {
                data: "VNAME",
                name: "VNAME",
            },
            {
                data: "DBIRTH",
                name: "dbirth",
                searchable: false,
            },
            {
                data: "GENDER",
                name: "GENDER",
            },
            {
                data: "LASTVISITDATE",
                name: "lastvisitdate",
                searchable: false,
            },
            {
                data: "VPHONENO",
                name: "VPHONENO",
            },
            {
                data: "DOCTOR",
                name: "DOCTOR",
            }
        ],
    });
		$('input[name="start_date"]').val($('input[name="DFROM"]').val());
		$('input[name="end_date"]').val($('input[name="DTO"]').val());
   }

   
</script>
@endsection