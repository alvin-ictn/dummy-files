@extends('layout.app')
@section('content')
      <audio id="suarabel" src="/audio/Airport_Bell.mp3"></audio>
		<audio id="suarabelnomorurut" src="/audio/nomor-urut.wav"  ></audio> 
		<audio id="suarabelsuarabelloket" src="/audio/loket.wav"  ></audio> 
       
		<audio id="belas" src="/audio/belas.wav"  ></audio> 
		<audio id="sebelas" src="/audio/sebelas.wav"  ></audio> 
        <audio id="puluh" src="/audio/puluh.wav"  ></audio> 
        <audio id="sepuluh" src="/audio/sepuluh.wav"  ></audio> 
        <audio id="ratus" src="/audio/ratus.wav"  ></audio> 
        <audio id="seratus" src="/audio/seratus.wav"  ></audio> 
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Booking Schedule</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                  @if(session::get('typeuser') === "E")
                     Booking Schedule
                  @else
                     Patient Queue
                  @endif   
                  </h3>
               </div>
               <div class="card-header">
               <div class="form-group">
 
                  </div>
                  <h3 class="card-title">
                  @if( Session::get('typeuser') === "E")
                     <a class="btn btn-sz btn-primary" href="booking/add" role="button">Add New</a>
                  @else
                  <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('C', 'F01')) { ?>

         
                     <a class="btn btn-sz btn-primary" href="booking/add" role="button">Add New</a>

                     <?php }  ?>
                     @endif
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
               @if ($errors->any())
                  <div class="alert alert-danger">
                      <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div>
               @endif
                  <div class="table-responsive">
                     <table id="cmbooking" class="table table-bordered table-striped display compact nowrap"  style="width:100%">
                        <thead>
                           <tr>
                              <th scope="col-1">Action</th>
                              <th scope="col-1">Visit Date</th>
                              <th scope="col-1">Doctor</th>
                              <th scope="col-1">Queue No.</th>
                              <th scope="col-1">MR No.</th>
                              <th scope="col-1">Patient Name</th>
                              <th scope="col-1">Date Of Birth</th>
                              <th scope="col-1">Category</th>
                              <th scope="col-1">Status</th>
                           </tr>
                        </thead>
                        <tbody>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<style>
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::after{display: none}
     .dataTable > thead > tr:nth-child(2) [class*="sort"]::before{display: none}
</style>
<script>
   $(document).ready(function(){
	$("#play").click(function(){
		document.getElementById('suarabel').play();		
	});
	
	
});
$(document).ready(function(){
   LoadTable();
   $('#cmbooking thead tr').clone(true).appendTo( '#cmbooking thead' );
   $('#cmbooking thead tr:eq(1) th').each( function (i) {
    
       var title = $(this).text();
       if(title === "Date Of Birth"){

        $(this).html( '<input type="date" class="input-sm" pattern="\d{4}-\d{2}-\d{2}" placeholder="Search '+title+'" />' );

       }
       else if(title === "Visit Date"){

        $(this).html( '<input type="date" class="input-sm" pattern="\d{4}-\d{2}-\d{2}" placeholder="Search '+title+'" />' );

       }
       else{
        $(this).html( '<input type="text" class="input-sm" placeholder="Search '+title+'" />' );

       }

       //???? tablemedical?
       $( 'input', this ).on( 'keyup change', function () {
           if ( tablebooking.column(i).search() !== this.value ) {
            tablebooking
                   .column(i)
                   .search( this.value )
                   .draw();
           }
       });
       $('.datepicker').datepicker({
        locale: moment().local('en'),
       })
    });
 
   $('#DFROM, #DTO').datetimepicker({
         format: 'DD-MMM-YYYY',
      });
   $(document).on("submit", "[class^=btncancel]", function (e) {
    var url = $(this).data("url");
      var id = $(this).data("id");
    e.preventDefault();
    swal.fire({
        text: "Are you sure to process data ?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        showLoaderOnConfirm: true,
        preConfirm: function () {
            return new Promise(function (resolve, reject) {
                // here should be AJAX request
                setTimeout(function () {
                    resolve();
                }, 1000);
            });
        },
    }).then(function (result) {
        if (result.value) {
            // handle confirm
            $.ajax({
                url: url +'/'+id ,
                type: "GET",
                headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
                dataType: "JSON",
                data: $("#form-edit").serialize(),
                success: function (data) {
                  
                  window.location.href = "bookingsm";

                },
            });
        } else {
            // handle cancel
            
        }
    });
    return false;
});
});

function mulai(id){
   var bel = id;
   //MAINKAN SUARA BEL PADA SAAT AWAL
	document.getElementById('suarabel').pause();
	document.getElementById('suarabel').currentTime=0;
   document.getElementById('suarabel').play();
   	//SET DELAY UNTUK MEMAINKAN REKAMAN NOMOR URUT		
	totalwaktu=document.getElementById('suarabel').duration*1000;	
  


	//MAINKAN SUARA NOMOR URUT		
	setTimeout(function() {
			document.getElementById('suarabelnomorurut').pause();
			document.getElementById('suarabelnomorurut').currentTime=0;
         document.getElementById('suarabelnomorurut').play();
         
	}, totalwaktu);
	totalwaktu=totalwaktu+1000;
	
		if(bel<10){

			
			setTimeout(function() {
            
            document.getElementById('suarabel'+bel).pause();
				   document.getElementById('suarabel'+bel).currentTime=0;
					document.getElementById('suarabel'+bel).play();
  

					
		},totalwaktu);
			
			totalwaktu=totalwaktu+1000;
	
		    }else if(bel ==10){
			//JIKA 10 MAKA MAIKAN SUARA SEPULUH
 
				setTimeout(function() {
						document.getElementById('sepuluh').pause();
						document.getElementById('sepuluh').currentTime=0;
						document.getElementById('sepuluh').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
	
			}else if(bel ==11){
				//JIKA 11 MAKA MAIKAN SUARA SEBELAS
  
				setTimeout(function() {
						document.getElementById('sebelas').pause();
						document.getElementById('sebelas').currentTime=0;
						document.getElementById('sebelas').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;

			}else if(bel < 20){
		
				setTimeout(function() {
						document.getElementById('suarabel1').pause();
						document.getElementById('suarabel1').currentTime=0;
						document.getElementById('suarabel1').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('belas').pause();
						document.getElementById('belas').currentTime=0;
						document.getElementById('belas').play();
					}, totalwaktu);
            totalwaktu=totalwaktu+1000;
            
			}else if(bel < 100){				
				//JIKA PULUHAN MAKA MAINKAN SUARA ANGKA1+PULUH+AKNGKA2

				setTimeout(function() {
                  document.getElementById('suarabel'+String(bel).substr(0,1)).pause();
						document.getElementById('suarabel'+String(bel).substr(0,1)).currentTime=0;
						document.getElementById('suarabel'+String(bel).substr(0,1)).play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('puluh').pause();
						document.getElementById('puluh').currentTime=0;
						document.getElementById('puluh').play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				setTimeout(function() {
						document.getElementById('suarabel'+String(bel).substr(1,2)).pause();
						document.getElementById('suarabel'+String(bel).substr(1,2)).currentTime=0;
						document.getElementById('suarabel'+String(bel).substr(1,2)).play();
					}, totalwaktu);
				totalwaktu=totalwaktu+1000;
				

			}else{
				//JIKA LEBIH DARI 100 
				//Karena aplikasi ini masih sederhana maka logina konversi hanya sampai 100
				//Selebihnya akan langsung disebutkan angkanya saja 
            //tanpa kata "RATUS", "PULUH", maupun "BELAS"
         }
      // ?>
      $('.btn-disabled').attr("disabled", "disabled")
    
          setTimeout(function(){ 
            
            $('.btn-disabled').removeAttr("disabled");
            
            
         },totalwaktu+3000);
        
}

   //==== Load the main table
   function LoadTable()
   {
      tablebooking  = $("#cmbooking").DataTable({
         destroy: true,
        processing: true,
        serverSide: true,
        order :  [1, "desc" ],
        dom: '<lf<t><r>ip>',
        columnDefs: [
            { "width": "5%", "className": "text-center", "targets": 0},
            {"targets":0, "type":"date-eu"}
        ],
        ajax: {
            url: '/ajaxbookings',
            type: "GET",
            data: function (d) {
                d.datebirth = $('.datebirth').val(),
                d.lvdate = $('.lvdate').val(),
                d.search = $('input[type="search"]').val()
            },
            data: {
               'DFROM': $('input[name="DFROM"]').val(), 
               'DTO': $('input[name="DTO"]').val()
            },
        },
        columns: [
            {
                data: "action",
                name: "action",
                
            },
            {
                data: "visitdates",
                name: "visitdate",
                orderable: true,
            },
            {
                data: "Doctor",
                name: "Doctor",
            },
            {
                data: "QueueNo",
                name: "QueueNo",
            },
            {
                data: "MRNOA",
                name: "MRNOA",
            },
            {
                data: "PatienName",
                name: "PatienName",
            },
            {
                data: "DBIRTH",
                name: "DBIRTH",
            },
            {
                data: "GROUP",
                name: "GROUP",
            },
            {
                data: "BSTATUS",
                name: "BSTATUS",
            }
           
            
        ],
    });
      //  $('#cmbooking thead tr').clone(true).appendTo( '#cmbooking thead' );
   }
</script>



@endsection