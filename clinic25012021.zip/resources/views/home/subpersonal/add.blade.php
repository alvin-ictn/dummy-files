@extends('layout.app')
@section('content')
<section class="content">
   <section class="content-header">
      <div class="container-fluid">
         <div class="row mb-2">
            <div class="col-sm-6" style="margin-top: -10px; padding-left: 25px; "></div>
            <div class="col-sm-6">
               <ol class="breadcrumb float-sm-right" style="margin-top: -10px;">
                  <li class="breadcrumb-item"><a href="/account/home">Home</a></li>
                  <li class="breadcrumb-item active">Add Sub Personnel Area</li>
               </ol>
            </div>
         </div>
      </div>
      <!-- /.container-fluid -->
   </section>
   <div class="container-fluid">
      <div class="row">
         <div class="col-12">
            <div class="card">
               <div class="card-header card-color">
                  <h3 class="card-title text-white">
                     Add New Data
                  </h3>
               </div>
               <!-- /.card-header -->
               <div class="card-body">
                  <form  method="POST" data-url="/addsubpersonel/insert" id="form-confirm">
                     @csrf
                     <div class="form-body">
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Sub Personnel Code</label>
                              <div class="col-sm-4">
                                 <input name="subcode" id="subcode" placeholder="Sub Personnel Code" class="form-control" type="text" maxlength="20" required>
                                 <span class="help-block"></span>
                                 <div class="invalid-feedback" id="exists"></div>
                              </div>
                              <label for="example-text-input" class="req col-form-label col-sm-2">Personnel Area</label>
                              <div class="col-sm-4">
                                 <div class="input-group">
                                    <input name="personcode" placeholder="Personnel Area" class="form-control" type="text" readonly>
                                    <input name="VPRSNLAREACODE" class="form-control" type="hidden" readonly>
                                    <div class="input-group-append" style="cursor: pointer;" data-toggle="modal" data-target="#myPersoncode">
                                       <div class="input-group-text"><i class="fa fa-search"></i></div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <div class="form-group row required">
                              <label for="example-text-input" class="req col-form-label col-sm-2">Sub Personnel Name</label>
                              <div class="col-sm-4">
                                 <input name="subname" placeholder="Sub Personnel Name" class="form-control" type="text" maxlength="50" required>
                                 <span class="help-block"></span>
                              </div>
                           </div>
                        </div>
                        <div class="form-group row">
                           <div class="col-md-12">
                              <div class="float-right">
                                 <button id="startDiv" type="submit" class="btn-cstm btn-primary btn-sz">Save</button>
                                 <a href="/account/subpersonel" class="btn btn-cstm btn-light btn-sz">Close</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade in" id="myPersoncode" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-lg modal-content">
            <div class="card mb-4">
               <div class="card-header bg-info">
                  <h5 class="card-title text-white" align="center">Personnel Code List</h5>
                  <button type="button" class="close text-white" data-dismiss="modal">×</button>
               </div>
               <div class="card-body p-3">
                  <div id="dvData" class="table-responsive">
                     <table id="tblcode" class="display" style="width:100%">
                        <thead>
                           <tr>
                              <th>
                                 Personnel Code
                              </th>
                              <th>
                                 Personnel Name
                              </th>
                           </tr>
                        </thead>
                     </table>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<script>
   $(document).ready(function() {
		var table = $("#tblcode").DataTable({ pagingType: $(window).width() < 768 ? "simple" : "simple_numbers", ajax: { url: '/getcodelookup', type: "GET", }, columns: [ { data: "VPRSNLAREACODE", name: "VPRSNLAREACODE" }, { data: "VPRSNLNAME", name: "VPRSNLNAME" } ] });
   	$('#tblcode tbody').on('dblclick', 'tr', function () {
   		var data = table.row(this).data();
   		$('input[name="personcode"]').val(data['VPRSNLAREACODE'] + ' - ' + data['VPRSNLNAME']);
   		$('input[name="VPRSNLAREACODE"]').val(data['VPRSNLAREACODE']);
         $(this).closest('.card').find('button').trigger('click');
         CheckSubPrsnlCodeExists(); // Sub Personnel Area Code Check
   	});

      $("#subcode").keyup(function() {
         CheckSubPrsnlCodeExists(); // Sub Personnel Area Code Check
      });

   });

   //==== Check if current inputted Sub Personnel Area Code is already exists for current inputted Personnel Area
   function CheckSubPrsnlCodeExists()
   {
      if($('#subcode').val() == '' || $('input[name="VPRSNLAREACODE"]').val() == '') return;
      var sub_prsnl_code = $('#subcode').val();
      var prsnl_code = $('input[name="VPRSNLAREACODE"]').val();
      var base = btoa(sub_prsnl_code + ',' + prsnl_code);
      $.ajax({
         dataType: "json",
         type: "GET",
         url: "/getajaxsubpersonnel/" + base,
         success: function(result) {
            if(result.data === 'exists'){
               $('#exists').html('Sub Personnel Area Code already in use for this Personnel Area!');
               $('#subcode').addClass("is-invalid");
            }else{
               $('#exists').html('');
               $('#subcode').removeClass("is-invalid");
            }
         }
      });
   }

</script>
@endsection