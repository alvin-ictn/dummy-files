<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo Request::ip(); ?></title>
        <meta name="csrf-token" content="{{ csrf_token() }}" />

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <script src="{{ asset('js/app.js') }}" defer></script>
    	<script src="{{ asset('js/jquery.js') }}"></script>

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
    @yield('content')
    <div id="return"></div>
    </body>
    <script src="{{ asset('js/adminlte.js') }}" defer></script>
<script src="{{ asset('js/demo.js') }}" defer></script>
<script src="{{ asset('js/jquery-ui.js') }}" defer></script>
<script src="{{ asset('plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>
<script>

    $(document).on("submit", "[id^=form-login]", function (e) {
     e.preventDefault();

        $.ajax({
            url: "{{ route('login') }}",
            type: "POST",
            headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
            dataType: "JSON",
            data: $("#form-login").serialize(),
            success: function (data) {
               if(data.null === "NULL"){
                $("#modallogin").modal("show");
                $('[name="id"]').val(data.id);
               }else if(data.null === "AD"){

                window.location.href = "backend/home";

               }else if(data.null === "NAD"){
                window.location.href = "backend/home";

                // $("#myDiv").append("<div class='form-group row'>" +
                //      "<label for='password' class='col-md-4 col-form-label text-md-right'>{{ __('Password') }}</label>"+
                //      "<div class='col-md-6'>"+
                //         "<input id='konfirmasi' type='password' class='form-control @error('password') is-invalid @enderror' name='currentpass'  autocomplete='current-password'>"+
                //         "@error('password')"+
                //         "<span class='invalid-feedback' role='alert'>"+
                //         "<strong>{{ $message }}</strong>"+
                //         "</span>"+
                //         "@enderror"+
                //      "</div>"+
                //   "</div>");
                // $("#buttons").hide();
                // $("#buttonconfirm").show();

               }else if(data.null === "NADS"){


               }
               else if(data.null === "PW"){

                Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: data.pesan,
                    });

               }
            },
        });

    });
    $(document).on("submit", "[id^=form-type]", function (e) {
    e.preventDefault();
    swal.fire({
        title: "Are you sure?",
        text: "do you want to update the data ??",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes, Update it!",
        cancelButtonText: "No, cancel pls!",
    }).then(function (result) {
        if (result.value) {
            // handle confirm
            $.ajax({
                url: "login/updatetype",
                type: "POST",
                headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
                dataType: "JSON",
                data: $("#form-type").serialize(),
                success: function (data) {
                    Swal.fire({
                        title: 'Success !',
                        text: 'data update successfully',
                        icon: 'success',
                    })
                    location.reload();
                },
                error: function (errormessage) {
                    //do something else
                    swal.fire("Sending Failed!", "User code cannot be the same");
                },
            });
        } else {
            // handle cancel
            location.reload();
        }
    });
    return false;
});
function Validate() {
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("konfirmasi").value;
    if (password != confirmPassword) {
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'The password must be the same!'
        });
        return false;
    }
    return true;
}


    </script>
</html>
