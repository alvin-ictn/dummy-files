<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>CMS Clinic</title>
	<!-- Fonts -->
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <link rel="stylesheet" href="{{ mix('css/backend.css') }}">

    <script src="{{ asset('js/jquery.js') }}"></script>
    <script src="{{ asset('plugins/Readmore/readmore.js') }}" ></script>
    <script src="{{ asset('js/cbpFWTabs.js') }}" ></script>
    <script src="{{ asset('js/print.min.js') }}" ></script>

    <script type="module" src="{{ asset('plugins/tempusdominus/js/tempusdominus-bootstrap-4.js') }}"></script>
    <script  src="{{ asset('plugins/select2/js/select2.js') }}"></script>
    <script  type="text/javascript" src="{{ asset('plugins/ckeditor/ckeditor.js') }}"></script>

	<!-- Styles -->
    <style>
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
     -webkit-appearance: none;
     margin: 0;
    }

    /* Firefox */
    input[type=number] {
        -moz-appearance: textfield;
    } 
     .card-color{
        background-color : #0062cc;
    }
        #loader { 
            border: 12px solid #f3f3f3; 
            border-radius: 50%; 
            border-top: 12px solid #444444; 
            width: 70px; 
            height: 70px; 
            animation: spin 1s linear infinite; 
        } 
          
        @keyframes spin { 
            100% { 
                transform: rotate(360deg); 
            } 
        } 
          
        .center { 
            position: absolute; 
            top: 0; 
            bottom: 0; 
            left: 0; 
            right: 0; 
            margin: auto; 
        } 
    </style> 
</head>

<body class="sidebar-mini sidebar-collapse">

<div id="loader" class="center"></div> 

	<div class="wrapper">
		<!-- Navbar -->
		<nav class="main-header navbar navbar-expand navbar-white navbar-light">
			<!-- Left navbar links -->
			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="fas fa-bars nav-link" data-widget="pushmenu" href="#" role="button">
					</a>
				</li>
				<li class="nav-item"><a href="/account/home" class="fa fa-home nav-link"></a>
				</li>
			</ul>
			<ul class="navbar-nav ml-auto">
				<li class="nav-item"> <a class="icon nav-link" aria-hidden="true" href="{{ url('/logout') }}">&nbsp;Logout</a>
				</li>
			</ul>
		</nav>
		<!-- /.navbar -->
		<!-- Main Sidebar Container -->
		<aside class="main-sidebar sidebar-dark-primary elevation-4">
			<!-- Brand Logo -->
            <a href="/account/home" class="brand-link">	
                <img src="\img\Medical Logo Template.jpg" alt="Logo" class="brand-image gambar"
                    style=" margin-left: 18px; margin-top: 3px;"><br>
            </a>
			<!-- Sidebar user panel (optional) -->
			<div class="nav-link blackline col-12 mt-3 pb-3 mb-3 d-flex">
				<div class="image">
					<img src="\img\user-male-circle.png"style=" margin-left: 10px; margin-top: 0px;" class="img-circle elevation-2" alt="User Image">
				</div>
				<div class="nav-link col-12">
                    <a href="{{ Session::get('typeuser') == NULL ? '#' : '/account/myprofile' }}" style="color:white;" class="font-sidebar">{{ Session::get('nameuser') }}</a>
                    <br>
                    <p style="color:white;" class="font-sidebar">{{ Session::get('clinicname') }}</p>				
                </div>
			</div>
			<!-- Sidebar -->
			<div class="sidebar">
				<!-- Sidebar Menu -->
				<nav class="mt-2">
					<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
						<!-- Add icons to the links using the .nav-icon class
                     with font-awesome or any other icon font library -->
                        <!-- @if( Session::get('groupuser') === "USR")
                        <li class="nav-item">
							<a href="/account/bookingsm" class="nav-link">
								<p>Booking Schedule MCU <i class="right fas fa-angle-left"></i></p>
							</a>
							<ul class="nav nav-treeview">
								<li class="nav-item">
									<a href="/account/employeed" class="nav-link">
										<p class="font-sidebar" style="margin-left: 10px;">Employeed</p>
									</a>
								</li>
							</ul>
						</li>
                        @else -->
                        <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F01', 'F02', 'F03', 'F04', 'F05', 'F06', 'F07')) { ?>
                            <li class="nav-item">
                                <a href="/account/bookingsm"style=" margin-left: 10px; margin-top: 0px;" class="nav-link">
                                    <i class="nav-icon far fa-calendar-alt"></i>
                                    <p class="font-sidebar">
                                        @if(session::get('typeuser') === "E")
                                            Booking Schedule
                                        @else
                                            Patient Queue
                                        @endif
                                    </p>
                                </a>
                            </li>
                        <?php } ?>
                        <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F27', 'F28', 'F29', 'F30', 'F31', 'F32')) { ?>
                            <li class="nav-item">
                                <a href="/account/booking/patientlist/"style=" margin-left: 10px; margin-top: 0px;" class="nav-link">
                                    <i class="nav-icon far fa-calendar-alt"></i>
                                    <p class="font-sidebar">
                                        Patient List
                                    </p>
                                </a>
                            </li>
                        <?php } ?>
                        <!-- @if(session('groupuser')[0] == 'ADM')
                        <li class="nav-item">
                            <a href="/account/booking/patientlist/"style=" margin-left: 10px; margin-top: 0px;" class="nav-link">
                                <i class="nav-icon far fa-calendar-alt"></i>
                                <p class="font-sidebar">
                                    Patient List
                                </p>
                            </a>
                        </li>
                        @else
                        <li class="nav-item">
                            <a href="/account/bookingsm"style=" margin-left: 10px; margin-top: 0px;" class="nav-link">
                                <i class="nav-icon far fa-calendar-alt"></i>
                                <p class="font-sidebar">
                                    @if(session::get('typeuser') === "E")
                                        Booking Schedule
                                    @else
                                        Patient Queue
                                    @endif
                                </p>
                            </a>
                            @if(session('groupuser')[0] == 'DCTR' || session('groupuser')[0] == 'HRADM' )
                            <li class="nav-item">
                                <a href="/account/booking/patientlist/"style=" margin-left: 10px; margin-top: 0px;" class="nav-link">
                                    <i class="nav-icon far fa-calendar-alt"></i>
                                    <p class="font-sidebar">
                                        Patient List
                                    </p>
                                </a>
                            </li>
                            @endif
                        </li>
                        @endif -->
                        <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F38')) { ?>
                            <li class="nav-item">
                                <a href="/account/payment"style=" margin-left: 10px; margin-top: 0px;" class="nav-link">
                                    <i class="nav-icon fas fa-credit-card"></i>
                                    <p class="font-sidebar">
                                        Close Booking
                                    </p>
                                </a>
                            </li>
                        <?php } ?>
                       
                        <!-- @endif -->
                        <?php if(App\Http\Controllers\RoleAccessController::MenuAccessCheck('M1')) { ?>
                            <li class="nav-item has-treeview">
                                <a href="#"style=" margin-left: 10px; margin-top: 0px;" class="nav-link">
                                    <i class="nav-icon fa fa-poll-h left"></i>
                                    <p class="font-sidebar">
                                        Master Data
                                        <i class="right fas fa-angle-left" style="margin-top: 5px; float: right;"></i>
                                    </p>
                                </a>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F08')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/clinic" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Clinic</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F39')) { ?>   <!--Function code not yet created-->
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/content" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Content</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F09')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/costcenter" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Cost Center</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F17')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/packages" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Packages</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F10')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/costcenterpackages" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Cost Center Packages</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F12')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/scheduledoctors" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Doctors Schedule</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F13')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/drugs" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Drugs</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F14')) { ?>
                                    <ul class="nav nav-treeview">
						    	    	<li class="nav-item">
						    	    		<a href="/account/general" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master General</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F40')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/icd" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master ICD</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F15')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/medical" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Medical Kits</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F41')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/mcu/schedule" class="nav-link">
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master MCU Schedule </p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F16')) { ?>
                                    <ul class="nav nav-treeview">
						    	    	<li class="nav-item">
						    	    		<a href="/account/setting" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Parameter</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F18')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/personel" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Personnel Area</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F22')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/subpersonel" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Sub Personnel Area</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F19')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/province" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Province</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F11')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/district" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master District</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F21')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/subdistrict" class="nav-link">
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Sub District</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>

                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F20')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/roleaccess" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Role Access</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F23')) { ?>
                                    <ul class="nav nav-treeview">
						    	    	<li class="nav-item">
						    	    		<a href="/account/users" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master Users</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F24')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/userclinic" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master User Clinic</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                                <ul class="nav nav-treeview">
                                    <!-- <li class="nav-item">
						    			<a href="/account/userlogs" class="nav-link"> 
						    				<p class="font-sidebar" style="margin-left: 10px;">Master User Logs</p>
						    			</a>
						    		</li> -->
						    	</ul>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F25')) { ?>
                                    <ul class="nav nav-treeview">
                                        <li class="nav-item">
						    	    		<a href="/account/userrole" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Master User Role</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
                                <?php } ?>
                            </li>
                        <?php } ?>

                        <?php if(App\Http\Controllers\RoleAccessController::MenuAccessCheck('M3')) { ?>
                            <li class="nav-item has-treeview">
                                <a href="#"style=" margin-left: 10px; margin-top: 0px;" class="nav-link">
                                    <i class="nav-icon fa fa-house-user left"></i>
                                    <p class="font-sidebar">
                                        Inventory
                                        <i class="right fas fa-angle-left" style="margin-top: 5px; float: right;"></i>
                                    </p>
                                </a>
						    	<?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F26')) { ?>
						    		<ul class="nav nav-treeview">
						    			<li class="nav-item">
						    				<a href="/account/inventory" class="nav-link"> 
						    					<p class="font-sidebar" style="margin-left: 10px;">Request List</p>
						    				</a>
						    			</li>
						    		</ul>
						    	<?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F35')) { ?>
                                    <ul class="nav nav-treeview">
						    	    	<li class="nav-item">
						    	    		<a href="/account/movementinquiry" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Movement Inquiry</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
						    	<?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F36')) { ?>
                                    <ul class="nav nav-treeview">
						    	    	<li class="nav-item">
						    	    		<a href="/account/balance" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Balance</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
						    	<?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F37')) { ?>
                                    <ul class="nav nav-treeview">
						    	    	<li class="nav-item">
						    	    		<a href="/account/movement" class="nav-link"> 
						    	    			<p class="font-sidebar" style="margin-left: 10px;">Movement</p>
						    	    		</a>
						    	    	</li>
						    	    </ul>
						    	<?php } ?>
                            </li>
                        <?php } ?>

                        <?php if(App\Http\Controllers\RoleAccessController::MenuAccessCheck('M8')) { ?>
                            <li class="nav-item has-treeview">
                                <a href="#"style=" margin-left: 10px; margin-top: 0px;" class="nav-link">
                                    <i class="nav-icon fa fa-book-medical left"></i>
                                    <p class="font-sidebar">
                                        MCU
                                        <i class="right fas fa-angle-left" style="margin-top: 5px; float: right;"></i>
                                    </p>
                                </a>
						    	<?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F33')) { ?>
						    		<ul class="nav nav-treeview">
						    			<li class="nav-item">
						    				<a href="/account/mcu" class="nav-link"> 
						    					<p class="font-sidebar" style="margin-left: 10px;">Registration List</p>
						    				</a>
						    			</li>
						    		</ul>
						    	<?php } ?>
						    	<?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F34')) { ?>
						    		<ul class="nav nav-treeview">
						    			<li class="nav-item">
						    				<a href="/account/resultmcu" class="nav-link"> 
						    					<p class="font-sidebar" style="margin-left: 10px;">Result MCU</p>
						    				</a>
						    			</li>
						    		</ul>
						    	<?php } ?>
                            </li>
                        <?php } ?>
                        <?php if(App\Http\Controllers\RoleAccessController::MenuAccessCheck('M5')) { ?>

                            <li class="nav-item has-treeview">
                                <a href="#"style=" margin-left: 10px; margin-top: 0px;" class="nav-link">
                                    <i class="nav-icon fa fa-clipboard left"></i>
                                    <p class="font-sidebar">
                                        Report
                                        <i class="right fas fa-angle-left" style="margin-top: 5px; float: right;"></i>
                                    </p>
                                </a>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F42')) { ?>

						    		<ul class="nav nav-treeview">
						    			<li class="nav-item">
						    				<a href="/account/reportkunjungan" class="nav-link"> 
						    					<p class="font-sidebar" style="margin-left: 10px;">Detail Visit Report</p>
						    				</a>
						    			</li>
                                <?php } ?>
                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F43')) { ?>

                                        <li class="nav-item">
						    				<a href="/account/reportdrugs" class="nav-link"> 
						    					<p class="font-sidebar" style="margin-left: 10px;">Drugs Movement Report</p>
						    				</a>
						    			</li>
                                <?php } ?>

                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F44')) { ?>

                                        <li class="nav-item">
						    				<a href="/account/reportMcus" class="nav-link"> 
						    					<p class="font-sidebar" style="margin-left: 10px;">MCU Report</p>
						    				</a>
						    			</li>
                                <?php } ?>

                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F45')) { ?>

                                        <li class="nav-item">
						    				<a href="/account/reportmcu" class="nav-link"> 
						    					<p class="font-sidebar" style="margin-left: 10px;">Dashboard MCU</p>
						    				</a>
						    			</li>
                                <?php } ?>

                                <?php if(App\Http\Controllers\RoleAccessController::FunctionAccessCheck('V', 'F46')) { ?>

                                        <li class="nav-item">
						    				<a href="/account/reportvisit" class="nav-link"> 
						    					<p class="font-sidebar" style="margin-left: 10px;">Dasboard Visit</p>
						    				</a>
						    			</li>
                                <?php } ?>

						    		</ul>
                            </li>  
                        <?php } ?>         
					</ul>
				</nav>
				<!-- /.sidebar-menu -->
			</div>
			<!-- /.sidebar -->
		</aside>
		<div class="content-wrapper">
        
        @yield('content')
        
        </div>
        <footer id="mainfoot" class="main-footer">
            <!-- To the right -->
            <div class="float-right d-none d-sm-inline">

            </div>
            <!-- Default to the left -->
            <strong>Copyright &copy; 2020 <a href="#">RAPP</a>.</strong> All rights reserved.
        </footer>

</body>
<script src="{{ asset('js/adminlte.js') }}" defer></script>
<script src="{{ asset('js/demo.js') }}" defer></script>
<script src="{{ asset('js/jquery-ui.js') }}" defer></script>
<script src="{{ asset('plugins/pdfmake/pdfmake.min.js') }}" ></script>
<script src="{{ asset('plugins/pdfmake/vfs_fonts.js') }}" ></script>

<script src="{{ asset('plugins/bootstrap/js/bootstrap.js') }}"></script>
<script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('plugins/datatables/dataTables.tableTools.js') }}"></script>

<script src="{{ asset('plugins/datatables-buttons/js/dataTables.buttons.min.js') }}"></script>

<script src="{{ asset('plugins/datatables/date-eu.js') }}"></script>
<script src="{{ asset('plugins/datatables/dataTables.select.min.js') }}"></script>
<script src="{{ asset('plugins/datatables-buttons/js/buttons.html5.js') }}" ></script>
<script src="{{ asset('plugins/datatables-buttons/js/buttons.bootstrap4.js') }}"></script>
<script src="{{ asset('plugins/datatables-buttons/js/buttons.print.min.js') }}"></script>
<script src="{{ asset('plugins/jszip/jszip.js') }}"></script>

<script src="{{ asset('js/custom-clinic.js') }}" ></script>
<script src="{{ asset('plugins/moment/moment.min.js') }}" ></script>
<script src="{{ asset('plugins/moment/moment-with-locales.js') }}" ></script>
<script src="{{ asset('plugins/sweetalert2/sweetalert2.js') }}"></script>
<script src="{{ asset('plugins/crypto/crypto.js') }}" ></script>

<script>
jQuery(function($) { // DOM ready

$('form').on('keydown', function(e) {
  if (e.which === 13 && !$(e.target).is('textarea')) {
    e.preventDefault();
    //console.log("ENTER-KEY PREVENTED ON NON-TEXTAREA ELEMENTS");
  }
});

});
    $(function () {
    
        $('#dateth').datetimepicker({
            format: 'MM/DD/YYYY'
        });
    });
    $(function () {
        $('#mdate').datetimepicker({
            format: 'MM/DD/YYYY'
        });
    });
    $(function () {
        $('#dates').datetimepicker({
            format: 'MM/DD/YYYY'
        });
    });
    $(function () {
        $('#dateh').datetimepicker({
            format: 'MM/DD/YYYY'
        });
    });
   
    document.onreadystatechange = function() { 
        if (document.readyState !== "complete") { 
            $('#startDiv').hide();
            $('#loadingDIv').show();
            document.querySelector( 
              "body").style.visibility = "hidden"; 
            document.querySelector( 
              "#loader").style.visibility = "visible"; 
        } else { 
            $('#startDiv').show();
            $('#loadingDIv').hide();
            document.querySelector( 
              "#loader").style.display = "none"; 
            document.querySelector( 
              "body").style.visibility = "visible"; 
        } 
    }; 
   (function () {
    "use strict";
    window.addEventListener(
        "load",
        function () {
            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.getElementsByClassName("needs-validation");
            // Loop over them and prevent submission
            var validation = Array.prototype.filter.call(forms, function (form) {
                form.addEventListener(
                    "submit",
                    function (event) {
                        if (form.checkValidity() === false) {
                            event.preventDefault();
                            event.stopPropagation();
                        }
                        form.classList.add("was-validated");
                    },
                    false
                );
            });
        },
        false
    );
})();

$(document).ready(function () {
    var tablesynch = $("#cmsynch").DataTable({
        pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
        processing: true,
        serverSide: true,
        searching: false,
        dom: 'lrtip',
        columnDefs: [
            { "width": "5%", "targets": 0 },
            { "width": "10%", "targets": 1 },
            { "width": "10%", "targets": 2 }
        ],
        ajax:{
               url: '/ajaxsynch',
               type: "GET"
			   
            },
        columns: [
			{
                data: "VCLINICNAME",
                name: "VCLINICNAME",
            },
			{
                data: "action",
                name: "action",
                orderable: false,
                className: 'dt-body-center'
                
            },
            {
                data: "DLASTSYNC",
                name: "DLASTSYNC",
            },
            
           ],
		createdRow: function (row, data) {
			$(row).css('background-color', data.COLOUR);
		}
	});


    var tableinventory = $("#cminventory").DataTable({
        pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
        processing: true,
        serverSide: true,
        dom: '<lf<t><r>ip>',
        columnDefs: [
            { "width": "5%", "targets": 0 },
            { "width": "10%", "targets": 2 }
        ],
        ajax:{
               url: '/ajaxinventory',
               type: "GET",
			   data: function (d) {
					d.date = $('.date').val(),
					d.search = $('input[type="search"]').val()
				}
            },
        columns: [
            {
                data: "no",
                name: "no",
            },
            {
                data: "action",
                name: "action",
				render: function (data, type, row) {
                    return "<a href='inventory/form/"+ btoa(data) +"'>" + data + "</a>"
				}
            },
            {
                data: "DREQ",
                name: "DREQ",
				searchable: false
            },
            {
                data: "VCLINICNAME",
                name: "VCLINICNAME",
            },
            {
                data: "BSTATUS",
                name: "BSTATUS",
            },
           ],
		createdRow: function (row, data) {
			$(row).css('background-color', data.COLOUR);
		}
	});
	
	$('#cminventory thead tr').clone(true).appendTo( '#cminventory thead' );
	
	$('#cminventory thead tr:eq(1) th').each( function (i) {
		var title = $(this).text();
		if (title === "Request Date") {
			$(this).html( '<input type="date" class="input-sm date" placeholder="Search '+title+'" />' );
		} else {
			$(this).html( '<input type="text" class="input-sm ' + title.toLowerCase().replace(" ", "_").replace(".", "") + '" placeholder="Search '+title+'" />' );
		}
		$( 'input', this ).on( 'keyup change', function () {
			if ( tableinventory.column(i).search() !== this.value ) {
				tableinventory
					.column(i)
					.search( this.value )
					.draw();
				$('input[name="' + $(this).attr('class').replace('input-sm ', '') + '"]').val($('.' + $(this).attr('class').replace('input-sm ', '')).val());
			}
		});
	});

	tableinventory.columns().every(function (index) {
		$('#cminventory thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
			tableinventory.column($(this).parent().index() + ':visible')
				.search(this.value)
				.draw();
		});
	});

    var tablemovement = $("#cmmovement").DataTable({
        pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
        processing: true,
        serverSide: true,
        dom: '<lf<t><r>ip>',
        columnDefs: [
            { "width": "5%", "targets": 0 }
        ],
        ajax:{
               url: '/ajaxmovement',
               type: "GET",
			   data: function (d) {
					d.date = $('.date').val(),
					d.search = $('input[type="search"]').val()
				}
            },
        columns: [
            {
                data: "no",
                name: "no",
            },
            {
                data: "DTRX",
                name: "DTRX",
				searchable: false
            },
            {
                data: "action",
                name: "action",
				render: function (data, type, row) {
                    return "<a href='movement/form/"+ btoa(data) +"'>" + data + "</a>"
				}
            },
            {
                data: "VREQNO",
                name: "VREQNO",
            }
           ]
	});
		
	$('#cmmovement thead tr').clone(true).appendTo( '#cmmovement thead' );
	
	$('#cmmovement thead tr:eq(1) th').each( function (i) {
		var title = $(this).text();
		if (title === "Date") {
			$(this).html( '<input type="date" class="input-sm date" placeholder="Search '+title+'" />' );
		} else {
			$(this).html( '<input type="text" class="input-sm ' + title.toLowerCase().replace(" ", "_").replace(".", "") + '" placeholder="Search '+title+'" />' );
		}
		$( 'input', this ).on( 'keyup change', function () {
			if ( tablemovement.column(i).search() !== this.value ) {
				tablemovement
					.column(i)
					.search( this.value )
					.draw();
				$('input[name="' + $(this).attr('class').replace('input-sm ', '') + '"]').val($('.' + $(this).attr('class').replace('input-sm ', '')).val());
			}
		});
	});

	tablemovement.columns().every(function (index) {
		$('#cmmovement thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
			tablemovement.column($(this).parent().index() + ':visible')
				.search(this.value)
				.draw();
		});
	});

        var tablemedical = $("#cmmedical").DataTable({
        pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
        processing: true,
        serverSide: true,
        dom: '<lf<t><r>ip>',
        columnDefs: [
            { "width": "5%", "targets": [0,4,5] },
            { "targets": 13, "className": "text-right"}
        ],
        ajax: {
            url: '/ajaxmedical',
            type: "GET",
            data: function (d) {
                d.purchase_date = $('.pd').val()
                d.submit_date = $('.sd').val()
                d.calibrate_date = $('.cd').val()
                d.date = $('.lastmo').val()
                d.search = $('input[type="search"]').val()
            },
        },
        columns: [
            {
                data: "no",
                name: "no",
            },
            {
                data: "action",
                name: "action",
                render:function(data, type, row){
                    if(data != null) return "<a href='medical/edit/"+ btoa(data) +"'>" + data + "</a>";
                    else return row.REG_NO;
                },
            },
            {
                data: "MTRL_CODE",
                name: "MTRL_CODE",
            },
            {
                data: "ASSET_NO",
                name: "ASSET_NO",
            },
            {
                data: "INSTR_NAME",
                name: "INSTR_NAME",
            },
            {
                data: "INSTR_BRAND",
                name: "INSTR_BRAND",
            },
            {
                data: "PURCHASE_DATE",
                name: "purchase_date",
                searchable: false,
            },
            {
                data: "SUBMIT_DATE",
                name: "submit_date",
                searchable: false,
            },
            {
                data: "LOCATION_NAME",
                name: "LOCATION_NAME",
            },
            {
                data: "BUSINESS_UNIT",
                name: "BUSINESS_UNIT",
            },
            {
                data: "CALIBRATE_DATE",
                name: "calibrate_date",
                searchable: false,
            },
            {
                data: "Status",
                name: "Status",
            },
            {
                data: "CRITERIA",
                name: "CRITERIA",
            },
            {
                data: "QTY",
                name: "QTY",
            },
            {
                data: "REMARKS",
                name: "REMARKS",
            },
            {
                data: "MODIFY_NAME",
                name: "MODIFY_NAME",
            },
            {
                data: "MODIFY_DATE",
                name: "modify_date",
                searchable: false,
            },
        ],
    });

    $('#cmmedical thead tr').clone(true).appendTo( '#cmmedical thead' );
   $('#cmmedical thead tr:eq(1) th').each( function (i) {
       var title = $(this).text();
       if(title === "Last Modified Date"){
        $(this).html( '<input type="date" class="input-sm lastmo" placeholder="Search '+title+'" />' );
       }
       else if (title === "No"){
           $(this).html( '<input type="text" class="input-sm no" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Regist Number"){
           $(this).html( '<input type="text" class="input-sm rn" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Material Code"){
           $(this).html( '<input type="text" class="input-sm mc" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Assets No"){
           $(this).html( '<input type="text" class="input-sm ass" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Medical Kits Name"){
           $(this).html( '<input type="text" class="input-sm insn" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Medical Kits Code"){
           $(this).html( '<input type="text" class="input-sm insb" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Purchase Date"){
           $(this).html( '<input type="date" class="input-sm pd" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Submit Date"){
           $(this).html( '<input type="date" class="input-sm sd" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Location Name"){
           $(this).html( '<input type="text" class="input-sm ln" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Business Unit"){
           $(this).html( '<input type="text" class="input-sm bu" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Calibrate Date"){
           $(this).html( '<input type="date" class="input-sm cd" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Status"){
           $(this).html( '<input type="text" class="input-sm sta" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Criteria"){
           $(this).html( '<input type="text" class="input-sm crit" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Quantity"){
           $(this).html( '<input type="text" class="input-sm ques" placeholder="Search ' + title + '" />' );
       }
       else if (title === "Remarks"){
           $(this).html( '<input type="text" class="input-sm rmrks" placeholder="Search ' + title + '" />' );
       }
       else if(title === "Last Modified Name"){
       $(this).html( '<input type="text" class="input-sm modifiedn" placeholder="Search '+title+'" />' );
       }
       else{
        $(this).html( '<input type="text" class="input-sm" placeholder="Search '+title+'" />' );

       }
       $( 'input', this ).on( 'keyup change', function () {
           if ( tablemedical.column(i).search() !== this.value ) {
            tablemedical
                   .column(i)
                   .search( this.value )
                   .draw();
                   
                   var rn = $('.rn').val();
                   var mc = $('.mc').val();
                   var ass = $('.ass').val();
                   var insn = $('.insn').val();
                   var insb = $('.insb').val();
                   var pd = $('.pd').val();
                   var sd = $('.sd').val();
                   var ln = $('.ln').val();
                   var bu = $('.bu').val();
                   var cd = $('.cd').val();
                   var sta = $('.sta').val();
                   var crit = $('.crit').val();
                   var ques = $('.ques').val();
                   var rmrks = $('.rmrks').val();
                   var lastmo = $('.lastmo').val();
                   var modifiedn = $('.modifiedn').val();
                   var no = $('.no').val();

                   $('#regist').val(rn);
                   $('#material').val(mc);
                   $('#assets').val(ass);
                   $('#instrname').val(insn);
                   $('#instrbrand').val(insb);
                   $('#purchdate').val(pd);
                   $('#submitdate').val(sd);
                   $('#locatname').val(ln);
                   $('#busunit').val(bu);
                   $('#caldate').val(cd);
                   $('#status').val(sta);
                   $('#criteria').val(crit);
                   $('#question').val(ques);
                   $('#remarks').val(rmrks);
                   $('#lm').val(lastmo);
                   $('#modifiedn').val(modifiedn);
                   $('#no').val(no);
           }
       });
    });
    $('input[type="search"]').on( 'keyup change', function () {
        $('#search').val($('input[type="search"]').val());
    });

    tablemedical.columns().every(function (index) {
     $('#cmmedical thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
        tablemedical.column($(this).parent().index() + ':visible')
             .search(this.value)
             .draw();
        });
    });
    
    var tablesubpersonal = $("#cmsubpersonal").DataTable({
        pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
        processing: true,
        serverSide: true,
        dom: '<lf<t><r>ip>',
        columnDefs: [
            { "width": "5%", "targets": [0,4,5] }
        ],
        ajax: {
            url: '{{ url("ajaxsubpersonel") }}',
            type: "GET",
            data: function (d) {
                d.date = $('.date').val(),
                d.search = $('input[type="search"]').val()
            },
        },
        columns: [
            {
                data: "no",
                name: "no",
            },
            {
                data: "action",
                name: "SUBPERSONELCODE",
                render:function(data, type, row){
                    if(data != null) return "<a href='subpersonel/edit/"+ data.link +"'>" + data.data + "</a>";
                    else return row.SUBPERSONELCODE;
                },
            },
            {
                data: "SUBPERSONELNAME",
                name: "SUBPERSONELNAME",
            },
            {
                data: "PERSONELNAME",
                name: "PERSONELNAME",
            },
            {
                data: "STATUS",
                name: "STATUS",
            },
            {
                data: "MODIFY_NAME",
                name: "MODIFY_NAME",
            },
            {
                data: "MODIFY_DATE",
                name: "modify_date",
                searchable: false,
            },
        ],
    });

    $('#cmsubpersonal thead tr').clone(true).appendTo( '#cmsubpersonal thead' );
   $('#cmsubpersonal thead tr:eq(1) th').each( function (i) {
        var title = $(this).text();

        if(title === "Last Modified Date"){
        $(this).html( '<input type="date" class="input-sm date" placeholder="Search '+title+'" />' );
        }
        else if (title === "No"){
            $(this).html( '<input type="text" class="input-sm no" placeholder="Search ' + title + '" />' );
        }
        else if (title === "Sub Personnel Code"){
            $(this).html( '<input type="text" class="input-sm subcode" placeholder="Search ' + title + '" />' );
        }
        else if (title === "Sub Personnel Name"){
            $(this).html( '<input type="text" class="input-sm subname" placeholder="Search ' + title + '" />' );
        }
        else if (title === "Personnel Area Name"){
            $(this).html( '<input type="text" class="input-sm persname" placeholder="Search ' + title + '" />' );
        }
        else if (title === "Status"){
            $(this).html( '<input type="text" class="input-sm status" placeholder="Search ' + title + '" />' );
        }
        else if(title === "Last Modified Name"){
        $(this).html( '<input type="text" class="input-sm modifiedn" placeholder="Search '+title+'" />' );
        }

       $( 'input', this ).on( 'keyup change', function () {
           if ( tablesubpersonal.column(i).search() !== this.value ) {
            tablesubpersonal
                   .column(i)
                   .search( this.value )
                   .draw();
                   

                     
                   var subcode = $('.subcode').val();
                   var subname = $('.subname').val();
                   var persname = $('.persname').val();
                   var date = $('.date').val();
                   var status = $('.status').val();
                   var modifiedn = $('.modifiedn').val();
                   var no = $('.no').val();

                   $('#sc').val(subcode);
                   $('#sn').val(subname);
                   $('#pn').val(persname);
                   $('#lm').val(date);
                   $('#st').val(status);
                   $('#modifiedn').val(modifiedn);
                   $('#no').val(no);
           }
       });
    $('input[type="search"]').on( 'keyup change', function () {
        $('#search').val($('input[type="search"]').val());
    });
    });

    tablesubpersonal.columns().every(function (index) {
     $('#cmsubpersonal thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
        tablesubpersonal.column($(this).parent().index() + ':visible')
             .search(this.value)
             .draw();
        });
    });

    var tablepersonal = $("#cmpersonal").DataTable({
        pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
        processing: true,
        serverSide: true,
        dom: '<lf<t><r>ip>',
        columnDefs: [
            { "width": "5%", "targets": [0,4,5] }
        ],
        ajax: {
            url: '{{ url("ajaxpersonel") }}',
            type: "GET",
            data: function (d) {
                d.date = $('.lastmo').val(),
                d.search = $('input[type="search"]').val()
            },
        },
        columns: [
            {
                data: "no",
                name: "no",
            },
            {
                data: "action",
                name: "action",
                render:function(data, type, row){
                    if(data != null) return "<a href='personel/edit/"+ btoa(data) +"'>" + data + "</a>";
                    else return row.PERSONELCODE;
                },
            },
            {
                data: "PERSONELNAME",
                name: "PERSONELNAME",
            },
            {
                data: "STATUS",
                name: "STATUS",
            },
            {
                data: "MODIFY_NAME",
                name: "MODIFY_NAME",
            },
            {
                data: "MODIFY_DATE",
                name: "modify_date",
                searchable: false,
            },
        ],
    });

    $('#cmpersonal thead tr').clone(true).appendTo( '#cmpersonal thead' );
   $('#cmpersonal thead tr:eq(1) th').each( function (i) {
       var title = $(this).text();
       if(title === "Last Modified Date"){
        $(this).html( '<input type="date" class="input-sm lastmo" placeholder="Search '+title+'" />' );
       }
        else if (title === "No"){
            $(this).html( '<input type="text" class="input-sm no" placeholder="Search ' + title + '" />' );
        }
        else if (title === "Personnel Area Code"){
            $(this).html( '<input type="text" class="input-sm perscode" placeholder="Search ' + title + '" />' );
        }
        else if (title === "Personnel Area Name"){
            $(this).html( '<input type="text" class="input-sm persname" placeholder="Search ' + title + '" />' );
        }
        else if (title === "Status"){
            $(this).html( '<input type="text" class="input-sm status" placeholder="Search ' + title + '" />' );
        }
        else if(title === "Last Modified Name"){
        $(this).html( '<input type="text" class="input-sm modifiedn" placeholder="Search '+title+'" />' );
        }
       else{
        $(this).html( '<input type="text" class="input-sm" placeholder="Search '+title+'" />' );

       }
       $( 'input', this ).on( 'keyup change', function () {
           if ( tablepersonal.column(i).search() !== this.value ) {
            tablepersonal
                   .column(i)
                   .search( this.value )
                   .draw();
                     
                     var perscode = $('.perscode').val();
                     var persname = $('.persname').val();
                     var lastmo = $('.lastmo').val();
                     var status = $('.status').val();
                     var modifiedn = $('.modifiedn').val();
                     var no = $('.no').val();
  
                     $('#pc').val(perscode);
                     $('#pn').val(persname);
                     $('#lm').val(lastmo);
                     $('#st').val(status);
                     $('#modifiedn').val(modifiedn);
                     $('#no').val(no);
           }
       });
    $('input[type="search"]').on( 'keyup change', function () {
        $('#search').val($('input[type="search"]').val());
    });
    });

    tablepersonal.columns().every(function (index) {
     $('#cmpersonal thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
        tablepersonal.column($(this).parent().index() + ':visible')
             .search(this.value)
             .draw();
        });
    });

    var tableusracc = $("#cmuseracc").DataTable({
        pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
        processing: true,
        serverSide: true,
        dom: '<lf<t><r>ip>',
        ajax: {
            url: '{{ url("ajaxuseracc") }}',
            type: "GET",
        },
        columns: [
            {
                data: "no",
                name: "no",
            },
            {
                data: "action",
                name: "action",
            },
            {
                data: "VMENUCODE",
                name: "VMENUCODE",
            },
            {
                data: "BUSRADD",
                name: "BUSRADD",
            },
            {
                data: "BUSREDIT",
                name: "BUSREDIT",
            },
            {
                data: "BUSRDEL",
                name: "BUSRDEL",
            },
            {
                data: "BUSRPRINT",
                name: "BUSRPRINT",
            },
            {
                data: "BUSRPOST",
                name: "BUSRPOST",
            },
            {
                data: "MODIFY_DATE",
                name: "MODIFY_DATE",
            },
        ],
    });
    tableusracc.on( 'draw.dt', function () {
        var PageInfo = $('#cmuseracc').DataTable().page.info();
        tableusracc.column(0, { page: 'current' }).nodes().each( function (cell, i) {
                cell.innerHTML = i + 1 + PageInfo.start;
            });
        });
   
    $('#cmuseracc thead tr').clone(true).appendTo( '#cmuseracc thead' );
   $('#cmuseracc thead tr:eq(1) th').each( function (i) {
       var title = $(this).text();
       if(title === "Last Modified Date"){

        $(this).html( '<input type="date" class="input-sm" placeholder="Search '+title+'" />' );

       }
       else{
        $(this).html( '<input type="text" class="input-sm" placeholder="Search '+title+'" />' );

       }
       $( 'input', this ).on( 'keyup change', function () {
           if ( tableusracc.column(i).search() !== this.value ) {
            tableusracc
                   .column(i)
                   .search( this.value )
                   .draw();
           }
       });
    });

    tableusracc.columns().every(function (index) {
     $('#cmuseracc thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
        tableusracc.column($(this).parent().index() + ':visible')
             .search(this.value)
             .draw();
        });
    });

    var tablelog = $("#cmuserlogs").DataTable({
        pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
        processing: true,
        serverSide: true,
        dom: '<lf<t><r>ip>',
        ajax: {
            url: '{{ url("ajaxuserlog") }}',
            type: "GET",
        },
        columns: [
            {
                data: "no",
                name: "no",
            },
            {
                data: "action",
                name: "action",
            },
            {
                data: "VUSRID",
                name: "VUSRID",
            },
            {
                data: "BUSRLOCK",
                name: "BUSRLOCK",
            },
            {
                data: "MODIFY_DATE",
                name: "MODIFY_DATE",
            },
            {
                data: "BACTIVE",
                name: "BACTIVE",
            },
        ],
    });
    tablelog.on( 'draw.dt', function () {
        var PageInfo = $('#cmuserlogs').DataTable().page.info();
        tablelog.column(0, { page: 'current' }).nodes().each( function (cell, i) {
                cell.innerHTML = i + 1 + PageInfo.start;
            });
        });
   
    $('#cmuserlogs thead tr').clone(true).appendTo( '#cmuserlogs thead' );
   $('#cmuserlogs thead tr:eq(1) th').each( function (i) {
       var title = $(this).text();
       if(title === "Last Modified Date"){

        $(this).html( '<input type="date" class="input-sm" placeholder="Search '+title+'" />' );

       }
       else{
        $(this).html( '<input type="text" class="input-sm" placeholder="Search '+title+'" />' );

       }
       $( 'input', this ).on( 'keyup change', function () {
           if ( tablelog.column(i).search() !== this.value ) {
            tablelog
                   .column(i)
                   .search( this.value )
                   .draw();
           }
       });
    });

    tablelog.columns().every(function (index) {
     $('#cmuserlogs thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
        tablelog.column($(this).parent().index() + ':visible')
             .search(this.value)
             .draw();
        });
    });

    var tablepackageslist = $("#cmpacklist").DataTable({
        pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
        processing: true,
        serverSide: true,
        dom: '<lf<t><r>ip>',
        columnDefs: [
            { "width": "5%", "targets": 0 }
        ],
        ajax: {
            url: '/ajaxpackageslist',
            type: "GET",
        },
        bAutoWidth: false, 
        columns: [
            {
                data: "no",
                name: "no",
            },
            {
                data: "action",
                name: "action",
            },
            {
                data: "VCHCKCODE",
                name: "VCHCKCODE",
            },
            {
                data: "MODIFY_DATE",
                name: "MODIFY_DATE",
            },
            {
                data: "BACTIVE",
                name: "BACTIVE",
            },
        ],
    });
    tablepackageslist.on( 'draw.dt', function () {
        var PageInfo = $('#cmpacklist').DataTable().page.info();
            tablepackageslist.column(0, { page: 'current' }).nodes().each( function (cell, i) {
                cell.innerHTML = i + 1 + PageInfo.start;
            });
        });
    $('#cmpacklist thead tr').clone(true).appendTo( '#cmpacklist thead' );
   $('#cmpacklist thead tr:eq(1) th').each( function (i) {
       var title = $(this).text();
       if(title === "Last Modified Date"){

        $(this).html( '<input type="date" class="input-sm" placeholder="Search '+title+'" />' );

       }
       else{
        $(this).html( '<input type="text" class="input-sm" placeholder="Search '+title+'" />' );

       }
       $( 'input', this ).on( 'keyup change', function () {
           if ( tablepackageslist.column(i).search() !== this.value ) {
            tablepackageslist
                   .column(i)
                   .search( this.value )
                   .draw();
           }
       });
    });

    var tablechecklist = $("#cmchcklist").DataTable({
        pagingType: $(window).width() < 768 ? "simple" : "simple_numbers",
        processing: true,
        serverSide: true,
        dom: '<lf<t><r>ip>',
        ajax: {
            url: '/ajaxchecklist',
            type: "GET",
        },
        bAutoWidth: false, 
        columns: [
            {
                data: "no",
                name: "no",
            },
            {
                data: "action",
                name: "action",
            },
            {
                data: "VCHCKCODE",
                name: "VCHCKCODE",
            },
            {
                data: "DMODI",
                name: "DMODI",
            },
            {
                data: "BACTIVE",
                name: "BACTIVE",
            },
        ],
    });
    tablechecklist.on( 'draw.dt', function () {
        var PageInfo = $('#cmchcklist').DataTable().page.info();
        tablechecklist.column(0, { page: 'current' }).nodes().each( function (cell, i) {
                cell.innerHTML = i + 1 + PageInfo.start;
            } );
    });
    $('#cmchcklist thead tr').clone(true).appendTo( '#cmchcklist thead' );
   $('#cmchcklist thead tr:eq(1) th').each( function (i) {
       var title = $(this).text();
       if(title === "Last Modified Date"){

        $(this).html( '<input type="date" placeholder="Search '+title+'" />' );

       }
       else{
        $(this).html( '<input type="text" placeholder="Search '+title+'" />' );

       }
       $( 'input', this ).on( 'keyup change', function () {
           if ( tablechecklist.column(i).search() !== this.value ) {
            tablechecklist
                   .column(i)
                   .search( this.value )
                   .draw();
           }
       });
    });
	
	var tableresultmcu = $("#cmresultmcu").DataTable({
        processing: true,
        serverSide: true,
        dom: '<lf<t><r>ip>',
        columnDefs: [
            { "width": "5%", "targets": 0 }
        ],
        ajax:{
               url: '/ajaxresultmcu',
               type: "GET",
			   data: function (d) {
					d.verifiedDate = $('input.verifiedDate').val(),
					d.completedDate = $('input.completedDate').val(),
					d.resultDate = $('input.resultDate').val(),
					d.search = $('input[type="search"]').val()
				}
            },
        columns: [
            {
                data: "no",
                name: "no"
            },
            {
                data: "VREGNO",
                name: "VREGNO",
				render: function (data, type, row) {
                    <?php if(!App\Http\Controllers\Controller::check_role("ADM") && !App\Http\Controllers\Controller::check_role("ANALYST") && !App\Http\Controllers\Controller::check_role("PRMDC") && !App\Http\Controllers\Controller::check_role("DCTR")) { ?>
						if (row.RESULT == '0') {
							return "<a href='' onclick=\"alert('no result yet'); return false\">" + data + "</a>"
						} else {
					<?php } ?>
							return "<a href='resultmcu/form/"+ btoa(data) +"'>" + data + "</a>"
					<?php if(!App\Http\Controllers\Controller::check_role("ADM") && !App\Http\Controllers\Controller::check_role("ANALYST") && !App\Http\Controllers\Controller::check_role("PRMDC") && !App\Http\Controllers\Controller::check_role("DCTR")) { ?>
						}
					<?php } ?>
				}
            },
            {
                data: "VIDNO",
                name: "VIDNO"
            },
            {
                data: "EMPNAME",
                name: "EMPNAME"
            },
            {
                data: "DEPARTMENT",
                name: "DEPARTMENT"
            },
			{
				data: "DVERIFIED",
				name: "DVERIFIED",
				searchable: false
			},
            {
                data: "DCOMPLETED",
                name: "DCOMPLETED",
				searchable: false
            },
            {
                data: "DRESULT",
                name: "DRESULT",
				searchable: false
            }
           ]
        });
		
		$('#cmresultmcu thead tr').clone(true).appendTo( '#cmresultmcu thead' );
		
		$('#cmresultmcu thead tr:eq(1) th').each( function (i) {
			var title = $(this).text();
			if (title.indexOf('Date') != -1) {
				$(this).html( '<input type="date" class="input-sm ' + title.toLowerCase().replace(" ", "_").replace(".", "") + '" placeholder="Search '+title+'" />' );
			} else {
				$(this).html( '<input type="text" class="input-sm ' + title.toLowerCase().replace(" ", "_").replace(".", "") + '" placeholder="Search '+title+'" />' );
			}
			$( 'input', this ).on( 'keyup change', function () {
				if ( tableresultmcu.column(i).search() !== this.value ) {
					tableresultmcu
						.column(i)
						.search( this.value )
                        .draw();
                    $('input[name="' + $(this).attr('class').replace('input-sm ', '') + '"]').val($('.' + $(this).attr('class').replace('input-sm ', '')).val());
				}
			});
        });
        
		tableresultmcu.columns().every(function (index) {
			$('#cmresultmcu thead tr:eq(1) th:eq(' + index + ') input').on('keyup change', function () {
				tableresultmcu.column($(this).parent().index() + ':visible')
					.search(this.value)
					.draw();
			});
		});
		
		
		$('input[type="search"]').on( 'keyup change', function () {
			$('#search').val($('input[type="search"]').val());
        });
        
    $('.dataTable').wrap('<div class="table-responsive" />');

});


function deleteform(elem) {
    var id = $(elem).data("id");
  
    var url = $(elem).data("url");
    swal.fire({
        text: "Do you want to delete the data?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
    }).then(function (result) {
        if (result.value) {
            // handle confirm
            $.ajax({
                url: url + id,
                type: "GET",
                dataType: "JSON",
                success: function (data) {
                    Swal.fire({
                        icon: "success",
                        title: "SUCCESS !!",
                        text: "Delete Success!",
                    });
                    location.reload();
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    alert("Error get data from ajax");
                },
            });
        } else {
            // handle cancel
            location.reload();
        }
    });
}

function mylock(elem) {
    var dataId = $(elem).data("id");
    swal.fire({
        text: "You sure you want to unlock ??",
        icon: "warning",
        showCancelButton: true,
        showLoaderOnConfirm: true,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        preConfirm: function () {
            return new Promise(function (resolve, reject) {
                // here should be AJAX request
                setTimeout(function () {
                    resolve();
                }, 1000);
            });
        },
    }).then(function (result) {
        if (result.value) {
            $.ajax({
                url: "/users/update-lock",
                type: "POST",
                headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
                dataType: "JSON",
				data: { "id": dataId },
				success: function (data) {
                    Swal.fire({
                        icon: "success",
                        title: "SUCCESS",
                        text: "Success, the account has been unlocked!",
                    });
                    location.reload();
                },
            });
            // handle confirm
        } else {
            // handle cancel

            location.reload();
        }
    });
}
function kick(elem) {
    var dataId = $(elem).data("id");
    swal.fire({
        text: "You sure you want to kick this user?",
        icon: "warning",
        showCancelButton: true,
        showLoaderOnConfirm: true,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        preConfirm: function () {
            return new Promise(function (resolve, reject) {
                // here should be AJAX request
                setTimeout(function () {
                    resolve();
                }, 1000);
            });
        },
    }).then(function (result) {
        if (result.value) {
            $.ajax({
                url: "/users/kick-user",
                type: "POST",
                headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
                dataType: "JSON",
				data: { "id": dataId },
				success: function (data) {
                    Swal.fire({
                        icon: "success",
                        title: "SUCCESS",
                        text: "Success, this user has been kicked!",
                    });
                    location.reload();
                },
            });
            // handle confirm
        } else {
            // handle cancel

            location.reload();
        }
    });
}
$(document).on("submit", "[id^=form-confirm]", function (e) {
    swal.fire({
        html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
        allowOutsideClick: false,
        showCancelButton: false,
        showConfirmButton: false,
    });
	e.preventDefault();
    var prop = {
		url: $(this).data("url"),
		type: "POST",
		headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
		dataType: "JSON",
		success: function (data) {
            if (data.response != null) {
                Swal.fire({
                    title: data.response.msg
                })
                .then((result) =>{

                    if (window.location.href.indexOf('/account/myprofile') !== -1 || window.location.href.indexOf('/account/permissionsetting') !== -1 ||window.location.href.indexOf('/account/booking/patientinfo') !== -1)
                    {
                        location.reload();
                    }
                    else
                    {
                        if (window.history.length > 1) window.history.back();
                        else window.location.href = document.referrer;
                    }
                })
            }
            else{
                if (window.location.href.indexOf('/account/myprofile') !== -1 || window.location.href.indexOf('/account/permissionsetting') !== -1 || window.location.href.indexOf('/account/mcu/form') !== -1)
                {
					if (window.location.href.indexOf('/account/mcu/form') !== -1) {
						if (data.url != null) {
							window.location.href = window.location.href + '/' + data.url + '/second';
						} else {
							var wlh = window.location.href;
							window.location.href = wlh.substring(0, wlh.indexOf(wlh.split('/')[wlh.split('/').length - 3]) - 1);
						}
					} else {
						location.reload();
					}
                }
                else
                {
                    if (window.history.length > 1) window.history.back();
                    else window.location.href = document.referrer;
                }
            }
		},
		error: function (data, errormessage) {
			//do something else
            swal.close();
            if (data.responseJSON != null && typeof data.responseJSON.error !== 'undefined') swal.fire("", data.responseJSON.error, errormessage.responseJSON);
            else if (data.responseJSON.eror != null && Object.values(data.responseJSON.eror).every(key => key.every(value => value.includes("required")))) swal.fire("", "Please fill all required field(s)", errormessage.responseJSON);
            else if (data.responseJSON.errors != null && Object.values(data.responseJSON.errors).every(key => key.every(value => value.includes("required")))) swal.fire("", "Please fill all required field(s)", errormessage.responseJSON);
            else swal.fire("",'Data Already Exist!', errormessage.responseJSON);
		},
	};
	var formData = false;
	if ($(this).find('input[type="file"]').length > 0) {
		$.each($(this).find('input[type="file"]'), function( index, value ) {
			if ($(value).prop('files')[0] !== undefined) {
				if (formData === false) {
					formData = new FormData($("#form-confirm")[0]);
					prop.contentType = false;
					prop.processData = false;
				}
				formData.append('files[]', $(value).prop('files')[0]);
			}
		});
	}
    prop.data = formData ? formData : $("#form-confirm").serialize();
    $.ajax(prop);
    return false;
});
$(document).on("submit", "[id^=form-edit]", function (e) {
    var url = $(this).data("url");
    e.preventDefault();
    var prop = {
            url: url,
            type: "POST",
            headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
            dataType: "JSON",
            data: $("#form-edit").serialize(),
            success: function (data) {
                window.history.back();
            },
            error: function(data, errormessage)
            {
                if (data.responseJSON != null && typeof data.responseJSON.error !== 'undefined') swal.fire("", data.responseJSON.error, errormessage.responseJSON);
                else if (data.responseJSON.eror != null && Object.values(data.responseJSON.eror).every(key => key.every(value => value.includes("required")))) swal.fire("", "Please fill all required field(s)", errormessage.responseJSON);
                else if (data.responseJSON.errors != null && Object.values(data.responseJSON.errors).every(key => key.every(value => value.includes("required")))) swal.fire("", "Please fill all required field(s)", errormessage.responseJSON);
                else swal.fire("",'Data Already Exist!', errormessage.responseJSON);
            }
        };
	var formData = false;
	if ($(this).find('input[type="file"]').length > 0) {
		$.each($(this).find('input[type="file"]'), function( index, value ) {
			if ($(value).prop('files')[0] !== undefined) {
				if (formData === false) {
					formData = new FormData($("#form-edit")[0]);
					prop.contentType = false;
					prop.processData = false;
				}
				formData.append('files[]', $(value).prop('files')[0]);
			}
		});
	}
    prop.data = formData ? formData : $("#form-edit").serialize();
    $.ajax(prop);
    return false;
});
$(document).on("submit", "[id^=form-password-register]", function (e) {
    e.preventDefault();
    swal.fire({
        text: "Do you want Change Password ??",
        icon: "warning",
        showCancelButton: true,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        showLoaderOnConfirm: true,
        preConfirm: function () {
            return new Promise(function (resolve, reject) {
                // here should be AJAX request
                setTimeout(function () {
                    resolve();
                }, 1000);
            });
        },
    }).then(function (result) {
        if (result.value) {
            // handle confirm
            $.ajax({
                url: "/users/update-password",
                type: "POST",
                headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
                dataType: "JSON",
                data: $("#form-password-register").serialize(),
                success: function (data) {
                    Swal.fire({
                        icon: "success",
                        title: "SUCCESS",
                        text: "Data berhasil masuk!",
                    });
                    location.reload();
                },
                error: function (error) {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Error, Data tidak ke save!",
                    });
                },
            });
        } else {
            // handle cancel
            location.reload();
        }
    });
    return false;
    
});
$('.deletebooking').click(function(){
var formData = {
  'id_mhs': $(this).attr('value')
};
console.log(formData);
$.ajax({
      type: 'POST',
      url: '',
      data: formData,
      dataType: 'json',
      encode: true
  })
  .done(function(data) {
      console.log(data);
  })
});

</script>
</html>
