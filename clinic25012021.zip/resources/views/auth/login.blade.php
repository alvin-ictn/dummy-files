<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CMS Clinic</title>
      <meta name="csrf-token" content="{{ csrf_token() }}" />
      <!-- Fonts -->
      <!-- <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet"> -->
      <link href="{{ asset('css/app.css') }}" rel="stylesheet">
      <link rel="stylesheet" href="{{ asset('css/all.min.css') }}">
      <script src="{{ asset('js/app.js') }}" defer></script>
      <script src="{{ asset('js/jquery.js') }}"></script>
      <link href="{{ asset('css/adminlte.css') }}" rel="stylesheet">
      <!-- <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet"> -->
      <!-- <link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"> -->
      <link rel="stylesheet" href="{{ asset('css/ionicons.min.css') }}">
      <!-- <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet"> -->
      <style>
         label {
         width: 100%;
         font-size: 1rem;
         }
         .card-input-element+.card {
         height: calc(36px + 2*1rem);
         color: var(--primary);
         -webkit-box-shadow: none;
         box-shadow: none;
         border: 2px solid transparent;
         border-radius: 4px;
         }
         .card-input-element+.card:hover {
         cursor: pointer;
         }
         .card-input-element:checked+.card {
         border: 2px solid var(--primary);
         -webkit-transition: border .3s;
         -o-transition: border .3s;
         transition: border .3s;
         }
         .card-input-element:checked+.card::after {
         content: '\e5ca';
         color: #AFB8EA;
         font-family: 'Material Icons';
         font-size: 24px;
         -webkit-animation-name: fadeInCheckbox;
         animation-name: fadeInCheckbox;
         -webkit-animation-duration: .5s;
         animation-duration: .5s;
         -webkit-animation-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
         animation-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
         }
         @-webkit-keyframes fadeInCheckbox {
         from {
         opacity: 0;
         -webkit-transform: rotateZ(-20deg);
         }
         to {
         opacity: 1;
         -webkit-transform: rotateZ(0deg);
         }
         }
         @keyframes fadeInCheckbox {
         from {
         opacity: 0;
         transform: rotateZ(-20deg);
         }
         to {
         opacity: 1;
         transform: rotateZ(0deg);
         }
		 }
		 


.material-icons {
  font-family: 'Material Icons';
  font-weight: normal;
  font-style: normal;
  font-size: 24px;
  line-height: 1;
  letter-spacing: normal;
  text-transform: none;
  display: inline-block;
  white-space: nowrap;
  word-wrap: normal;
  direction: ltr;
  -webkit-font-feature-settings: 'liga';
  -webkit-font-smoothing: antialiased;
}
         
.card-input-element {
    display: none;
}

.card-input {
    margin: 10px;
    padding: 00px;
}

.card-input:hover {
    cursor: pointer;
}

.card-input-element:checked + .card-input {
     box-shadow: 0 0 1px 1px #2ecc71;
 }
 
      </style>
   </head>
   <body class="hold-transition login-page">
      <div class="login-box rounded">
         <!-- /.login-logo -->
         <div class=" card-color">
            <div id="registrasi"  ></div>
            <div id="loginhide" class="card-body login-card-body">
               <br/>

               <form  method="POST" id="form-login" class="vertical-button" data-url="login" autocomplete="off">
               {{ csrf_field() }}
                  <div class="input-group mb-3">
                     <input id="email" type="text" placeholder="User ID" class="form-control-lg form-control @error('email') is-invalid @enderror" name="username" value="{{ old('email') }}" required>
                     <div class="input-group-append">
                        <div class="input-group-text">
                           <i class="fas fa-user"></i>
                        </div>
                     </div>
                  </div>
                  <div class="input-group mb-3">
                     <input id="password" placeholder="Password" type="password" class="form-control-lg form-control @error('password') is-invalid @enderror" name="password" readonly onfocus="this.removeAttribute('readonly');" style="background:#fff;">
                     <div class="input-group-append">
                        <div class="input-group-text">
                           <i toggle="#password" class="fa fa-eye toggle-password"></i>
                        </div>
                        <div class="input-group-text">
                           <i class="fas fa-lock"></i>
                        </div>
                     </div>
                  </div>
				  <div class="row">
					<div class="col-12 buttom" style="color: white; font-size: 0.55rem; text-align: center;">
						This system is for the use of authorized users only. All activities of the users in this system were regularly monitor by system security administrators. If such monitoring reveals possible evidence of unauthorized use or in excess of the authority or any other security violation or criminal activity, system security administrator may provide evidence such monitoring to the respective superiors and/or law enforcement officials.
					</div>
                  </div>
                  <div class="row">
					<div class="col-12 buttom ade-error-login" style="color: #BE0002; font-size: 15px; visibility: hidden; text-align: center;"><b>error-login</b></div>
                  </div>
                  <div class="row">
                    
                     <div class="col-12 buttom">
                        
                        <button type="submit" class="btn btn-primary btn-lg btn-block">
                        {{ __('LOGIN') }}
                        </button>
                         
                     </div>
                  </div>
                  <div class="row">
                    <div class="col-12">
                    	<div class="float-right">
						  <button class="btn btn-sm btn-primary" type="button" onclick="return toFormForgotPassword();" style="border:none;padding:0;background:none;"><u>Forgot Password</u></button>
                    	</div>
                    </div>
                 </div>
               </form>
			   <!-- <form id="form-forgot" action="/sendemail/forgotpassword" method="POST">
					@csrf
					<input type="hidden" value="test/vincent" name="id" id="id">
				</form> -->
            </div>
            <!-- /.login-card-body -->
         </div>
      </div>
      
	<div class="modal fade" id="modalforgotpassword" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-sm modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-body">
					<label class="text-label">FORGOT PASSWORD</label>
					<form id="form-forgot" action="/sendemail/forgotpassword" method="POST">
						<div class="container">
							{{ csrf_field() }}
							<div class="row">
								<div class='input-group'>
									<input type='text' name='id' id="id" placeholder='User ID' class='form-control'>
								</div>
							</div>
							<br/>
							<div style="text-align:center;">
								<button class="btn-cstm btn-primary btn-sz" type="submit">Send Email</button>
								<!-- <button type="button" id="btn_updatea" class="btn btn-primary" onclick="return toForm(this);">OK</button> -->
								<a href="./login" type="button" class="btn btn-cstm btn-light btn-sz">Close</a>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade" id="modalexpired" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-sm modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-body">
					<label class="text-label"><strong>Expired Date</strong></label>
					<form id="form-expired" method="POST">
						<div class="container">
							<div class="text-center form-group">
 								<span id="expired_alert" style="font-size: 0.65rem;"></span>
							</div>
							<div class="text-center">
								<button class="btn-cstm btn-primary btn-sz" type="button" id="expired_yes">Yes</button>
								<button class="btn-cstm btn-light btn-sz" type="button" id="expired_no">No</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade" id="modalchangepassword" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-sm modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-body">
					<label class="text-label">CHANGE PASSWORD</label>
					<form id="form-chngpwd" method="post" autocomplete="off">
						<input type="hidden" name="email">
						<div class="container">
							{{ csrf_field() }}
							<div class="row">
								<div class='input-group'>
									<input placeholder='New Password' type='password' class='form-control new required' name='chng_new' readonly onfocus="this.removeAttribute('readonly');" style="background:#fff;" required>
									<div class='input-group-append'>
										<div class="input-group-text">
											<i toggle=".new" class="fa fa-eye toggle-password"></i>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12 ade-input-pwd" style="font-size: 0.68rem; visibility: hidden; text-align: center;">
										Password must contain at least {{ $prmchar }} characters, including UPPER/lowercase, symbol, letter and number
									</div>
								</div>
								<div class='input-group'>
									<input placeholder='Re-type New Password' type='password' class='form-control confirm required' name='chng_confirm' readonly onfocus="this.removeAttribute('readonly');" style="background:#fff;" required>
									<div class='input-group-append'>
										<div class="input-group-text">
											<i toggle=".confirm" class="fa fa-eye toggle-password"></i>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-12 ade-input-confirm" style="font-size: 0.68rem; visibility: hidden; text-align: center;">
										The password must be the same!
									</div>
								</div>
								<div class="row">
									<div class="col-12 ade-error-login-modal" style="color: #901515; font-size: 0.98rem; visibility: hidden; text-align: center;">error-login</div>
								</div>
							</div>
							<br/>
							<div style="text-align:center;">
								<button class="btn btn-primary" type="submit">Save</button>
								<a href="./login" type="button" class="btn btn-primary btn-light">Close</a>
								<!-- <button type="button" id="btn_updatea" class="btn btn-primary" onclick="return toForm(this);">OK</button> -->
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade" id="modallogin" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-sm modal-dialog-centered">
			<div class="modal-content">
				<div class="modal-body">
					<label class="text-label first">GROUP USER</label>
					<form id="form-type" method="post" autocomplete="off">
					<input type="hidden" name="id">
					<div class="container">
						<div class="row first">
							<div class="col-6 left-row">
								<div class="form-check">
									<input class="form-check-input" name="typeuser" value="AD" type="radio">
									<label class="form-check-label">AD</label>
								</div>
							</div>
						<div class="col-6">
							<div class="form-check">
								<input class="form-check-input" name="typeuser" value="NAD" type="radio" checked>
								<label class="form-check-label">Non AD</label>
							</div>
						</div>
						</div>
						<div class="row second" style="display: none;">
						<div class='input-group mb-3'>
							<input type='text' class='form-control' name='email' readonly>
							<div class='input-group-append'>
								<div class='input-group-text'>
									<i class='fas fa-user'></i>
								</div>
							</div>
						</div>
						<div class='input-group'>
							<input placeholder='New Password' type='password' class='form-control new required' name='new' readonly onfocus="this.removeAttribute('readonly');" style="background:#fff;" required>
							<div class='input-group-append'>
								<div class="input-group-text">
									<i toggle=".new" class="fa fa-eye toggle-password"></i>
									</div>
								<div class='input-group-text'>
									<i class='fas fa-lock'></i>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-12 ade-input-pwd" style="font-size: 0.68rem; visibility: hidden; text-align: center;">
								Password must contain at least {{ $prmchar }} characters, including UPPER/lowercase, symbol, letter and number
							</div>
						</div>
						<div class='input-group'>
							<input placeholder='Re-type New Password' type='password' class='form-control confirm required' name='confirm' readonly onfocus="this.removeAttribute('readonly');" style="background:#fff;" required>
							<div class='input-group-append'>
								<div class="input-group-text">
									<i toggle=".confirm" class="fa fa-eye toggle-password"></i>
								</div>
								<div class='input-group-text'>
									<i class='fas fa-lock'></i>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-12 ade-input-confirm" style="font-size: 0.68rem; visibility: hidden; text-align: center;">
								The password must be the same!
							</div>
						</div>
						<div class="row">
							<div class="col-12 ade-error-login-modal" style="color: #901515; font-size: 0.98rem; visibility: hidden; text-align: center;">error-login</div>
						</div>
					</div>
					<br/>
					<div style="text-align:center;">
						<button type="button" id="btn_updatea" class="btn btn-primary" onclick="return toForm(this);">Save</button>
						<a href="./login" type="button" class="btn btn-primary btn-light">Close</a>
					</div>
				</div>
			</form>
				
			<form id="form-clinic" method='POST' action='logindoctor' style="display: none;" autocomplete="off">
				<input name='id' type='hidden'>
				<input name='password' type='hidden'>
				{{ csrf_field() }}
				<div class='row'>
					<div class='col-12'>
						<select id="typeclinic" class='form-control' name='typeclinic' required>
							<option value="">-- Select Clinic --</option>
						</select>
					</div>
				</div>
				<br />
					<div style="text-align:center;">
						<button id="btnSetClinic" type='submit' class='btn btn-primary'>Enter</button>
						<a href="./login" type="button" class="btn btn-primary btn-light">Close</a>
					</div>
				<!-- <button id="btnSetClinic" type='submit' class='btn btn-primary btn-block'>Enter</button>
				<a href="./login" type="button" class="btn btn-primary btn-light">Close</a> -->

			</form>
		</div>
	</div>
		
   	</body>
   	<script src="{{ asset('js/adminlte.js') }}" defer></script>
   	<script src="{{ asset('js/demo.js') }}" defer></script>
   	<script src="{{ asset('js/jquery-ui.js') }}" defer></script>
   	<script src="{{ asset('plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
   	<script src="{{ asset('plugins/sweetalert2/sweetalert2.js') }}"></script>
   	<script src="{{ asset('plugins/sweetalert2/sweetalert2_boostrap.js') }}"></script>
 
   	<script src="{{ asset('plugins/datatables/jquery.dataTables.min.js') }}"></script>
   	<script src="{{ asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js') }}"></script>
   	<script src="{{ asset('plugins/datatables-responsive/js/dataTables.responsive.min.js') }}"></script>
   	<script src="{{ asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js') }}"></script>
   	<script>
	 $("#buttonconfirm").hide();
	 $(document).ready(function() {
	 	$(function(){
      		if(window.location.hash) {
				var hash = window.location.hash.split(",");
				//alert(hash[0] + ', ' + hash[1]);
				$(hash[0]).modal('toggle');
				$('[name="email"]').val(atob(hash[1]));
      		}
		  });
	 });

      $(document).on("submit", "[id^=form-login]", function (e) {
       if ($('.ade-input-pw').css('visibility') == 'visible')
	   {
		   return false;
	   }
	   swal.fire({
		   html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
		   allowOutsideClick: false,
		   showCancelButton: false,
		   showConfirmButton: false,
	   });
	   e.preventDefault();
       var url = $(this).data("url");
          $.ajax({
              url: url,
              type: "POST",
              headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
              dataType: "JSON",
              data: $("#form-login").serialize(),
              success: function (data) {
                 if(data.null === "NULL"){
                  $("#modallogin").modal("show");
                  $('[name="id"]').val(data.id);
                 }else if(data.null === "AD"){
                  window.location.href = "account/home";
                 }else if(data.null === "NAD"){
                  window.location.href = "account/home";
                 }else if(data.null === "PW"){
					  $('.ade-error-login').html(data.pesan);
					  $('.ade-error-login').css('visibility', 'visible');
					  if (data.pesan.indexOf('Username') != -1)
					  {
						  $('#email').css('border-color', 'red');
						  $('#password').css('border-color', '');
					  }
					  else if(data.pesan.indexOf('Password') != -1){
						  $('#email').css('border-color', '');
						  $('#password').css('border-color', 'red');
					  }
					  else{
						  $('#email').css('border-color', '');
						  $('#password').css('border-color', '');
					  }
                 }else if(data.null === "cc"){
					  $("#modallogin").modal("show");
					  $("#modallogin .modal-dialog").removeClass('modal-sm').addClass('modal-md');
					  $('.first').css('display', 'none');
					  $('#form-clinic input[name="password"]').val($('#password').val());
					  setClinic(data.data);
                 }else if(data.null === "CP"){
					  toFormChangePassword(data.id);
					  $('#form-type').siblings('label').text('your account password has expired').css('display', 'block');
                 }else if(data.null === "RCP"){
					toExpiredDate();
					$("#expired_alert").html("Your account password will expired soon in " + data.dayleft + " day(s),<br/>do you want to change your password now?");
					$('#expired_yes').on("click", function(){ toFormChangePassword(data.id); $("#modalexpired").modal("hide"); });	// change password now
					$('#expired_no').on("click", function(){ 
						// continue to normal login
						$("#modalexpired").modal("hide");
					  	$("#modallogin").modal("show");
					  	$("#modallogin .modal-dialog").removeClass('modal-sm').addClass('modal-md');
					  	$('.first').css('display', 'none');
					  	$('#form-clinic input[name="password"]').val($('#password').val());
						setClinic(data.data);
					});
					$('#form-type').siblings('label').text('your account password has expired').css('display', 'block');
					//   swal.fire({
					// 	text: "Your account password will expired soon in " + data.dayleft + " day(s),<br/>do you want to change your password now?",
					// 	icon: "warning",
					// 	showCancelButton: true,
					// 	confirmButtonText: "Yes",
					// 	cancelButtonText: "No"
					// }).then(function (result) {
					// 	if (result.value) {
					// 		toFormChangePassword(data.id);
					// 	} else {
					// 		if (data.data) {
					// 			$("#modallogin").modal("show");
					// 			$("#modallogin .modal-dialog").removeClass('modal-sm').addClass('modal-md');
					// 			$('.first').css('display', 'none');
					// 			$('#form-clinic input[name="password"]').val($('#password').val());
					// 			setClinic(data.data);
					// 		} else {
					// 			$.ajax({
					// 			  url: "login",
					// 			  type: "POST",
					// 			  headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
					// 			  data: { "allow": true, "username": data.id, "password": $("#password").val() },
					// 			  success: function () {
					// 				  window.location.href = "account/home";
					// 			  }
					// 			});
					// 		}
					// 	}
					// });
                 }
				 swal.close();
              }
          });
      });
	  
      $(document).on("submit", "[id^=form-forgot]", function (e) {
		  var btn = $(this);
		  e.preventDefault();
		  if (btn.data('isRunning')) return;
		  btn.data('isRunning', true);
		  $.ajax({
			  url: "sendemail/forgotpassword",
			  type: "POST",
			  headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
			  dataType: "JSON",
			  data: $("#form-forgot").serialize(),
			  statusCode: {
            	400: function(data) {
                	Swal.fire(
						'Forgot Password',
						'Invalid User ID!',
						'error'
					);
				},
            	200: function(data) {
                	Swal.fire(
						'Forgot Password',
						'Email successfully sent!',
						'success'
					).then(function()
					{
						location.reload();
					});
				},
			  },
			  complete: function() { btn.data('isRunning', false); }
		  });
	  });

	  $(document).on("submit", "[id^=form-chngpwd]", function (e) {
		  var btn = $(this);
		  e.preventDefault();
		  if (btn.data('isRunning')) return;
		  btn.data('isRunning', true);
		  $.ajax({
			  url: "changepasword/forgotpassword",
			  type: "POST",
			  headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
			  dataType: "JSON",
			  data: $("#form-chngpwd").serialize(),
			  statusCode: {
            	200: function(data) {
					window.location.href = "./";
				},
				400: function(data){
					if(data.responseJSON.null === "cp"){
						Swal.fire(
							'Forgot Password',
							data.responseJSON.msg,
							'error'
						);
					}
				}
       	      },
			  complete: function() { btn.data('isRunning', false); }
		  });
	  });

      $(document).on("submit", "[id^=form-type]", function (e) {
		  var url = $(this).find('.second').css('display') == "none" ? "login/updatetype" : "changepasword";
		  swal.fire({
			  html: "<i class='fa fa-spin fa-spinner fa-3x mr-2'></i> <h6 class='mt-3'>Loading ...</h6>",
			  allowOutsideClick: false,
			  showCancelButton: false,
			  showConfirmButton: false,
		  });
		  e.preventDefault();
		  $.ajax({
			  url: url,
			  type: "POST",
			  headers: { "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content") },
			  dataType: "JSON",
			  data: $("#form-type").serialize(),
			  success: function (data) {
				 if(url === "login/updatetype"){
					Swal.fire(
						'Good job!',
						'Data Save!',
						'success'
					);
					location.reload();
				 }else if(url === "changepasword"){
					if(data.null === "cc"){
						$('#form-type').siblings('label').css('display', 'none');
						$('#form-clinic input[name="password"]').val($('#form-type input[name="new"]').val());
						setClinic(data.data);
					}
					else if(data.null === "cp"){
						$('.ade-error-login-modal').html(data.pesan);
						$('.ade-error-login-modal').css('visibility', 'visible');
					}
					else if(data.null === "NULL"){
						window.location.href = "account/home";
					}
				 }
				 swal.close();
			  }
		  });
	 });
     
      $(document).on("keyup", "[id=password]", function (e) {
		  var t = $(this).val();
		  if (t.length == 0 || (t.length >= <?php echo $prmchar; ?> && t.match(new RegExp('[A-Z]')) && t.match(new RegExp('[a-z]')) && t.match(new RegExp('[0-9]')) && t.match(new RegExp('[!@#$%^&*()]'))))
		  {
			  $('.ade-input-pw').css('visibility', 'hidden');
		  }
		  else
		  {
			  $('.ade-input-pw').css('visibility', 'visible');
		  }
	  });
	  
	  $(".toggle-password").click(function() {
		$(this).toggleClass("fa-eye fa-eye-slash");
		var input = $($(this).attr("toggle"));
		if (input.attr("type") == "password") {
		  input.attr("type", "text");
		} else {
		  input.attr("type", "password");
		}
	  });
	
	function toForm(th) {
		if ($('input[name="typeuser"]:checked').val() == "AD") {
			$(th).removeAttr("onclick").removeAttr("type").attr("type", "submit");
		}
		else {
			$('#form-type input[name="email"]').val($('#email').val());
			$('#form-type input[name="new"]').prop('required',true);
			$('#form-type input[name="confirm"]').prop('required',true);
			$("#modallogin .modal-dialog").removeClass('modal-sm').addClass('modal-md');
			$('.first').css('display', 'none');
			$('.second').css('display', 'block');
			$(th).removeAttr("onclick").removeAttr("type").attr("type", "submit");
			return false;
		}
	}
  
	  $(document).on("keyup", "[name=new], [name=chng_new]", function (e) {
		  var t = $(this).val();
		  if (t.length == 0 || (t.length >= <?php echo $prmchar; ?> && t.match(new RegExp('[A-Z]')) && t.match(new RegExp('[a-z]')) && t.match(new RegExp('[0-9]')) && t.match(new RegExp('[!@#$%^&*()]'))))
		  {
			  $('.ade-input-pwd').css('visibility', 'hidden');
		  }
		  else
		  {
			  $('.ade-input-pwd').css('visibility', 'visible');
		  }
		  if ($('input[name="confirm"]').val().length != 0 || $('input[name="chng_confirm"]').val().length != 0)
		  {
			  if (t == $('input[name="confirm"]').val() || t == $('input[name="chng_confirm"]'))
			  {
				  $('.ade-input-confirm').css('visibility', 'hidden');
			  }
			  else
			  {
				  $('.ade-input-confirm').css('visibility', 'visible');
			  }
		  }
	  });
	  
	  $(document).on("keyup", "[name=confirm], [name=chng_confirm]", function (e) {
		  var t = $(this).val();
		  if (t.length == 0 || $('input[name="new"]').val() == t || $('input[name="chng_new"]').val() == t)
		  {
			  $('.ade-input-confirm').css('visibility', 'hidden');
		  }
		  else
		  {
			  $('.ade-input-confirm').css('visibility', 'visible');
		  }
	  });
	
		function setClinic(data) {
			$.each(data, function( index, value ) {
				$("select").append(new Option(value['VCLINICNAME'], value['VCLINICCODE']));
			});

			$('#form-type').css("display", "none");
			$('#form-clinic input[name="id"]').val($('#email').val());

			if($("#typeclinic option").length == 2)			// if there is only one option
			{
				$("#typeclinic")[0].selectedIndex = 1;		// automatically pick that option
				$("#btnSetClinic").click();
			}
			else $('#form-clinic').css("display", "block");
		}
	
		function toFormChangePassword(id) {
			$("#modallogin").modal("show");
			$('[name="email"]').val(id);
			$("#modallogin .modal-dialog").removeClass('modal-sm').addClass('modal-md');
			$('#btn_updatea').removeAttr("onclick").removeAttr("type").attr("type", "submit");
			$('.first').css('display', 'none');
			$('.second').css('display', 'block');
		}

		function toFormForgotPassword()
		{
			$("#modalforgotpassword").modal("show");
		}
		
		function toExpiredDate()
		{
			$("#modalexpired").modal("show");
		}

		function toFormForgotPasswordChngPwd()
		{
			return false;
			$("#modalchangepassword").modal("show");
		}

   </script>
</html>